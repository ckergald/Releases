"""
 Copyright (c) 2010, 2011, 2012 Popeye

 Permission is hereby granted, free of charge, to any person
 obtaining a copy of this software and associated documentation
 files (the "Software"), to deal in the Software without
 restriction, including without limitation the rights to use,
 copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the
 Software is furnished to do so, subject to the following
 conditions:

 The above copyright notice and this permission notice shall be
 included in all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 OTHER DEALINGS IN THE SOFTWARE.
"""

import urllib
import re
import xbmcaddon
import xbmcgui
import xbmcplugin
import os
import pickle

import cache

__settings__ = xbmcaddon.Addon(id='plugin.video.nzbtv')
__language__ = __settings__.getLocalizedString

USERDATA_PATH = xbmc.translatePath(__settings__.getAddonInfo("profile"))
CACHE_TIME = int(__settings__.getSetting("cache_time"))*60
CACHE = cache.Cache(USERDATA_PATH, CACHE_TIME)

PNEUMATIC = "plugin://plugin.program.pneumatic"

NS_REPORT = "http://www.newzbin.com/DTD/2007/feeds/report/"
NS_NEWZNAB = "http://www.newznab.com/DTD/2010/feeds/attributes/"

MODE_PNEUMATIC_PLAY = "play"
MODE_PNEUMATIC_DOWNLOAD = "download"
MODE_PNEUMATIC_INCOMPLETE = "incomplete"
MODE_PNEUMATIC_LOCAL = "local"
MODE_PNEUMATIC_SAVE_STRM = "save_strm"

MODE_INDEX = "index"
MODE_HIDE = "hide"
MODE_CART = "cart"
MODE_CART_DEL = "cart_del"
MODE_CART_ADD = "cart_add"
MODE_SEARCH = "search"
MODE_SEARCH_RAGEID = "search_rageid"
MODE_SEARCH_IMDB = "search_imdb"
MODE_FAVORITES = "favorites"
MODE_FAVORITES_TOP = "favorites_top"
MODE_FAVORITE_ADD = "favorites_add"
MODE_FAVORITE_DEL = "favorites_del"

MODE_NEWZNAB = "newznab"
MODE_NEWZNAB_SEARCH = "newznab&newznab=search"
MODE_NEWZNAB_SEARCH_RAGEID = "newznab&newznab=search_rageid"
MODE_NEWZNAB_SEARCH_IMDB = "newznab&newznab=search_imdb"
MODE_NEWZNAB_MYCART = "newznab&newznab=mycart"
MODE_NEWZNAB_MYSHOWS = "newznab&newznab=myshows"
MODE_NEWZNAB_MYMOVIES = "newznab&newznab=mymovies"
        
def site_caps(index):
    url = "http://" + __settings__.getSetting("newznab_site_%s" % index) + "/api?t=caps" +\
          "&apikey=" + __settings__.getSetting("newznab_key_%s" % index)
    doc, state = load_xml(url)
    if doc and not state:
        table = []
        for category in doc.getElementsByTagName("category"):
            row = []
            row.append(category.getAttribute("name"))
            row.append(category.getAttribute("id"))
            table.append(row)
            if category.getElementsByTagName("subcat"):
                for subcat in category.getElementsByTagName("subcat"):
                    row = []
                    row.append((" - " + subcat.getAttribute("name")))
                    row.append(subcat.getAttribute("id"))
                    table.append(row)
        return table
    else:
        return None

def newznab(index, params = None):
    newznab_url = ("http://" + __settings__.getSetting("newznab_site_%s" % index) + "/rss?dl=1&num=100&i=" +\
                  __settings__.getSetting("newznab_id_%s" % index) + "&r=" +\
                  __settings__.getSetting("newznab_key_%s" % index))
    newznab_url_search = ("http://" + __settings__.getSetting("newznab_site_%s" % index) +\
                         "/api?dl=1&limit=100&apikey=" + __settings__.getSetting("newznab_key_%s" % index))
    hide_cat = __settings__.getSetting("newznab_hide_cat_%s" % index)
    if params:
        get = params.get
        catid = get("catid")
        newznab_id = get("newznab")
        url = get("url")
        if url:
            url_out = urllib.unquote_plus(url)
        else:
            url_out = None
        get_offset = get("offset")
        if newznab_id:


            if newznab_id == 'Latest Releases':
                add_posts({'title' : 'All',}, index, mode='newznab&newznab=LatestAll')
                add_posts({'title' : 'HD',}, index, mode='newznab&newznab=LatestHD')
                add_posts({'title' : 'SD',}, index, mode='newznab&newznab=LatestSD')
            if newznab_id == 'LatestAll':
                url_out = (newznab_url_search + '&t=tvsearch&cat=5000&extended=1')
            if newznab_id == 'LatestHD':
                url_out = (newznab_url_search + '&t=tvsearch&cat=5040&extended=1')
            if newznab_id == 'LatestSD':
                url_out = (newznab_url_search + '&t=tvsearch&cat=5030&extended=1')
            if newznab_id == 'A and E':
                add_posts({'title' : 'American Hoggers',}, index, mode='newznab&newznab=28984',thumb='http://thetvdb.com/banners/posters/252617-1.jpg')
                add_posts({'title' : 'Barter Kings',}, index, mode='newznab&newznab=31812',thumb='http://thetvdb.com/banners/posters/259497-1.jpg')
                add_posts({'title' : 'Beyond Scared Straight',}, index, mode='newznab&newznab=27203',thumb='http://thetvdb.com/banners/posters/219331-1.jpg')
                add_posts({'title' : 'Billy the Exterminator',}, index, mode='newznab&newznab=21064',thumb='http://thetvdb.com/banners/posters/166101-1.jpg')
                add_posts({'title' : 'Bordertown Laredo',}, index, mode='newznab&newznab=29776',thumb='http://thetvdb.com/banners/posters/252574-1.jpg')
                add_posts({'title' : 'Breakout Kings',}, index, mode='newznab&newznab=24612',thumb='http://thetvdb.com/banners/posters/219341-1.jpg')
                add_posts({'title' : 'Cajun Justice',}, index, mode='newznab&newznab=31802',thumb='http://thetvdb.com/banners/posters/259423-1.jpg')
                add_posts({'title' : 'Canjun Justice',}, index, mode='newznab&newznab=31802',thumb='http://thetvdb.com/banners/posters/259423-1.jpg')
                add_posts({'title' : 'Crime 360',}, index, mode='newznab&newznab=18532',thumb='http://thetvdb.com/banners/posters/81487-1.jpg')
                add_posts({'title' : 'Criss Angel Mindfreak',}, index, mode='newznab&newznab=6718',thumb='http://thetvdb.com/banners/posters/78841-1.jpg')
                add_posts({'title' : 'Dallas SWAT',}, index, mode='newznab&newznab=7042',thumb='http://thetvdb.com/banners/posters/80341-1.jpg')
                add_posts({'title' : 'Detroit SWAT',}, index, mode='newznab&newznab=21140')
                add_posts({'title' : 'Dog The Bounty Hunter',}, index, mode='newznab&newznab=3337',thumb='http://thetvdb.com/banners/posters/75036-1.jpg')
                add_posts({'title' : 'Duck Dynasty',}, index, mode='newznab&newznab=30870',thumb='http://thetvdb.com/banners/posters/256825-1.jpg')
                add_posts({'title' : 'Fliped Off',}, index, mode='newznab&newznab=31096',thumb='http://thetvdb.com/banners/posters/257836-1.jpg')
                add_posts({'title' : 'Flipped Off',}, index, mode='newznab&newznab=31096',thumb='http://thetvdb.com/banners/posters/257836-1.jpg')
                add_posts({'title' : 'Gene Simmons Family Jewels',}, index, mode='newznab&newznab=11051',thumb='http://thetvdb.com/banners/posters/79406-1.jpg')
                add_posts({'title' : 'Gene Simmons Family lewels',}, index, mode='newznab&newznab=11051',thumb='http://thetvdb.com/banners/posters/79406-1.jpg')
                add_posts({'title' : 'Heavy',}, index, mode='newznab&newznab=27210',thumb='http://thetvdb.com/banners/posters/213131-1.jpg')
                add_posts({'title' : 'Hoarders',}, index, mode='newznab&newznab=23511',thumb='http://thetvdb.com/banners/posters/109621-1.jpg')
                add_posts({'title' : 'Intervention',}, index, mode='newznab&newznab=3976',thumb='http://thetvdb.com/banners/posters/75896-1.jpg')
                add_posts({'title' : 'Jacked Auto Theft Task Force',}, index, mode='newznab&newznab=19673')
                add_posts({'title' : 'Kansas City SWAT',}, index, mode='newznab&newznab=21141')
                add_posts({'title' : 'Lady Hoggers',}, index, mode='newznab&newznab=30195',thumb='http://thetvdb.com/banners/posters/253872-1.jpg')
                add_posts({'title' : 'Last Chance Driving School',}, index, mode='newznab&newznab=31376',thumb='http://thetvdb.com/banners/posters/257985-1.jpg')
                add_posts({'title' : 'Longmire',}, index, mode='newznab&newznab=29357',thumb='http://thetvdb.com/banners/posters/253491-1.jpg')
                add_posts({'title' : 'Manhunters Fugitive Task Force',}, index, mode='newznab&newznab=20516',thumb='http://thetvdb.com/banners/posters/84133-1.jpg')
                add_posts({'title' : 'Monster In Laws',}, index, mode='newznab&newznab=29697',thumb='http://thetvdb.com/banners/posters/253055-1.jpg')
                add_posts({'title' : 'Paranormal State',}, index, mode='newznab&newznab=18003',thumb='http://thetvdb.com/banners/posters/81408-1.jpg')
                add_posts({'title' : 'Parking Wars',}, index, mode='newznab&newznab=18064',thumb='http://thetvdb.com/banners/posters/81343-1.jpg')
                add_posts({'title' : 'Psychic Kids Children of the Paranormal',}, index, mode='newznab&newznab=19279',thumb='http://thetvdb.com/banners/posters/82476-1.jpg')
                add_posts({'title' : 'Relapse',}, index, mode='newznab&newznab=27804',thumb='http://thetvdb.com/banners/posters/220401-1.jpg')
                add_posts({'title' : 'Rookies',}, index, mode='newznab&newznab=20289',thumb='http://thetvdb.com/banners/posters/84533-1.jpg')
                add_posts({'title' : 'Runaway Squad',}, index, mode='newznab&newznab=22723')
                add_posts({'title' : 'Shipping Wars',}, index, mode='newznab&newznab=30492',thumb='http://thetvdb.com/banners/posters/254669-1.jpg')
                add_posts({'title' : 'Steven Seagal Lawman',}, index, mode='newznab&newznab=20664',thumb='http://thetvdb.com/banners/posters/126841-1.jpg')
                add_posts({'title' : 'Storage Wars Texas',}, index, mode='newznab&newznab=29364',thumb='http://thetvdb.com/banners/posters/251596-1.jpg')
                add_posts({'title' : 'Storage Wars',}, index, mode='newznab&newznab=26974',thumb='http://thetvdb.com/banners/posters/207621-1.jpg')
                add_posts({'title' : 'The Cleaner',}, index, mode='newznab&newznab=18397',thumb='http://thetvdb.com/banners/posters/82492-1.jpg')
                add_posts({'title' : 'The First 48 Missing Persons',}, index, mode='newznab&newznab=28553',thumb='http://thetvdb.com/banners/posters/249241-1.jpg')
                add_posts({'title' : 'The First 48',}, index, mode='newznab&newznab=2300',thumb='http://thetvdb.com/banners/posters/81275-1.jpg')
                add_posts({'title' : 'The Glades',}, index, mode='newznab&newznab=25608',thumb='http://thetvdb.com/banners/posters/168941-1.jpg')
                add_posts({'title' : 'Those Who Kill',}, index, mode='newznab&newznab=33389',thumb='http://thetvdb.com/banners/posters/235981-1.jpg')
            if newznab_id == 'ABC':
                add_posts({'title' : '101 Ways to Leave a Game Show US',}, index, mode='newznab&newznab=27939',thumb='http://thetvdb.com/banners/posters/249736-1.jpg')
                add_posts({'title' : '666 Park Avenue',}, index, mode='newznab&newznab=30744',thumb='http://thetvdb.com/banners/posters/256204-1.jpg')
                add_posts({'title' : '8 Simple Rules',}, index, mode='newznab&newznab=2464',thumb='http://thetvdb.com/banners/posters/78461-1.jpg')
                add_posts({'title' : 'According To Jim',}, index, mode='newznab&newznab=2481',thumb='http://thetvdb.com/banners/posters/75926-1.jpg')
                add_posts({'title' : 'Adam Hills In Gordon St Tonight',}, index, mode='newznab&newznab=27742',thumb='http://thetvdb.com/banners/posters/230471-1.jpg')
                add_posts({'title' : 'Agony Aunts',}, index, mode='newznab&newznab=31593',thumb='http://thetvdb.com/banners/posters/259113-1.jpg')
                add_posts({'title' : 'Alias Smith And Jones',}, index, mode='newznab&newznab=2538',thumb='http://thetvdb.com/banners/posters/73399-1.jpg')
                add_posts({'title' : 'Alias',}, index, mode='newznab&newznab=2537',thumb='http://thetvdb.com/banners/posters/75930-1.jpg')
                add_posts({'title' : 'Americas Funniest Home Videos',}, index, mode='newznab&newznab=2584',thumb='http://thetvdb.com/banners/posters/76235-1.jpg')
                add_posts({'title' : 'Australian Story',}, index, mode='newznab&newznab=7555',thumb='http://thetvdb.com/banners/posters/90161-1.jpg')
                add_posts({'title' : 'B L Stryker',}, index, mode='newznab&newznab=2689',thumb='http://thetvdb.com/banners/posters/73664-1.jpg')
                add_posts({'title' : 'Bachelor Pad',}, index, mode='newznab&newznab=2029',thumb='http://thetvdb.com/banners/posters/74123-1.jpg')
                add_posts({'title' : 'Ball Boys',}, index, mode='newznab&newznab=31227',thumb='http://thetvdb.com/banners/posters/257524-1.jpg')
                add_posts({'title' : 'Bananas in Pyjamas',}, index, mode='newznab&newznab=2707',thumb='http://thetvdb.com/banners/posters/72638-1.jpg')
                add_posts({'title' : 'Bed Of Roses',}, index, mode='newznab&newznab=18984',thumb='http://thetvdb.com/banners/posters/100321-1.jpg')
                add_posts({'title' : 'Benson',}, index, mode='newznab&newznab=2761',thumb='http://thetvdb.com/banners/posters/78553-1.jpg')
                add_posts({'title' : 'Better Off Ted',}, index, mode='newznab&newznab=19907',thumb='http://thetvdb.com/banners/posters/84021-1.jpg')
                add_posts({'title' : 'Better With You',}, index, mode='newznab&newznab=25745',thumb='http://thetvdb.com/banners/posters/166361-1.jpg')
                add_posts({'title' : 'Bewitched',}, index, mode='newznab&newznab=2779',thumb='http://thetvdb.com/banners/posters/71528-1.jpg')
                add_posts({'title' : 'Blue Water High',}, index, mode='newznab&newznab=2850',thumb='http://thetvdb.com/banners/posters/76110-1.jpg')
                add_posts({'title' : 'Body of Proof',}, index, mode='newznab&newznab=25718',thumb='http://thetvdb.com/banners/posters/167591-1.jpg')
                add_posts({'title' : 'Boston Legal',}, index, mode='newznab&newznab=2882',thumb='http://thetvdb.com/banners/posters/74058-1.jpg')
                add_posts({'title' : 'Boy Meets World',}, index, mode='newznab&newznab=2887',thumb='http://thetvdb.com/banners/posters/71889-1.jpg')
                add_posts({'title' : 'Brothers and Sisters',}, index, mode='newznab&newznab=8090',thumb='http://thetvdb.com/banners/posters/79506-1.jpg')
                add_posts({'title' : 'Buddies',}, index, mode='newznab&newznab=107',thumb='http://thetvdb.com/banners/posters/71250-1.jpg')
                add_posts({'title' : 'Bump in the Night',}, index, mode='newznab&newznab=2937',thumb='http://thetvdb.com/banners/posters/70945-1.jpg')
                add_posts({'title' : 'Bush Mechanics',}, index, mode='newznab&newznab=11926',thumb='http://thetvdb.com/banners/posters/80734-1.jpg')
                add_posts({'title' : 'Castle 2009',}, index, mode='newznab&newznab=19267',thumb='http://thetvdb.com/banners/posters/83462-1.jpg')
                add_posts({'title' : 'Charlies Angels 2011',}, index, mode='newznab&newznab=24634',thumb='http://thetvdb.com/banners/posters/241531-1.jpg')
                add_posts({'title' : 'Columbo',}, index, mode='newznab&newznab=3114',thumb='http://thetvdb.com/banners/posters/70369-1.jpg')
                add_posts({'title' : 'Dancing with the Stars US',}, index, mode='newznab&newznab=3220')
                add_posts({'title' : 'Desperate Housewives',}, index, mode='newznab&newznab=3294',thumb='http://thetvdb.com/banners/posters/73800-1.jpg')
                add_posts({'title' : 'Detroit 1 8 7',}, index, mode='newznab&newznab=25043',thumb='http://thetvdb.com/banners/posters/164221-1.jpg')
                add_posts({'title' : 'Dharma and Greg',}, index, mode='newznab&newznab=3299',thumb='http://thetvdb.com/banners/posters/72406-1.jpg')
                add_posts({'title' : 'Don t Trust The B In Apartment 23',}, index, mode='newznab&newznab=23727',thumb='http://thetvdb.com/banners/posters/248812-1.jpg')
                add_posts({'title' : 'Dont Trust The B In Apartment 23',}, index, mode='newznab&newznab=23727',thumb='http://thetvdb.com/banners/posters/248812-1.jpg')
                add_posts({'title' : 'Doogie Howser M D',}, index, mode='newznab&newznab=3344',thumb='http://thetvdb.com/banners/posters/72203-1.jpg')
                add_posts({'title' : 'Doogie Howser MD',}, index, mode='newznab&newznab=3344',thumb='http://thetvdb.com/banners/posters/72203-1.jpg')
                add_posts({'title' : 'Duets',}, index, mode='newznab&newznab=31302',thumb='http://thetvdb.com/banners/posters/258558-1.jpg')
                add_posts({'title' : 'Eight is Enough',}, index, mode='newznab&newznab=3426',thumb='http://thetvdb.com/banners/posters/77771-1.jpg')
                add_posts({'title' : 'Eli Stone',}, index, mode='newznab&newznab=15727',thumb='http://thetvdb.com/banners/posters/81025-1.jpg')
                add_posts({'title' : 'Empire 2005',}, index, mode='newznab&newznab=3441')
                add_posts({'title' : 'Expedition Impossible',}, index, mode='newznab&newznab=27940',thumb='http://thetvdb.com/banners/posters/248786-1.jpg')
                add_posts({'title' : 'Extreme Makeover Home Edition',}, index, mode='newznab&newznab=3476',thumb='http://thetvdb.com/banners/posters/73444-1.jpg')
                add_posts({'title' : 'Extreme Makeover Weight Loss Edition',}, index, mode='newznab&newznab=26171',thumb='http://thetvdb.com/banners/posters/249085-1.jpg')
                add_posts({'title' : 'Family',}, index, mode='newznab&newznab=15840',thumb='http://thetvdb.com/banners/posters/77477-1.jpg')
                add_posts({'title' : 'Foreign Correspondent',}, index, mode='newznab&newznab=7561',thumb='http://thetvdb.com/banners/posters/165921-1.jpg')
                add_posts({'title' : 'GCB',}, index, mode='newznab&newznab=28393',thumb='http://thetvdb.com/banners/posters/248839-1.jpg')
                add_posts({'title' : 'Greys Anatomy',}, index, mode='newznab&newznab=3741',thumb='http://thetvdb.com/banners/posters/73762-1.jpg')
                add_posts({'title' : 'Growing Pains US',}, index, mode='newznab&newznab=3747')
                add_posts({'title' : 'Happy Days',}, index, mode='newznab&newznab=3785',thumb='http://thetvdb.com/banners/posters/74475-1.jpg')
                add_posts({'title' : 'Happy Endings',}, index, mode='newznab&newznab=25661',thumb='http://thetvdb.com/banners/posters/167571-1.jpg')
                add_posts({'title' : 'Hart To Hart',}, index, mode='newznab&newznab=3799',thumb='http://thetvdb.com/banners/posters/71308-1.jpg')
                add_posts({'title' : 'Heartbreak High',}, index, mode='newznab&newznab=200',thumb='http://thetvdb.com/banners/posters/73979-1.jpg')
                add_posts({'title' : 'Hong Kong Phooey',}, index, mode='newznab&newznab=3894',thumb='http://thetvdb.com/banners/posters/76205-1.jpg')
                add_posts({'title' : 'Hungry Beast',}, index, mode='newznab&newznab=23967',thumb='http://thetvdb.com/banners/posters/116801-1.jpg')
                add_posts({'title' : 'Jamie Olivers Food Revolution',}, index, mode='newznab&newznab=24887',thumb='http://thetvdb.com/banners/posters/151421-1.jpg')
                add_posts({'title' : 'Kaboodle',}, index, mode='newznab&newznab=11616')
                add_posts({'title' : 'Karaoke Battle USA',}, index, mode='newznab&newznab=28411',thumb='http://thetvdb.com/banners/posters/250739-1.jpg')
                add_posts({'title' : 'Kung Fu',}, index, mode='newznab&newznab=4162',thumb='http://thetvdb.com/banners/posters/73069-1.jpg')
                add_posts({'title' : 'Labor In Power',}, index, mode='newznab&newznab=11571')
                add_posts({'title' : 'Land of the Giants',}, index, mode='newznab&newznab=4178',thumb='http://thetvdb.com/banners/posters/77218-1.jpg')
                add_posts({'title' : 'Last Man Standing',}, index, mode='newznab&newznab=28386',thumb='http://thetvdb.com/banners/posters/75670-1.jpg')
                add_posts({'title' : 'Last Resort',}, index, mode='newznab&newznab=30614',thumb='http://thetvdb.com/banners/posters/255413-1.jpg')
                add_posts({'title' : 'Lawman',}, index, mode='newznab&newznab=4207',thumb='http://thetvdb.com/banners/posters/71211-1.jpg')
                add_posts({'title' : 'Leave It To Beaver',}, index, mode='newznab&newznab=4213',thumb='http://thetvdb.com/banners/posters/71575-1.jpg')
                add_posts({'title' : 'Lift Off',}, index, mode='newznab&newznab=11593')
                add_posts({'title' : 'Lost',}, index, mode='newznab&newznab=4284',thumb='http://thetvdb.com/banners/posters/73739-1.jpg')
                add_posts({'title' : 'Lowdown',}, index, mode='newznab&newznab=23973',thumb='http://thetvdb.com/banners/posters/160321-1.jpg')
                add_posts({'title' : 'Malibu Country',}, index, mode='newznab&newznab=30840',thumb='http://thetvdb.com/banners/posters/259059-1.jpg')
                add_posts({'title' : 'Man Up',}, index, mode='newznab&newznab=28395',thumb='http://thetvdb.com/banners/posters/248840-1.jpg')
                add_posts({'title' : 'Marcus Welby MD',}, index, mode='newznab&newznab=8',thumb='http://thetvdb.com/banners/posters/78170-1.jpg')
                add_posts({'title' : 'Matlock',}, index, mode='newznab&newznab=4391',thumb='http://thetvdb.com/banners/posters/73064-1.jpg')
                add_posts({'title' : 'Missing 2012',}, index, mode='newznab&newznab=28396',thumb='http://thetvdb.com/banners/posters/248797-1.jpg')
                add_posts({'title' : 'Modern Family',}, index, mode='newznab&newznab=22622',thumb='http://thetvdb.com/banners/posters/95011-1.jpg')
                add_posts({'title' : 'Mr Sunshine 2011',}, index, mode='newznab&newznab=25048',thumb='http://thetvdb.com/banners/posters/164481-1.jpg')
                add_posts({'title' : 'My Wife And Kids',}, index, mode='newznab&newznab=4610',thumb='http://thetvdb.com/banners/posters/70329-1.jpg')
                add_posts({'title' : 'Nashville 2012',}, index, mode='newznab&newznab=30808')
                add_posts({'title' : 'Night Stalker',}, index, mode='newznab&newznab=4670',thumb='http://thetvdb.com/banners/posters/78952-1.jpg')
                add_posts({'title' : 'No Ordinary Family',}, index, mode='newznab&newznab=25011',thumb='http://thetvdb.com/banners/posters/163851-1.jpg')
                add_posts({'title' : 'Noah And Saskia',}, index, mode='newznab&newznab=7630')
                add_posts({'title' : 'NY Med',}, index, mode='newznab&newznab=31939',thumb='http://thetvdb.com/banners/posters/260317-1.jpg')
                add_posts({'title' : 'NYPD Blue',}, index, mode='newznab&newznab=4698',thumb='http://thetvdb.com/banners/posters/73132-1.jpg')
                add_posts({'title' : 'October Road',}, index, mode='newznab&newznab=8344',thumb='http://thetvdb.com/banners/posters/79934-1.jpg')
                add_posts({'title' : 'Off the Map',}, index, mode='newznab&newznab=24993',thumb='http://thetvdb.com/banners/posters/164371-1.jpg')
                add_posts({'title' : 'Once And Again',}, index, mode='newznab&newznab=4713',thumb='http://thetvdb.com/banners/posters/72012-1.jpg')
                add_posts({'title' : 'Once Upon A Time',}, index, mode='newznab&newznab=28385',thumb='http://thetvdb.com/banners/posters/83882-1.jpg')
                add_posts({'title' : 'Pan Am',}, index, mode='newznab&newznab=28397',thumb='http://thetvdb.com/banners/posters/247361-1.jpg')
                add_posts({'title' : 'Pohs Kitchen',}, index, mode='newznab&newznab=24366',thumb='http://thetvdb.com/banners/posters/145971-1.jpg')
                add_posts({'title' : 'police rescue',}, index, mode='newznab&newznab=195',thumb='http://thetvdb.com/banners/posters/73859-1.jpg')
                add_posts({'title' : 'Private Practice',}, index, mode='newznab&newznab=15576',thumb='http://thetvdb.com/banners/posters/80542-1.jpg')
                add_posts({'title' : 'Pushing Daisies',}, index, mode='newznab&newznab=15716',thumb='http://thetvdb.com/banners/posters/80351-1.jpg')
                add_posts({'title' : 'Revenge',}, index, mode='newznab&newznab=28387',thumb='http://thetvdb.com/banners/posters/248837-1.jpg')
                add_posts({'title' : 'Roseanne',}, index, mode='newznab&newznab=5055',thumb='http://thetvdb.com/banners/posters/77068-1.jpg')
                add_posts({'title' : 'Samantha Who',}, index, mode='newznab&newznab=15713',thumb='http://thetvdb.com/banners/posters/80680-1.jpg')
                add_posts({'title' : 'Scandal',}, index, mode='newznab&newznab=28398',thumb='http://thetvdb.com/banners/posters/105941-1.jpg')
                add_posts({'title' : 'Scoobys All Star Laff A Lympics',}, index, mode='newznab&newznab=5112',thumb='http://thetvdb.com/banners/posters/78328-1.jpg')
                add_posts({'title' : 'Scrubs',}, index, mode='newznab&newznab=5118',thumb='http://thetvdb.com/banners/posters/76156-1.jpg')
                add_posts({'title' : 'Secret Millionaire',}, index, mode='newznab&newznab=19012',thumb='http://thetvdb.com/banners/posters/84146-1.jpg')
                add_posts({'title' : 'Shark Tank',}, index, mode='newznab&newznab=22610',thumb='http://thetvdb.com/banners/posters/100981-1.jpg')
                add_posts({'title' : 'Shaun Micallefs Mad As Hell',}, index, mode='newznab&newznab=30936')
                add_posts({'title' : 'Sledge Hammer',}, index, mode='newznab&newznab=5220',thumb='http://thetvdb.com/banners/posters/79170-1.jpg')
                add_posts({'title' : 'Sleek Geeks',}, index, mode='newznab&newznab=18453')
                add_posts({'title' : 'Spicks and Specks',}, index, mode='newznab&newznab=5292')
                add_posts({'title' : 'Spin City',}, index, mode='newznab&newznab=5301',thumb='http://thetvdb.com/banners/posters/73153-1.jpg')
                add_posts({'title' : 'Suburgatory',}, index, mode='newznab&newznab=28399',thumb='http://thetvdb.com/banners/posters/248842-1.jpg')
                add_posts({'title' : 'Supernanny',}, index, mode='newznab&newznab=5409',thumb='http://thetvdb.com/banners/posters/74850-1.jpg')
                add_posts({'title' : 'Take the Money and Run',}, index, mode='newznab&newznab=27690',thumb='http://thetvdb.com/banners/posters/223861-1.jpg')
                add_posts({'title' : 'Tales Of Tomorrow',}, index, mode='newznab&newznab=5455')
                add_posts({'title' : 'Thats My Mama',}, index, mode='newznab&newznab=55',thumb='http://thetvdb.com/banners/posters/77854-1.jpg')
                add_posts({'title' : 'The Addams Family 1964',}, index, mode='newznab&newznab=5521')
                add_posts({'title' : 'The Bachelor',}, index, mode='newznab&newznab=5593',thumb='http://thetvdb.com/banners/posters/70869-1.jpg')
                add_posts({'title' : 'The Bachelorette',}, index, mode='newznab&newznab=5594',thumb='http://thetvdb.com/banners/posters/71187-1.jpg')
                add_posts({'title' : 'The Big Valley',}, index, mode='newznab&newznab=5622',thumb='http://thetvdb.com/banners/posters/77581-1.jpg')
                add_posts({'title' : 'The Brady Bunch',}, index, mode='newznab&newznab=5643',thumb='http://thetvdb.com/banners/posters/77010-1.jpg')
                add_posts({'title' : 'The Cook And The Chef',}, index, mode='newznab&newznab=17703',thumb='http://thetvdb.com/banners/posters/95921-1.jpg')
                add_posts({'title' : 'The Donna Reed Show',}, index, mode='newznab&newznab=5730',thumb='http://thetvdb.com/banners/posters/77779-1.jpg')
                add_posts({'title' : 'The Flintstones',}, index, mode='newznab&newznab=5785',thumb='http://thetvdb.com/banners/posters/76171-1.jpg')
                add_posts({'title' : 'The Glass House US',}, index, mode='newznab&newznab=31736',thumb='http://thetvdb.com/banners/posters/258795-1.jpg')
                add_posts({'title' : 'The Glass House',}, index, mode='newznab&newznab=5817',thumb='http://thetvdb.com/banners/posters/158761-1.jpg')
                add_posts({'title' : 'The Gruen Transfer',}, index, mode='newznab&newznab=19716')
                add_posts({'title' : 'The Librarians',}, index, mode='newznab&newznab=17863',thumb='http://thetvdb.com/banners/posters/80738-1.jpg')
                add_posts({'title' : 'The Magistrate',}, index, mode='newznab&newznab=11550')
                add_posts({'title' : 'The Micallef Programme',}, index, mode='newznab&newznab=8570')
                add_posts({'title' : 'The Middle',}, index, mode='newznab&newznab=20678',thumb='http://thetvdb.com/banners/posters/95021-1.jpg')
                add_posts({'title' : 'The Neighbors 2012',}, index, mode='newznab&newznab=31677')
                add_posts({'title' : 'The Neighbors',}, index, mode='newznab&newznab=10680',thumb='http://thetvdb.com/banners/posters/259057-1.jpg')
                add_posts({'title' : 'The Outer Limits 1963',}, index, mode='newznab&newznab=6070')
                add_posts({'title' : 'The Practice',}, index, mode='newznab&newznab=6105',thumb='http://thetvdb.com/banners/posters/73226-1.jpg')
                add_posts({'title' : 'The River',}, index, mode='newznab&newznab=28362',thumb='http://thetvdb.com/banners/posters/71723-1.jpg')
                add_posts({'title' : 'The Super',}, index, mode='newznab&newznab=829',thumb='http://thetvdb.com/banners/posters/71572-1.jpg')
                add_posts({'title' : 'The Time Tunnel',}, index, mode='newznab&newznab=6239',thumb='http://thetvdb.com/banners/posters/77268-1.jpg')
                add_posts({'title' : 'The Wonder Years',}, index, mode='newznab&newznab=6302',thumb='http://thetvdb.com/banners/posters/72888-1.jpg')
                add_posts({'title' : 'The Young Riders',}, index, mode='newznab&newznab=6324',thumb='http://thetvdb.com/banners/posters/71589-1.jpg')
                add_posts({'title' : 'Thirtysomething',}, index, mode='newznab&newznab=6331',thumb='http://thetvdb.com/banners/posters/72781-1.jpg')
                add_posts({'title' : 'Top Cat',}, index, mode='newznab&newznab=6383',thumb='http://thetvdb.com/banners/posters/76172-1.jpg')
                add_posts({'title' : 'Trust Us with Your Life',}, index, mode='newznab&newznab=31854',thumb='http://thetvdb.com/banners/posters/258814-1.jpg')
                add_posts({'title' : 'Twisted',}, index, mode='newznab&newznab=11325',thumb='http://thetvdb.com/banners/posters/184081-1.jpg')
                add_posts({'title' : 'Ugly Betty',}, index, mode='newznab&newznab=8089',thumb='http://thetvdb.com/banners/posters/79352-1.jpg')
                add_posts({'title' : 'V 2009',}, index, mode='newznab&newznab=22814',thumb='http://thetvdb.com/banners/posters/94971-1.jpg')
                add_posts({'title' : 'Voyage To The Bottom Of The Sea',}, index, mode='newznab&newznab=6524',thumb='http://thetvdb.com/banners/posters/77301-1.jpg')
                add_posts({'title' : 'Wagon Train',}, index, mode='newznab&newznab=6531',thumb='http://thetvdb.com/banners/posters/76974-1.jpg')
                add_posts({'title' : 'Whats Happening',}, index, mode='newznab&newznab=6566',thumb='http://thetvdb.com/banners/posters/73506-1.jpg')
                add_posts({'title' : 'Wildside AU',}, index, mode='newznab&newznab=18387')
                add_posts({'title' : 'Wipeout US',}, index, mode='newznab&newznab=18959',thumb='http://thetvdb.com/banners/posters/82226-1.jpg')
                add_posts({'title' : 'Work It',}, index, mode='newznab&newznab=28412',thumb='http://thetvdb.com/banners/posters/248843-1.jpg')
                add_posts({'title' : 'You Deserve It',}, index, mode='newznab&newznab=30065',thumb='http://thetvdb.com/banners/posters/253531-1.jpg')
                add_posts({'title' : 'Zorro 1957',}, index, mode='newznab&newznab=6705',thumb='http://thetvdb.com/banners/posters/124801-1.jpg')
            if newznab_id == 'ABC Family':
                add_posts({'title' : '10 Things I Hate About You',}, index, mode='newznab&newznab=21702',thumb='http://thetvdb.com/banners/posters/95761-1.jpg')
                add_posts({'title' : 'Baby Daddy',}, index, mode='newznab&newznab=30876',thumb='http://thetvdb.com/banners/posters/258602-1.jpg')
                add_posts({'title' : 'Beverly Hills Nannies',}, index, mode='newznab&newznab=30877',thumb='http://thetvdb.com/banners/posters/260126-1.jpg')
                add_posts({'title' : 'Big Wolf On Campus',}, index, mode='newznab&newznab=2803',thumb='http://thetvdb.com/banners/posters/74477-1.jpg')
                add_posts({'title' : 'Bunheads',}, index, mode='newznab&newznab=30871',thumb='http://thetvdb.com/banners/posters/257377-1.jpg')
                add_posts({'title' : 'Greek',}, index, mode='newznab&newznab=16432',thumb='http://thetvdb.com/banners/posters/80301-1.jpg')
                add_posts({'title' : 'Huge',}, index, mode='newznab&newznab=25632',thumb='http://thetvdb.com/banners/posters/162541-1.jpg')
                add_posts({'title' : 'Jane By Design',}, index, mode='newznab&newznab=28367',thumb='http://thetvdb.com/banners/posters/253086-1.jpg')
                add_posts({'title' : 'Kyle XY',}, index, mode='newznab&newznab=10629',thumb='http://thetvdb.com/banners/posters/76143-1.jpg')
                add_posts({'title' : 'Make It or Break It',}, index, mode='newznab&newznab=22679',thumb='http://thetvdb.com/banners/posters/95751-1.jpg')
                add_posts({'title' : 'Melissa and Joey',}, index, mode='newznab&newznab=25864',thumb='http://thetvdb.com/banners/posters/168621-1.jpg')
                add_posts({'title' : 'Pretty Little Liars',}, index, mode='newznab&newznab=25591',thumb='http://thetvdb.com/banners/posters/146711-1.jpg')
                add_posts({'title' : 'State of Georgia',}, index, mode='newznab&newznab=28360',thumb='http://thetvdb.com/banners/posters/248448-1.jpg')
                add_posts({'title' : 'Switched at Birth',}, index, mode='newznab&newznab=27701',thumb='http://thetvdb.com/banners/posters/247773-1.jpg')
                add_posts({'title' : 'The Lying Game',}, index, mode='newznab&newznab=27661',thumb='http://thetvdb.com/banners/posters/234461-1.jpg')
                add_posts({'title' : 'The Nine Lives of Chloe King',}, index, mode='newznab&newznab=27745',thumb='http://thetvdb.com/banners/posters/247774-1.jpg')
                add_posts({'title' : 'The Secret Life of the American Teenager',}, index, mode='newznab&newznab=18837',thumb='http://thetvdb.com/banners/posters/82422-1.jpg')
            if newznab_id == 'ABC1':
                add_posts({'title' : 'A Moody Christmas',}, index, mode='newznab&newznab=33437',thumb='http://thetvdb.com/banners/posters/263812-1.jpg')
                add_posts({'title' : 'Angry Boys',}, index, mode='newznab&newznab=28421',thumb='http://thetvdb.com/banners/posters/244351-1.jpg')
                add_posts({'title' : 'At Home With Juila',}, index, mode='newznab&newznab=29458',thumb='http://thetvdb.com/banners/posters/251710-1.jpg')
                add_posts({'title' : 'At Home With Julia',}, index, mode='newznab&newznab=29458',thumb='http://thetvdb.com/banners/posters/251710-1.jpg')
                add_posts({'title' : 'Crownies',}, index, mode='newznab&newznab=28942',thumb='http://thetvdb.com/banners/posters/249811-1.jpg')
                add_posts({'title' : 'Gruen Planet',}, index, mode='newznab&newznab=29688',thumb='http://thetvdb.com/banners/posters/82135-1.jpg')
                add_posts({'title' : 'Laid',}, index, mode='newznab&newznab=27571',thumb='http://thetvdb.com/banners/posters/221381-1.jpg')
                add_posts({'title' : 'Lawrence Leungs Unbelievable',}, index, mode='newznab&newznab=28901',thumb='http://thetvdb.com/banners/posters/249579-1.jpg')
                add_posts({'title' : 'Miss Fishers Murder Mysteries',}, index, mode='newznab&newznab=30923',thumb='http://thetvdb.com/banners/posters/256352-1.jpg')
                add_posts({'title' : 'Myf Warhursts Nice',}, index, mode='newznab&newznab=32111',thumb='http://thetvdb.com/banners/posters/259895-1.jpg')
                add_posts({'title' : 'Outland',}, index, mode='newznab&newznab=30937',thumb='http://thetvdb.com/banners/posters/255264-1.jpg')
                add_posts({'title' : 'Rake',}, index, mode='newznab&newznab=26845',thumb='http://thetvdb.com/banners/posters/203401-1.jpg')
                add_posts({'title' : 'The Hamster Wheel',}, index, mode='newznab&newznab=30071',thumb='http://thetvdb.com/banners/posters/252276-1.jpg')
                add_posts({'title' : 'The Slap',}, index, mode='newznab&newznab=24221',thumb='http://thetvdb.com/banners/posters/252325-1.jpg')
                add_posts({'title' : 'The Straits',}, index, mode='newznab&newznab=30677',thumb='http://thetvdb.com/banners/posters/254734-1.jpg')
                add_posts({'title' : 'Woodley',}, index, mode='newznab&newznab=30939',thumb='http://thetvdb.com/banners/posters/250104-1.jpg')
            if newznab_id == 'ABC2':
                add_posts({'title' : 'Dumb Drunk And Racist',}, index, mode='newznab&newznab=32269')
                add_posts({'title' : 'Good Game',}, index, mode='newznab&newznab=17719',thumb='http://thetvdb.com/banners/posters/81443-1.jpg')
                add_posts({'title' : 'Review With Myles Barlow',}, index, mode='newznab&newznab=24519')
                add_posts({'title' : 'The New Inventors',}, index, mode='newznab&newznab=17315',thumb='http://thetvdb.com/banners/posters/80358-1.jpg')
                add_posts({'title' : 'Twentysomething',}, index, mode='newznab&newznab=29457',thumb='http://thetvdb.com/banners/posters/251613-1.jpg')
            if newznab_id == 'ABC3':
                add_posts({'title' : 'CJ The DJ',}, index, mode='newznab&newznab=23999')
                add_posts({'title' : 'Dance Academy',}, index, mode='newznab&newznab=23963',thumb='http://thetvdb.com/banners/posters/167461-1.jpg')
                add_posts({'title' : 'Dance Akademy',}, index, mode='newznab&newznab=23963',thumb='http://thetvdb.com/banners/posters/167461-1.jpg')
                add_posts({'title' : 'Good Game Spawn Point',}, index, mode='newznab&newznab=31210',thumb='http://thetvdb.com/banners/posters/144281-1.jpg')
                add_posts({'title' : 'My Place',}, index, mode='newznab&newznab=23974',thumb='http://thetvdb.com/banners/posters/195021-1.jpg')
            if newznab_id == 'AcAcn':
                add_posts({'title' : 'Het Goddelijke Monster',}, index, mode='newznab&newznab=29377',thumb='http://thetvdb.com/banners/posters/251640-1.jpg')
            if newznab_id == 'Action':
                add_posts({'title' : 'Kenny Hotzs Triumph Of The Will',}, index, mode='newznab&newznab=28979',thumb='http://thetvdb.com/banners/posters/248647-1.jpg')
                add_posts({'title' : 'The Drunk And On Drugs Happy Funtime Hour',}, index, mode='newznab&newznab=25907',thumb='http://thetvdb.com/banners/posters/249544-1.jpg')
            if newznab_id == 'Adult Swim':
                add_posts({'title' : 'Aqua Teen Hunger Force',}, index, mode='newznab&newznab=2638')
                add_posts({'title' : 'Assy McGee',}, index, mode='newznab&newznab=10934',thumb='http://thetvdb.com/banners/posters/82661-1.jpg')
                add_posts({'title' : 'Black Dynamite',}, index, mode='newznab&newznab=30112',thumb='http://thetvdb.com/banners/posters/250821-1.jpg')
                add_posts({'title' : 'Childrens Hospital US',}, index, mode='newznab&newznab=24636')
                add_posts({'title' : 'China IL',}, index, mode='newznab&newznab=28441',thumb='http://thetvdb.com/banners/posters/251507-1.jpg')
                add_posts({'title' : 'Delocated',}, index, mode='newznab&newznab=20799',thumb='http://thetvdb.com/banners/posters/85190-1.jpg')
                add_posts({'title' : 'Eagleheart',}, index, mode='newznab&newznab=24654',thumb='http://thetvdb.com/banners/posters/228751-1.jpg')
                add_posts({'title' : 'Mary Shelleys Frankenhole',}, index, mode='newznab&newznab=26054',thumb='http://thetvdb.com/banners/posters/172221-1.jpg')
                add_posts({'title' : 'Metalocalypse',}, index, mode='newznab&newznab=12636',thumb='http://thetvdb.com/banners/posters/79563-1.jpg')
                add_posts({'title' : 'Moral Orel',}, index, mode='newznab&newznab=7038',thumb='http://thetvdb.com/banners/posters/79302-1.jpg')
                add_posts({'title' : 'NTSF SD SUV',}, index, mode='newznab&newznab=28439',thumb='http://thetvdb.com/banners/posters/248261-1.jpg')
                add_posts({'title' : 'Robot Chicken',}, index, mode='newznab&newznab=5027',thumb='http://thetvdb.com/banners/posters/75734-1.jpg')
                add_posts({'title' : 'Squidbillies',}, index, mode='newznab&newznab=2292',thumb='http://thetvdb.com/banners/posters/79017-1.jpg')
                add_posts({'title' : 'Superjail',}, index, mode='newznab&newznab=15529',thumb='http://thetvdb.com/banners/posters/83306-1.jpg')
                add_posts({'title' : 'The Drinky Crow Show',}, index, mode='newznab&newznab=15528',thumb='http://thetvdb.com/banners/posters/83931-1.jpg')
                add_posts({'title' : 'The Heart She Holler',}, index, mode='newznab&newznab=28440',thumb='http://thetvdb.com/banners/posters/252567-1.jpg')
                add_posts({'title' : 'The Venture Bros',}, index, mode='newznab&newznab=6270',thumb='http://thetvdb.com/banners/posters/72306-1.jpg')
                add_posts({'title' : 'Tim and Eric Awesome Show Great Job',}, index, mode='newznab&newznab=15069',thumb='http://thetvdb.com/banners/posters/79905-1.jpg')
                add_posts({'title' : 'Tom Goes To The Mayor',}, index, mode='newznab&newznab=6379',thumb='http://thetvdb.com/banners/posters/75221-1.jpg')
            if newznab_id == 'AMC':
                add_posts({'title' : 'Breaking Bad',}, index, mode='newznab&newznab=18164',thumb='http://thetvdb.com/banners/posters/81189-1.jpg')
                add_posts({'title' : 'Comic Book Men',}, index, mode='newznab&newznab=30604',thumb='http://thetvdb.com/banners/posters/254990-1.jpg')
                add_posts({'title' : 'Hell on Wheels',}, index, mode='newznab&newznab=27195',thumb='http://thetvdb.com/banners/posters/212961-1.jpg')
                add_posts({'title' : 'Mad Men',}, index, mode='newznab&newznab=16356',thumb='http://thetvdb.com/banners/posters/80337-1.jpg')
                add_posts({'title' : 'Rubicon',}, index, mode='newznab&newznab=23400',thumb='http://thetvdb.com/banners/posters/158411-1.jpg')
                add_posts({'title' : 'Small Town Security',}, index, mode='newznab&newznab=31941',thumb='http://thetvdb.com/banners/posters/259728-1.jpg')
                add_posts({'title' : 'Talking Dead',}, index, mode='newznab&newznab=29695',thumb='http://thetvdb.com/banners/posters/252861-1.jpg')
                add_posts({'title' : 'The Killing',}, index, mode='newznab&newznab=27387',thumb='http://thetvdb.com/banners/posters/79689-1.jpg')
                add_posts({'title' : 'The Pitch',}, index, mode='newznab&newznab=31349',thumb='http://thetvdb.com/banners/posters/257717-1.jpg')
                add_posts({'title' : 'The Talking Dead',}, index, mode='newznab&newznab=25056',thumb='http://thetvdb.com/banners/posters/153021-1.jpg')
                add_posts({'title' : 'The Walking Dead',}, index, mode='newznab&newznab=25056',thumb='http://thetvdb.com/banners/posters/153021-1.jpg')
            if newznab_id == 'Animal Planet':
                add_posts({'title' : 'American Stuffers',}, index, mode='newznab&newznab=30516',thumb='http://thetvdb.com/banners/posters/254586-1.jpg')
                add_posts({'title' : 'Animal Cops Houston',}, index, mode='newznab&newznab=2615',thumb='http://thetvdb.com/banners/posters/93361-1.jpg')
                add_posts({'title' : 'Animal Cops Philadelphia',}, index, mode='newznab&newznab=19592',thumb='http://thetvdb.com/banners/posters/263232-1.jpg')
                add_posts({'title' : 'Animal Cops South Africa',}, index, mode='newznab&newznab=19226')
                add_posts({'title' : 'Blonde vs Bear',}, index, mode='newznab&newznab=27781')
                add_posts({'title' : 'Call of the Wildman',}, index, mode='newznab&newznab=29757',thumb='http://thetvdb.com/banners/posters/253415-1.jpg')
                add_posts({'title' : 'Call of the Wilman',}, index, mode='newznab&newznab=29757',thumb='http://thetvdb.com/banners/posters/253415-1.jpg')
                add_posts({'title' : 'Cats 101',}, index, mode='newznab&newznab=20728',thumb='http://thetvdb.com/banners/posters/189111-1.jpg')
                add_posts({'title' : 'Confessions Animal Hoarding',}, index, mode='newznab&newznab=26161',thumb='http://thetvdb.com/banners/posters/181051-1.jpg')
                add_posts({'title' : 'Dogs 101',}, index, mode='newznab&newznab=20306',thumb='http://thetvdb.com/banners/posters/138821-1.jpg')
                add_posts({'title' : 'Fatal Attractions',}, index, mode='newznab&newznab=24806',thumb='http://thetvdb.com/banners/posters/196191-1.jpg')
                add_posts({'title' : 'Finding Bigfoot',}, index, mode='newznab&newznab=28516',thumb='http://thetvdb.com/banners/posters/249235-1.jpg')
                add_posts({'title' : 'Frontier Earth with Dave Salmoni',}, index, mode='newznab&newznab=32866')
                add_posts({'title' : 'Gator Boys',}, index, mode='newznab&newznab=30517',thumb='http://thetvdb.com/banners/posters/254649-1.jpg')
                add_posts({'title' : 'Hillbilly Handfishin',}, index, mode='newznab&newznab=28969',thumb='http://thetvdb.com/banners/posters/250475-1.jpg')
                add_posts({'title' : 'Hillbilly HandFishing',}, index, mode='newznab&newznab=28969',thumb='http://thetvdb.com/banners/posters/250475-1.jpg')
                add_posts({'title' : 'I Predator',}, index, mode='newznab&newznab=27199',thumb='http://thetvdb.com/banners/posters/221021-1.jpg')
                add_posts({'title' : 'I Shouldn t Be Alive',}, index, mode='newznab&newznab=6733',thumb='http://thetvdb.com/banners/posters/80983-1.jpg')
                add_posts({'title' : 'I Shouldnt Be Alive',}, index, mode='newznab&newznab=6733',thumb='http://thetvdb.com/banners/posters/80983-1.jpg')
                add_posts({'title' : 'Infested',}, index, mode='newznab&newznab=27170',thumb='http://thetvdb.com/banners/posters/220881-1.jpg')
                add_posts({'title' : 'Into The Pride',}, index, mode='newznab&newznab=23233',thumb='http://thetvdb.com/banners/posters/138791-1.jpg')
                add_posts({'title' : 'K9 Cops',}, index, mode='newznab&newznab=24027')
                add_posts({'title' : 'Karina Wild On Safari',}, index, mode='newznab&newznab=33514',thumb='http://thetvdb.com/banners/posters/248981-1.jpg')
                add_posts({'title' : 'Killer Outbreaks',}, index, mode='newznab&newznab=27925',thumb='http://thetvdb.com/banners/posters/248150-1.jpg')
                add_posts({'title' : 'Lost Tapes',}, index, mode='newznab&newznab=21191',thumb='http://thetvdb.com/banners/posters/254201-1.jpg')
                add_posts({'title' : 'Louisiana Lockdown',}, index, mode='newznab&newznab=31738',thumb='http://thetvdb.com/banners/posters/259907-1.jpg')
                add_posts({'title' : 'Monsters Inside Me',}, index, mode='newznab&newznab=23072',thumb='http://thetvdb.com/banners/posters/101951-1.jpg')
                add_posts({'title' : 'Must Love Cats',}, index, mode='newznab&newznab=27284',thumb='http://thetvdb.com/banners/posters/215371-1.jpg')
                add_posts({'title' : 'My Cat From Hell',}, index, mode='newznab&newznab=28065',thumb='http://thetvdb.com/banners/posters/248569-1.jpg')
                add_posts({'title' : 'My Extreme Animal Phobia',}, index, mode='newznab&newznab=29434',thumb='http://thetvdb.com/banners/posters/252795-1.jpg')
                add_posts({'title' : 'New Breed Vets',}, index, mode='newznab&newznab=7902')
                add_posts({'title' : 'North Woods Law',}, index, mode='newznab&newznab=31126',thumb='http://thetvdb.com/banners/posters/257553-1.jpg')
                add_posts({'title' : 'Off the Hook Extreme Catches',}, index, mode='newznab&newznab=31947',thumb='http://thetvdb.com/banners/posters/261119-1.jpg')
                add_posts({'title' : 'Pets 101',}, index, mode='newznab&newznab=27050')
                add_posts({'title' : 'Pit Boss XL',}, index, mode='newznab&newznab=25875')
                add_posts({'title' : 'Pit Boss',}, index, mode='newznab&newznab=24543',thumb='http://thetvdb.com/banners/posters/145551-1.jpg')
                add_posts({'title' : 'Pit Bull and Parolees',}, index, mode='newznab&newznab=24447',thumb='http://thetvdb.com/banners/posters/220871-1.jpg')
                add_posts({'title' : 'Pit Bulls and Parolees',}, index, mode='newznab&newznab=24447',thumb='http://thetvdb.com/banners/posters/220871-1.jpg')
                add_posts({'title' : 'Puppies vs Babies',}, index, mode='newznab&newznab=29478')
                add_posts({'title' : 'Rat Busters NYC',}, index, mode='newznab&newznab=29120',thumb='http://thetvdb.com/banners/posters/251319-1.jpg')
                add_posts({'title' : 'Rattlesnake Republic',}, index, mode='newznab&newznab=30925')
                add_posts({'title' : 'River Monsters',}, index, mode='newznab&newznab=21955',thumb='http://thetvdb.com/banners/posters/99151-1.jpg')
                add_posts({'title' : 'Saved 2011',}, index, mode='newznab&newznab=29130')
                add_posts({'title' : 'Snake Man of Appalachia',}, index, mode='newznab&newznab=30523',thumb='http://thetvdb.com/banners/posters/255138-1.jpg')
                add_posts({'title' : 'Swamp Wars',}, index, mode='newznab&newznab=28527',thumb='http://thetvdb.com/banners/posters/249372-1.jpg')
                add_posts({'title' : 'Taking on Tyson',}, index, mode='newznab&newznab=27562',thumb='http://thetvdb.com/banners/posters/219311-1.jpg')
                add_posts({'title' : 'Tanked',}, index, mode='newznab&newznab=28995',thumb='http://thetvdb.com/banners/posters/250181-1.jpg')
                add_posts({'title' : 'The Crocodile Hunter Diaries',}, index, mode='newznab&newznab=5704',thumb='http://thetvdb.com/banners/posters/70951-1.jpg')
                add_posts({'title' : 'Too Cute',}, index, mode='newznab&newznab=31057',thumb='http://thetvdb.com/banners/posters/257804-1.jpg')
                add_posts({'title' : 'Viking Wilderness',}, index, mode='newznab&newznab=29419',thumb='http://thetvdb.com/banners/posters/252096-1.jpg')
                add_posts({'title' : 'Whale Wars Viking Shores',}, index, mode='newznab&newznab=31585',thumb='http://thetvdb.com/banners/posters/258519-1.jpg')
                add_posts({'title' : 'Whale Wars',}, index, mode='newznab&newznab=20399',thumb='http://thetvdb.com/banners/posters/83682-1.jpg')
            if newznab_id == 'Animax':
                add_posts({'title' : 'Blade',}, index, mode='newznab&newznab=28449',thumb='http://thetvdb.com/banners/posters/73192-1.jpg')
                add_posts({'title' : 'Vipers Creed',}, index, mode='newznab&newznab=20957',thumb='http://thetvdb.com/banners/posters/84571-1.jpg')
            if newznab_id == 'Antena 1':
                add_posts({'title' : 'X Factor Romania',}, index, mode='newznab&newznab=28312')
            if newznab_id == 'Antena 3':
                add_posts({'title' : 'Luna El Misterio de Calenda',}, index, mode='newznab&newznab=31351')
            if newznab_id == 'ARD':
                add_posts({'title' : 'Mord mit Aussicht',}, index, mode='newznab&newznab=18213',thumb='http://thetvdb.com/banners/posters/82638-1.jpg')
            if newznab_id == 'Arena':
                add_posts({'title' : 'Project Runway Australia',}, index, mode='newznab&newznab=19621',thumb='http://thetvdb.com/banners/posters/82448-1.jpg')
            if newznab_id == 'AT X':
                add_posts({'title' : 'MM',}, index, mode='newznab&newznab=26295',thumb='http://thetvdb.com/banners/posters/194541-1.jpg')
            if newznab_id == 'AXS TV':
                add_posts({'title' : 'Art Mann Presents',}, index, mode='newznab&newznab=7221',thumb='http://thetvdb.com/banners/posters/168311-1.jpg')
                add_posts({'title' : 'CelebriDate',}, index, mode='newznab&newznab=29818',thumb='http://thetvdb.com/banners/posters/252794-1.jpg')
                add_posts({'title' : 'Deadline 2011',}, index, mode='newznab&newznab=29889',thumb='http://thetvdb.com/banners/posters/253324-1.jpg')
                add_posts({'title' : 'Drinking Made Easy',}, index, mode='newznab&newznab=26841',thumb='http://thetvdb.com/banners/posters/195831-1.jpg')
                add_posts({'title' : 'Get Out',}, index, mode='newznab&newznab=19352',thumb='http://thetvdb.com/banners/posters/221361-1.jpg')
                add_posts({'title' : 'Goodnight Burbank',}, index, mode='newznab&newznab=29902',thumb='http://thetvdb.com/banners/posters/252845-1.jpg')
                add_posts({'title' : 'Svetlana',}, index, mode='newznab&newznab=25845',thumb='http://thetvdb.com/banners/posters/166001-1.jpg')
                add_posts({'title' : 'The Ferris Wheel',}, index, mode='newznab&newznab=29890',thumb='http://thetvdb.com/banners/posters/253663-1.jpg')
                add_posts({'title' : 'The Super 2011',}, index, mode='newznab&newznab=29848',thumb='http://thetvdb.com/banners/posters/254241-1.jpg')
            if newznab_id == 'BBC':
                add_posts({'title' : 'World War 1 In Colour',}, index, mode='newznab&newznab=27565')
            if newznab_id == 'BBC America':
                add_posts({'title' : 'Copper',}, index, mode='newznab&newznab=30120',thumb='http://thetvdb.com/banners/posters/257939-1.jpg')
                add_posts({'title' : 'Go Back To Where You Came From',}, index, mode='newznab&newznab=33237',thumb='http://thetvdb.com/banners/posters/249694-1.jpg')
                add_posts({'title' : 'Richard Hammonds Crash Course',}, index, mode='newznab&newznab=30984',thumb='http://thetvdb.com/banners/posters/256300-1.jpg')
            if newznab_id == 'BBC FOUR':
                add_posts({'title' : 'A History Of Art In Three Colours',}, index, mode='newznab&newznab=32232',thumb='http://thetvdb.com/banners/posters/261096-1.jpg')
                add_posts({'title' : 'Afterlife The Strange Science of Decay',}, index, mode='newznab&newznab=32260',thumb='http://thetvdb.com/banners/posters/260610-1.jpg')
                add_posts({'title' : 'British Masters',}, index, mode='newznab&newznab=28812',thumb='http://thetvdb.com/banners/posters/250287-1.jpg')
                add_posts({'title' : 'Canal Walks With Julia Bradbury',}, index, mode='newznab&newznab=28147',thumb='http://thetvdb.com/banners/posters/248464-1.jpg')
                add_posts({'title' : 'Charlie Brookers Screen Wipe',}, index, mode='newznab&newznab=13011')
                add_posts({'title' : 'Dirk Gently',}, index, mode='newznab&newznab=27204',thumb='http://thetvdb.com/banners/posters/213081-1.jpg')
                add_posts({'title' : 'Elegance And Decadance The Age Of The Regency',}, index, mode='newznab&newznab=29231')
                add_posts({'title' : 'Elegance and Decadence The Age of the Regency',}, index, mode='newznab&newznab=29231')
                add_posts({'title' : 'Everything And Nothing',}, index, mode='newznab&newznab=27873',thumb='http://thetvdb.com/banners/posters/244101-1.jpg')
                add_posts({'title' : 'Getting On',}, index, mode='newznab&newznab=23309',thumb='http://thetvdb.com/banners/posters/103151-1.jpg')
                add_posts({'title' : 'Great Thinkers In Their Own Words',}, index, mode='newznab&newznab=29042',thumb='http://thetvdb.com/banners/posters/250664-1.jpg')
                add_posts({'title' : 'Guilty Pleasures',}, index, mode='newznab&newznab=28758',thumb='http://thetvdb.com/banners/posters/249814-1.jpg')
                add_posts({'title' : 'How It works',}, index, mode='newznab&newznab=31290',thumb='http://thetvdb.com/banners/posters/257789-1.jpg')
                add_posts({'title' : 'Illuminations The Private Lives Of Medieval Kings',}, index, mode='newznab&newznab=30644',thumb='http://thetvdb.com/banners/posters/255113-1.jpg')
                add_posts({'title' : 'Ive Never Seen Star Wars',}, index, mode='newznab&newznab=21949',thumb='http://thetvdb.com/banners/posters/85811-1.jpg')
                add_posts({'title' : 'Jerusalem The making Of A Holy City',}, index, mode='newznab&newznab=30141',thumb='http://thetvdb.com/banners/posters/254279-1.jpg')
                add_posts({'title' : 'Lost Kingdoms Of Africa',}, index, mode='newznab&newznab=29674',thumb='http://thetvdb.com/banners/posters/134421-1.jpg')
                add_posts({'title' : 'Metalworks',}, index, mode='newznab&newznab=31848',thumb='http://thetvdb.com/banners/posters/258685-1.jpg')
                add_posts({'title' : 'Michael Woods Story of England',}, index, mode='newznab&newznab=26537',thumb='http://thetvdb.com/banners/posters/191851-1.jpg')
                add_posts({'title' : 'Natures Microworlds',}, index, mode='newznab&newznab=33391',thumb='http://thetvdb.com/banners/posters/261155-1.jpg')
                add_posts({'title' : 'Only Connect',}, index, mode='newznab&newznab=23123',thumb='http://thetvdb.com/banners/posters/83221-1.jpg')
                add_posts({'title' : 'Petworth House The Big Spring Clean',}, index, mode='newznab&newznab=27931',thumb='http://thetvdb.com/banners/posters/247977-1.jpg')
                add_posts({'title' : 'Railway Walks',}, index, mode='newznab&newznab=22135',thumb='http://thetvdb.com/banners/posters/83986-1.jpg')
                add_posts({'title' : 'Rome A History of the Eternal City',}, index, mode='newznab&newznab=33678',thumb='http://thetvdb.com/banners/posters/264667-1.jpg')
                add_posts({'title' : 'Room At The Top',}, index, mode='newznab&newznab=32746',thumb='http://thetvdb.com/banners/posters/262777-1.jpg')
                add_posts({'title' : 'Sandhurst',}, index, mode='newznab&newznab=29402',thumb='http://thetvdb.com/banners/posters/252047-1.jpg')
                add_posts({'title' : 'Sex Death and the Meaning of Life',}, index, mode='newznab&newznab=33438',thumb='http://thetvdb.com/banners/posters/263321-1.jpg')
                add_posts({'title' : 'South Africa Walks',}, index, mode='newznab&newznab=25487')
                add_posts({'title' : 'Survivors Natures Indestructible Creatures',}, index, mode='newznab&newznab=30762',thumb='http://thetvdb.com/banners/posters/255520-1.jpg')
                add_posts({'title' : 'Symphony',}, index, mode='newznab&newznab=29814',thumb='http://thetvdb.com/banners/posters/253429-1.jpg')
                add_posts({'title' : 'The Art Of America',}, index, mode='newznab&newznab=29991')
                add_posts({'title' : 'The Dark Ages An Age Of Light',}, index, mode='newznab&newznab=33609')
                add_posts({'title' : 'The Gene Code',}, index, mode='newznab&newznab=28072',thumb='http://thetvdb.com/banners/posters/248074-1.jpg')
                add_posts({'title' : 'The Grammer School A Secret History',}, index, mode='newznab&newznab=30676')
                add_posts({'title' : 'The King And The Playwright A Jacobean History',}, index, mode='newznab&newznab=31296')
                add_posts({'title' : 'The Story Of Musicals',}, index, mode='newznab&newznab=30394',thumb='http://thetvdb.com/banners/posters/254937-1.jpg')
                add_posts({'title' : 'The Story Of Variety With Michael Grade',}, index, mode='newznab&newznab=27656')
                add_posts({'title' : 'The Strange Case Of The Law',}, index, mode='newznab&newznab=31831',thumb='http://thetvdb.com/banners/posters/260024-1.jpg')
                add_posts({'title' : 'The Thick Of It',}, index, mode='newznab&newznab=7108',thumb='http://thetvdb.com/banners/posters/79843-1.jpg')
                add_posts({'title' : 'Time Shift',}, index, mode='newznab&newznab=33770')
                add_posts({'title' : 'Unnatural Histories',}, index, mode='newznab&newznab=28744',thumb='http://thetvdb.com/banners/posters/249532-1.jpg')
            if newznab_id == 'BBC One':
                add_posts({'title' : '1 vs 100',}, index, mode='newznab&newznab=12707',thumb='http://thetvdb.com/banners/posters/256940-1.jpg')
                add_posts({'title' : '32 Brinkburn Street',}, index, mode='newznab&newznab=27788',thumb='http://thetvdb.com/banners/posters/244751-1.jpg')
                add_posts({'title' : '55 Degrees North',}, index, mode='newznab&newznab=2456',thumb='http://thetvdb.com/banners/posters/73801-1.jpg')
                add_posts({'title' : 'A Bit of Fry and Laurie',}, index, mode='newznab&newznab=667')
                add_posts({'title' : 'A Question Of Sport',}, index, mode='newznab&newznab=7341',thumb='http://thetvdb.com/banners/posters/72914-1.jpg')
                add_posts({'title' : 'Absolutely Fabulous',}, index, mode='newznab&newznab=2477',thumb='http://thetvdb.com/banners/posters/73314-1.jpg')
                add_posts({'title' : 'Accused UK',}, index, mode='newznab&newznab=26855')
                add_posts({'title' : 'Andrew Marrs History of the World',}, index, mode='newznab&newznab=32736',thumb='http://thetvdb.com/banners/posters/262586-1.jpg')
                add_posts({'title' : 'Andrew Marrs Megacities',}, index, mode='newznab&newznab=28407',thumb='http://thetvdb.com/banners/posters/249244-1.jpg')
                add_posts({'title' : 'antiques roadshow',}, index, mode='newznab&newznab=7762',thumb='http://thetvdb.com/banners/posters/83774-1.jpg')
                add_posts({'title' : 'Aristocrats',}, index, mode='newznab&newznab=32233',thumb='http://thetvdb.com/banners/posters/127131-1.jpg')
                add_posts({'title' : 'Ask Rhod Gilbert',}, index, mode='newznab&newznab=26616',thumb='http://thetvdb.com/banners/posters/193451-1.jpg')
                add_posts({'title' : 'Ballykissangel',}, index, mode='newznab&newznab=2704',thumb='http://thetvdb.com/banners/posters/76735-1.jpg')
                add_posts({'title' : 'Bang Goes The Theory',}, index, mode='newznab&newznab=23312',thumb='http://thetvdb.com/banners/posters/107471-1.jpg')
                add_posts({'title' : 'Beautiful Lives Stories From A Childrens Hospice',}, index, mode='newznab&newznab=29653',thumb='http://thetvdb.com/banners/posters/253191-1.jpg')
                add_posts({'title' : 'Bedtime',}, index, mode='newznab&newznab=1624',thumb='http://thetvdb.com/banners/posters/76914-1.jpg')
                add_posts({'title' : 'Behind Bars',}, index, mode='newznab&newznab=12588')
                add_posts({'title' : 'Bergerac',}, index, mode='newznab&newznab=2763',thumb='http://thetvdb.com/banners/posters/73650-1.jpg')
                add_posts({'title' : 'Birdsong',}, index, mode='newznab&newznab=30598',thumb='http://thetvdb.com/banners/posters/255250-1.jpg')
                add_posts({'title' : 'Blackadder',}, index, mode='newznab&newznab=5626',thumb='http://thetvdb.com/banners/posters/76736-1.jpg')
                add_posts({'title' : 'Blackout',}, index, mode='newznab&newznab=32037',thumb='http://thetvdb.com/banners/posters/81943-1.jpg')
                add_posts({'title' : 'Blackpool',}, index, mode='newznab&newznab=2318',thumb='http://thetvdb.com/banners/posters/75350-1.jpg')
                add_posts({'title' : 'Blakes 7',}, index, mode='newznab&newznab=2823',thumb='http://thetvdb.com/banners/posters/75565-1.jpg')
                add_posts({'title' : 'Bob The Builder',}, index, mode='newznab&newznab=2861',thumb='http://thetvdb.com/banners/posters/78685-1.jpg')
                add_posts({'title' : 'Bonekickers',}, index, mode='newznab&newznab=17689',thumb='http://thetvdb.com/banners/posters/82456-1.jpg')
                add_posts({'title' : 'Brazil With Michael Palin',}, index, mode='newznab&newznab=33057',thumb='http://thetvdb.com/banners/posters/263431-1.jpg')
                add_posts({'title' : 'Britain From Above',}, index, mode='newznab&newznab=19745',thumb='http://thetvdb.com/banners/posters/82678-1.jpg')
                add_posts({'title' : 'Britains Hidden Heritage',}, index, mode='newznab&newznab=29139',thumb='http://thetvdb.com/banners/posters/251529-1.jpg')
                add_posts({'title' : 'Britains Lost Routes With Griff Rhys Jones',}, index, mode='newznab&newznab=31710',thumb='http://thetvdb.com/banners/posters/259753-1.jpg')
                add_posts({'title' : 'Bugs',}, index, mode='newznab&newznab=2933',thumb='http://thetvdb.com/banners/posters/77698-1.jpg')
                add_posts({'title' : 'By the Sword Divided',}, index, mode='newznab&newznab=14333',thumb='http://thetvdb.com/banners/posters/120361-1.jpg')
                add_posts({'title' : 'Call The Midwife',}, index, mode='newznab&newznab=30579',thumb='http://thetvdb.com/banners/posters/255192-1.jpg')
                add_posts({'title' : 'Case Histories',}, index, mode='newznab&newznab=28469',thumb='http://thetvdb.com/banners/posters/249237-1.jpg')
                add_posts({'title' : 'Casualty',}, index, mode='newznab&newznab=3005',thumb='http://thetvdb.com/banners/posters/71756-1.jpg')
                add_posts({'title' : 'Charlie And Lola',}, index, mode='newznab&newznab=3033')
                add_posts({'title' : 'Chatsworth',}, index, mode='newznab&newznab=31573',thumb='http://thetvdb.com/banners/posters/259296-1.jpg')
                add_posts({'title' : 'Citizen Khan',}, index, mode='newznab&newznab=32448',thumb='http://thetvdb.com/banners/posters/261745-1.jpg')
                add_posts({'title' : 'Come Fly With Me 2010',}, index, mode='newznab&newznab=27012')
                add_posts({'title' : 'Country Tracks',}, index, mode='newznab&newznab=22277')
                add_posts({'title' : 'Countryfile',}, index, mode='newznab&newznab=11083',thumb='http://thetvdb.com/banners/posters/84945-1.jpg')
                add_posts({'title' : 'Crimewatch UK',}, index, mode='newznab&newznab=8321',thumb='http://thetvdb.com/banners/posters/72728-1.jpg')
                add_posts({'title' : 'Criminal Justice',}, index, mode='newznab&newznab=19329',thumb='http://thetvdb.com/banners/posters/82512-1.jpg')
                add_posts({'title' : 'Cutting It',}, index, mode='newznab&newznab=873',thumb='http://thetvdb.com/banners/posters/71734-1.jpg')
                add_posts({'title' : 'Dad 1997',}, index, mode='newznab&newznab=3202')
                add_posts({'title' : 'Dalziel And Pascoe',}, index, mode='newznab&newznab=3213',thumb='http://thetvdb.com/banners/posters/76187-1.jpg')
                add_posts({'title' : 'Death In Paradise',}, index, mode='newznab&newznab=29741',thumb='http://thetvdb.com/banners/posters/252800-1.jpg')
                add_posts({'title' : 'Death Unexplained',}, index, mode='newznab&newznab=30719',thumb='http://thetvdb.com/banners/posters/256314-1.jpg')
                add_posts({'title' : 'Dinnerladies',}, index, mode='newznab&newznab=3314',thumb='http://thetvdb.com/banners/posters/76899-1.jpg')
                add_posts({'title' : 'Dirty Tricks of the Tradesmen',}, index, mode='newznab&newznab=29596',thumb='http://thetvdb.com/banners/posters/253242-1.jpg')
                add_posts({'title' : 'DIY SOS',}, index, mode='newznab&newznab=10928',thumb='http://thetvdb.com/banners/posters/248379-1.jpg')
                add_posts({'title' : 'Doctor Who 2005',}, index, mode='newznab&newznab=3332',thumb='http://thetvdb.com/banners/posters/78804-1.jpg')
                add_posts({'title' : 'Doctor Who',}, index, mode='newznab&newznab=3331',thumb='http://thetvdb.com/banners/posters/76107-1.jpg')
                add_posts({'title' : 'Dont Get Done Get Dom',}, index, mode='newznab&newznab=12012',thumb='http://thetvdb.com/banners/posters/259241-1.jpg')
                add_posts({'title' : 'Doorstep Crime 999',}, index, mode='newznab&newznab=30880',thumb='http://thetvdb.com/banners/posters/260448-1.jpg')
                add_posts({'title' : 'Earthflight',}, index, mode='newznab&newznab=30318',thumb='http://thetvdb.com/banners/posters/254572-1.jpg')
                add_posts({'title' : 'Eastenders',}, index, mode='newznab&newznab=3418',thumb='http://thetvdb.com/banners/posters/71753-1.jpg')
                add_posts({'title' : 'Epic Win',}, index, mode='newznab&newznab=29145',thumb='http://thetvdb.com/banners/posters/262690-1.jpg')
                add_posts({'title' : 'Exile',}, index, mode='newznab&newznab=27899',thumb='http://thetvdb.com/banners/posters/187991-1.jpg')
                add_posts({'title' : 'Fake or Fortune',}, index, mode='newznab&newznab=28631',thumb='http://thetvdb.com/banners/posters/249785-1.jpg')
                add_posts({'title' : 'Famous Rich And In The Slums With Comic Relief',}, index, mode='newznab&newznab=27632')
                add_posts({'title' : 'Fast And Loose',}, index, mode='newznab&newznab=9311',thumb='http://thetvdb.com/banners/posters/221581-1.jpg')
                add_posts({'title' : 'Filthy Rotten Scoundrels',}, index, mode='newznab&newznab=26530')
                add_posts({'title' : 'Fireman Sam',}, index, mode='newznab&newznab=1416',thumb='http://thetvdb.com/banners/posters/73517-1.jpg')
                add_posts({'title' : 'First Of The Summer Wine',}, index, mode='newznab&newznab=8889',thumb='http://thetvdb.com/banners/posters/116481-1.jpg')
                add_posts({'title' : 'Five Days',}, index, mode='newznab&newznab=13028',thumb='http://thetvdb.com/banners/posters/80895-1.jpg')
                add_posts({'title' : 'Food Factory',}, index, mode='newznab&newznab=24045',thumb='http://thetvdb.com/banners/posters/261524-1.jpg')
                add_posts({'title' : 'Food Inspectors',}, index, mode='newznab&newznab=30966',thumb='http://thetvdb.com/banners/posters/256811-1.jpg')
                add_posts({'title' : 'Frozen Planet',}, index, mode='newznab&newznab=27911',thumb='http://thetvdb.com/banners/posters/251418-1.jpg')
                add_posts({'title' : 'Gavin And Stacey',}, index, mode='newznab&newznab=15597')
                add_posts({'title' : 'Good Cop',}, index, mode='newznab&newznab=32449',thumb='http://thetvdb.com/banners/posters/261144-1.jpg')
                add_posts({'title' : 'Goodnight Sweetheart',}, index, mode='newznab&newznab=3722',thumb='http://thetvdb.com/banners/posters/76333-1.jpg')
                add_posts({'title' : 'Great Expectations 2011',}, index, mode='newznab&newznab=30234',thumb='http://thetvdb.com/banners/posters/254143-1.jpg')
                add_posts({'title' : 'Harrys Arctic Heroes',}, index, mode='newznab&newznab=29144',thumb='http://thetvdb.com/banners/posters/251372-1.jpg')
                add_posts({'title' : 'Have I Got News for You',}, index, mode='newznab&newznab=3804',thumb='http://thetvdb.com/banners/posters/74281-1.jpg')
                add_posts({'title' : 'Hidden',}, index, mode='newznab&newznab=29556',thumb='http://thetvdb.com/banners/posters/252418-1.jpg')
                add_posts({'title' : 'Holby Blue',}, index, mode='newznab&newznab=15567',thumb='http://thetvdb.com/banners/posters/80969-1.jpg')
                add_posts({'title' : 'Holby City',}, index, mode='newznab&newznab=3876',thumb='http://thetvdb.com/banners/posters/77235-1.jpg')
                add_posts({'title' : 'Horrible Histories With Stephen Fry',}, index, mode='newznab&newznab=30820',thumb='http://thetvdb.com/banners/posters/249653-1.jpg')
                add_posts({'title' : 'House Of Cards',}, index, mode='newznab&newznab=17544',thumb='http://thetvdb.com/banners/posters/79861-1.jpg')
                add_posts({'title' : 'How To Start Your Own Country',}, index, mode='newznab&newznab=12290',thumb='http://thetvdb.com/banners/posters/79913-1.jpg')
                add_posts({'title' : 'Howards Way',}, index, mode='newznab&newznab=368',thumb='http://thetvdb.com/banners/posters/76389-1.jpg')
                add_posts({'title' : 'Human Planet',}, index, mode='newznab&newznab=27134')
                add_posts({'title' : 'Hunted',}, index, mode='newznab&newznab=32213',thumb='http://thetvdb.com/banners/posters/259702-1.jpg')
                add_posts({'title' : 'Hustle',}, index, mode='newznab&newznab=1281',thumb='http://thetvdb.com/banners/posters/73028-1.jpg')
                add_posts({'title' : 'Imagine UK',}, index, mode='newznab&newznab=11237')
                add_posts({'title' : 'In With The Flynns',}, index, mode='newznab&newznab=28420',thumb='http://thetvdb.com/banners/posters/249242-1.jpg')
                add_posts({'title' : 'Inside Men',}, index, mode='newznab&newznab=30663',thumb='http://thetvdb.com/banners/posters/255507-1.jpg')
                add_posts({'title' : 'Inside Out',}, index, mode='newznab&newznab=8213',thumb='http://thetvdb.com/banners/posters/77005-1.jpg')
                add_posts({'title' : 'Inside The Human Body',}, index, mode='newznab&newznab=28100',thumb='http://thetvdb.com/banners/posters/248516-1.jpg')
                add_posts({'title' : 'Jane Eyre 1983',}, index, mode='newznab&newznab=15068',thumb='http://thetvdb.com/banners/posters/86781-1.jpg')
                add_posts({'title' : 'John Bishops Big Year',}, index, mode='newznab&newznab=33499',thumb='http://thetvdb.com/banners/posters/264501-1.jpg')
                add_posts({'title' : 'John Bishops Britain',}, index, mode='newznab&newznab=26180',thumb='http://thetvdb.com/banners/posters/178481-1.jpg')
                add_posts({'title' : 'Jonathan Creek',}, index, mode='newznab&newznab=4073',thumb='http://thetvdb.com/banners/posters/75033-1.jpg')
                add_posts({'title' : 'Judge John Deed',}, index, mode='newznab&newznab=785',thumb='http://thetvdb.com/banners/posters/79120-1.jpg')
                add_posts({'title' : 'Just William 2010',}, index, mode='newznab&newznab=27077',thumb='http://thetvdb.com/banners/posters/215781-1.jpg')
                add_posts({'title' : 'Keeping Up Appearances',}, index, mode='newznab&newznab=64',thumb='http://thetvdb.com/banners/posters/78079-1.jpg')
                add_posts({'title' : 'Kevin Bridges Whats The Story',}, index, mode='newznab&newznab=30720',thumb='http://thetvdb.com/banners/posters/255987-1.jpg')
                add_posts({'title' : 'Land Girls',}, index, mode='newznab&newznab=23712',thumb='http://thetvdb.com/banners/posters/112871-1.jpg')
                add_posts({'title' : 'Lark Rise To Candleford',}, index, mode='newznab&newznab=17974',thumb='http://thetvdb.com/banners/posters/81161-1.jpg')
                add_posts({'title' : 'Last Of The Summer Wine',}, index, mode='newznab&newznab=1877',thumb='http://thetvdb.com/banners/posters/77945-1.jpg')
                add_posts({'title' : 'Last Tango In Halifax',}, index, mode='newznab&newznab=32658',thumb='http://thetvdb.com/banners/posters/264185-1.jpg')
                add_posts({'title' : 'Lee Macks All Star Cast',}, index, mode='newznab&newznab=28629',thumb='http://thetvdb.com/banners/posters/249619-1.jpg')
                add_posts({'title' : 'Lets Dance For Comic Relief',}, index, mode='newznab&newznab=21815',thumb='http://thetvdb.com/banners/posters/237621-1.jpg')
                add_posts({'title' : 'Life Of Riley 2008',}, index, mode='newznab&newznab=20910',thumb='http://thetvdb.com/banners/posters/84483-1.jpg')
                add_posts({'title' : 'Life On Mars UK',}, index, mode='newznab&newznab=7158')
                add_posts({'title' : 'Life UK',}, index, mode='newznab&newznab=23271')
                add_posts({'title' : 'Lilies',}, index, mode='newznab&newznab=12739',thumb='http://thetvdb.com/banners/posters/80582-1.jpg')
                add_posts({'title' : 'Live At The Apollo',}, index, mode='newznab&newznab=17842',thumb='http://thetvdb.com/banners/posters/80905-1.jpg')
                add_posts({'title' : 'Lost Land Of The Jaguar',}, index, mode='newznab&newznab=19639',thumb='http://thetvdb.com/banners/posters/82715-1.jpg')
                add_posts({'title' : 'Lost Land Of The Tiger',}, index, mode='newznab&newznab=26573',thumb='http://thetvdb.com/banners/posters/191491-1.jpg')
                add_posts({'title' : 'Lost Land Of The Volcano',}, index, mode='newznab&newznab=23777',thumb='http://thetvdb.com/banners/posters/112631-1.jpg')
                add_posts({'title' : 'Love Soup',}, index, mode='newznab&newznab=4303',thumb='http://thetvdb.com/banners/posters/78964-1.jpg')
                add_posts({'title' : 'Lovejoy',}, index, mode='newznab&newznab=4301',thumb='http://thetvdb.com/banners/posters/71764-1.jpg')
                add_posts({'title' : 'Luther',}, index, mode='newznab&newznab=25522',thumb='http://thetvdb.com/banners/posters/159591-1.jpg')
                add_posts({'title' : 'Madame Bovary',}, index, mode='newznab&newznab=13245',thumb='http://thetvdb.com/banners/posters/116841-1.jpg')
                add_posts({'title' : 'Maid Marian And Her Merry Men',}, index, mode='newznab&newznab=4340',thumb='http://thetvdb.com/banners/posters/78765-1.jpg')
                add_posts({'title' : 'Me And Mrs Jones',}, index, mode='newznab&newznab=32947',thumb='http://thetvdb.com/banners/posters/263209-1.jpg')
                add_posts({'title' : 'Merlin 2008',}, index, mode='newznab&newznab=18834',thumb='http://thetvdb.com/banners/posters/83123-1.jpg')
                add_posts({'title' : 'Michael McIntyres Comedy Roadshow',}, index, mode='newznab&newznab=22905',thumb='http://thetvdb.com/banners/posters/98151-1.jpg')
                add_posts({'title' : 'Miranda',}, index, mode='newznab&newznab=24313',thumb='http://thetvdb.com/banners/posters/123721-1.jpg')
                add_posts({'title' : 'Monarchy The Royal Family at Work',}, index, mode='newznab&newznab=17865',thumb='http://thetvdb.com/banners/posters/81136-1.jpg')
                add_posts({'title' : 'Moving On',}, index, mode='newznab&newznab=22613',thumb='http://thetvdb.com/banners/posters/94941-1.jpg')
                add_posts({'title' : 'Mrs Browns Boys',}, index, mode='newznab&newznab=27551',thumb='http://thetvdb.com/banners/posters/219631-1.jpg')
                add_posts({'title' : 'Murder in Mind',}, index, mode='newznab&newznab=4556',thumb='http://thetvdb.com/banners/posters/77978-1.jpg')
                add_posts({'title' : 'My Family',}, index, mode='newznab&newznab=4574',thumb='http://thetvdb.com/banners/posters/74438-1.jpg')
                add_posts({'title' : 'National Treasures Live',}, index, mode='newznab&newznab=29054',thumb='http://thetvdb.com/banners/posters/251403-1.jpg')
                add_posts({'title' : 'Natures Great Events',}, index, mode='newznab&newznab=21608',thumb='http://thetvdb.com/banners/posters/85083-1.jpg')
                add_posts({'title' : 'Natures Miracle Babies',}, index, mode='newznab&newznab=27634',thumb='http://thetvdb.com/banners/posters/251632-1.jpg')
                add_posts({'title' : 'Neighbourhood Watched',}, index, mode='newznab&newznab=23455',thumb='http://thetvdb.com/banners/posters/111721-1.jpg')
                add_posts({'title' : 'New Tricks',}, index, mode='newznab&newznab=4652',thumb='http://thetvdb.com/banners/posters/78823-1.jpg')
                add_posts({'title' : 'Nick Nickleby',}, index, mode='newznab&newznab=33332',thumb='http://thetvdb.com/banners/posters/263882-1.jpg')
                add_posts({'title' : 'Nigel Slaters Simple Cooking',}, index, mode='newznab&newznab=29491',thumb='http://thetvdb.com/banners/posters/252129-1.jpg')
                add_posts({'title' : 'Nigel Slaters Simple Suppers',}, index, mode='newznab&newznab=23779',thumb='http://thetvdb.com/banners/posters/113201-1.jpg')
                add_posts({'title' : 'Noise Squad',}, index, mode='newznab&newznab=30150',thumb='http://thetvdb.com/banners/posters/254360-1.jpg')
                add_posts({'title' : 'Not Going Out',}, index, mode='newznab&newznab=10792',thumb='http://thetvdb.com/banners/posters/80411-1.jpg')
                add_posts({'title' : 'Ocean Giants',}, index, mode='newznab&newznab=29140',thumb='http://thetvdb.com/banners/posters/251041-1.jpg')
                add_posts({'title' : 'One Night',}, index, mode='newznab&newznab=31091',thumb='http://thetvdb.com/banners/posters/257487-1.jpg')
                add_posts({'title' : 'Only Fools And Horses',}, index, mode='newznab&newznab=4727',thumb='http://thetvdb.com/banners/posters/75628-1.jpg')
                add_posts({'title' : 'Outcasts',}, index, mode='newznab&newznab=26356',thumb='http://thetvdb.com/banners/posters/185251-1.jpg')
                add_posts({'title' : 'Outnumbered',}, index, mode='newznab&newznab=17215',thumb='http://thetvdb.com/banners/posters/80592-1.jpg')
                add_posts({'title' : 'Panorama',}, index, mode='newznab&newznab=10101',thumb='http://thetvdb.com/banners/posters/80748-1.jpg')
                add_posts({'title' : 'Parents Of The Band',}, index, mode='newznab&newznab=20142',thumb='http://thetvdb.com/banners/posters/84134-1.jpg')
                add_posts({'title' : 'Pie In The Sky',}, index, mode='newznab&newznab=4824',thumb='http://thetvdb.com/banners/posters/71762-1.jpg')
                add_posts({'title' : 'Planet Dinosaur',}, index, mode='newznab&newznab=29344',thumb='http://thetvdb.com/banners/posters/251542-1.jpg')
                add_posts({'title' : 'Planet Earth Live',}, index, mode='newznab&newznab=31475',thumb='http://thetvdb.com/banners/posters/258788-1.jpg')
                add_posts({'title' : 'Planet Earth',}, index, mode='newznab&newznab=8077',thumb='http://thetvdb.com/banners/posters/79257-1.jpg')
                add_posts({'title' : 'Playing The Field',}, index, mode='newznab&newznab=1909',thumb='http://thetvdb.com/banners/posters/78141-1.jpg')
                add_posts({'title' : 'Prisoners Wives',}, index, mode='newznab&newznab=30664',thumb='http://thetvdb.com/banners/posters/255677-1.jpg')
                add_posts({'title' : 'Public Enemies',}, index, mode='newznab&newznab=27901',thumb='http://thetvdb.com/banners/posters/253073-1.jpg')
                add_posts({'title' : 'Richard Hammonds Invisible Worlds',}, index, mode='newznab&newznab=25272',thumb='http://thetvdb.com/banners/posters/149731-1.jpg')
                add_posts({'title' : 'Richard Hammonds Journey To The',}, index, mode='newznab&newznab=28893')
                add_posts({'title' : 'Richard Hammonds Miracles Of Nature',}, index, mode='newznab&newznab=33253',thumb='http://thetvdb.com/banners/posters/263889-1.jpg')
                add_posts({'title' : 'Rip Off Britain',}, index, mode='newznab&newznab=24342')
                add_posts({'title' : 'Robbed Raided Reunited',}, index, mode='newznab&newznab=31454')
                add_posts({'title' : 'Robin Hood',}, index, mode='newznab&newznab=10436',thumb='http://thetvdb.com/banners/posters/79479-1.jpg')
                add_posts({'title' : 'Rock And Chips',}, index, mode='newznab&newznab=23432',thumb='http://thetvdb.com/banners/posters/137591-1.jpg')
                add_posts({'title' : 'Room 101',}, index, mode='newznab&newznab=5050',thumb='http://thetvdb.com/banners/posters/73765-1.jpg')
                add_posts({'title' : 'Saints And Scroungers',}, index, mode='newznab&newznab=23542',thumb='http://thetvdb.com/banners/posters/255434-1.jpg')
                add_posts({'title' : 'Saturday Kitchen',}, index, mode='newznab&newznab=11092',thumb='http://thetvdb.com/banners/posters/85284-1.jpg')
                add_posts({'title' : 'See You In Court',}, index, mode='newznab&newznab=27797',thumb='http://thetvdb.com/banners/posters/247731-1.jpg')
                add_posts({'title' : 'Shaun The Sheep',}, index, mode='newznab&newznab=15251',thumb='http://thetvdb.com/banners/posters/79890-1.jpg')
                add_posts({'title' : 'Sherlock',}, index, mode='newznab&newznab=23433',thumb='http://thetvdb.com/banners/posters/176941-1.jpg')
                add_posts({'title' : 'Shoestring',}, index, mode='newznab&newznab=5186',thumb='http://thetvdb.com/banners/posters/77175-1.jpg')
                add_posts({'title' : 'Silent Witness',}, index, mode='newznab&newznab=5199',thumb='http://thetvdb.com/banners/posters/76355-1.jpg')
                add_posts({'title' : 'Silk',}, index, mode='newznab&newznab=27552',thumb='http://thetvdb.com/banners/posters/188011-1.jpg')
                add_posts({'title' : 'Snow Babies',}, index, mode='newznab&newznab=33653',thumb='http://thetvdb.com/banners/posters/265006-1.jpg')
                add_posts({'title' : 'So You Think You Can Dance UK',}, index, mode='newznab&newznab=24566',thumb='http://thetvdb.com/banners/posters/132481-1.jpg')
                add_posts({'title' : 'Some Mothers Do Ave Em',}, index, mode='newznab&newznab=1665',thumb='http://thetvdb.com/banners/posters/77043-1.jpg')
                add_posts({'title' : 'Songs Of Praise',}, index, mode='newznab&newznab=8283',thumb='http://thetvdb.com/banners/posters/264577-1.jpg')
                add_posts({'title' : 'Sorry',}, index, mode='newznab&newznab=5259',thumb='http://thetvdb.com/banners/posters/70542-1.jpg')
                add_posts({'title' : 'South Riding',}, index, mode='newznab&newznab=27550',thumb='http://thetvdb.com/banners/posters/232471-1.jpg')
                add_posts({'title' : 'Spooks',}, index, mode='newznab&newznab=4458',thumb='http://thetvdb.com/banners/posters/78890-1.jpg')
                add_posts({'title' : 'State of Play',}, index, mode='newznab&newznab=5343',thumb='http://thetvdb.com/banners/posters/80383-1.jpg')
                add_posts({'title' : 'Striclty Come Dancing',}, index, mode='newznab&newznab=6747',thumb='http://thetvdb.com/banners/posters/83127-1.jpg')
                add_posts({'title' : 'Strictly Come Dancing',}, index, mode='newznab&newznab=6747',thumb='http://thetvdb.com/banners/posters/83127-1.jpg')
                add_posts({'title' : 'Stuck On Sheep Mountain',}, index, mode='newznab&newznab=28810')
                add_posts({'title' : 'Sugartown',}, index, mode='newznab&newznab=28950',thumb='http://thetvdb.com/banners/posters/250460-1.jpg')
                add_posts({'title' : 'Super Smart Animals',}, index, mode='newznab&newznab=30768',thumb='http://thetvdb.com/banners/posters/256005-1.jpg')
                add_posts({'title' : 'Supersize Ambulance',}, index, mode='newznab&newznab=28305')
                add_posts({'title' : 'Supersized Earth',}, index, mode='newznab&newznab=33407',thumb='http://thetvdb.com/banners/posters/264268-1.jpg')
                add_posts({'title' : 'Terry Wogans Ireland',}, index, mode='newznab&newznab=27413')
                add_posts({'title' : 'Thats Britain',}, index, mode='newznab&newznab=30135',thumb='http://thetvdb.com/banners/posters/254610-1.jpg')
                add_posts({'title' : 'The Adventures Of Spot',}, index, mode='newznab&newznab=5544',thumb='http://thetvdb.com/banners/posters/99961-1.jpg')
                add_posts({'title' : 'The Apprentice UK',}, index, mode='newznab&newznab=5582',thumb='http://thetvdb.com/banners/posters/75795-1.jpg')
                add_posts({'title' : 'The Boat That Guy Built',}, index, mode='newznab&newznab=27627',thumb='http://thetvdb.com/banners/posters/236551-1.jpg')
                add_posts({'title' : 'The Body Farm',}, index, mode='newznab&newznab=29345',thumb='http://thetvdb.com/banners/posters/251676-1.jpg')
                add_posts({'title' : 'The Bomb Squad',}, index, mode='newznab&newznab=29346',thumb='http://thetvdb.com/banners/posters/251876-1.jpg')
                add_posts({'title' : 'The Chronicles Of Narnia',}, index, mode='newznab&newznab=7958',thumb='http://thetvdb.com/banners/posters/78930-1.jpg')
                add_posts({'title' : 'The Clangers',}, index, mode='newznab&newznab=13535',thumb='http://thetvdb.com/banners/posters/79166-1.jpg')
                add_posts({'title' : 'The Diamond Queen',}, index, mode='newznab&newznab=30718',thumb='http://thetvdb.com/banners/posters/255921-1.jpg')
                add_posts({'title' : 'The Fast Show',}, index, mode='newznab&newznab=5775',thumb='http://thetvdb.com/banners/posters/70415-1.jpg')
                add_posts({'title' : 'The Field Of Blood',}, index, mode='newznab&newznab=29206',thumb='http://thetvdb.com/banners/posters/248620-1.jpg')
                add_posts({'title' : 'The Flowerpot Gang',}, index, mode='newznab&newznab=32372',thumb='http://thetvdb.com/banners/posters/261514-1.jpg')
                add_posts({'title' : 'The Good Cook',}, index, mode='newznab&newznab=28704',thumb='http://thetvdb.com/banners/posters/250063-1.jpg')
                add_posts({'title' : 'The Graham Norton Show',}, index, mode='newznab&newznab=15181',thumb='http://thetvdb.com/banners/posters/80660-1.jpg')
                add_posts({'title' : 'The Great British Countryside',}, index, mode='newznab&newznab=30843',thumb='http://thetvdb.com/banners/posters/256305-1.jpg')
                add_posts({'title' : 'The Great British Weather',}, index, mode='newznab&newznab=28813',thumb='http://thetvdb.com/banners/posters/251673-1.jpg')
                add_posts({'title' : 'The Impressionists',}, index, mode='newznab&newznab=10750',thumb='http://thetvdb.com/banners/posters/196371-1.jpg')
                add_posts({'title' : 'The Impressions Show With Culshaw And Stephenson',}, index, mode='newznab&newznab=24240',thumb='http://thetvdb.com/banners/posters/121991-1.jpg')
                add_posts({'title' : 'The Indian Doctor',}, index, mode='newznab&newznab=26854',thumb='http://thetvdb.com/banners/posters/205731-1.jpg')
                add_posts({'title' : 'The Inspector Lynley Mysteries',}, index, mode='newznab&newznab=3972',thumb='http://thetvdb.com/banners/posters/78774-1.jpg')
                add_posts({'title' : 'The Magicians 2011',}, index, mode='newznab&newznab=27130')
                add_posts({'title' : 'The Manor Reborn',}, index, mode='newznab&newznab=30136',thumb='http://thetvdb.com/banners/posters/253899-1.jpg')
                add_posts({'title' : 'The Matt Lucas Awards',}, index, mode='newznab&newznab=31250',thumb='http://thetvdb.com/banners/posters/258047-1.jpg')
                add_posts({'title' : 'The One Lenny Henry',}, index, mode='newznab&newznab=30389')
                add_posts({'title' : 'The Onedin Line',}, index, mode='newznab&newznab=943',thumb='http://thetvdb.com/banners/posters/71978-1.jpg')
                add_posts({'title' : 'The Paradise',}, index, mode='newznab&newznab=32796',thumb='http://thetvdb.com/banners/posters/262585-1.jpg')
                add_posts({'title' : 'The Queens Palaces',}, index, mode='newznab&newznab=29382',thumb='http://thetvdb.com/banners/posters/251851-1.jpg')
                add_posts({'title' : 'The Royal Bodyguard',}, index, mode='newznab&newznab=30236',thumb='http://thetvdb.com/banners/posters/254219-1.jpg')
                add_posts({'title' : 'The Sarah Jane Adventures',}, index, mode='newznab&newznab=13365',thumb='http://thetvdb.com/banners/posters/79708-1.jpg')
                add_posts({'title' : 'The Secret of Crickley Hall',}, index, mode='newznab&newznab=33355',thumb='http://thetvdb.com/banners/posters/262242-1.jpg')
                add_posts({'title' : 'The Sins',}, index, mode='newznab&newznab=29147',thumb='http://thetvdb.com/banners/posters/247884-1.jpg')
                add_posts({'title' : 'The Street',}, index, mode='newznab&newznab=10292',thumb='http://thetvdb.com/banners/posters/81015-1.jpg')
                add_posts({'title' : 'The Syndicate',}, index, mode='newznab&newznab=10853',thumb='http://thetvdb.com/banners/posters/253485-1.jpg')
                add_posts({'title' : 'The Thin Blue Line',}, index, mode='newznab&newznab=6233',thumb='http://thetvdb.com/banners/posters/76753-1.jpg')
                add_posts({'title' : 'The Town That Never Retired',}, index, mode='newznab&newznab=32035',thumb='http://thetvdb.com/banners/posters/260702-1.jpg')
                add_posts({'title' : 'The Two Ronnies',}, index, mode='newznab&newznab=426',thumb='http://thetvdb.com/banners/posters/76590-1.jpg')
                add_posts({'title' : 'The Voice UK',}, index, mode='newznab&newznab=28668',thumb='http://thetvdb.com/banners/posters/257313-1.jpg')
                add_posts({'title' : 'Titanic with Len Goodman',}, index, mode='newznab&newznab=31113',thumb='http://thetvdb.com/banners/posters/257730-1.jpg')
                add_posts({'title' : 'Torchwood',}, index, mode='newznab&newznab=6993',thumb='http://thetvdb.com/banners/posters/79511-1.jpg')
                add_posts({'title' : 'Total Wipeout',}, index, mode='newznab&newznab=20835',thumb='http://thetvdb.com/banners/posters/84352-1.jpg')
                add_posts({'title' : 'Traffic Cops',}, index, mode='newznab&newznab=10931',thumb='http://thetvdb.com/banners/posters/84218-1.jpg')
                add_posts({'title' : 'tricky business',}, index, mode='newznab&newznab=9926',thumb='http://thetvdb.com/banners/posters/255592-1.jpg')
                add_posts({'title' : 'True Dare Kiss',}, index, mode='newznab&newznab=15124',thumb='http://thetvdb.com/banners/posters/81017-1.jpg')
                add_posts({'title' : 'True Love',}, index, mode='newznab&newznab=31003',thumb='http://thetvdb.com/banners/posters/259280-1.jpg')
                add_posts({'title' : 'Turn Back Time 2010',}, index, mode='newznab&newznab=26821')
                add_posts({'title' : 'Upstairs Downstairs 2010',}, index, mode='newznab&newznab=27014',thumb='http://thetvdb.com/banners/posters/214921-1.jpg')
                add_posts({'title' : 'village sos',}, index, mode='newznab&newznab=29053',thumb='http://thetvdb.com/banners/posters/251039-1.jpg')
                add_posts({'title' : 'Waking The Dead',}, index, mode='newznab&newznab=6533',thumb='http://thetvdb.com/banners/posters/79053-1.jpg')
                add_posts({'title' : 'Wallander',}, index, mode='newznab&newznab=18175',thumb='http://thetvdb.com/banners/posters/82505-1.jpg')
                add_posts({'title' : 'Wanted Down Under',}, index, mode='newznab&newznab=15198',thumb='http://thetvdb.com/banners/posters/84491-1.jpg')
                add_posts({'title' : 'Warship',}, index, mode='newznab&newznab=12515',thumb='http://thetvdb.com/banners/posters/82181-1.jpg')
                add_posts({'title' : 'Watchdog Daily',}, index, mode='newznab&newznab=33380',thumb='http://thetvdb.com/banners/posters/264158-1.jpg')
                add_posts({'title' : 'Watchdog',}, index, mode='newznab&newznab=7963',thumb='http://thetvdb.com/banners/posters/80762-1.jpg')
                add_posts({'title' : 'Waterloo Road',}, index, mode='newznab&newznab=8531',thumb='http://thetvdb.com/banners/posters/80763-1.jpg')
                add_posts({'title' : 'Wessex Tales',}, index, mode='newznab&newznab=13164',thumb='http://thetvdb.com/banners/posters/77902-1.jpg')
                add_posts({'title' : 'Whats Really In Our Food',}, index, mode='newznab&newznab=23856',thumb='http://thetvdb.com/banners/posters/112791-1.jpg')
                add_posts({'title' : 'Who Do You Think You Are UK',}, index, mode='newznab&newznab=7436')
                add_posts({'title' : 'Would I Lie To You',}, index, mode='newznab&newznab=16424',thumb='http://thetvdb.com/banners/posters/82548-1.jpg')
                add_posts({'title' : 'Young Herriot',}, index, mode='newznab&newznab=30235',thumb='http://thetvdb.com/banners/posters/254469-1.jpg')
                add_posts({'title' : 'Zen',}, index, mode='newznab&newznab=27129',thumb='http://thetvdb.com/banners/posters/216181-1.jpg')
            if newznab_id == 'BBC One Scotland':
                add_posts({'title' : 'Gary Tank Commander',}, index, mode='newznab&newznab=27347',thumb='http://thetvdb.com/banners/posters/124781-1.jpg')
            if newznab_id == 'BBC THREE':
                add_posts({'title' : '24 Hour Panel People',}, index, mode='newznab&newznab=27717')
                add_posts({'title' : 'Bad Education',}, index, mode='newznab&newznab=32413',thumb='http://thetvdb.com/banners/posters/261277-1.jpg')
                add_posts({'title' : 'Being Human UK',}, index, mode='newznab&newznab=18434')
                add_posts({'title' : 'Bizarre Crime',}, index, mode='newznab&newznab=30460',thumb='http://thetvdb.com/banners/posters/255212-1.jpg')
                add_posts({'title' : 'Bizarre ER',}, index, mode='newznab&newznab=22329',thumb='http://thetvdb.com/banners/posters/102391-1.jpg')
                add_posts({'title' : 'Botox Britain',}, index, mode='newznab&newznab=27867')
                add_posts({'title' : 'Cannabis Whats The Harm',}, index, mode='newznab&newznab=27646',thumb='http://thetvdb.com/banners/posters/226201-1.jpg')
                add_posts({'title' : 'Cherry Healey How To Get A Life',}, index, mode='newznab&newznab=31830',thumb='http://thetvdb.com/banners/posters/260371-1.jpg')
                add_posts({'title' : 'Coming Of Age UK',}, index, mode='newznab&newznab=20167')
                add_posts({'title' : 'Cuckoo',}, index, mode='newznab&newznab=32811',thumb='http://thetvdb.com/banners/posters/262558-1.jpg')
                add_posts({'title' : 'Dead Boss',}, index, mode='newznab&newznab=30960',thumb='http://thetvdb.com/banners/posters/259808-1.jpg')
                add_posts({'title' : 'Doctor Who Confidential',}, index, mode='newznab&newznab=3333',thumb='http://thetvdb.com/banners/posters/79298-1.jpg')
                add_posts({'title' : 'DogTown',}, index, mode='newznab&newznab=12780',thumb='http://thetvdb.com/banners/posters/161541-1.jpg')
                add_posts({'title' : 'Dont Blame The Dog',}, index, mode='newznab&newznab=31256',thumb='http://thetvdb.com/banners/posters/258078-1.jpg')
                add_posts({'title' : 'Dont Tell The Bride',}, index, mode='newznab&newznab=17776',thumb='http://thetvdb.com/banners/posters/81243-1.jpg')
                add_posts({'title' : 'Geordie Finishing School For Girls',}, index, mode='newznab&newznab=29043',thumb='http://thetvdb.com/banners/posters/250527-1.jpg')
                add_posts({'title' : 'Him And Her',}, index, mode='newznab&newznab=26478',thumb='http://thetvdb.com/banners/posters/187801-1.jpg')
                add_posts({'title' : 'Hot Like Us',}, index, mode='newznab&newznab=29883')
                add_posts({'title' : 'Hotter Than My Daughter',}, index, mode='newznab&newznab=24986',thumb='http://thetvdb.com/banners/posters/139661-1.jpg')
                add_posts({'title' : 'How Drugs Work',}, index, mode='newznab&newznab=27156',thumb='http://thetvdb.com/banners/posters/218991-1.jpg')
                add_posts({'title' : 'How Not To Live Your Life',}, index, mode='newznab&newznab=19838',thumb='http://thetvdb.com/banners/posters/82825-1.jpg')
                add_posts({'title' : 'How Sex Works',}, index, mode='newznab&newznab=30436',thumb='http://thetvdb.com/banners/posters/255064-1.jpg')
                add_posts({'title' : 'How To Live With Women',}, index, mode='newznab&newznab=27625')
                add_posts({'title' : 'Ideal',}, index, mode='newznab&newznab=2073',thumb='http://thetvdb.com/banners/posters/74345-1.jpg')
                add_posts({'title' : 'Junior Doctors Your Life In Their Hands',}, index, mode='newznab&newznab=27510')
                add_posts({'title' : 'Kids Behind Bars',}, index, mode='newznab&newznab=28594',thumb='http://thetvdb.com/banners/posters/249498-1.jpg')
                add_posts({'title' : 'Kill It Cut It Use It',}, index, mode='newznab&newznab=28569',thumb='http://thetvdb.com/banners/posters/249502-1.jpg')
                add_posts({'title' : 'Lee Nelsons Well Good Show',}, index, mode='newznab&newznab=25872',thumb='http://thetvdb.com/banners/posters/187201-1.jpg')
                add_posts({'title' : 'Lip Service',}, index, mode='newznab&newznab=26673',thumb='http://thetvdb.com/banners/posters/197231-1.jpg')
                add_posts({'title' : 'Live At The Electric',}, index, mode='newznab&newznab=31714',thumb='http://thetvdb.com/banners/posters/259547-1.jpg')
                add_posts({'title' : 'Lunch Monkeys',}, index, mode='newznab&newznab=23715',thumb='http://thetvdb.com/banners/posters/113301-1.jpg')
                add_posts({'title' : 'Misbehaving Mums To Be',}, index, mode='newznab&newznab=27865',thumb='http://thetvdb.com/banners/posters/248882-1.jpg')
                add_posts({'title' : 'Mongrels',}, index, mode='newznab&newznab=25870',thumb='http://thetvdb.com/banners/posters/171481-1.jpg')
                add_posts({'title' : 'Our War',}, index, mode='newznab&newznab=28419',thumb='http://thetvdb.com/banners/posters/249353-1.jpg')
                add_posts({'title' : 'Pramface',}, index, mode='newznab&newznab=30844',thumb='http://thetvdb.com/banners/posters/256383-1.jpg')
                add_posts({'title' : 'Riots And Revolutions Nels Arab Journey',}, index, mode='newznab&newznab=30919')
                add_posts({'title' : 'Russell Howards Good News UK',}, index, mode='newznab&newznab=24140',thumb='http://thetvdb.com/banners/posters/120541-1.jpg')
                add_posts({'title' : 'Russell Howards Good News',}, index, mode='newznab&newznab=24140',thumb='http://thetvdb.com/banners/posters/120541-1.jpg')
                add_posts({'title' : 'Secrets Of The Superbrands',}, index, mode='newznab&newznab=28394',thumb='http://thetvdb.com/banners/posters/248826-1.jpg')
                add_posts({'title' : 'Small Teen Bigger World',}, index, mode='newznab&newznab=29209',thumb='http://thetvdb.com/banners/posters/250271-1.jpg')
                add_posts({'title' : 'Snog Marry Avoid',}, index, mode='newznab&newznab=19318',thumb='http://thetvdb.com/banners/posters/82609-1.jpg')
                add_posts({'title' : 'Some Girls',}, index, mode='newznab&newznab=33333',thumb='http://thetvdb.com/banners/posters/263921-1.jpg')
                add_posts({'title' : 'Stacey Dooley In The USA',}, index, mode='newznab&newznab=32427',thumb='http://thetvdb.com/banners/posters/263706-1.jpg')
                add_posts({'title' : 'Strictly Soulmates',}, index, mode='newznab&newznab=30667',thumb='http://thetvdb.com/banners/posters/255582-1.jpg')
                add_posts({'title' : 'Sun Sex And Suspicious Parents',}, index, mode='newznab&newznab=27157',thumb='http://thetvdb.com/banners/posters/218161-1.jpg')
                add_posts({'title' : 'The Career Crashers',}, index, mode='newznab&newznab=30459')
                add_posts({'title' : 'The Fades',}, index, mode='newznab&newznab=28456',thumb='http://thetvdb.com/banners/posters/251539-1.jpg')
                add_posts({'title' : 'The Lock Up UK',}, index, mode='newznab&newznab=27470')
                add_posts({'title' : 'The Nearlyweds',}, index, mode='newznab&newznab=30375')
                add_posts({'title' : 'The Pranker',}, index, mode='newznab&newznab=28895',thumb='http://thetvdb.com/banners/posters/250272-1.jpg')
                add_posts({'title' : 'The Real Hustle UK',}, index, mode='newznab&newznab=8179')
                add_posts({'title' : 'The Undercover Princes',}, index, mode='newznab&newznab=21017')
                add_posts({'title' : 'The Worlds Strictest Parents AU',}, index, mode='newznab&newznab=23796',thumb='http://thetvdb.com/banners/posters/83115-1.jpg')
                add_posts({'title' : 'The Worlds Strictest Parents UK',}, index, mode='newznab&newznab=23796',thumb='http://thetvdb.com/banners/posters/83115-1.jpg')
                add_posts({'title' : 'Tourettes Let Me Entertain You',}, index, mode='newznab&newznab=32657',thumb='http://thetvdb.com/banners/posters/262352-1.jpg')
                add_posts({'title' : 'Two Pints Of Lager And A Packet Of Crisps',}, index, mode='newznab&newznab=6457',thumb='http://thetvdb.com/banners/posters/77215-1.jpg')
                add_posts({'title' : 'Underage And Pregnant',}, index, mode='newznab&newznab=23214',thumb='http://thetvdb.com/banners/posters/149971-1.jpg')
                add_posts({'title' : 'Unsafe Sex In The City',}, index, mode='newznab&newznab=32426',thumb='http://thetvdb.com/banners/posters/263600-1.jpg')
                add_posts({'title' : 'Working Girls',}, index, mode='newznab&newznab=27635')
                add_posts({'title' : 'Worlds Craziest Fools',}, index, mode='newznab&newznab=28488',thumb='http://thetvdb.com/banners/posters/249318-1.jpg')
                add_posts({'title' : 'Young Dumb And Living Off Mum',}, index, mode='newznab&newznab=23306',thumb='http://thetvdb.com/banners/posters/108171-1.jpg')
                add_posts({'title' : 'Young Rich And Househunting',}, index, mode='newznab&newznab=28146',thumb='http://thetvdb.com/banners/posters/249412-1.jpg')
                add_posts({'title' : 'Young Soldiers',}, index, mode='newznab&newznab=29261',thumb='http://thetvdb.com/banners/posters/252102-1.jpg')
            if newznab_id == 'BBC TWO':
                add_posts({'title' : 'A Farmers Life For Me',}, index, mode='newznab&newznab=27428')
                add_posts({'title' : 'A History Of Ancient Britain',}, index, mode='newznab&newznab=27091',thumb='http://thetvdb.com/banners/posters/217171-1.jpg')
                add_posts({'title' : 'A History Of Ancient Britian',}, index, mode='newznab&newznab=27091',thumb='http://thetvdb.com/banners/posters/217171-1.jpg')
                add_posts({'title' : 'A History Of Celtic Britain',}, index, mode='newznab&newznab=28636')
                add_posts({'title' : 'A History Of Celtic Britian',}, index, mode='newznab&newznab=28636')
                add_posts({'title' : 'A History Of Scotland',}, index, mode='newznab&newznab=20538',thumb='http://thetvdb.com/banners/posters/83785-1.jpg')
                add_posts({'title' : 'A South American Journey With Jonathan Dimbleby',}, index, mode='newznab&newznab=29486',thumb='http://thetvdb.com/banners/posters/251989-1.jpg')
                add_posts({'title' : 'A Year At Kew',}, index, mode='newznab&newznab=7293',thumb='http://thetvdb.com/banners/posters/74944-1.jpg')
                add_posts({'title' : 'Absolute Power',}, index, mode='newznab&newznab=1370',thumb='http://thetvdb.com/banners/posters/78894-1.jpg')
                add_posts({'title' : 'Alex Polizzi The Fixer',}, index, mode='newznab&newznab=30665',thumb='http://thetvdb.com/banners/posters/255740-1.jpg')
                add_posts({'title' : 'All Roads Lead Home',}, index, mode='newznab&newznab=29610',thumb='http://thetvdb.com/banners/posters/252535-1.jpg')
                add_posts({'title' : 'An Island Parish',}, index, mode='newznab&newznab=30705',thumb='http://thetvdb.com/banners/posters/82306-1.jpg')
                add_posts({'title' : 'Antiques Road Trip',}, index, mode='newznab&newznab=25222',thumb='http://thetvdb.com/banners/posters/259829-1.jpg')
                add_posts({'title' : 'Antiques To The Rescue',}, index, mode='newznab&newznab=32738',thumb='http://thetvdb.com/banners/posters/264602-1.jpg')
                add_posts({'title' : 'Antiques Uncovered',}, index, mode='newznab&newznab=31466',thumb='http://thetvdb.com/banners/posters/258686-1.jpg')
                add_posts({'title' : 'Arctic with Bruce Parry',}, index, mode='newznab&newznab=27080',thumb='http://thetvdb.com/banners/posters/217391-1.jpg')
                add_posts({'title' : 'Around The World In 80 Faiths',}, index, mode='newznab&newznab=20773',thumb='http://thetvdb.com/banners/posters/84336-1.jpg')
                add_posts({'title' : 'Arts Troubleshooter',}, index, mode='newznab&newznab=31807')
                add_posts({'title' : 'Attenborough 60 Years In The Wild',}, index, mode='newznab&newznab=33337',thumb='http://thetvdb.com/banners/posters/264173-1.jpg')
                add_posts({'title' : 'Attenboroughs Ark',}, index, mode='newznab&newznab=33255')
                add_posts({'title' : 'Autumnwatch Unsprung',}, index, mode='newznab&newznab=23917')
                add_posts({'title' : 'Autumnwatch',}, index, mode='newznab&newznab=12709',thumb='http://thetvdb.com/banners/posters/263685-1.jpg')
                add_posts({'title' : 'Baking Made Easy',}, index, mode='newznab&newznab=27135',thumb='http://thetvdb.com/banners/posters/220691-1.jpg')
                add_posts({'title' : 'Bees Butterflies And Blooms',}, index, mode='newznab&newznab=30769',thumb='http://thetvdb.com/banners/posters/255988-1.jpg')
                add_posts({'title' : 'Bellamys People',}, index, mode='newznab&newznab=24884',thumb='http://thetvdb.com/banners/posters/137041-1.jpg')
                add_posts({'title' : 'Bibles Buried Secrets',}, index, mode='newznab&newznab=27673',thumb='http://thetvdb.com/banners/posters/238211-1.jpg')
                add_posts({'title' : 'Big Train',}, index, mode='newznab&newznab=557',thumb='http://thetvdb.com/banners/posters/70680-1.jpg')
                add_posts({'title' : 'Brick By Brick Rebuilding Our Past',}, index, mode='newznab&newznab=31199',thumb='http://thetvdb.com/banners/posters/257916-1.jpg')
                add_posts({'title' : 'Britains Heritage Heroes',}, index, mode='newznab&newznab=30766',thumb='http://thetvdb.com/banners/posters/256054-1.jpg')
                add_posts({'title' : 'Britains Killer Roads',}, index, mode='newznab&newznab=30040',thumb='http://thetvdb.com/banners/posters/260009-1.jpg')
                add_posts({'title' : 'Britains Next Big Thing',}, index, mode='newznab&newznab=27864',thumb='http://thetvdb.com/banners/posters/247902-1.jpg')
                add_posts({'title' : 'Britains Secret Seas',}, index, mode='newznab&newznab=28168',thumb='http://thetvdb.com/banners/posters/248687-1.jpg')
                add_posts({'title' : 'Business Nightmares With Evan Davis',}, index, mode='newznab&newznab=28193')
                add_posts({'title' : 'Butterflies',}, index, mode='newznab&newznab=2944',thumb='http://thetvdb.com/banners/posters/76334-1.jpg')
                add_posts({'title' : 'Cant Take It With You',}, index, mode='newznab&newznab=27196')
                add_posts({'title' : 'Cash In The Celebrity Attic',}, index, mode='newznab&newznab=19382')
                add_posts({'title' : 'Celebrity Antiques Road Trip',}, index, mode='newznab&newznab=29810',thumb='http://thetvdb.com/banners/posters/253098-1.jpg')
                add_posts({'title' : 'Celebrity MasterChef',}, index, mode='newznab&newznab=12698',thumb='http://thetvdb.com/banners/posters/113701-1.jpg')
                add_posts({'title' : 'Chaplains Angels Of Mersey',}, index, mode='newznab&newznab=31150')
                add_posts({'title' : 'China On Four Wheels',}, index, mode='newznab&newznab=32482',thumb='http://thetvdb.com/banners/posters/262279-1.jpg')
                add_posts({'title' : 'Churchills Desert War The Road To El Alamein',}, index, mode='newznab&newznab=33331',thumb='http://thetvdb.com/banners/posters/264246-1.jpg')
                add_posts({'title' : 'City Lights',}, index, mode='newznab&newznab=8684',thumb='http://thetvdb.com/banners/posters/74542-1.jpg')
                add_posts({'title' : 'Class of',}, index, mode='newznab&newznab=10057')
                add_posts({'title' : 'Coast',}, index, mode='newznab&newznab=6819',thumb='http://thetvdb.com/banners/posters/80429-1.jpg')
                add_posts({'title' : 'Dara O Briains Science Club',}, index, mode='newznab&newznab=33254')
                add_posts({'title' : 'David Attenboroughs First Life',}, index, mode='newznab&newznab=26822')
                add_posts({'title' : 'Dead Good Job',}, index, mode='newznab&newznab=32539',thumb='http://thetvdb.com/banners/posters/262372-1.jpg')
                add_posts({'title' : 'Digging For Britain',}, index, mode='newznab&newznab=26333',thumb='http://thetvdb.com/banners/posters/182111-1.jpg')
                add_posts({'title' : 'Divine Women',}, index, mode='newznab&newznab=31255',thumb='http://thetvdb.com/banners/posters/258079-1.jpg')
                add_posts({'title' : 'Dragons Den UK',}, index, mode='newznab&newznab=6783')
                add_posts({'title' : 'Eggheads',}, index, mode='newznab&newznab=10668',thumb='http://thetvdb.com/banners/posters/73288-1.jpg')
                add_posts({'title' : 'Engineering Giants',}, index, mode='newznab&newznab=32203',thumb='http://thetvdb.com/banners/posters/260773-1.jpg')
                add_posts({'title' : 'Ewan McGregor Cold Chain Mission',}, index, mode='newznab&newznab=31459',thumb='http://thetvdb.com/banners/posters/258439-1.jpg')
                add_posts({'title' : 'Faulks On Fiction',}, index, mode='newznab&newznab=27468',thumb='http://thetvdb.com/banners/posters/230001-1.jpg')
                add_posts({'title' : 'Fawlty Towers',}, index, mode='newznab&newznab=3532',thumb='http://thetvdb.com/banners/posters/75932-1.jpg')
                add_posts({'title' : 'Felicity Kendals Indian Shakespeare Quest',}, index, mode='newznab&newznab=31575',thumb='http://thetvdb.com/banners/posters/259111-1.jpg')
                add_posts({'title' : 'Filthy Cities',}, index, mode='newznab&newznab=27807',thumb='http://thetvdb.com/banners/posters/247121-1.jpg')
                add_posts({'title' : 'Francescos Italy Top To Toe',}, index, mode='newznab&newznab=12255',thumb='http://thetvdb.com/banners/posters/83725-1.jpg')
                add_posts({'title' : 'Frank Skinner Opinionated',}, index, mode='newznab&newznab=25434',thumb='http://thetvdb.com/banners/posters/156971-1.jpg')
                add_posts({'title' : 'Frank Skinners Opinionated',}, index, mode='newznab&newznab=25434',thumb='http://thetvdb.com/banners/posters/156971-1.jpg')
                add_posts({'title' : 'Frontline Medicine',}, index, mode='newznab&newznab=30108',thumb='http://thetvdb.com/banners/posters/253771-1.jpg')
                add_posts({'title' : 'Frys planet Word',}, index, mode='newznab&newznab=27909',thumb='http://thetvdb.com/banners/posters/251804-1.jpg')
                add_posts({'title' : 'Gandhi',}, index, mode='newznab&newznab=23938',thumb='http://thetvdb.com/banners/posters/119151-1.jpg')
                add_posts({'title' : 'Grandmas House',}, index, mode='newznab&newznab=26269',thumb='http://thetvdb.com/banners/posters/181551-1.jpg')
                add_posts({'title' : 'Great Barrier Reef',}, index, mode='newznab&newznab=30428',thumb='http://thetvdb.com/banners/posters/254930-1.jpg')
                add_posts({'title' : 'Great British Food Revival',}, index, mode='newznab&newznab=27667',thumb='http://thetvdb.com/banners/posters/238671-1.jpg')
                add_posts({'title' : 'Great British Menu',}, index, mode='newznab&newznab=10272',thumb='http://thetvdb.com/banners/posters/81561-1.jpg')
                add_posts({'title' : 'Hairy Bikers Meals On Wheels',}, index, mode='newznab&newznab=29347')
                add_posts({'title' : 'Hairy Dieters How To Love Food And Lose Weight',}, index, mode='newznab&newznab=32320',thumb='http://thetvdb.com/banners/posters/261094-1.jpg')
                add_posts({'title' : 'Harry and Paul',}, index, mode='newznab&newznab=26593',thumb='http://thetvdb.com/banners/posters/264305-1.jpg')
                add_posts({'title' : 'Hebburn',}, index, mode='newznab&newznab=33058',thumb='http://thetvdb.com/banners/posters/263377-1.jpg')
                add_posts({'title' : 'Hilary Deveys Women At The Top',}, index, mode='newznab&newznab=32760',thumb='http://thetvdb.com/banners/posters/262233-1.jpg')
                add_posts({'title' : 'History Cold Case',}, index, mode='newznab&newznab=25526',thumb='http://thetvdb.com/banners/posters/161611-1.jpg')
                add_posts({'title' : 'History Of Celtic Britain',}, index, mode='newznab&newznab=28636')
                add_posts({'title' : 'Home Cooking Made Easy',}, index, mode='newznab&newznab=29490',thumb='http://thetvdb.com/banners/posters/252354-1.jpg')
                add_posts({'title' : 'Home Time',}, index, mode='newznab&newznab=23846',thumb='http://thetvdb.com/banners/posters/113891-1.jpg')
                add_posts({'title' : 'Horizon',}, index, mode='newznab&newznab=7864',thumb='http://thetvdb.com/banners/posters/74379-1.jpg')
                add_posts({'title' : 'How To Grow A Planet',}, index, mode='newznab&newznab=30847',thumb='http://thetvdb.com/banners/posters/255951-1.jpg')
                add_posts({'title' : 'How To Win In The Den',}, index, mode='newznab&newznab=29487')
                add_posts({'title' : 'How TV Ruined Your Life',}, index, mode='newznab&newznab=27422',thumb='http://thetvdb.com/banners/posters/225251-1.jpg')
                add_posts({'title' : 'Im Alan Partridge',}, index, mode='newznab&newznab=3937',thumb='http://thetvdb.com/banners/posters/76605-1.jpg')
                add_posts({'title' : 'India On Four Wheels',}, index, mode='newznab&newznab=29211',thumb='http://thetvdb.com/banners/posters/251231-1.jpg')
                add_posts({'title' : 'Indian Ocean With Simon Reeve',}, index, mode='newznab&newznab=31295',thumb='http://thetvdb.com/banners/posters/258409-1.jpg')
                add_posts({'title' : 'Inside Claridges',}, index, mode='newznab&newznab=33564',thumb='http://thetvdb.com/banners/posters/264600-1.jpg')
                add_posts({'title' : 'James Mays Man Lab',}, index, mode='newznab&newznab=26815',thumb='http://thetvdb.com/banners/posters/202351-1.jpg')
                add_posts({'title' : 'James Mays Things You Need To Know',}, index, mode='newznab&newznab=28638',thumb='http://thetvdb.com/banners/posters/249663-1.jpg')
                add_posts({'title' : 'Jimmys Farm',}, index, mode='newznab&newznab=8398')
                add_posts({'title' : 'Knowing Me Knowing You with Alan Partridge',}, index, mode='newznab&newznab=4151',thumb='http://thetvdb.com/banners/posters/76997-1.jpg')
                add_posts({'title' : 'KYTV',}, index, mode='newznab&newznab=4165',thumb='http://thetvdb.com/banners/posters/72453-1.jpg')
                add_posts({'title' : 'Lab Rats',}, index, mode='newznab&newznab=19371')
                add_posts({'title' : 'Lambing Live',}, index, mode='newznab&newznab=25217')
                add_posts({'title' : 'Last Chance to See',}, index, mode='newznab&newznab=23775',thumb='http://thetvdb.com/banners/posters/85453-1.jpg')
                add_posts({'title' : 'Later Live With Jools Holland',}, index, mode='newznab&newznab=18663')
                add_posts({'title' : 'Later With Jools Holland',}, index, mode='newznab&newznab=4196',thumb='http://thetvdb.com/banners/posters/72150-1.jpg')
                add_posts({'title' : 'Lead Balloon',}, index, mode='newznab&newznab=13922',thumb='http://thetvdb.com/banners/posters/79573-1.jpg')
                add_posts({'title' : 'Life In A Cottage Garden With Carol Klein',}, index, mode='newznab&newznab=27372',thumb='http://thetvdb.com/banners/posters/220861-1.jpg')
                add_posts({'title' : 'Lifes Too Short',}, index, mode='newznab&newznab=27158',thumb='http://thetvdb.com/banners/posters/249698-1.jpg')
                add_posts({'title' : 'Line Of Duty',}, index, mode='newznab&newznab=31935',thumb='http://thetvdb.com/banners/posters/260092-1.jpg')
                add_posts({'title' : 'Look Around You',}, index, mode='newznab&newznab=1176',thumb='http://thetvdb.com/banners/posters/72805-1.jpg')
                add_posts({'title' : 'Lorraines Fast Fresh And Easy Food',}, index, mode='newznab&newznab=32412')
                add_posts({'title' : 'Made In Britain',}, index, mode='newznab&newznab=28637',thumb='http://thetvdb.com/banners/posters/249662-1.jpg')
                add_posts({'title' : 'Marion and Geoff',}, index, mode='newznab&newznab=957',thumb='http://thetvdb.com/banners/posters/72066-1.jpg')
                add_posts({'title' : 'Mastercrafts',}, index, mode='newznab&newznab=25079',thumb='http://thetvdb.com/banners/posters/142071-1.jpg')
                add_posts({'title' : 'Masters Of Money',}, index, mode='newznab&newznab=32726',thumb='http://thetvdb.com/banners/posters/262505-1.jpg')
                add_posts({'title' : 'Meet The Romans With Mary Beard',}, index, mode='newznab&newznab=31266',thumb='http://thetvdb.com/banners/posters/258285-1.jpg')
                add_posts({'title' : 'Men Of Rock',}, index, mode='newznab&newznab=27197',thumb='http://thetvdb.com/banners/posters/209051-1.jpg')
                add_posts({'title' : 'Michel Rouxs Service',}, index, mode='newznab&newznab=27141',thumb='http://thetvdb.com/banners/posters/220521-1.jpg')
                add_posts({'title' : 'Mixed Britannia',}, index, mode='newznab&newznab=29489',thumb='http://thetvdb.com/banners/posters/252578-1.jpg')
                add_posts({'title' : 'Mock The Week',}, index, mode='newznab&newznab=7081',thumb='http://thetvdb.com/banners/posters/79761-1.jpg')
                add_posts({'title' : 'Modern Spies',}, index, mode='newznab&newznab=31179',thumb='http://thetvdb.com/banners/posters/257809-1.jpg')
                add_posts({'title' : 'Monty Dons Italian Gardens',}, index, mode='newznab&newznab=27935')
                add_posts({'title' : 'Monty Halls Great Irish Escape',}, index, mode='newznab&newznab=29089',thumb='http://thetvdb.com/banners/posters/251257-1.jpg')
                add_posts({'title' : 'Natural World',}, index, mode='newznab&newznab=6815',thumb='http://thetvdb.com/banners/posters/80987-1.jpg')
                add_posts({'title' : 'Natures Weirdest Events',}, index, mode='newznab&newznab=30589',thumb='http://thetvdb.com/banners/posters/254870-1.jpg')
                add_posts({'title' : 'Neil Morrissey Care Home kid',}, index, mode='newznab&newznab=27674')
                add_posts({'title' : 'Never Mind The Buzzcocks UK',}, index, mode='newznab&newznab=4641')
                add_posts({'title' : 'Nicholas Cranes Britannia The Great Elizabethan Journey',}, index, mode='newznab&newznab=20872')
                add_posts({'title' : 'Nigella Kitchen',}, index, mode='newznab&newznab=26623',thumb='http://thetvdb.com/banners/posters/194201-1.jpg')
                add_posts({'title' : 'Nigellissima',}, index, mode='newznab&newznab=32795',thumb='http://thetvdb.com/banners/posters/262677-1.jpg')
                add_posts({'title' : 'Operation Good Guys',}, index, mode='newznab&newznab=1713',thumb='http://thetvdb.com/banners/posters/77274-1.jpg')
                add_posts({'title' : 'Operation Iceberg',}, index, mode='newznab&newznab=33163',thumb='http://thetvdb.com/banners/posters/263736-1.jpg')
                add_posts({'title' : 'Operation Iceburg',}, index, mode='newznab&newznab=33163',thumb='http://thetvdb.com/banners/posters/263736-1.jpg')
                add_posts({'title' : 'Origins Of Us',}, index, mode='newznab&newznab=29711',thumb='http://thetvdb.com/banners/posters/252903-1.jpg')
                add_posts({'title' : 'Our Food',}, index, mode='newznab&newznab=31198',thumb='http://thetvdb.com/banners/posters/257868-1.jpg')
                add_posts({'title' : 'Oz And James Big Wine Adventure',}, index, mode='newznab&newznab=12369')
                add_posts({'title' : 'Oz And James Drink To Britain',}, index, mode='newznab&newznab=20871')
                add_posts({'title' : 'Parades End',}, index, mode='newznab&newznab=27900',thumb='http://thetvdb.com/banners/posters/261284-1.jpg')
                add_posts({'title' : 'Party Animals',}, index, mode='newznab&newznab=15100',thumb='http://thetvdb.com/banners/posters/80843-1.jpg')
                add_posts({'title' : 'Paul Mertons Birth Of Hollywood',}, index, mode='newznab&newznab=28323',thumb='http://thetvdb.com/banners/posters/249087-1.jpg')
                add_posts({'title' : 'Pingu',}, index, mode='newznab&newznab=2381',thumb='http://thetvdb.com/banners/posters/75669-1.jpg')
                add_posts({'title' : 'Prehistoric Autopsy',}, index, mode='newznab&newznab=33055',thumb='http://thetvdb.com/banners/posters/263512-1.jpg')
                add_posts({'title' : 'Protecting Our Children',}, index, mode='newznab&newznab=30666',thumb='http://thetvdb.com/banners/posters/255722-1.jpg')
                add_posts({'title' : 'Psychoville',}, index, mode='newznab&newznab=22870',thumb='http://thetvdb.com/banners/posters/99101-1.jpg')
                add_posts({'title' : 'Putin Russia And The West',}, index, mode='newznab&newznab=30414',thumb='http://thetvdb.com/banners/posters/255370-1.jpg')
                add_posts({'title' : 'QI',}, index, mode='newznab&newznab=4920',thumb='http://thetvdb.com/banners/posters/72716-1.jpg')
                add_posts({'title' : 'Rab C Nesbitt',}, index, mode='newznab&newznab=22274',thumb='http://thetvdb.com/banners/posters/70706-1.jpg')
                add_posts({'title' : 'Ray Mears Northern Wilderness',}, index, mode='newznab&newznab=24155',thumb='http://thetvdb.com/banners/posters/121491-1.jpg')
                add_posts({'title' : 'Raymond Blancs Kitchen Secrets',}, index, mode='newznab&newznab=25077',thumb='http://thetvdb.com/banners/posters/142271-1.jpg')
                add_posts({'title' : 'Restoration Home',}, index, mode='newznab&newznab=28705',thumb='http://thetvdb.com/banners/posters/249980-1.jpg')
                add_posts({'title' : 'Rev',}, index, mode='newznab&newznab=25915',thumb='http://thetvdb.com/banners/posters/172361-1.jpg')
                add_posts({'title' : 'Reverse Missionaries',}, index, mode='newznab&newznab=31030',thumb='http://thetvdb.com/banners/posters/257416-1.jpg')
                add_posts({'title' : 'Rex the Runt',}, index, mode='newznab&newznab=4996',thumb='http://thetvdb.com/banners/posters/77030-1.jpg')
                add_posts({'title' : 'Richard Hammond Engineering Connections',}, index, mode='newznab&newznab=21817',thumb='http://thetvdb.com/banners/posters/83165-1.jpg')
                add_posts({'title' : 'Richard Hammonds Engineering Connections',}, index, mode='newznab&newznab=21817',thumb='http://thetvdb.com/banners/posters/83165-1.jpg')
                add_posts({'title' : 'Rick Steins Far Eastern Odyssey',}, index, mode='newznab&newznab=23191',thumb='http://thetvdb.com/banners/posters/104701-1.jpg')
                add_posts({'title' : 'Rick Steins Spain',}, index, mode='newznab&newznab=28896',thumb='http://thetvdb.com/banners/posters/250196-1.jpg')
                add_posts({'title' : 'Roger And Val Have Just Got In',}, index, mode='newznab&newznab=26193',thumb='http://thetvdb.com/banners/posters/182291-1.jpg')
                add_posts({'title' : 'Ruby',}, index, mode='newznab&newznab=1800',thumb='http://thetvdb.com/banners/posters/77642-1.jpg')
                add_posts({'title' : 'Scandal US',}, index, mode='newznab&newznab=6796')
                add_posts({'title' : 'Secret Pakistan',}, index, mode='newznab&newznab=29742',thumb='http://thetvdb.com/banners/posters/253333-1.jpg')
                add_posts({'title' : 'Secrets of Our Living Planet',}, index, mode='newznab&newznab=31920',thumb='http://thetvdb.com/banners/posters/259911-1.jpg')
                add_posts({'title' : 'Sensitive Skin',}, index, mode='newznab&newznab=6799',thumb='http://thetvdb.com/banners/posters/80838-1.jpg')
                add_posts({'title' : 'Servants The True Story Of Life Below Stairs',}, index, mode='newznab&newznab=32737',thumb='http://thetvdb.com/banners/posters/262813-1.jpg')
                add_posts({'title' : 'Shakespeare And Us',}, index, mode='newznab&newznab=31828',thumb='http://thetvdb.com/banners/posters/260804-1.jpg')
                add_posts({'title' : 'Shooting Stars',}, index, mode='newznab&newznab=1913',thumb='http://thetvdb.com/banners/posters/78157-1.jpg')
                add_posts({'title' : 'Sicily Unpacked',}, index, mode='newznab&newznab=30392',thumb='http://thetvdb.com/banners/posters/255162-1.jpg')
                add_posts({'title' : 'Sleepers',}, index, mode='newznab&newznab=27532',thumb='http://thetvdb.com/banners/posters/86031-1.jpg')
                add_posts({'title' : 'Springwatch',}, index, mode='newznab&newznab=12160',thumb='http://thetvdb.com/banners/posters/259475-1.jpg')
                add_posts({'title' : 'Stargazing Live Back To Earth',}, index, mode='newznab&newznab=30580',thumb='http://thetvdb.com/banners/posters/255260-1.jpg')
                add_posts({'title' : 'Stargazing Live',}, index, mode='newznab&newznab=27081',thumb='http://thetvdb.com/banners/posters/217181-1.jpg')
                add_posts({'title' : 'Stewart Lees Comedy Vehicle',}, index, mode='newznab&newznab=22054',thumb='http://thetvdb.com/banners/posters/85535-1.jpg')
                add_posts({'title' : 'Still Game',}, index, mode='newznab&newznab=5352',thumb='http://thetvdb.com/banners/posters/78838-1.jpg')
                add_posts({'title' : 'Strictly Come Dancing It Takes Two',}, index, mode='newznab&newznab=17523',thumb='http://thetvdb.com/banners/posters/195311-1.jpg')
                add_posts({'title' : 'Swimming With Crocodiles',}, index, mode='newznab&newznab=30879',thumb='http://thetvdb.com/banners/posters/256304-1.jpg')
                add_posts({'title' : 'The 70s',}, index, mode='newznab&newznab=31292',thumb='http://thetvdb.com/banners/posters/258254-1.jpg')
                add_posts({'title' : 'The Animals Guide To Britain',}, index, mode='newznab&newznab=27934',thumb='http://thetvdb.com/banners/posters/247972-1.jpg')
                add_posts({'title' : 'The Apprentice Youre Fired',}, index, mode='newznab&newznab=8261',thumb='http://thetvdb.com/banners/posters/88771-1.jpg')
                add_posts({'title' : 'The Armstrongs',}, index, mode='newznab&newznab=8260',thumb='http://thetvdb.com/banners/posters/232881-1.jpg')
                add_posts({'title' : 'The Big Bread Experiment',}, index, mode='newznab&newznab=30201',thumb='http://thetvdb.com/banners/posters/255230-1.jpg')
                add_posts({'title' : 'The Bleak Old Shop Of Stuff',}, index, mode='newznab&newznab=30353',thumb='http://thetvdb.com/banners/posters/254139-1.jpg')
                add_posts({'title' : 'The Boss Is Back',}, index, mode='newznab&newznab=32563',thumb='http://thetvdb.com/banners/posters/262012-1.jpg')
                add_posts({'title' : 'The British At Work',}, index, mode='newznab&newznab=27675')
                add_posts({'title' : 'The Chinese Are Coming',}, index, mode='newznab&newznab=27429',thumb='http://thetvdb.com/banners/posters/230771-1.jpg')
                add_posts({'title' : 'The Choir',}, index, mode='newznab&newznab=12711',thumb='http://thetvdb.com/banners/posters/255129-1.jpg')
                add_posts({'title' : 'The Code',}, index, mode='newznab&newznab=28949')
                add_posts({'title' : 'The Country House Revealed',}, index, mode='newznab&newznab=28205',thumb='http://thetvdb.com/banners/posters/248669-1.jpg')
                add_posts({'title' : 'The Crimson Petal And The White',}, index, mode='newznab&newznab=27723',thumb='http://thetvdb.com/banners/posters/246771-1.jpg')
                add_posts({'title' : 'The Crusades',}, index, mode='newznab&newznab=30487',thumb='http://thetvdb.com/banners/posters/80489-1.jpg')
                add_posts({'title' : 'The Culture Show',}, index, mode='newznab&newznab=9553',thumb='http://thetvdb.com/banners/posters/75748-1.jpg')
                add_posts({'title' : 'The Dark Charisma Of Adolf Hitler',}, index, mode='newznab&newznab=33336',thumb='http://thetvdb.com/banners/posters/264066-1.jpg')
                add_posts({'title' : 'The Dark Natures Nighttime World',}, index, mode='newznab&newznab=32315',thumb='http://thetvdb.com/banners/posters/261065-1.jpg')
                add_posts({'title' : 'The Delicious Miss Dahl',}, index, mode='newznab&newznab=25309',thumb='http://thetvdb.com/banners/posters/153511-1.jpg')
                add_posts({'title' : 'The Fishermans Apprentice With Monty Halls',}, index, mode='newznab&newznab=30922',thumb='http://thetvdb.com/banners/posters/256594-1.jpg')
                add_posts({'title' : 'The Great British Bake Off',}, index, mode='newznab&newznab=26332',thumb='http://thetvdb.com/banners/posters/184871-1.jpg')
                add_posts({'title' : 'The Great British Story A Peoples History',}, index, mode='newznab&newznab=31517',thumb='http://thetvdb.com/banners/posters/259447-1.jpg')
                add_posts({'title' : 'The Hairy Bikers Bakeation',}, index, mode='newznab&newznab=31021',thumb='http://thetvdb.com/banners/posters/256856-1.jpg')
                add_posts({'title' : 'The Hairy Bikers Cook Book',}, index, mode='newznab&newznab=7516')
                add_posts({'title' : 'The Hairy Bikers Mum Knows Best',}, index, mode='newznab&newznab=29927',thumb='http://thetvdb.com/banners/posters/133261-1.jpg')
                add_posts({'title' : 'The Hairy Bikers Mums Know Best',}, index, mode='newznab&newznab=29927',thumb='http://thetvdb.com/banners/posters/133261-1.jpg')
                add_posts({'title' : 'The Hollow Crown',}, index, mode='newznab&newznab=32174',thumb='http://thetvdb.com/banners/posters/260355-1.jpg')
                add_posts({'title' : 'The Hour UK 2011',}, index, mode='newznab&newznab=27308')
                add_posts({'title' : 'The Impressionists Painting And Revolution',}, index, mode='newznab&newznab=28945',thumb='http://thetvdb.com/banners/posters/250449-1.jpg')
                add_posts({'title' : 'The League of Gentlemen',}, index, mode='newznab&newznab=5918',thumb='http://thetvdb.com/banners/posters/72492-1.jpg')
                add_posts({'title' : 'The Life Of Mahammad',}, index, mode='newznab&newznab=28892',thumb='http://thetvdb.com/banners/posters/250124-1.jpg')
                add_posts({'title' : 'The Life Of Muhammad',}, index, mode='newznab&newznab=28892',thumb='http://thetvdb.com/banners/posters/250124-1.jpg')
                add_posts({'title' : 'The Marvellous Mrs Beeton With Sophie Dahi',}, index, mode='newznab&newznab=29401',thumb='http://thetvdb.com/banners/posters/252409-1.jpg')
                add_posts({'title' : 'The Men Who Made Us Fat',}, index, mode='newznab&newznab=31759',thumb='http://thetvdb.com/banners/posters/259944-1.jpg')
                add_posts({'title' : 'The Men Who Make Us Fat',}, index, mode='newznab&newznab=31759',thumb='http://thetvdb.com/banners/posters/259944-1.jpg')
                add_posts({'title' : 'The Midwives',}, index, mode='newznab&newznab=32314',thumb='http://thetvdb.com/banners/posters/261156-1.jpg')
                add_posts({'title' : 'The Rob Brydon Show',}, index, mode='newznab&newznab=26493',thumb='http://thetvdb.com/banners/posters/190411-1.jpg')
                add_posts({'title' : 'The Sarah Millican Television Programme',}, index, mode='newznab&newznab=30965',thumb='http://thetvdb.com/banners/posters/256900-1.jpg')
                add_posts({'title' : 'The Secret History Of Our Streets',}, index, mode='newznab&newznab=31707',thumb='http://thetvdb.com/banners/posters/259731-1.jpg')
                add_posts({'title' : 'The Secret War On Terror',}, index, mode='newznab&newznab=27722',thumb='http://thetvdb.com/banners/posters/239991-1.jpg')
                add_posts({'title' : 'The Shadow Line',}, index, mode='newznab&newznab=28099',thumb='http://thetvdb.com/banners/posters/248484-1.jpg')
                add_posts({'title' : 'The Spice Trails',}, index, mode='newznab&newznab=27553',thumb='http://thetvdb.com/banners/posters/232751-1.jpg')
                add_posts({'title' : 'The Story Of India',}, index, mode='newznab&newznab=18472',thumb='http://thetvdb.com/banners/posters/81523-1.jpg')
                add_posts({'title' : 'The Story Of Ireland',}, index, mode='newznab&newznab=28264',thumb='http://thetvdb.com/banners/posters/234991-1.jpg')
                add_posts({'title' : 'The Truth About Lions',}, index, mode='newznab&newznab=27798')
                add_posts({'title' : 'The Tube 2012',}, index, mode='newznab&newznab=30873',thumb='http://thetvdb.com/banners/posters/256303-1.jpg')
                add_posts({'title' : 'This World',}, index, mode='newznab&newznab=30884',thumb='http://thetvdb.com/banners/posters/83982-1.jpg')
                add_posts({'title' : 'Three Men Go To New England',}, index, mode='newznab&newznab=30319')
                add_posts({'title' : 'Three Men Go To Venice',}, index, mode='newznab&newznab=28639')
                add_posts({'title' : 'Top Gear',}, index, mode='newznab&newznab=6753',thumb='http://thetvdb.com/banners/posters/74608-1.jpg')
                add_posts({'title' : 'Top Of The Pops 2',}, index, mode='newznab&newznab=7493')
                add_posts({'title' : 'Toughest Place to Be a',}, index, mode='newznab&newznab=27511',thumb='http://thetvdb.com/banners/posters/233801-1.jpg')
                add_posts({'title' : 'Toughtest Place To Be A',}, index, mode='newznab&newznab=27511',thumb='http://thetvdb.com/banners/posters/233801-1.jpg')
                add_posts({'title' : 'TOWN With Nicholas Crane',}, index, mode='newznab&newznab=29019',thumb='http://thetvdb.com/banners/posters/250542-1.jpg')
                add_posts({'title' : 'Twenty Twelve',}, index, mode='newznab&newznab=27718',thumb='http://thetvdb.com/banners/posters/239861-1.jpg')
                add_posts({'title' : 'Two Greedy Italians',}, index, mode='newznab&newznab=28153',thumb='http://thetvdb.com/banners/posters/248492-1.jpg')
                add_posts({'title' : 'Versailles',}, index, mode='newznab&newznab=30954',thumb='http://thetvdb.com/banners/posters/243461-1.jpg')
                add_posts({'title' : 'Vexed',}, index, mode='newznab&newznab=26329',thumb='http://thetvdb.com/banners/posters/182601-1.jpg')
                add_posts({'title' : 'Vikings UK',}, index, mode='newznab&newznab=32540')
                add_posts({'title' : 'Volcano Live',}, index, mode='newznab&newznab=32167',thumb='http://thetvdb.com/banners/posters/260595-1.jpg')
                add_posts({'title' : 'Wartime Farm',}, index, mode='newznab&newznab=32481',thumb='http://thetvdb.com/banners/posters/261964-1.jpg')
                add_posts({'title' : 'Watson And Oliver',}, index, mode='newznab&newznab=30872',thumb='http://thetvdb.com/banners/posters/256309-1.jpg')
                add_posts({'title' : 'Welcome To India',}, index, mode='newznab&newznab=32891',thumb='http://thetvdb.com/banners/posters/262951-1.jpg')
                add_posts({'title' : 'Westminster Abbey',}, index, mode='newznab&newznab=33487',thumb='http://thetvdb.com/banners/posters/264703-1.jpg')
                add_posts({'title' : 'Wheeler Dealers',}, index, mode='newznab&newznab=10884',thumb='http://thetvdb.com/banners/posters/81320-1.jpg')
                add_posts({'title' : 'When Teenage Meets Old Age',}, index, mode='newznab&newznab=27583',thumb='http://thetvdb.com/banners/posters/234021-1.jpg')
                add_posts({'title' : 'White Heat',}, index, mode='newznab&newznab=27906',thumb='http://thetvdb.com/banners/posters/256665-1.jpg')
                add_posts({'title' : 'Winterwatch',}, index, mode='newznab&newznab=33885')
                add_posts({'title' : 'Wonderland UK',}, index, mode='newznab&newznab=18177')
                add_posts({'title' : 'Wonders Of The Universe',}, index, mode='newznab&newznab=27633',thumb='http://thetvdb.com/banners/posters/230281-1.jpg')
                add_posts({'title' : 'Wonderstuff',}, index, mode='newznab&newznab=29020',thumb='http://thetvdb.com/banners/posters/250500-1.jpg')
                add_posts({'title' : 'Worlds Most Dangerous Roads',}, index, mode='newznab&newznab=29327',thumb='http://thetvdb.com/banners/posters/179851-1.jpg')
                add_posts({'title' : 'Yes Prime Minister',}, index, mode='newznab&newznab=1615',thumb='http://thetvdb.com/banners/posters/76864-1.jpg')
                add_posts({'title' : 'Your Money And How They Spend It',}, index, mode='newznab&newznab=30137',thumb='http://thetvdb.com/banners/posters/254126-1.jpg')
            if newznab_id == 'BBC TWO Scotland':
                add_posts({'title' : 'Burnistoun',}, index, mode='newznab&newznab=26731',thumb='http://thetvdb.com/banners/posters/147331-1.jpg')
                add_posts({'title' : 'Limmys Show',}, index, mode='newznab&newznab=25153',thumb='http://thetvdb.com/banners/posters/87741-1.jpg')
            if newznab_id == 'BBC Wales':
                add_posts({'title' : 'Baker Boys',}, index, mode='newznab&newznab=27460',thumb='http://thetvdb.com/banners/posters/224901-1.jpg')
                add_posts({'title' : 'Rhod Gilberts Work Experience',}, index, mode='newznab&newznab=25225',thumb='http://thetvdb.com/banners/posters/136841-1.jpg')
                add_posts({'title' : 'Tenby 24 7',}, index, mode='newznab&newznab=30149')
            if newznab_id == 'BET':
                add_posts({'title' : 'Keyshia and Daniel Family First',}, index, mode='newznab&newznab=32705',thumb='http://thetvdb.com/banners/posters/263237-1.jpg')
                add_posts({'title' : 'Keyshia and Daniel Famly First',}, index, mode='newznab&newznab=32705',thumb='http://thetvdb.com/banners/posters/263237-1.jpg')
                add_posts({'title' : 'Lets Stay Together',}, index, mode='newznab&newznab=27058',thumb='http://thetvdb.com/banners/posters/220421-1.jpg')
                add_posts({'title' : 'Reed Between the Lines',}, index, mode='newznab&newznab=28107',thumb='http://thetvdb.com/banners/posters/252797-1.jpg')
                add_posts({'title' : 'The Family Crews',}, index, mode='newznab&newznab=23688',thumb='http://thetvdb.com/banners/posters/145931-1.jpg')
                add_posts({'title' : 'The Game',}, index, mode='newznab&newznab=8159',thumb='http://thetvdb.com/banners/posters/79636-1.jpg')
                add_posts({'title' : 'Toya A Family Affair',}, index, mode='newznab&newznab=27923',thumb='http://thetvdb.com/banners/posters/219601-1.jpg')
                add_posts({'title' : 'Vindicated',}, index, mode='newznab&newznab=33659')
            if newznab_id == 'Biography Channel':
                add_posts({'title' : 'Celebrity Ghost Hunt',}, index, mode='newznab&newznab=28902',thumb='http://thetvdb.com/banners/posters/250096-1.jpg')
                add_posts({'title' : 'Celebrity Ghost Stories',}, index, mode='newznab&newznab=23673',thumb='http://thetvdb.com/banners/posters/122701-1.jpg')
                add_posts({'title' : 'Cursed',}, index, mode='newznab&newznab=32936',thumb='http://thetvdb.com/banners/posters/263248-1.jpg')
                add_posts({'title' : 'Female Forces',}, index, mode='newznab&newznab=19671')
                add_posts({'title' : 'Ghostly Encounters',}, index, mode='newznab&newznab=21016',thumb='http://thetvdb.com/banners/posters/217081-1.jpg')
                add_posts({'title' : 'Haunted Encounters Face To Face',}, index, mode='newznab&newznab=33636',thumb='http://thetvdb.com/banners/posters/264505-1.jpg')
                add_posts({'title' : 'I Survived',}, index, mode='newznab&newznab=18629',thumb='http://thetvdb.com/banners/posters/139961-1.jpg')
                add_posts({'title' : 'My Ghost Story',}, index, mode='newznab&newznab=25862')
                add_posts({'title' : 'Outlaw Bikers',}, index, mode='newznab&newznab=31247',thumb='http://thetvdb.com/banners/posters/201691-1.jpg')
                add_posts({'title' : 'Paranormal Trauma',}, index, mode='newznab&newznab=30683',thumb='http://thetvdb.com/banners/posters/255092-1.jpg')
                add_posts({'title' : 'Psychic Investigators',}, index, mode='newznab&newznab=17374',thumb='http://thetvdb.com/banners/posters/254613-1.jpg')
                add_posts({'title' : 'Shatners Raw Nerve',}, index, mode='newznab&newznab=19520',thumb='http://thetvdb.com/banners/posters/84037-1.jpg')
                add_posts({'title' : 'The Ghost Inside My Child',}, index, mode='newznab&newznab=33635',thumb='http://thetvdb.com/banners/posters/264347-1.jpg')
                add_posts({'title' : 'The Haunting Of',}, index, mode='newznab&newznab=33267',thumb='http://thetvdb.com/banners/posters/263684-1.jpg')
                add_posts({'title' : 'The UneXplained',}, index, mode='newznab&newznab=32354',thumb='http://thetvdb.com/banners/posters/256661-1.jpg')
                add_posts({'title' : 'Watching the Detectives',}, index, mode='newznab&newznab=20264')
                add_posts({'title' : 'Why I Ran',}, index, mode='newznab&newznab=19674')
            if newznab_id == 'BNN':
                add_posts({'title' : '3 Op Reis',}, index, mode='newznab&newznab=20258',thumb='http://thetvdb.com/banners/posters/197361-1.jpg')
            if newznab_id == 'Bounce':
                add_posts({'title' : 'Family Time',}, index, mode='newznab&newznab=31883',thumb='http://thetvdb.com/banners/posters/260185-1.jpg')
                add_posts({'title' : 'Off the Chain',}, index, mode='newznab&newznab=33214')
            if newznab_id == 'Bravo':
                add_posts({'title' : 'Around the World in 80 Plates',}, index, mode='newznab&newznab=25952',thumb='http://thetvdb.com/banners/posters/258538-1.jpg')
                add_posts({'title' : 'Bethenny Ever After',}, index, mode='newznab&newznab=25596',thumb='http://thetvdb.com/banners/posters/170191-1.jpg')
                add_posts({'title' : 'Flipping Out',}, index, mode='newznab&newznab=16606',thumb='http://thetvdb.com/banners/posters/82309-1.jpg')
                add_posts({'title' : 'Gallery Girls',}, index, mode='newznab&newznab=32045',thumb='http://thetvdb.com/banners/posters/259240-1.jpg')
                add_posts({'title' : 'inside the actors studio',}, index, mode='newznab&newznab=3968',thumb='http://thetvdb.com/banners/posters/72614-1.jpg')
                add_posts({'title' : 'Interior Therapy With Jeff Lewis',}, index, mode='newznab&newznab=28461',thumb='http://thetvdb.com/banners/posters/256929-1.jpg')
                add_posts({'title' : 'Kathy Griffin My Life On The D List',}, index, mode='newznab&newznab=4106',thumb='http://thetvdb.com/banners/posters/79795-1.jpg')
                add_posts({'title' : 'Kathy',}, index, mode='newznab&newznab=31099',thumb='http://thetvdb.com/banners/posters/257842-1.jpg')
                add_posts({'title' : 'Life After Top Chef',}, index, mode='newznab&newznab=32047',thumb='http://thetvdb.com/banners/posters/262592-1.jpg')
                add_posts({'title' : 'LOLwork',}, index, mode='newznab&newznab=33011',thumb='http://thetvdb.com/banners/posters/263624-1.jpg')
                add_posts({'title' : 'Million Dollar Decorators',}, index, mode='newznab&newznab=25530',thumb='http://thetvdb.com/banners/posters/249084-1.jpg')
                add_posts({'title' : 'Million Dollar Listing',}, index, mode='newznab&newznab=7139')
                add_posts({'title' : 'Most Eligible Dallas',}, index, mode='newznab&newznab=28993',thumb='http://thetvdb.com/banners/posters/250374-1.jpg')
                add_posts({'title' : 'Platinum Hit',}, index, mode='newznab&newznab=28142',thumb='http://thetvdb.com/banners/posters/249062-1.jpg')
                add_posts({'title' : 'Pregnant in Heels',}, index, mode='newznab&newznab=25531',thumb='http://thetvdb.com/banners/posters/247885-1.jpg')
                add_posts({'title' : 'Shahs of Sunset',}, index, mode='newznab&newznab=30645',thumb='http://thetvdb.com/banners/posters/255649-1.jpg')
                add_posts({'title' : 'Start Ups Silicon Valley',}, index, mode='newznab&newznab=32046',thumb='http://thetvdb.com/banners/posters/263541-1.jpg')
                add_posts({'title' : 'Tabatha Takes Over',}, index, mode='newznab&newznab=19339',thumb='http://thetvdb.com/banners/posters/88321-1.jpg')
                add_posts({'title' : 'The Millionaire Matchmaker',}, index, mode='newznab&newznab=18275',thumb='http://thetvdb.com/banners/posters/85425-1.jpg')
                add_posts({'title' : 'The Rachel Zoe Project',}, index, mode='newznab&newznab=19198',thumb='http://thetvdb.com/banners/posters/87421-1.jpg')
                add_posts({'title' : 'The Real Housewives New York City',}, index, mode='newznab&newznab=18525',thumb='http://thetvdb.com/banners/posters/84669-1.jpg')
                add_posts({'title' : 'The Real Housewives of Atlanta',}, index, mode='newznab&newznab=19672',thumb='http://thetvdb.com/banners/posters/84159-1.jpg')
                add_posts({'title' : 'The Real Housewives of Beverly Hills',}, index, mode='newznab&newznab=25448',thumb='http://thetvdb.com/banners/posters/196741-1.jpg')
                add_posts({'title' : 'The Real Housewives of Miami',}, index, mode='newznab&newznab=27604',thumb='http://thetvdb.com/banners/posters/228691-1.jpg')
                add_posts({'title' : 'The Real Housewives of New Jersey',}, index, mode='newznab&newznab=22647',thumb='http://thetvdb.com/banners/posters/89831-1.jpg')
                add_posts({'title' : 'The Real Housewives of New York City',}, index, mode='newznab&newznab=18525',thumb='http://thetvdb.com/banners/posters/84669-1.jpg')
                add_posts({'title' : 'The Real Housewives of Orange County',}, index, mode='newznab&newznab=7218',thumb='http://thetvdb.com/banners/posters/80117-1.jpg')
                add_posts({'title' : 'Thicker Than Water The Marinos',}, index, mode='newznab&newznab=29156')
                add_posts({'title' : 'Top Chef Just Desserts',}, index, mode='newznab&newznab=26212',thumb='http://thetvdb.com/banners/posters/186171-1.jpg')
                add_posts({'title' : 'Top Chef Masters',}, index, mode='newznab&newznab=19649',thumb='http://thetvdb.com/banners/posters/98821-1.jpg')
                add_posts({'title' : 'Top Chef',}, index, mode='newznab&newznab=6995',thumb='http://thetvdb.com/banners/posters/79313-1.jpg')
                add_posts({'title' : 'Work Of Art The Next Great Artist',}, index, mode='newznab&newznab=25595',thumb='http://thetvdb.com/banners/posters/170911-1.jpg')
            if newznab_id == 'C4':
                add_posts({'title' : 'Making Tracks',}, index, mode='newznab&newznab=19258',thumb='http://thetvdb.com/banners/posters/82170-1.jpg')
            if newznab_id == 'Canal':
                add_posts({'title' : 'Borgia',}, index, mode='newznab&newznab=28228',thumb='http://thetvdb.com/banners/posters/251495-1.jpg')
                add_posts({'title' : 'Braquo',}, index, mode='newznab&newznab=24507',thumb='http://thetvdb.com/banners/posters/118451-1.jpg')
                add_posts({'title' : 'H',}, index, mode='newznab&newznab=32177',thumb='http://thetvdb.com/banners/posters/80409-1.jpg')
                add_posts({'title' : 'Maison Close',}, index, mode='newznab&newznab=27418',thumb='http://thetvdb.com/banners/posters/185851-1.jpg')
            if newznab_id == 'Cartoon Network':
                add_posts({'title' : 'Adventure Time',}, index, mode='newznab&newznab=23369',thumb='http://thetvdb.com/banners/posters/152831-1.jpg')
                add_posts({'title' : 'Almost Naked Animals',}, index, mode='newznab&newznab=28650',thumb='http://thetvdb.com/banners/posters/250281-1.jpg')
                add_posts({'title' : 'Batman The Brave and the Bold',}, index, mode='newznab&newznab=20349',thumb='http://thetvdb.com/banners/posters/82824-1.jpg')
                add_posts({'title' : 'Ben 10 Alien Force',}, index, mode='newznab&newznab=18699',thumb='http://thetvdb.com/banners/posters/81841-1.jpg')
                add_posts({'title' : 'Ben 10 Omniverse',}, index, mode='newznab&newznab=31489',thumb='http://thetvdb.com/banners/posters/260995-1.jpg')
                add_posts({'title' : 'Ben 10 Ultimate Alien',}, index, mode='newznab&newznab=23487',thumb='http://thetvdb.com/banners/posters/158501-1.jpg')
                add_posts({'title' : 'Ben 10',}, index, mode='newznab&newznab=6926',thumb='http://thetvdb.com/banners/posters/79567-1.jpg')
                add_posts({'title' : 'Dragonball GT',}, index, mode='newznab&newznab=3372',thumb='http://thetvdb.com/banners/posters/79275-1.jpg')
                add_posts({'title' : 'Dragons Riders of Berk',}, index, mode='newznab&newznab=31558',thumb='http://thetvdb.com/banners/posters/264902-1.jpg')
                add_posts({'title' : 'Ed Edd n Eddy',}, index, mode='newznab&newznab=3421',thumb='http://thetvdb.com/banners/posters/77466-1.jpg')
                add_posts({'title' : 'Fosters Home For Imaginary Friends',}, index, mode='newznab&newznab=3587',thumb='http://thetvdb.com/banners/posters/79323-1.jpg')
                add_posts({'title' : 'Generator Rex',}, index, mode='newznab&newznab=23484',thumb='http://thetvdb.com/banners/posters/158551-1.jpg')
                add_posts({'title' : 'Gormiti The Lords Of Nature Return',}, index, mode='newznab&newznab=25489')
                add_posts({'title' : 'Green Lantern The Animated Series',}, index, mode='newznab&newznab=26783',thumb='http://thetvdb.com/banners/posters/251807-1.jpg')
                add_posts({'title' : 'Harry And His Bucket Full Of Dinosaurs',}, index, mode='newznab&newznab=3794',thumb='http://thetvdb.com/banners/posters/79160-1.jpg')
                add_posts({'title' : 'Hot Wheels Battle Force 5',}, index, mode='newznab&newznab=23420',thumb='http://thetvdb.com/banners/posters/111961-1.jpg')
                add_posts({'title' : 'LEGO NinjaGo Masters Of Spinjitzu',}, index, mode='newznab&newznab=27477',thumb='http://thetvdb.com/banners/posters/253323-1.jpg')
                add_posts({'title' : 'Level Up',}, index, mode='newznab&newznab=29898',thumb='http://thetvdb.com/banners/posters/253525-1.jpg')
                add_posts({'title' : 'MAD',}, index, mode='newznab&newznab=26427',thumb='http://thetvdb.com/banners/posters/187911-1.jpg')
                add_posts({'title' : 'Metajets',}, index, mode='newznab&newznab=31840')
                add_posts({'title' : 'Regular Show',}, index, mode='newznab&newznab=26426',thumb='http://thetvdb.com/banners/posters/188401-1.jpg')
                add_posts({'title' : 'Space Ghost Coast To Coast',}, index, mode='newznab&newznab=5276',thumb='http://thetvdb.com/banners/posters/79171-1.jpg')
                add_posts({'title' : 'Star Wars The Clone Wars 2008',}, index, mode='newznab&newznab=19187')
                add_posts({'title' : 'Sym Bionic Titan',}, index, mode='newznab&newznab=23483',thumb='http://thetvdb.com/banners/posters/190511-1.jpg')
                add_posts({'title' : 'The Amazing World of Gumball',}, index, mode='newznab&newznab=28067',thumb='http://thetvdb.com/banners/posters/248482-1.jpg')
                add_posts({'title' : 'The Brak Show',}, index, mode='newznab&newznab=5647',thumb='http://thetvdb.com/banners/posters/77118-1.jpg')
                add_posts({'title' : 'The Garfield Show',}, index, mode='newznab&newznab=24402',thumb='http://thetvdb.com/banners/posters/145371-1.jpg')
                add_posts({'title' : 'The Looney Tunes Show 2011',}, index, mode='newznab&newznab=27389',thumb='http://thetvdb.com/banners/posters/248368-1.jpg')
                add_posts({'title' : 'The Looney Tunes Show 20111',}, index, mode='newznab&newznab=27389',thumb='http://thetvdb.com/banners/posters/248368-1.jpg')
                add_posts({'title' : 'The Looney Tunes Show',}, index, mode='newznab&newznab=5944')
                add_posts({'title' : 'Thundercats 2011',}, index, mode='newznab&newznab=27516',thumb='http://thetvdb.com/banners/posters/241431-1.jpg')
                add_posts({'title' : 'Unnatural History',}, index, mode='newznab&newznab=23493',thumb='http://thetvdb.com/banners/posters/168591-1.jpg')
                add_posts({'title' : 'Young Justice',}, index, mode='newznab&newznab=25542',thumb='http://thetvdb.com/banners/posters/192061-1.jpg')
            if newznab_id == 'CBBC':
                add_posts({'title' : 'Grange Hill',}, index, mode='newznab&newznab=156',thumb='http://thetvdb.com/banners/posters/72981-1.jpg')
                add_posts({'title' : 'Shaun the Sheep Championsheeps',}, index, mode='newznab&newznab=32200')
                add_posts({'title' : 'Shoebox Zoo',}, index, mode='newznab&newznab=2196',thumb='http://thetvdb.com/banners/posters/167041-1.jpg')
                add_posts({'title' : 'Wizards Vs Aliens',}, index, mode='newznab&newznab=32754',thumb='http://thetvdb.com/banners/posters/262513-1.jpg')
            if newznab_id == 'CBC':
                add_posts({'title' : '18 To Life',}, index, mode='newznab&newznab=24855',thumb='http://thetvdb.com/banners/posters/132781-1.jpg')
                add_posts({'title' : 'Arctic Air',}, index, mode='newznab&newznab=30357',thumb='http://thetvdb.com/banners/posters/253905-1.jpg')
                add_posts({'title' : 'Being Erica',}, index, mode='newznab&newznab=20818',thumb='http://thetvdb.com/banners/posters/84414-1.jpg')
                add_posts({'title' : 'Degrassi High',}, index, mode='newznab&newznab=3276',thumb='http://thetvdb.com/banners/posters/78300-1.jpg')
                add_posts({'title' : 'Dragons Den CA',}, index, mode='newznab&newznab=28171')
                add_posts({'title' : 'Heartland CA',}, index, mode='newznab&newznab=17878')
                add_posts({'title' : 'InSecurity',}, index, mode='newznab&newznab=26755',thumb='http://thetvdb.com/banners/posters/217961-1.jpg')
                add_posts({'title' : 'Intelligence',}, index, mode='newznab&newznab=13474',thumb='http://thetvdb.com/banners/posters/79508-1.jpg')
                add_posts({'title' : 'Little Mosque on the Prairie',}, index, mode='newznab&newznab=14977',thumb='http://thetvdb.com/banners/posters/79701-1.jpg')
                add_posts({'title' : 'Love Hate And Propaganda',}, index, mode='newznab&newznab=30476')
                add_posts({'title' : 'Michael Tuesdays and Thursdays',}, index, mode='newznab&newznab=29651',thumb='http://thetvdb.com/banners/posters/251947-1.jpg')
                add_posts({'title' : 'Mr D',}, index, mode='newznab&newznab=30648',thumb='http://thetvdb.com/banners/posters/255046-1.jpg')
                add_posts({'title' : 'Our Hero',}, index, mode='newznab&newznab=4739',thumb='http://thetvdb.com/banners/posters/77969-1.jpg')
                add_posts({'title' : 'Redemption Inc',}, index, mode='newznab&newznab=30650',thumb='http://thetvdb.com/banners/posters/255041-1.jpg')
                add_posts({'title' : 'Republic of Doyle',}, index, mode='newznab&newznab=24461',thumb='http://thetvdb.com/banners/posters/133251-1.jpg')
                add_posts({'title' : 'Rick Mercer Report',}, index, mode='newznab&newznab=1356',thumb='http://thetvdb.com/banners/posters/73319-1.jpg')
                add_posts({'title' : 'Road To Avonlea',}, index, mode='newznab&newznab=2685',thumb='http://thetvdb.com/banners/posters/74481-1.jpg')
                add_posts({'title' : 'The Big Decision',}, index, mode='newznab&newznab=31134',thumb='http://thetvdb.com/banners/posters/257103-1.jpg')
                add_posts({'title' : 'The Red Green Show',}, index, mode='newznab&newznab=6130',thumb='http://thetvdb.com/banners/posters/76863-1.jpg')
                add_posts({'title' : 'The Week the Women Went',}, index, mode='newznab&newznab=20879',thumb='http://thetvdb.com/banners/posters/261920-1.jpg')
                add_posts({'title' : 'this is wonderland',}, index, mode='newznab&newznab=6334',thumb='http://thetvdb.com/banners/posters/73283-1.jpg')
                add_posts({'title' : 'Total Recall 2070',}, index, mode='newznab&newznab=6389',thumb='http://thetvdb.com/banners/posters/76459-1.jpg')
                add_posts({'title' : 'Who Do You Think You Are CA',}, index, mode='newznab&newznab=25261')
            if newznab_id == 'Cbeebies':
                add_posts({'title' : 'Chuggington',}, index, mode='newznab&newznab=23851',thumb='http://thetvdb.com/banners/posters/85034-1.jpg')
                add_posts({'title' : 'In the Night Garden',}, index, mode='newznab&newznab=10813',thumb='http://thetvdb.com/banners/posters/81749-1.jpg')
                add_posts({'title' : 'Justins House',}, index, mode='newznab&newznab=29620',thumb='http://thetvdb.com/banners/posters/253105-1.jpg')
                add_posts({'title' : 'Timmy Time',}, index, mode='newznab&newznab=25049',thumb='http://thetvdb.com/banners/posters/88331-1.jpg')
            if newznab_id == 'CBS':
                add_posts({'title' : '2 Broke Girls',}, index, mode='newznab&newznab=28416',thumb='http://thetvdb.com/banners/posters/248741-1.jpg')
                add_posts({'title' : '3',}, index, mode='newznab&newznab=30918',thumb='http://thetvdb.com/banners/posters/260473-1.jpg')
                add_posts({'title' : 'A Gifted Man',}, index, mode='newznab&newznab=28414',thumb='http://thetvdb.com/banners/posters/248875-1.jpg')
                add_posts({'title' : 'Accidentally on Purpose',}, index, mode='newznab&newznab=22771',thumb='http://thetvdb.com/banners/posters/95471-1.jpg')
                add_posts({'title' : 'All in the Family',}, index, mode='newznab&newznab=2559',thumb='http://thetvdb.com/banners/posters/72741-1.jpg')
                add_posts({'title' : 'All New Dennis The Menace',}, index, mode='newznab&newznab=2548',thumb='http://thetvdb.com/banners/posters/72186-1.jpg')
                add_posts({'title' : 'American Gothic',}, index, mode='newznab&newznab=2599',thumb='http://thetvdb.com/banners/posters/76594-1.jpg')
                add_posts({'title' : 'Becker',}, index, mode='newznab&newznab=2748',thumb='http://thetvdb.com/banners/posters/77725-1.jpg')
                add_posts({'title' : 'Big Brother US',}, index, mode='newznab&newznab=2787')
                add_posts({'title' : 'Blue Bloods',}, index, mode='newznab&newznab=25756',thumb='http://thetvdb.com/banners/posters/164981-1.jpg')
                add_posts({'title' : 'Body Language',}, index, mode='newznab&newznab=18901',thumb='http://thetvdb.com/banners/posters/78747-1.jpg')
                add_posts({'title' : 'Brooklyn South',}, index, mode='newznab&newznab=2917',thumb='http://thetvdb.com/banners/posters/75517-1.jpg')
                add_posts({'title' : 'Cannon',}, index, mode='newznab&newznab=2969',thumb='http://thetvdb.com/banners/posters/78217-1.jpg')
                add_posts({'title' : 'Care Bears Adventures In Care A Lot',}, index, mode='newznab&newznab=18992',thumb='http://thetvdb.com/banners/posters/101901-1.jpg')
                add_posts({'title' : 'CHAOS',}, index, mode='newznab&newznab=25782',thumb='http://thetvdb.com/banners/posters/193801-1.jpg')
                add_posts({'title' : 'Chicago Hope',}, index, mode='newznab&newznab=3050',thumb='http://thetvdb.com/banners/posters/75544-1.jpg')
                add_posts({'title' : 'Cold Case',}, index, mode='newznab&newznab=3102',thumb='http://thetvdb.com/banners/posters/72167-1.jpg')
                add_posts({'title' : 'Criminal Minds Suspect Behavior',}, index, mode='newznab&newznab=25318',thumb='http://thetvdb.com/banners/posters/168151-1.jpg')
                add_posts({'title' : 'Criminal Minds',}, index, mode='newznab&newznab=3171',thumb='http://thetvdb.com/banners/posters/75710-1.jpg')
                add_posts({'title' : 'CSI Crime Scene Investigation',}, index, mode='newznab&newznab=3183',thumb='http://thetvdb.com/banners/posters/72546-1.jpg')
                add_posts({'title' : 'CSI Miami',}, index, mode='newznab&newznab=3184',thumb='http://thetvdb.com/banners/posters/78310-1.jpg')
                add_posts({'title' : 'CSI NY',}, index, mode='newznab&newznab=3185',thumb='http://thetvdb.com/banners/posters/73696-1.jpg')
                add_posts({'title' : 'Daktari',}, index, mode='newznab&newznab=1673',thumb='http://thetvdb.com/banners/posters/77094-1.jpg')
                add_posts({'title' : 'Dennis the Menace 1959',}, index, mode='newznab&newznab=3286')
                add_posts({'title' : 'Designing Women',}, index, mode='newznab&newznab=3291',thumb='http://thetvdb.com/banners/posters/76999-1.jpg')
                add_posts({'title' : 'Diagnosis Murder',}, index, mode='newznab&newznab=3301',thumb='http://thetvdb.com/banners/posters/72484-1.jpg')
                add_posts({'title' : 'Dogs in the City',}, index, mode='newznab&newznab=31379',thumb='http://thetvdb.com/banners/posters/258607-1.jpg')
                add_posts({'title' : 'Drak Pack',}, index, mode='newznab&newznab=3379',thumb='http://thetvdb.com/banners/posters/82100-1.jpg')
                add_posts({'title' : 'Elementary',}, index, mode='newznab&newznab=30750',thumb='http://thetvdb.com/banners/posters/255316-1.jpg')
                add_posts({'title' : 'Everybody Loves Raymond',}, index, mode='newznab&newznab=3466',thumb='http://thetvdb.com/banners/posters/73663-1.jpg')
                add_posts({'title' : 'For Better or Worse',}, index, mode='newznab&newznab=19054')
                add_posts({'title' : 'Front Row Center',}, index, mode='newznab&newznab=8813',thumb='http://thetvdb.com/banners/posters/77464-1.jpg')
                add_posts({'title' : 'Galaxy High School',}, index, mode='newznab&newznab=239',thumb='http://thetvdb.com/banners/posters/74914-1.jpg')
                add_posts({'title' : 'Garfield And Friends',}, index, mode='newznab&newznab=3644',thumb='http://thetvdb.com/banners/posters/77054-1.jpg')
                add_posts({'title' : 'Good Morning World',}, index, mode='newznab&newznab=15887')
                add_posts({'title' : 'Good Times',}, index, mode='newznab&newznab=3723',thumb='http://thetvdb.com/banners/posters/77357-1.jpg')
                add_posts({'title' : 'Gunsmoke',}, index, mode='newznab&newznab=3766',thumb='http://thetvdb.com/banners/posters/73559-1.jpg')
                add_posts({'title' : 'Have Gun Will Travel',}, index, mode='newznab&newznab=3803',thumb='http://thetvdb.com/banners/posters/72097-1.jpg')
                add_posts({'title' : 'Hawaii Five 0 2010',}, index, mode='newznab&newznab=24840')
                add_posts({'title' : 'Hearts Afire',}, index, mode='newznab&newznab=3821',thumb='http://thetvdb.com/banners/posters/77676-1.jpg')
                add_posts({'title' : 'Heres Lucy',}, index, mode='newznab&newznab=3836',thumb='http://thetvdb.com/banners/posters/70699-1.jpg')
                add_posts({'title' : 'Hogans Heroes',}, index, mode='newznab&newznab=3874',thumb='http://thetvdb.com/banners/posters/71635-1.jpg')
                add_posts({'title' : 'How I Met Your Mother',}, index, mode='newznab&newznab=3918',thumb='http://thetvdb.com/banners/posters/75760-1.jpg')
                add_posts({'title' : 'How To Be a Gentleman',}, index, mode='newznab&newznab=28415',thumb='http://thetvdb.com/banners/posters/248930-1.jpg')
                add_posts({'title' : 'I Get That Alot',}, index, mode='newznab&newznab=24551',thumb='http://thetvdb.com/banners/posters/90141-1.jpg')
                add_posts({'title' : 'I Love Lucy',}, index, mode='newznab&newznab=3944',thumb='http://thetvdb.com/banners/posters/70584-1.jpg')
                add_posts({'title' : 'Jag',}, index, mode='newznab&newznab=4032',thumb='http://thetvdb.com/banners/posters/73710-1.jpg')
                add_posts({'title' : 'Jake And The Fatman',}, index, mode='newznab&newznab=4034',thumb='http://thetvdb.com/banners/posters/72235-1.jpg')
                add_posts({'title' : 'Jericho',}, index, mode='newznab&newznab=8141')
                add_posts({'title' : 'Josie and the Pussycats',}, index, mode='newznab&newznab=4077',thumb='http://thetvdb.com/banners/posters/74883-1.jpg')
                add_posts({'title' : 'Kate And Allie',}, index, mode='newznab&newznab=4104',thumb='http://thetvdb.com/banners/posters/77436-1.jpg')
                add_posts({'title' : 'Mad Love',}, index, mode='newznab&newznab=25662',thumb='http://thetvdb.com/banners/posters/186551-1.jpg')
                add_posts({'title' : 'Made in Jersey',}, index, mode='newznab&newznab=31673',thumb='http://thetvdb.com/banners/posters/255317-1.jpg')
                add_posts({'title' : 'Make Room For Daddy',}, index, mode='newznab&newznab=4346',thumb='http://thetvdb.com/banners/posters/73496-1.jpg')
                add_posts({'title' : 'Mannix',}, index, mode='newznab&newznab=4368',thumb='http://thetvdb.com/banners/posters/71229-1.jpg')
                add_posts({'title' : 'Medium',}, index, mode='newznab&newznab=4432',thumb='http://thetvdb.com/banners/posters/73265-1.jpg')
                add_posts({'title' : 'Mike and Molly',}, index, mode='newznab&newznab=25050',thumb='http://thetvdb.com/banners/posters/164501-1.jpg')
                add_posts({'title' : 'Million Dollar Password',}, index, mode='newznab&newznab=17752')
                add_posts({'title' : 'Moonlight',}, index, mode='newznab&newznab=15753',thumb='http://thetvdb.com/banners/posters/80512-1.jpg')
                add_posts({'title' : 'Mr Terrific',}, index, mode='newznab&newznab=4545',thumb='http://thetvdb.com/banners/posters/74905-1.jpg')
                add_posts({'title' : 'Murder She Wrote',}, index, mode='newznab&newznab=4554',thumb='http://thetvdb.com/banners/posters/78049-1.jpg')
                add_posts({'title' : 'Nash Bridges',}, index, mode='newznab&newznab=4623',thumb='http://thetvdb.com/banners/posters/70845-1.jpg')
                add_posts({'title' : 'NCIS Los Angeles',}, index, mode='newznab&newznab=21934',thumb='http://thetvdb.com/banners/posters/95441-1.jpg')
                add_posts({'title' : 'NCIS',}, index, mode='newznab&newznab=4628',thumb='http://thetvdb.com/banners/posters/72108-1.jpg')
                add_posts({'title' : 'Numb3rs',}, index, mode='newznab&newznab=4696',thumb='http://thetvdb.com/banners/posters/73918-1.jpg')
                add_posts({'title' : 'NYC 22',}, index, mode='newznab&newznab=28413',thumb='http://thetvdb.com/banners/posters/248933-1.jpg')
                add_posts({'title' : 'On Trial',}, index, mode='newznab&newznab=12457',thumb='http://thetvdb.com/banners/posters/249231-1.jpg')
                add_posts({'title' : 'Partners 2012',}, index, mode='newznab&newznab=30810',thumb='http://thetvdb.com/banners/posters/259092-1.jpg')
                add_posts({'title' : 'Perry Mason',}, index, mode='newznab&newznab=4804',thumb='http://thetvdb.com/banners/posters/70589-1.jpg')
                add_posts({'title' : 'Person of Interest',}, index, mode='newznab&newznab=28376',thumb='http://thetvdb.com/banners/posters/248742-1.jpg')
                add_posts({'title' : 'Petticoat Junction',}, index, mode='newznab&newznab=4813',thumb='http://thetvdb.com/banners/posters/71569-1.jpg')
                add_posts({'title' : 'Rawhide',}, index, mode='newznab&newznab=4948',thumb='http://thetvdb.com/banners/posters/70635-1.jpg')
                add_posts({'title' : 'Rhoda',}, index, mode='newznab&newznab=4997',thumb='http://thetvdb.com/banners/posters/78723-1.jpg')
                add_posts({'title' : 'Rules of Engagement',}, index, mode='newznab&newznab=11224',thumb='http://thetvdb.com/banners/posters/79842-1.jpg')
                add_posts({'title' : 'Same Name',}, index, mode='newznab&newznab=28372',thumb='http://thetvdb.com/banners/posters/249069-1.jpg')
                add_posts({'title' : 'Scarecrow And Mrs King',}, index, mode='newznab&newznab=5104',thumb='http://thetvdb.com/banners/posters/78427-1.jpg')
                add_posts({'title' : 'Shark',}, index, mode='newznab&newznab=8490',thumb='http://thetvdb.com/banners/posters/79388-1.jpg')
                add_posts({'title' : 'Space Rangers',}, index, mode='newznab&newznab=182',thumb='http://thetvdb.com/banners/posters/73652-1.jpg')
                add_posts({'title' : 'Survivor',}, index, mode='newznab&newznab=5418',thumb='http://thetvdb.com/banners/posters/76733-1.jpg')
                add_posts({'title' : 'T J Hooker',}, index, mode='newznab&newznab=5441',thumb='http://thetvdb.com/banners/posters/77076-1.jpg')
                add_posts({'title' : 'Tales From The Cryptkeeper',}, index, mode='newznab&newznab=5449',thumb='http://thetvdb.com/banners/posters/73540-1.jpg')
                add_posts({'title' : 'Teenage Mutant Ninja Turtles 1987',}, index, mode='newznab&newznab=5481',thumb='http://thetvdb.com/banners/posters/74582-1.jpg')
                add_posts({'title' : 'The Amazing Race',}, index, mode='newznab&newznab=5566',thumb='http://thetvdb.com/banners/posters/77666-1.jpg')
                add_posts({'title' : 'The Andy Griffith Show',}, index, mode='newznab&newznab=5574',thumb='http://thetvdb.com/banners/posters/77754-1.jpg')
                add_posts({'title' : 'The Big Bang Theory',}, index, mode='newznab&newznab=8511',thumb='http://thetvdb.com/banners/posters/80379-1.jpg')
                add_posts({'title' : 'The Big C',}, index, mode='newznab&newznab=22774')
                add_posts({'title' : 'The Charlie Brown And Snoopy Show',}, index, mode='newznab&newznab=5678',thumb='http://thetvdb.com/banners/posters/78225-1.jpg')
                add_posts({'title' : 'The Defenders 2010',}, index, mode='newznab&newznab=25663',thumb='http://thetvdb.com/banners/posters/164521-1.jpg')
                add_posts({'title' : 'The Dick Van Dyke Show',}, index, mode='newznab&newznab=5725',thumb='http://thetvdb.com/banners/posters/77041-1.jpg')
                add_posts({'title' : 'The Doris Day Show',}, index, mode='newznab&newznab=5733',thumb='http://thetvdb.com/banners/posters/71658-1.jpg')
                add_posts({'title' : 'The Dukes of Hazzard',}, index, mode='newznab&newznab=5741',thumb='http://thetvdb.com/banners/posters/77748-1.jpg')
                add_posts({'title' : 'The Equalizer',}, index, mode='newznab&newznab=5755',thumb='http://thetvdb.com/banners/posters/72170-1.jpg')
                add_posts({'title' : 'The Good Life',}, index, mode='newznab&newznab=22755',thumb='http://thetvdb.com/banners/posters/95451-1.jpg')
                add_posts({'title' : 'The Good Wife',}, index, mode='newznab&newznab=22755',thumb='http://thetvdb.com/banners/posters/95451-1.jpg')
                add_posts({'title' : 'The Guardian',}, index, mode='newznab&newznab=5835',thumb='http://thetvdb.com/banners/posters/82866-1.jpg')
                add_posts({'title' : 'The Honeymooners',}, index, mode='newznab&newznab=5858',thumb='http://thetvdb.com/banners/posters/73923-1.jpg')
                add_posts({'title' : 'The King of Queens',}, index, mode='newznab&newznab=5907',thumb='http://thetvdb.com/banners/posters/73641-1.jpg')
                add_posts({'title' : 'The Little Mermaid',}, index, mode='newznab&newznab=5936',thumb='http://thetvdb.com/banners/posters/77088-1.jpg')
                add_posts({'title' : 'The Lucy Show',}, index, mode='newznab&newznab=5956',thumb='http://thetvdb.com/banners/posters/70695-1.jpg')
                add_posts({'title' : 'The Mary Tyler Moore Show',}, index, mode='newznab&newznab=5973',thumb='http://thetvdb.com/banners/posters/77051-1.jpg')
                add_posts({'title' : 'The Mentalist',}, index, mode='newznab&newznab=18967',thumb='http://thetvdb.com/banners/posters/82459-1.jpg')
                add_posts({'title' : 'The Munsters',}, index, mode='newznab&newznab=5998',thumb='http://thetvdb.com/banners/posters/77280-1.jpg')
                add_posts({'title' : 'The New Adventures of Old Christine',}, index, mode='newznab&newznab=7908',thumb='http://thetvdb.com/banners/posters/75756-1.jpg')
                add_posts({'title' : 'The New Loretta Young Show',}, index, mode='newznab&newznab=6035',thumb='http://thetvdb.com/banners/posters/75264-1.jpg')
                add_posts({'title' : 'The New Scooby Doo Movies',}, index, mode='newznab&newznab=6041',thumb='http://thetvdb.com/banners/posters/75661-1.jpg')
                add_posts({'title' : 'The Unit',}, index, mode='newznab&newznab=6832',thumb='http://thetvdb.com/banners/posters/75707-1.jpg')
                add_posts({'title' : 'The Waltons',}, index, mode='newznab&newznab=6277',thumb='http://thetvdb.com/banners/posters/71226-1.jpg')
                add_posts({'title' : 'This Is America Charlie Brown',}, index, mode='newznab&newznab=6332',thumb='http://thetvdb.com/banners/posters/73669-1.jpg')
                add_posts({'title' : 'Two and a Half Men',}, index, mode='newznab&newznab=6454',thumb='http://thetvdb.com/banners/posters/72227-1.jpg')
                add_posts({'title' : 'Undercover Boss',}, index, mode='newznab&newznab=22657',thumb='http://thetvdb.com/banners/posters/100061-1.jpg')
                add_posts({'title' : 'Unforgettable',}, index, mode='newznab&newznab=28417',thumb='http://thetvdb.com/banners/posters/248861-1.jpg')
                add_posts({'title' : 'Vegas',}, index, mode='newznab&newznab=31701',thumb='http://thetvdb.com/banners/posters/71051-1.jpg')
                add_posts({'title' : 'Walker Texas Ranger',}, index, mode='newznab&newznab=6534',thumb='http://thetvdb.com/banners/posters/73756-1.jpg')
                add_posts({'title' : 'Wiseguy',}, index, mode='newznab&newznab=6625',thumb='http://thetvdb.com/banners/posters/76273-1.jpg')
                add_posts({'title' : 'Without A Trace',}, index, mode='newznab&newznab=6628',thumb='http://thetvdb.com/banners/posters/77963-1.jpg')
            if newznab_id == 'Centric':
                add_posts({'title' : 'Keeping Up With The Joneses AU',}, index, mode='newznab&newznab=25359',thumb='http://thetvdb.com/banners/posters/198931-1.jpg')
            if newznab_id == 'Channel 10':
                add_posts({'title' : 'Survivor Israel',}, index, mode='newznab&newznab=18604')
            if newznab_id == 'Channel 4':
                add_posts({'title' : '10 O Clock Live',}, index, mode='newznab&newznab=27363',thumb='http://thetvdb.com/banners/posters/221001-1.jpg')
                add_posts({'title' : '10 OClock Live',}, index, mode='newznab&newznab=27363',thumb='http://thetvdb.com/banners/posters/221001-1.jpg')
                add_posts({'title' : '15 Kids And Counting',}, index, mode='newznab&newznab=30578',thumb='http://thetvdb.com/banners/posters/256064-1.jpg')
                add_posts({'title' : '17 Kids And Counting',}, index, mode='newznab&newznab=30578')
                add_posts({'title' : '24 Hours In A And E',}, index, mode='newznab&newznab=28202')
                add_posts({'title' : '8 Out Of 10 Cats',}, index, mode='newznab&newznab=7074',thumb='http://thetvdb.com/banners/posters/79556-1.jpg')
                add_posts({'title' : '999 Whats Your Emergency',}, index, mode='newznab&newznab=32634',thumb='http://thetvdb.com/banners/posters/262366-1.jpg')
                add_posts({'title' : 'A Short History Of Everything Else',}, index, mode='newznab&newznab=31815',thumb='http://thetvdb.com/banners/posters/259922-1.jpg')
                add_posts({'title' : 'Alan Carr Chatty Man',}, index, mode='newznab&newznab=22957',thumb='http://thetvdb.com/banners/posters/99711-1.jpg')
                add_posts({'title' : 'Back From The Dead',}, index, mode='newznab&newznab=29328',thumb='http://thetvdb.com/banners/posters/251743-1.jpg')
                add_posts({'title' : 'Bad Santas',}, index, mode='newznab&newznab=33589',thumb='http://thetvdb.com/banners/posters/264930-1.jpg')
                add_posts({'title' : 'Beauty And The Beast The Ugly Face Of Prejudice',}, index, mode='newznab&newznab=27489',thumb='http://thetvdb.com/banners/posters/263249-1.jpg')
                add_posts({'title' : 'Beauty And The Beast Ugly Face Of Prejudice',}, index, mode='newznab&newznab=27489')
                add_posts({'title' : 'Beenys Restoration Nightmare',}, index, mode='newznab&newznab=26872',thumb='http://thetvdb.com/banners/posters/203691-1.jpg')
                add_posts({'title' : 'Being N Dubz',}, index, mode='newznab&newznab=25976',thumb='http://thetvdb.com/banners/posters/185441-1.jpg')
                add_posts({'title' : 'Big Fat Gipsy Weddings',}, index, mode='newznab&newznab=27371',thumb='http://thetvdb.com/banners/posters/223421-1.jpg')
                add_posts({'title' : 'Big Fat Gypsy Weddings',}, index, mode='newznab&newznab=27371',thumb='http://thetvdb.com/banners/posters/223421-1.jpg')
                add_posts({'title' : 'Black Books',}, index, mode='newznab&newznab=2812',thumb='http://thetvdb.com/banners/posters/76924-1.jpg')
                add_posts({'title' : 'Black Mirror',}, index, mode='newznab&newznab=30348',thumb='http://thetvdb.com/banners/posters/253463-1.jpg')
                add_posts({'title' : 'Bouncers',}, index, mode='newznab&newznab=30704',thumb='http://thetvdb.com/banners/posters/80368-1.jpg')
                add_posts({'title' : 'Brave New World With Stephen Hawking',}, index, mode='newznab&newznab=29668',thumb='http://thetvdb.com/banners/posters/252882-1.jpg')
                add_posts({'title' : 'Campus',}, index, mode='newznab&newznab=27852',thumb='http://thetvdb.com/banners/posters/247101-1.jpg')
                add_posts({'title' : 'Celebrity Bedlam',}, index, mode='newznab&newznab=32415',thumb='http://thetvdb.com/banners/posters/261630-1.jpg')
                add_posts({'title' : 'Celebrity Coach Trip',}, index, mode='newznab&newznab=26842')
                add_posts({'title' : 'Chris Moyles Quiz Night',}, index, mode='newznab&newznab=22033',thumb='http://thetvdb.com/banners/posters/87071-1.jpg')
                add_posts({'title' : 'Civilization Is The West History',}, index, mode='newznab&newznab=27655',thumb='http://thetvdb.com/banners/posters/240211-1.jpg')
                add_posts({'title' : 'Comedy Showcase',}, index, mode='newznab&newznab=23822',thumb='http://thetvdb.com/banners/posters/82760-1.jpg')
                add_posts({'title' : 'Coming Up',}, index, mode='newznab&newznab=32112',thumb='http://thetvdb.com/banners/posters/253027-1.jpg')
                add_posts({'title' : 'Cookery School',}, index, mode='newznab&newznab=27504',thumb='http://thetvdb.com/banners/posters/230501-2.jpg')
                add_posts({'title' : 'Coppers',}, index, mode='newznab&newznab=26811',thumb='http://thetvdb.com/banners/posters/202801-1.jpg')
                add_posts({'title' : 'Countdown UK',}, index, mode='newznab&newznab=7031')
                add_posts({'title' : 'Country House Rescue',}, index, mode='newznab&newznab=20648',thumb='http://thetvdb.com/banners/posters/84079-1.jpg')
                add_posts({'title' : 'Da Ali G Show',}, index, mode='newznab&newznab=3200',thumb='http://thetvdb.com/banners/posters/72165-1.jpg')
                add_posts({'title' : 'Daddy Daycare',}, index, mode='newznab&newznab=30825',thumb='http://thetvdb.com/banners/posters/256253-1.jpg')
                add_posts({'title' : 'David Walliams Awfully Good',}, index, mode='newznab&newznab=27908',thumb='http://thetvdb.com/banners/posters/218521-1.jpg')
                add_posts({'title' : 'Derren Brown Apocalypse',}, index, mode='newznab&newznab=33149')
                add_posts({'title' : 'Derren Brown Fear And Faith',}, index, mode='newznab&newznab=33328')
                add_posts({'title' : 'Derren Brown The Experiments',}, index, mode='newznab&newznab=29800',thumb='http://thetvdb.com/banners/posters/252707-1.jpg')
                add_posts({'title' : 'Dispatches',}, index, mode='newznab&newznab=10932',thumb='http://thetvdb.com/banners/posters/83231-1.jpg')
                add_posts({'title' : 'Double Your House For Half The Money',}, index, mode='newznab&newznab=32644',thumb='http://thetvdb.com/banners/posters/262377-1.jpg')
                add_posts({'title' : 'Educating Essex',}, index, mode='newznab&newznab=29485',thumb='http://thetvdb.com/banners/posters/252106-1.jpg')
                add_posts({'title' : 'Embarrassing Bodies Live From The Clinic',}, index, mode='newznab&newznab=28301',thumb='http://thetvdb.com/banners/posters/259193-1.jpg')
                add_posts({'title' : 'Embarrassing Bodies',}, index, mode='newznab&newznab=26610',thumb='http://thetvdb.com/banners/posters/136191-1.jpg')
                add_posts({'title' : 'Embarrassing Fat Bodies',}, index, mode='newznab&newznab=28470',thumb='http://thetvdb.com/banners/posters/249332-1.jpg')
                add_posts({'title' : 'Embarrassing Teen Bodies',}, index, mode='newznab&newznab=28757',thumb='http://thetvdb.com/banners/posters/250103-1.jpg')
                add_posts({'title' : 'Facejacker',}, index, mode='newznab&newznab=25454',thumb='http://thetvdb.com/banners/posters/157221-1.jpg')
                add_posts({'title' : 'Fighting On The Frontline',}, index, mode='newznab&newznab=29547',thumb='http://thetvdb.com/banners/posters/252537-1.jpg')
                add_posts({'title' : 'Food Unwrapped',}, index, mode='newznab&newznab=32643',thumb='http://thetvdb.com/banners/posters/262305-1.jpg')
                add_posts({'title' : 'Four In A Bed',}, index, mode='newznab&newznab=28644',thumb='http://thetvdb.com/banners/posters/207701-1.jpg')
                add_posts({'title' : 'Four Rooms',}, index, mode='newznab&newznab=28302',thumb='http://thetvdb.com/banners/posters/249421-1.jpg')
                add_posts({'title' : 'Frankie Boyles Tramadol Nights',}, index, mode='newznab&newznab=26922',thumb='http://thetvdb.com/banners/posters/205911-1.jpg')
                add_posts({'title' : 'Fresh Meat',}, index, mode='newznab&newznab=29484',thumb='http://thetvdb.com/banners/posters/251889-1.jpg')
                add_posts({'title' : 'Friday Night Dinner',}, index, mode='newznab&newznab=27623',thumb='http://thetvdb.com/banners/posters/235081-1.jpg')
                add_posts({'title' : 'Full English',}, index, mode='newznab&newznab=33392',thumb='http://thetvdb.com/banners/posters/264071-1.jpg')
                add_posts({'title' : 'Get Your House In Order',}, index, mode='newznab&newznab=31075',thumb='http://thetvdb.com/banners/posters/257900-1.jpg')
                add_posts({'title' : 'Gok Cooks Chinese',}, index, mode='newznab&newznab=31629',thumb='http://thetvdb.com/banners/posters/259293-1.jpg')
                add_posts({'title' : 'Goks Clothes Roadshow',}, index, mode='newznab&newznab=27414',thumb='http://thetvdb.com/banners/posters/223221-1.jpg')
                add_posts({'title' : 'Goks Teens The Naked Truth',}, index, mode='newznab&newznab=30761',thumb='http://thetvdb.com/banners/posters/255942-1.jpg')
                add_posts({'title' : 'Gordon Ramsays Ultimate Cookery Course',}, index, mode='newznab&newznab=32645',thumb='http://thetvdb.com/banners/posters/262267-1.jpg')
                add_posts({'title' : 'Gordons Great Escape',}, index, mode='newznab&newznab=24862',thumb='http://thetvdb.com/banners/posters/136311-1.jpg')
                add_posts({'title' : 'Grand Designs Abroad',}, index, mode='newznab&newznab=11191',thumb='http://thetvdb.com/banners/posters/82408-1.jpg')
                add_posts({'title' : 'Grand Designs Trade Secrets',}, index, mode='newznab&newznab=18739',thumb='http://thetvdb.com/banners/posters/85324-1.jpg')
                add_posts({'title' : 'Grand Designs',}, index, mode='newznab&newznab=11187',thumb='http://thetvdb.com/banners/posters/79264-1.jpg')
                add_posts({'title' : 'Green Wing',}, index, mode='newznab&newznab=3738',thumb='http://thetvdb.com/banners/posters/78899-1.jpg')
                add_posts({'title' : 'Hacks',}, index, mode='newznab&newznab=30380',thumb='http://thetvdb.com/banners/posters/254799-1.jpg')
                add_posts({'title' : 'Help My House Is Falling Down',}, index, mode='newznab&newznab=26266',thumb='http://thetvdb.com/banners/posters/182101-1.jpg')
                add_posts({'title' : 'Hestons Fantastical Food',}, index, mode='newznab&newznab=33325',thumb='http://thetvdb.com/banners/posters/263928-1.jpg')
                add_posts({'title' : 'Hestons Feast',}, index, mode='newznab&newznab=21879',thumb='http://thetvdb.com/banners/posters/85356-1.jpg')
                add_posts({'title' : 'Hestons Mission Impossible',}, index, mode='newznab&newznab=27580',thumb='http://thetvdb.com/banners/posters/232161-1.jpg')
                add_posts({'title' : 'Hidden Talent',}, index, mode='newznab&newznab=31362',thumb='http://thetvdb.com/banners/posters/258458-1.jpg')
                add_posts({'title' : 'Hit The Road Jack',}, index, mode='newznab&newznab=31074',thumb='http://thetvdb.com/banners/posters/257242-1.jpg')
                add_posts({'title' : 'Home Of The Future',}, index, mode='newznab&newznab=30853',thumb='http://thetvdb.com/banners/posters/256057-1.jpg')
                add_posts({'title' : 'Hotel GB',}, index, mode='newznab&newznab=32877',thumb='http://thetvdb.com/banners/posters/262731-1.jpg')
                add_posts({'title' : 'How To Cook Like Heston',}, index, mode='newznab&newznab=30387',thumb='http://thetvdb.com/banners/posters/255004-1.jpg')
                add_posts({'title' : 'Hughs Fish Fight',}, index, mode='newznab&newznab=27348',thumb='http://thetvdb.com/banners/posters/220651-1.jpg')
                add_posts({'title' : 'Hughs Three Hungry Boys',}, index, mode='newznab&newznab=30581',thumb='http://thetvdb.com/banners/posters/256134-1.jpg')
                add_posts({'title' : 'Im Spazticus',}, index, mode='newznab&newznab=32614',thumb='http://thetvdb.com/banners/posters/261699-1.jpg')
                add_posts({'title' : 'Inside Natures Giants',}, index, mode='newznab&newznab=23045',thumb='http://thetvdb.com/banners/posters/103211-1.jpg')
                add_posts({'title' : 'Jakes Progress',}, index, mode='newznab&newznab=18000',thumb='http://thetvdb.com/banners/posters/250304-1.jpg')
                add_posts({'title' : 'Jam',}, index, mode='newznab&newznab=716',thumb='http://thetvdb.com/banners/posters/80617-1.jpg')
                add_posts({'title' : 'Jamies 15 Minute Meals',}, index, mode='newznab&newznab=33147',thumb='http://thetvdb.com/banners/posters/263506-1.jpg')
                add_posts({'title' : 'Jamies 16 Minute Meals',}, index, mode='newznab&newznab=33147',thumb='http://thetvdb.com/banners/posters/263506-1.jpg')
                add_posts({'title' : 'Jamies 30 Minute Meals',}, index, mode='newznab&newznab=26723',thumb='http://thetvdb.com/banners/posters/197031-1.jpg')
                add_posts({'title' : 'Jamies American Road Trip',}, index, mode='newznab&newznab=23703',thumb='http://thetvdb.com/banners/posters/111161-1.jpg')
                add_posts({'title' : 'Jamies Christmas With Bells On',}, index, mode='newznab&newznab=30222',thumb='http://thetvdb.com/banners/posters/254353-1.jpg')
                add_posts({'title' : 'Jamies Dream School',}, index, mode='newznab&newznab=27621',thumb='http://thetvdb.com/banners/posters/230311-1.jpg')
                add_posts({'title' : 'Jamies Great Britain',}, index, mode='newznab&newznab=29802',thumb='http://thetvdb.com/banners/posters/253097-1.jpg')
                add_posts({'title' : 'Jamies Summer Food Rave Up',}, index, mode='newznab&newznab=32094',thumb='http://thetvdb.com/banners/posters/260409-1.jpg')
                add_posts({'title' : 'Jimmy And The Giant Supermarket',}, index, mode='newznab&newznab=31694',thumb='http://thetvdb.com/banners/posters/259460-1.jpg')
                add_posts({'title' : 'Jo Frost Extreme Parental Guidance',}, index, mode='newznab&newznab=25023',thumb='http://thetvdb.com/banners/posters/142391-1.jpg')
                add_posts({'title' : 'Katie My Beautiful Friends',}, index, mode='newznab&newznab=27756',thumb='http://thetvdb.com/banners/posters/254617-1.jpg')
                add_posts({'title' : 'Kevin McClouds Man Made Home',}, index, mode='newznab&newznab=32799',thumb='http://thetvdb.com/banners/posters/262648-1.jpg')
                add_posts({'title' : 'Kirsties Handmade Britain',}, index, mode='newznab&newznab=29709',thumb='http://thetvdb.com/banners/posters/253299-1.jpg')
                add_posts({'title' : 'Kirsties Handmade Chirstmas',}, index, mode='newznab&newznab=30185')
                add_posts({'title' : 'Kirsties Handmade Christmas',}, index, mode='newznab&newznab=30185')
                add_posts({'title' : 'Lily Allen From Riches To Rags',}, index, mode='newznab&newznab=27721')
                add_posts({'title' : 'Living With The Amish',}, index, mode='newznab&newznab=30127',thumb='http://thetvdb.com/banners/posters/253893-1.jpg')
                add_posts({'title' : 'Location Location Location',}, index, mode='newznab&newznab=8360',thumb='http://thetvdb.com/banners/posters/82195-1.jpg')
                add_posts({'title' : 'Lost Children',}, index, mode='newznab&newznab=32305')
                add_posts({'title' : 'Mary Portas Secret Shopper',}, index, mode='newznab&newznab=27361')
                add_posts({'title' : 'Mary Queen Of Frocks',}, index, mode='newznab&newznab=29595',thumb='http://thetvdb.com/banners/posters/252622-1.jpg')
                add_posts({'title' : 'My Transsexual Summer',}, index, mode='newznab&newznab=29981',thumb='http://thetvdb.com/banners/posters/253604-1.jpg')
                add_posts({'title' : 'One Born Every Minute',}, index, mode='newznab&newznab=25014',thumb='http://thetvdb.com/banners/posters/142401-1.jpg')
                add_posts({'title' : 'Party Paramedics',}, index, mode='newznab&newznab=30673',thumb='http://thetvdb.com/banners/posters/255500-1.jpg')
                add_posts({'title' : 'Peep Show',}, index, mode='newznab&newznab=849',thumb='http://thetvdb.com/banners/posters/71656-1.jpg')
                add_posts({'title' : 'Pete Versus Life',}, index, mode='newznab&newznab=26234',thumb='http://thetvdb.com/banners/posters/180871-1.jpg')
                add_posts({'title' : 'Phil Spencer Secret Agent',}, index, mode='newznab&newznab=29671',thumb='http://thetvdb.com/banners/posters/260132-1.jpg')
                add_posts({'title' : 'Quiz Trippers',}, index, mode='newznab&newznab=28884')
                add_posts({'title' : 'Ramsays Kitchen Nightmares',}, index, mode='newznab&newznab=4943',thumb='http://thetvdb.com/banners/posters/74584-1.jpg')
                add_posts({'title' : 'Relocation Phil Down Under',}, index, mode='newznab&newznab=24866',thumb='http://thetvdb.com/banners/posters/137191-1.jpg')
                add_posts({'title' : 'Relocation Relocation',}, index, mode='newznab&newznab=18344')
                add_posts({'title' : 'River Cottage Veg',}, index, mode='newznab&newznab=29710')
                add_posts({'title' : 'Rome Wasnt Built In A Day',}, index, mode='newznab&newznab=27358')
                add_posts({'title' : 'Rude Tube',}, index, mode='newznab&newznab=20491',thumb='http://thetvdb.com/banners/posters/84364-1.jpg')
                add_posts({'title' : 'Scrapheap Challenge The Scrappy Races',}, index, mode='newznab&newznab=13016',thumb='http://thetvdb.com/banners/posters/85470-1.jpg')
                add_posts({'title' : 'Scrapheap Challenge',}, index, mode='newznab&newznab=10833',thumb='http://thetvdb.com/banners/posters/79903-1.jpg')
                add_posts({'title' : 'Secret Eaters',}, index, mode='newznab&newznab=31565',thumb='http://thetvdb.com/banners/posters/259112-1.jpg')
                add_posts({'title' : 'Secret State',}, index, mode='newznab&newznab=33326',thumb='http://thetvdb.com/banners/posters/263672-1.jpg')
                add_posts({'title' : 'Seven Dwarves',}, index, mode='newznab&newznab=29134',thumb='http://thetvdb.com/banners/posters/251208-1.jpg')
                add_posts({'title' : 'Shameless',}, index, mode='newznab&newznab=5162',thumb='http://thetvdb.com/banners/posters/78846-1.jpg')
                add_posts({'title' : 'Show Me Your Money',}, index, mode='newznab&newznab=32161',thumb='http://thetvdb.com/banners/posters/260719-1.jpg')
                add_posts({'title' : 'Sirens UK',}, index, mode='newznab&newznab=28700',thumb='http://thetvdb.com/banners/posters/249478-1.jpg')
                add_posts({'title' : 'Six Wives Of Henry VIII',}, index, mode='newznab&newznab=31536')
                add_posts({'title' : 'Spoons',}, index, mode='newznab&newznab=9841')
                add_posts({'title' : 'Stand Up For The Week',}, index, mode='newznab&newznab=25906',thumb='http://thetvdb.com/banners/posters/171851-1.jpg')
                add_posts({'title' : 'Stephen Fry Gadget Man',}, index, mode='newznab&newznab=33431',thumb='http://thetvdb.com/banners/posters/264190-1.jpg')
                add_posts({'title' : 'Superscrimpers Waste Not Want Not',}, index, mode='newznab&newznab=27795',thumb='http://thetvdb.com/banners/posters/247381-1.jpg')
                add_posts({'title' : 'Supersize Versus Superskinny Kids',}, index, mode='newznab&newznab=27755')
                add_posts({'title' : 'Supersize Vs Superskinny',}, index, mode='newznab&newznab=23001',thumb='http://thetvdb.com/banners/posters/81582-1.jpg')
                add_posts({'title' : 'The Angelos Neil Epithemiou Show',}, index, mode='newznab&newznab=32169')
                add_posts({'title' : 'The Audience',}, index, mode='newznab&newznab=32646',thumb='http://thetvdb.com/banners/posters/262465-1.jpg')
                add_posts({'title' : 'The Birth Of Britain',}, index, mode='newznab&newznab=27357')
                add_posts({'title' : 'The Book Group',}, index, mode='newznab&newznab=460',thumb='http://thetvdb.com/banners/posters/78588-1.jpg')
                add_posts({'title' : 'The Comic Strip Presents',}, index, mode='newznab&newznab=5690',thumb='http://thetvdb.com/banners/posters/76387-1.jpg')
                add_posts({'title' : 'The Comics Choice Awards',}, index, mode='newznab&newznab=27356')
                add_posts({'title' : 'The Fabulous Baker Brothers',}, index, mode='newznab&newznab=30388',thumb='http://thetvdb.com/banners/posters/254991-1.jpg')
                add_posts({'title' : 'The Fairy Jobmother',}, index, mode='newznab&newznab=26071',thumb='http://thetvdb.com/banners/posters/265158-1.jpg')
                add_posts({'title' : 'The Fat Fighters',}, index, mode='newznab&newznab=30374')
                add_posts({'title' : 'The Fear 2012',}, index, mode='newznab&newznab=32272',thumb='http://thetvdb.com/banners/posters/263731-1.jpg')
                add_posts({'title' : 'The Food Hospital',}, index, mode='newznab&newznab=29860',thumb='http://thetvdb.com/banners/posters/253842-1.jpg')
                add_posts({'title' : 'The Ghost Squad',}, index, mode='newznab&newznab=6809',thumb='http://thetvdb.com/banners/posters/79155-1.jpg')
                add_posts({'title' : 'The Great British Property Scandal',}, index, mode='newznab&newznab=30177')
                add_posts({'title' : 'The Hoarder Next Door',}, index, mode='newznab&newznab=31452',thumb='http://thetvdb.com/banners/posters/259145-1.jpg')
                add_posts({'title' : 'The Hotel',}, index, mode='newznab&newznab=28032',thumb='http://thetvdb.com/banners/posters/84432-1.jpg')
                add_posts({'title' : 'The House the 50s Built',}, index, mode='newznab&newznab=31731',thumb='http://thetvdb.com/banners/posters/259774-1.jpg')
                add_posts({'title' : 'The IT Crowd',}, index, mode='newznab&newznab=8044',thumb='http://thetvdb.com/banners/posters/79216-1.jpg')
                add_posts({'title' : 'The Joy Of Teen Sex',}, index, mode='newznab&newznab=27362',thumb='http://thetvdb.com/banners/posters/223501-1.jpg')
                add_posts({'title' : 'The King Of',}, index, mode='newznab&newznab=28575',thumb='http://thetvdb.com/banners/posters/249590-1.jpg')
                add_posts({'title' : 'The Mad Bad Ad Show',}, index, mode='newznab&newznab=30836',thumb='http://thetvdb.com/banners/posters/255965-1.jpg')
                add_posts({'title' : 'The Model Agency',}, index, mode='newznab&newznab=27582',thumb='http://thetvdb.com/banners/posters/235101-1.jpg')
                add_posts({'title' : 'The New Paul Ogrady Show',}, index, mode='newznab&newznab=10218')
                add_posts({'title' : 'The Peoples Supermarket',}, index, mode='newznab&newznab=27503',thumb='http://thetvdb.com/banners/posters/229741-1.jpg')
                add_posts({'title' : 'The Promise',}, index, mode='newznab&newznab=27499',thumb='http://thetvdb.com/banners/posters/229071-1.jpg')
                add_posts({'title' : 'The Restoration Man',}, index, mode='newznab&newznab=25305',thumb='http://thetvdb.com/banners/posters/151501-1.jpg')
                add_posts({'title' : 'The Secret Life Of Buildings',}, index, mode='newznab&newznab=29044',thumb='http://thetvdb.com/banners/posters/250758-1.jpg')
                add_posts({'title' : 'The Secret Millionaire',}, index, mode='newznab&newznab=14681',thumb='http://thetvdb.com/banners/posters/79687-1.jpg')
                add_posts({'title' : 'The Sex Education Show',}, index, mode='newznab&newznab=19970',thumb='http://thetvdb.com/banners/posters/83169-1.jpg')
                add_posts({'title' : 'The Sex Researchers',}, index, mode='newznab&newznab=28699',thumb='http://thetvdb.com/banners/posters/249605-1.jpg')
                add_posts({'title' : 'The Undateables',}, index, mode='newznab&newznab=31183',thumb='http://thetvdb.com/banners/posters/257867-1.jpg')
                add_posts({'title' : 'The Vue Film Show',}, index, mode='newznab&newznab=30196',thumb='http://thetvdb.com/banners/posters/249054-1.jpg')
                add_posts({'title' : 'Thelmas Gypsy Girls',}, index, mode='newznab&newznab=32209',thumb='http://thetvdb.com/banners/posters/260682-1.jpg')
                add_posts({'title' : 'This Is England 86',}, index, mode='newznab&newznab=26481')
                add_posts({'title' : 'This Is England 88',}, index, mode='newznab&newznab=26481')
                add_posts({'title' : 'Three In A Bed',}, index, mode='newznab&newznab=25456',thumb='http://thetvdb.com/banners/posters/165711-1.jpg')
                add_posts({'title' : 'Time Team',}, index, mode='newznab&newznab=8551',thumb='http://thetvdb.com/banners/posters/73096-1.jpg')
                add_posts({'title' : 'Tony Robinsons Gods And Monsters',}, index, mode='newznab&newznab=30158',thumb='http://thetvdb.com/banners/posters/253981-1.jpg')
                add_posts({'title' : 'Top Boy',}, index, mode='newznab&newznab=29861',thumb='http://thetvdb.com/banners/posters/253138-1.jpg')
                add_posts({'title' : 'True Stories UK',}, index, mode='newznab&newznab=30584')
                add_posts({'title' : 'Undercover Boss UK',}, index, mode='newznab&newznab=26074')
                add_posts({'title' : 'Vacation Vacation Vacation',}, index, mode='newznab&newznab=27794',thumb='http://thetvdb.com/banners/posters/245501-1.jpg')
                add_posts({'title' : 'Very Important People',}, index, mode='newznab&newznab=31363',thumb='http://thetvdb.com/banners/posters/258531-1.jpg')
                add_posts({'title' : 'White Teeth',}, index, mode='newznab&newznab=715',thumb='http://thetvdb.com/banners/posters/250833-1.jpg')
            if newznab_id == 'Channel 5':
                add_posts({'title' : 'Banged Up Abroad',}, index, mode='newznab&newznab=19682',thumb='http://thetvdb.com/banners/posters/83430-1.jpg')
                add_posts({'title' : 'Big Brother UK',}, index, mode='newznab&newznab=2792',thumb='http://thetvdb.com/banners/posters/72549-1.jpg')
                add_posts({'title' : 'Celebrity Big Brother',}, index, mode='newznab&newznab=3012',thumb='http://thetvdb.com/banners/posters/70760-1.jpg')
                add_posts({'title' : 'Fraud Squad UK',}, index, mode='newznab&newznab=29178',thumb='http://thetvdb.com/banners/posters/251488-1.jpg')
                add_posts({'title' : 'Royal Marines Mission Afghanistan',}, index, mode='newznab&newznab=30703',thumb='http://thetvdb.com/banners/posters/255761-1.jpg')
                add_posts({'title' : 'The Beat Goes On',}, index, mode='newznab&newznab=29185')
            if newznab_id == 'Channel 7':
                add_posts({'title' : 'Dinner Date AU',}, index, mode='newznab&newznab=29210')
                add_posts({'title' : 'Highway Patrol AU',}, index, mode='newznab&newznab=23896')
            if newznab_id == 'Chiba TV':
                add_posts({'title' : 'Black Lagoon',}, index, mode='newznab&newznab=18063',thumb='http://thetvdb.com/banners/posters/79604-1.jpg')
            if newznab_id == 'CineMax':
                add_posts({'title' : 'Chemistry',}, index, mode='newznab&newznab=29273',thumb='http://thetvdb.com/banners/posters/251405-1.jpg')
                add_posts({'title' : 'Femme Fatales',}, index, mode='newznab&newznab=28282',thumb='http://thetvdb.com/banners/posters/249164-1.jpg')
                add_posts({'title' : 'Skin to the Max',}, index, mode='newznab&newznab=29274',thumb='http://thetvdb.com/banners/posters/251399-1.jpg')
            if newznab_id == 'CITV':
                add_posts({'title' : 'Kipper',}, index, mode='newznab&newznab=4138',thumb='http://thetvdb.com/banners/posters/71479-1.jpg')
            if newznab_id == 'CityTV':
                add_posts({'title' : 'Canadas Got Talent',}, index, mode='newznab&newznab=29038',thumb='http://thetvdb.com/banners/posters/256805-1.jpg')
                add_posts({'title' : 'The Bachelor Canada',}, index, mode='newznab&newznab=33212',thumb='http://thetvdb.com/banners/posters/262880-1.jpg')
            if newznab_id == 'Cloo':
                add_posts({'title' : 'Killer Instinct 2011',}, index, mode='newznab&newznab=29280',thumb='http://thetvdb.com/banners/posters/251830-1.jpg')
            if newznab_id == 'CMT':
                add_posts({'title' : 'Angels Among Us',}, index, mode='newznab&newznab=29244',thumb='http://thetvdb.com/banners/posters/251776-1.jpg')
                add_posts({'title' : 'Bayou Billionaires',}, index, mode='newznab&newznab=29759',thumb='http://thetvdb.com/banners/posters/253211-1.jpg')
                add_posts({'title' : 'Big Texas Heat',}, index, mode='newznab&newznab=33227',thumb='http://thetvdb.com/banners/posters/263324-1.jpg')
                add_posts({'title' : 'Chainsaw Gang',}, index, mode='newznab&newznab=32317',thumb='http://thetvdb.com/banners/posters/263322-1.jpg')
                add_posts({'title' : 'Cheer',}, index, mode='newznab&newznab=24598',thumb='http://thetvdb.com/banners/posters/261795-1.jpg')
                add_posts({'title' : 'Dallas Cowboys Cheerleaders Making the Team',}, index, mode='newznab&newznab=13782',thumb='http://thetvdb.com/banners/posters/79395-1.jpg')
                add_posts({'title' : 'Jennie Garth A Little Bit Country',}, index, mode='newznab&newznab=31142')
                add_posts({'title' : 'Made in America',}, index, mode='newznab&newznab=19606')
                add_posts({'title' : 'Melissa and Tye',}, index, mode='newznab&newznab=31484',thumb='http://thetvdb.com/banners/posters/257485-1.jpg')
                add_posts({'title' : 'My Big Redneck Vacation',}, index, mode='newznab&newznab=30534',thumb='http://thetvdb.com/banners/posters/254679-1.jpg')
                add_posts({'title' : 'Redneck Island',}, index, mode='newznab&newznab=31705',thumb='http://thetvdb.com/banners/posters/259570-1.jpg')
                add_posts({'title' : 'Redneck Rehab',}, index, mode='newznab&newznab=32544',thumb='http://thetvdb.com/banners/posters/262492-1.jpg')
                add_posts({'title' : 'Southern Nights',}, index, mode='newznab&newznab=31267',thumb='http://thetvdb.com/banners/posters/257348-1.jpg')
                add_posts({'title' : 'Sweet Home Alabama',}, index, mode='newznab&newznab=28762',thumb='http://thetvdb.com/banners/posters/250306-1.jpg')
                add_posts({'title' : 'Texas Women',}, index, mode='newznab&newznab=28763',thumb='http://thetvdb.com/banners/posters/250334-1.jpg')
                add_posts({'title' : 'Top Secret Recipe',}, index, mode='newznab&newznab=29633',thumb='http://thetvdb.com/banners/posters/253007-1.jpg')
                add_posts({'title' : 'Working Class',}, index, mode='newznab&newznab=26928',thumb='http://thetvdb.com/banners/posters/214051-1.jpg')
                add_posts({'title' : 'Worlds Strictest Parents',}, index, mode='newznab&newznab=22386')
            if newznab_id == 'CNBC':
                add_posts({'title' : 'American Greed',}, index, mode='newznab&newznab=21731',thumb='http://thetvdb.com/banners/posters/170491-1.jpg')
            if newznab_id == 'Comedy Central':
                add_posts({'title' : 'Brickleberry',}, index, mode='newznab&newznab=31996',thumb='http://thetvdb.com/banners/posters/259569-1.jpg')
                add_posts({'title' : 'Comedy Central Presents',}, index, mode='newznab&newznab=3117',thumb='http://thetvdb.com/banners/posters/74337-1.jpg')
                add_posts({'title' : 'Dog Bites Man',}, index, mode='newznab&newznab=7234',thumb='http://thetvdb.com/banners/posters/79555-1.jpg')
                add_posts({'title' : 'Futurama',}, index, mode='newznab&newznab=3628',thumb='http://thetvdb.com/banners/posters/73871-1.jpg')
                add_posts({'title' : 'Gabriel Iglesias Presents Stand Up Revolution',}, index, mode='newznab&newznab=29424')
                add_posts({'title' : 'Hounds',}, index, mode='newznab&newznab=24849',thumb='http://thetvdb.com/banners/posters/259574-1.jpg')
                add_posts({'title' : 'Important Things With Demetri Martin',}, index, mode='newznab&newznab=20802',thumb='http://thetvdb.com/banners/posters/85061-1.jpg')
                add_posts({'title' : 'John Olivers New York Stand Up Show',}, index, mode='newznab&newznab=24553',thumb='http://thetvdb.com/banners/posters/136521-1.jpg')
                add_posts({'title' : 'Jon Benjamin Has a Van',}, index, mode='newznab&newznab=28612',thumb='http://thetvdb.com/banners/posters/249373-1.jpg')
                add_posts({'title' : 'Key and Peele',}, index, mode='newznab&newznab=30543',thumb='http://thetvdb.com/banners/posters/255325-1.jpg')
                add_posts({'title' : 'Michael And Michael Have Issues',}, index, mode='newznab&newznab=22705',thumb='http://thetvdb.com/banners/posters/105331-1.jpg')
                add_posts({'title' : 'Nick Swardsons Pretend Time',}, index, mode='newznab&newznab=26352',thumb='http://thetvdb.com/banners/posters/194551-1.jpg')
                add_posts({'title' : 'Onion SportsDome',}, index, mode='newznab&newznab=27060',thumb='http://thetvdb.com/banners/posters/209551-1.jpg')
                add_posts({'title' : 'South Park',}, index, mode='newznab&newznab=5266',thumb='http://thetvdb.com/banners/posters/75897-1.jpg')
                add_posts({'title' : 'Strangers With Candy',}, index, mode='newznab&newznab=5364',thumb='http://thetvdb.com/banners/posters/75341-1.jpg')
                add_posts({'title' : 'The Burn',}, index, mode='newznab&newznab=32013')
                add_posts({'title' : 'The Half Hour',}, index, mode='newznab&newznab=31652',thumb='http://thetvdb.com/banners/posters/259073-1.jpg')
                add_posts({'title' : 'The Sarah Silverman Program',}, index, mode='newznab&newznab=8065',thumb='http://thetvdb.com/banners/posters/79789-1.jpg')
                add_posts({'title' : 'Tosh 0',}, index, mode='newznab&newznab=22690',thumb='http://thetvdb.com/banners/posters/97731-1.jpg')
                add_posts({'title' : 'Ugly Americans',}, index, mode='newznab&newznab=22711',thumb='http://thetvdb.com/banners/posters/150051-1.jpg')
                add_posts({'title' : 'Upright Citizens Brigade',}, index, mode='newznab&newznab=1607',thumb='http://thetvdb.com/banners/posters/76823-1.jpg')
                add_posts({'title' : 'Workaholics',}, index, mode='newznab&newznab=23658',thumb='http://thetvdb.com/banners/posters/211751-1.jpg')
            if newznab_id == 'Comedy Central UK':
                add_posts({'title' : 'Threesome',}, index, mode='newznab&newznab=29870',thumb='http://thetvdb.com/banners/posters/252854-1.jpg')
            if newznab_id == 'Cooking Channel':
                add_posts({'title' : 'Bills Food',}, index, mode='newznab&newznab=25835',thumb='http://thetvdb.com/banners/posters/82983-1.jpg')
                add_posts({'title' : 'Food ography',}, index, mode='newznab&newznab=25822',thumb='http://thetvdb.com/banners/posters/219481-1.jpg')
                add_posts({'title' : 'Not My Mamas Meals',}, index, mode='newznab&newznab=30508',thumb='http://thetvdb.com/banners/posters/255244-1.jpg')
                add_posts({'title' : 'The Big Cheese',}, index, mode='newznab&newznab=29966',thumb='http://thetvdb.com/banners/posters/254555-1.jpg')
                add_posts({'title' : 'The Originals With Emeril',}, index, mode='newznab&newznab=28125',thumb='http://thetvdb.com/banners/posters/248788-1.jpg')
                add_posts({'title' : 'Unique Eats',}, index, mode='newznab&newznab=25825',thumb='http://thetvdb.com/banners/posters/226251-1.jpg')
                add_posts({'title' : 'Unique Sweets',}, index, mode='newznab&newznab=28106',thumb='http://thetvdb.com/banners/posters/248467-1.jpg')
            if newznab_id == 'Court TV':
                add_posts({'title' : 'Open Court',}, index, mode='newznab&newznab=31017')
            if newznab_id == 'Crackle':
                add_posts({'title' : 'Comedians In Cars Getting Coffee',}, index, mode='newznab&newznab=32630',thumb='http://thetvdb.com/banners/posters/260845-1.jpg')
            if newznab_id == 'Crime and Investigation Network':
                add_posts({'title' : 'Kalgoorlie Cops',}, index, mode='newznab&newznab=28208',thumb='http://thetvdb.com/banners/posters/247954-1.jpg')
            if newznab_id == 'CTV':
                add_posts({'title' : 'Corner Gas',}, index, mode='newznab&newznab=3139',thumb='http://thetvdb.com/banners/posters/73615-1.jpg')
                add_posts({'title' : 'Dan For Mayor',}, index, mode='newznab&newznab=25240',thumb='http://thetvdb.com/banners/posters/144621-1.jpg')
                add_posts({'title' : 'Flashpoint',}, index, mode='newznab&newznab=18531',thumb='http://thetvdb.com/banners/posters/82438-1.jpg')
                add_posts({'title' : 'FX The Series',}, index, mode='newznab&newznab=3482',thumb='http://thetvdb.com/banners/posters/73771-1.jpg')
                add_posts({'title' : 'Hiccups',}, index, mode='newznab&newznab=23201',thumb='http://thetvdb.com/banners/posters/142001-1.jpg')
                add_posts({'title' : 'Instant Star',}, index, mode='newznab&newznab=3974',thumb='http://thetvdb.com/banners/posters/74703-1.jpg')
                add_posts({'title' : 'Saving Hope',}, index, mode='newznab&newznab=30617',thumb='http://thetvdb.com/banners/posters/256111-1.jpg')
                add_posts({'title' : 'So You Think You Can Dance Canada',}, index, mode='newznab&newznab=20068',thumb='http://thetvdb.com/banners/posters/83034-1.jpg')
                add_posts({'title' : 'The Bridge',}, index, mode='newznab&newznab=21894',thumb='http://thetvdb.com/banners/posters/140151-1.jpg')
                add_posts({'title' : 'The Listener',}, index, mode='newznab&newznab=18689',thumb='http://thetvdb.com/banners/posters/85358-1.jpg')
                add_posts({'title' : 'The Listner',}, index, mode='newznab&newznab=18689',thumb='http://thetvdb.com/banners/posters/85358-1.jpg')
                add_posts({'title' : 'The Starlost',}, index, mode='newznab&newznab=6211',thumb='http://thetvdb.com/banners/posters/76802-1.jpg')
            if newznab_id == 'Current TV':
                add_posts({'title' : '4th and Forever',}, index, mode='newznab&newznab=28139',thumb='http://thetvdb.com/banners/posters/249758-1.jpg')
                add_posts({'title' : 'Bar Karma',}, index, mode='newznab&newznab=27557',thumb='http://thetvdb.com/banners/posters/219431-1.jpg')
                add_posts({'title' : 'Vanguard',}, index, mode='newznab&newznab=28708',thumb='http://thetvdb.com/banners/posters/222061-1.jpg')
            if newznab_id == 'Dave':
                add_posts({'title' : 'Al Murrays Compete For The Meat',}, index, mode='newznab&newznab=28317',thumb='http://thetvdb.com/banners/posters/249079-1.jpg')
                add_posts({'title' : 'Alexander Armstrongs Big Ask',}, index, mode='newznab&newznab=28382',thumb='http://thetvdb.com/banners/posters/249167-1.jpg')
                add_posts({'title' : 'Argumental',}, index, mode='newznab&newznab=20685',thumb='http://thetvdb.com/banners/posters/83597-1.jpg')
                add_posts({'title' : 'Bush Pilots',}, index, mode='newznab&newznab=32239',thumb='http://thetvdb.com/banners/posters/260414-1.jpg')
                add_posts({'title' : 'Dara O Briain School Of Hard Sums',}, index, mode='newznab&newznab=31297')
                add_posts({'title' : 'Daves One Night Stand',}, index, mode='newznab&newznab=29021',thumb='http://thetvdb.com/banners/posters/196861-1.jpg')
                add_posts({'title' : 'Red Dwarf',}, index, mode='newznab&newznab=4959',thumb='http://thetvdb.com/banners/posters/71326-1.jpg')
            if newznab_id == 'Destination America':
                add_posts({'title' : 'A Haunting',}, index, mode='newznab&newznab=13319',thumb='http://thetvdb.com/banners/posters/79535-1.jpg')
                add_posts({'title' : 'BBQ Pitmasters',}, index, mode='newznab&newznab=24424',thumb='http://thetvdb.com/banners/posters/126571-1.jpg')
                add_posts({'title' : 'Buying Alaska',}, index, mode='newznab&newznab=33007',thumb='http://thetvdb.com/banners/posters/263551-1.jpg')
                add_posts({'title' : 'Cheating Vegas',}, index, mode='newznab&newznab=31940',thumb='http://thetvdb.com/banners/posters/261490-1.jpg')
            if newznab_id == 'DIRECTV':
                add_posts({'title' : 'Damages',}, index, mode='newznab&newznab=15422',thumb='http://thetvdb.com/banners/posters/80367-1.jpg')
            if newznab_id == 'Discovery Channel':
                add_posts({'title' : 'After the Catch',}, index, mode='newznab&newznab=15927',thumb='http://thetvdb.com/banners/posters/82391-1.jpg')
                add_posts({'title' : 'Air Crash Confidential',}, index, mode='newznab&newznab=27862',thumb='http://thetvdb.com/banners/posters/228251-1.jpg')
                add_posts({'title' : 'Alaska The Last Frontier',}, index, mode='newznab&newznab=30505',thumb='http://thetvdb.com/banners/posters/254738-1.jpg')
                add_posts({'title' : 'American Chopper Senior vs Junior',}, index, mode='newznab&newznab=25696',thumb='http://thetvdb.com/banners/posters/181321-1.jpg')
                add_posts({'title' : 'American Guns',}, index, mode='newznab&newznab=29746',thumb='http://thetvdb.com/banners/posters/252571-1.jpg')
                add_posts({'title' : 'American Loggers',}, index, mode='newznab&newznab=21887',thumb='http://thetvdb.com/banners/posters/85317-1.jpg')
                add_posts({'title' : 'American Underworld',}, index, mode='newznab&newznab=29605',thumb='http://thetvdb.com/banners/posters/252034-1.jpg')
                add_posts({'title' : 'Amish Mafia',}, index, mode='newznab&newznab=33547',thumb='http://thetvdb.com/banners/posters/264416-1.jpg')
                add_posts({'title' : 'Auction Kings',}, index, mode='newznab&newznab=26858',thumb='http://thetvdb.com/banners/posters/201771-1.jpg')
                add_posts({'title' : 'Bad Universe',}, index, mode='newznab&newznab=26406',thumb='http://thetvdb.com/banners/posters/184341-2.jpg')
                add_posts({'title' : 'Bering Sea Gold Under the Ice',}, index, mode='newznab&newznab=32374',thumb='http://thetvdb.com/banners/posters/260980-1.jpg')
                add_posts({'title' : 'Bering Sea Gold',}, index, mode='newznab&newznab=30539',thumb='http://thetvdb.com/banners/posters/254203-1.jpg')
                add_posts({'title' : 'Best in the Business',}, index, mode='newznab&newznab=28129',thumb='http://thetvdb.com/banners/posters/254686-1.jpg')
                add_posts({'title' : 'Body Invaders',}, index, mode='newznab&newznab=32995',thumb='http://thetvdb.com/banners/posters/164391-1.jpg')
                add_posts({'title' : 'Bounty Wars',}, index, mode='newznab&newznab=32221',thumb='http://thetvdb.com/banners/posters/260605-1.jpg')
                add_posts({'title' : 'Breaking Magic',}, index, mode='newznab&newznab=33137',thumb='http://thetvdb.com/banners/posters/263737-1.jpg')
                add_posts({'title' : 'Brew Masters',}, index, mode='newznab&newznab=26992',thumb='http://thetvdb.com/banners/posters/203331-1.jpg')
                add_posts({'title' : 'Canadas Greatest Know It All',}, index, mode='newznab&newznab=30547')
                add_posts({'title' : 'Carfellas',}, index, mode='newznab&newznab=29408',thumb='http://thetvdb.com/banners/posters/251429-1.jpg')
                add_posts({'title' : 'Cool Stuff How It Works',}, index, mode='newznab&newznab=24449')
                add_posts({'title' : 'Cops and Coyotes',}, index, mode='newznab&newznab=27102',thumb='http://thetvdb.com/banners/posters/254769-1.jpg')
                add_posts({'title' : 'Curiosity',}, index, mode='newznab&newznab=24641',thumb='http://thetvdb.com/banners/posters/250572-1.jpg')
                add_posts({'title' : 'Curiousity',}, index, mode='newznab&newznab=24641',thumb='http://thetvdb.com/banners/posters/250572-1.jpg')
                add_posts({'title' : 'Dangerous Flights',}, index, mode='newznab&newznab=31781',thumb='http://thetvdb.com/banners/posters/259359-1.jpg')
                add_posts({'title' : 'Deadliest Catch',}, index, mode='newznab&newznab=3260',thumb='http://thetvdb.com/banners/posters/78957-1.jpg')
                add_posts({'title' : 'deadly sea',}, index, mode='newznab&newznab=31909',thumb='http://thetvdb.com/banners/posters/259822-1.jpg')
                add_posts({'title' : 'Deadly Seas',}, index, mode='newznab&newznab=31909',thumb='http://thetvdb.com/banners/posters/259822-1.jpg')
                add_posts({'title' : 'Deception with Keith Barry',}, index, mode='newznab&newznab=28443',thumb='http://thetvdb.com/banners/posters/248909-1.jpg')
                add_posts({'title' : 'Desert Car Kings',}, index, mode='newznab&newznab=27255',thumb='http://thetvdb.com/banners/posters/214841-1.jpg')
                add_posts({'title' : 'Dinosaur Revolution',}, index, mode='newznab&newznab=29124',thumb='http://thetvdb.com/banners/posters/251627-1.jpg')
                add_posts({'title' : 'Dirty Jobs',}, index, mode='newznab&newznab=6920',thumb='http://thetvdb.com/banners/posters/78904-1.jpg')
                add_posts({'title' : 'Dirty Money',}, index, mode='newznab&newznab=29125',thumb='http://thetvdb.com/banners/posters/85147-1.jpg')
                add_posts({'title' : 'Dual Survival',}, index, mode='newznab&newznab=25851',thumb='http://thetvdb.com/banners/posters/166991-1.jpg')
                add_posts({'title' : 'Extreme Engineering',}, index, mode='newznab&newznab=1128',thumb='http://thetvdb.com/banners/posters/72702-1.jpg')
                add_posts({'title' : 'Fast N Loud',}, index, mode='newznab&newznab=31800',thumb='http://thetvdb.com/banners/posters/259393-1.jpg')
                add_posts({'title' : 'Fifth Gear',}, index, mode='newznab&newznab=6740',thumb='http://thetvdb.com/banners/posters/78998-1.jpg')
                add_posts({'title' : 'Fight Quest',}, index, mode='newznab&newznab=18109',thumb='http://thetvdb.com/banners/posters/81359-1.jpg')
                add_posts({'title' : 'Fighting Tuna',}, index, mode='newznab&newznab=33420',thumb='http://thetvdb.com/banners/posters/263751-1.jpg')
                add_posts({'title' : 'Final Offer',}, index, mode='newznab&newznab=31765',thumb='http://thetvdb.com/banners/posters/259431-1.jpg')
                add_posts({'title' : 'First Week In',}, index, mode='newznab&newznab=30427',thumb='http://thetvdb.com/banners/posters/254464-1.jpg')
                add_posts({'title' : 'Flying Wild Alaska',}, index, mode='newznab&newznab=27161',thumb='http://thetvdb.com/banners/posters/214531-1.jpg')
                add_posts({'title' : 'Ghost Lab',}, index, mode='newznab&newznab=23905',thumb='http://thetvdb.com/banners/posters/117651-1.jpg')
                add_posts({'title' : 'Ghost Town Gold',}, index, mode='newznab&newznab=32056',thumb='http://thetvdb.com/banners/posters/264153-1.jpg')
                add_posts({'title' : 'Gold Rush',}, index, mode='newznab&newznab=26961',thumb='http://thetvdb.com/banners/posters/208111-1.jpg')
                add_posts({'title' : 'Head Games 2012',}, index, mode='newznab&newznab=31793')
                add_posts({'title' : 'Highway Thru Hell',}, index, mode='newznab&newznab=32591',thumb='http://thetvdb.com/banners/posters/262152-1.jpg')
                add_posts({'title' : 'Hogs Gone Wild',}, index, mode='newznab&newznab=27208',thumb='http://thetvdb.com/banners/posters/219611-1.jpg')
                add_posts({'title' : 'How Booze Built America',}, index, mode='newznab&newznab=32824',thumb='http://thetvdb.com/banners/posters/262466-1.jpg')
                add_posts({'title' : 'How Do They Do It',}, index, mode='newznab&newznab=20405',thumb='http://thetvdb.com/banners/posters/80038-1.jpg')
                add_posts({'title' : 'How We Invented the World',}, index, mode='newznab&newznab=29998',thumb='http://thetvdb.com/banners/posters/263905-1.jpg')
                add_posts({'title' : 'Howe and Howe Tech',}, index, mode='newznab&newznab=24741')
                add_posts({'title' : 'HowStuffWorks',}, index, mode='newznab&newznab=20539')
                add_posts({'title' : 'I Faked My Own Death',}, index, mode='newznab&newznab=29281',thumb='http://thetvdb.com/banners/posters/251466-1.jpg')
                add_posts({'title' : 'Jesse James Outlaw Garage',}, index, mode='newznab&newznab=33311',thumb='http://thetvdb.com/banners/posters/258035-1.jpg')
                add_posts({'title' : 'Jetstream',}, index, mode='newznab&newznab=21939',thumb='http://thetvdb.com/banners/posters/102421-1.jpg')
                add_posts({'title' : 'Jungle Gold',}, index, mode='newznab&newznab=33259',thumb='http://thetvdb.com/banners/posters/263296-1.jpg')
                add_posts({'title' : 'Kurt Sutters Outlaw Empires',}, index, mode='newznab&newznab=31662')
                add_posts({'title' : 'Life on a Wire',}, index, mode='newznab&newznab=28130')
                add_posts({'title' : 'Man vs Wild',}, index, mode='newznab&newznab=14573',thumb='http://thetvdb.com/banners/posters/79545-1.jpg')
                add_posts({'title' : 'Man Woman Wild',}, index, mode='newznab&newznab=25983',thumb='http://thetvdb.com/banners/posters/176011-1.jpg')
                add_posts({'title' : 'Masters of Survival',}, index, mode='newznab&newznab=27459',thumb='http://thetvdb.com/banners/posters/221591-1.jpg')
                add_posts({'title' : 'Mega Engineering',}, index, mode='newznab&newznab=22991',thumb='http://thetvdb.com/banners/posters/220951-1.jpg')
                add_posts({'title' : 'MegaWorld',}, index, mode='newznab&newznab=20936',thumb='http://thetvdb.com/banners/posters/83598-1.jpg')
                add_posts({'title' : 'Mobster Confessions',}, index, mode='newznab&newznab=30576',thumb='http://thetvdb.com/banners/posters/260250-1.jpg')
                add_posts({'title' : 'Monster Garage',}, index, mode='newznab&newznab=4517',thumb='http://thetvdb.com/banners/posters/73080-1.jpg')
                add_posts({'title' : 'Moonshiners',}, index, mode='newznab&newznab=29973',thumb='http://thetvdb.com/banners/posters/253695-1.jpg')
                add_posts({'title' : 'MythBusters',}, index, mode='newznab&newznab=4605',thumb='http://thetvdb.com/banners/posters/73388-1.jpg')
                add_posts({'title' : 'One Car Too Far',}, index, mode='newznab&newznab=31334',thumb='http://thetvdb.com/banners/posters/261489-1.jpg')
                add_posts({'title' : 'One Man Army',}, index, mode='newznab&newznab=28692',thumb='http://thetvdb.com/banners/posters/249975-1.jpg')
                add_posts({'title' : 'Out of Egypt',}, index, mode='newznab&newznab=23183',thumb='http://thetvdb.com/banners/posters/112191-1.jpg')
                add_posts({'title' : 'Out of the Wild Venezuela',}, index, mode='newznab&newznab=27290')
                add_posts({'title' : 'Patent Bending',}, index, mode='newznab&newznab=13473',thumb='http://thetvdb.com/banners/posters/79427-1.jpg')
                add_posts({'title' : 'Penn and Teller Tell a Lie',}, index, mode='newznab&newznab=29508',thumb='http://thetvdb.com/banners/posters/251756-1.jpg')
                add_posts({'title' : 'Pitchmen',}, index, mode='newznab&newznab=22287',thumb='http://thetvdb.com/banners/posters/90001-1.jpg')
                add_posts({'title' : 'Property Wars',}, index, mode='newznab&newznab=32228',thumb='http://thetvdb.com/banners/posters/260376-1.jpg')
                add_posts({'title' : 'Ragin Cajuns',}, index, mode='newznab&newznab=30529',thumb='http://thetvdb.com/banners/posters/254987-1.jpg')
                add_posts({'title' : 'Rising Rebuilding Ground Zero',}, index, mode='newznab&newznab=29157',thumb='http://thetvdb.com/banners/posters/251422-1.jpg')
                add_posts({'title' : 'Sons of Guns',}, index, mode='newznab&newznab=27201',thumb='http://thetvdb.com/banners/posters/209361-1.jpg')
                add_posts({'title' : 'South Beach Classics',}, index, mode='newznab&newznab=27792')
                add_posts({'title' : 'Surviving the Cut',}, index, mode='newznab&newznab=26218',thumb='http://thetvdb.com/banners/posters/181331-1.jpg')
                add_posts({'title' : 'Survivorman',}, index, mode='newznab&newznab=6858',thumb='http://thetvdb.com/banners/posters/79203-1.jpg')
                add_posts({'title' : 'Swamp Brother',}, index, mode='newznab&newznab=28128',thumb='http://thetvdb.com/banners/posters/248696-1.jpg')
                add_posts({'title' : 'Swamp Brothers',}, index, mode='newznab&newznab=28128',thumb='http://thetvdb.com/banners/posters/248696-1.jpg')
                add_posts({'title' : 'Swamp Loggers',}, index, mode='newznab&newznab=22948',thumb='http://thetvdb.com/banners/posters/101671-1.jpg')
                add_posts({'title' : 'Swords Life on the Line',}, index, mode='newznab&newznab=20572',thumb='http://thetvdb.com/banners/posters/109531-1.jpg')
                add_posts({'title' : 'Texas Car Wars',}, index, mode='newznab&newznab=32594',thumb='http://thetvdb.com/banners/posters/262088-1.jpg')
                add_posts({'title' : 'Texas Drug Wars',}, index, mode='newznab&newznab=27793')
                add_posts({'title' : 'The Alaska Experiment',}, index, mode='newznab&newznab=19141',thumb='http://thetvdb.com/banners/posters/81911-1.jpg')
                add_posts({'title' : 'The Colony US',}, index, mode='newznab&newznab=23356')
                add_posts({'title' : 'The Devils Ride',}, index, mode='newznab&newznab=31624',thumb='http://thetvdb.com/banners/posters/258549-1.jpg')
                add_posts({'title' : 'Trawler Wars',}, index, mode='newznab&newznab=29692',thumb='http://thetvdb.com/banners/posters/199851-1.jpg')
                add_posts({'title' : 'Treasure Quest',}, index, mode='newznab&newznab=21068',thumb='http://thetvdb.com/banners/posters/84657-1.jpg')
                add_posts({'title' : 'Unchained Reaction',}, index, mode='newznab&newznab=30986',thumb='http://thetvdb.com/banners/posters/256404-1.jpg')
                add_posts({'title' : 'Weed Wars',}, index, mode='newznab&newznab=29773',thumb='http://thetvdb.com/banners/posters/253718-1.jpg')
                add_posts({'title' : 'Wheeler Dealers 2003',}, index, mode='newznab&newznab=26698')
                add_posts({'title' : 'Wheeler Dealers 2011',}, index, mode='newznab&newznab=26698')
                add_posts({'title' : 'When We Left Earth The NASA Missions',}, index, mode='newznab&newznab=19164',thumb='http://thetvdb.com/banners/posters/82232-1.jpg')
                add_posts({'title' : 'Wild Animal Repo',}, index, mode='newznab&newznab=27209',thumb='http://thetvdb.com/banners/posters/248674-1.jpg')
                add_posts({'title' : 'Wreck Chasers',}, index, mode='newznab&newznab=30484')
                add_posts({'title' : 'Yukon Men',}, index, mode='newznab&newznab=32491',thumb='http://thetvdb.com/banners/posters/261445-1.jpg')
            if newznab_id == 'Discovery Fit and Health':
                add_posts({'title' : 'Curious And Unsusual Deaths',}, index, mode='newznab&newznab=27735')
                add_posts({'title' : 'High School Moms',}, index, mode='newznab&newznab=31303',thumb='http://thetvdb.com/banners/posters/261452-1.jpg')
                add_posts({'title' : 'Untold Stories of the E R',}, index, mode='newznab&newznab=6960')
            if newznab_id == 'Discovery HD Theater':
                add_posts({'title' : 'Mighty Ships',}, index, mode='newznab&newznab=26677',thumb='http://thetvdb.com/banners/posters/153531-1.jpg')
            if newznab_id == 'Discovery Health Channel':
                add_posts({'title' : 'Body In Numbers',}, index, mode='newznab&newznab=24321',thumb='http://thetvdb.com/banners/posters/171891-1.jpg')
                add_posts({'title' : 'Dr G Medical Examiner',}, index, mode='newznab&newznab=3359',thumb='http://thetvdb.com/banners/posters/250448-1.jpg')
            if newznab_id == 'Discovery Kids Channel':
                add_posts({'title' : 'Tutenstein',}, index, mode='newznab&newznab=6442',thumb='http://thetvdb.com/banners/posters/73039-1.jpg')
            if newznab_id == 'Discovery Velocity':
                add_posts({'title' : 'Saw Dogs',}, index, mode='newznab&newznab=30560',thumb='http://thetvdb.com/banners/posters/254614-1.jpg')
                add_posts({'title' : 'Shooting Stars US',}, index, mode='newznab&newznab=30559')
                add_posts({'title' : 'Tech Toys 360',}, index, mode='newznab&newznab=29728',thumb='http://thetvdb.com/banners/posters/258736-1.jpg')
            if newznab_id == 'Disney Channel':
                add_posts({'title' : 'A N T Farm',}, index, mode='newznab&newznab=28621',thumb='http://thetvdb.com/banners/posters/249229-1.jpg')
                add_posts({'title' : 'Austin and Ally',}, index, mode='newznab&newznab=29965',thumb='http://thetvdb.com/banners/posters/254245-1.jpg')
                add_posts({'title' : 'Dog with a Blog',}, index, mode='newznab&newznab=31385',thumb='http://thetvdb.com/banners/posters/263203-1.jpg')
                add_posts({'title' : 'Fish Hooks',}, index, mode='newznab&newznab=26510',thumb='http://thetvdb.com/banners/posters/193491-1.jpg')
                add_posts({'title' : 'Good Luck Charlie',}, index, mode='newznab&newznab=23993',thumb='http://thetvdb.com/banners/posters/154341-1.jpg')
                add_posts({'title' : 'Goodluck Charlie',}, index, mode='newznab&newznab=23993',thumb='http://thetvdb.com/banners/posters/154341-1.jpg')
                add_posts({'title' : 'Gravity Falls',}, index, mode='newznab&newznab=31839',thumb='http://thetvdb.com/banners/posters/259972-1.jpg')
                add_posts({'title' : 'Handy Manny',}, index, mode='newznab&newznab=14506',thumb='http://thetvdb.com/banners/posters/81587-1.jpg')
                add_posts({'title' : 'Hannah Montana',}, index, mode='newznab&newznab=7096',thumb='http://thetvdb.com/banners/posters/79317-1.jpg')
                add_posts({'title' : 'Jessie 2011',}, index, mode='newznab&newznab=29355',thumb='http://thetvdb.com/banners/posters/252312-1.jpg')
                add_posts({'title' : 'Johnny and the Sprites',}, index, mode='newznab&newznab=12304',thumb='http://thetvdb.com/banners/posters/259078-1.jpg')
                add_posts({'title' : 'Mickey Mouse Clubhouse',}, index, mode='newznab&newznab=10824',thumb='http://thetvdb.com/banners/posters/79854-1.jpg')
                add_posts({'title' : 'Mickey Mouse Clubshouse',}, index, mode='newznab&newznab=10824',thumb='http://thetvdb.com/banners/posters/79854-1.jpg')
                add_posts({'title' : 'My Babysitter s A Vampire',}, index, mode='newznab&newznab=28603',thumb='http://thetvdb.com/banners/posters/248972-1.jpg')
                add_posts({'title' : 'My Babysitters a Vampire',}, index, mode='newznab&newznab=28603',thumb='http://thetvdb.com/banners/posters/248972-1.jpg')
                add_posts({'title' : 'Phineas and Ferb',}, index, mode='newznab&newznab=12677',thumb='http://thetvdb.com/banners/posters/81848-1.jpg')
                add_posts({'title' : 'PrankStars',}, index, mode='newznab&newznab=28967')
                add_posts({'title' : 'Shake It Up',}, index, mode='newznab&newznab=25778',thumb='http://thetvdb.com/banners/posters/205251-1.jpg')
                add_posts({'title' : 'So Random',}, index, mode='newznab&newznab=28559',thumb='http://thetvdb.com/banners/posters/249286-1.jpg')
                add_posts({'title' : 'Sonny With A Chance',}, index, mode='newznab&newznab=19770',thumb='http://thetvdb.com/banners/posters/84963-1.jpg')
                add_posts({'title' : 'Stephen Hawkings Grand Design',}, index, mode='newznab&newznab=32020',thumb='http://thetvdb.com/banners/posters/259980-1.jpg')
                add_posts({'title' : 'Take Two With Phineas and Ferb',}, index, mode='newznab&newznab=27028',thumb='http://thetvdb.com/banners/posters/207551-1.jpg')
                add_posts({'title' : 'The Suite Life On Deck',}, index, mode='newznab&newznab=18575',thumb='http://thetvdb.com/banners/posters/83207-1.jpg')
                add_posts({'title' : 'Wizards of Waverly Place',}, index, mode='newznab&newznab=15176',thumb='http://thetvdb.com/banners/posters/80726-1.jpg')
            if newznab_id == 'Disney Junior':
                add_posts({'title' : 'Jake and the Never Land Pirates',}, index, mode='newznab&newznab=31910',thumb='http://thetvdb.com/banners/posters/223831-1.jpg')
            if newznab_id == 'Disney XD':
                add_posts({'title' : 'Avengers Earths Mightiest Heroes',}, index, mode='newznab&newznab=23227')
                add_posts({'title' : 'Crash and Bernstein',}, index, mode='newznab&newznab=31533',thumb='http://thetvdb.com/banners/posters/263374-1.jpg')
                add_posts({'title' : 'Kick Buttowski Suburban Daredevil',}, index, mode='newznab&newznab=25041')
                add_posts({'title' : 'Kickin It',}, index, mode='newznab&newznab=28609',thumb='http://thetvdb.com/banners/posters/248744-1.jpg')
                add_posts({'title' : 'Motorcity',}, index, mode='newznab&newznab=31546',thumb='http://thetvdb.com/banners/posters/258233-1.jpg')
                add_posts({'title' : 'Pair of Kings',}, index, mode='newznab&newznab=24825',thumb='http://thetvdb.com/banners/posters/194191-1.jpg')
                add_posts({'title' : 'Randy Cunningham 9th Grade Ninja',}, index, mode='newznab&newznab=31843',thumb='http://thetvdb.com/banners/posters/262736-1.jpg')
                add_posts({'title' : 'Rated A for Awesome',}, index, mode='newznab&newznab=28626',thumb='http://thetvdb.com/banners/posters/250470-1.jpg')
                add_posts({'title' : 'Tron Uprising',}, index, mode='newznab&newznab=31559',thumb='http://thetvdb.com/banners/posters/258480-1.jpg')
                add_posts({'title' : 'Ultimate Spider Man',}, index, mode='newznab&newznab=27587',thumb='http://thetvdb.com/banners/posters/257645-1.jpg')
                add_posts({'title' : 'Ultimate Spiderman',}, index, mode='newznab&newznab=27587',thumb='http://thetvdb.com/banners/posters/257645-1.jpg')
            if newznab_id == 'DIY Network':
                add_posts({'title' : 'Bath Crashers',}, index, mode='newznab&newznab=25064',thumb='http://thetvdb.com/banners/posters/250666-1.jpg')
                add_posts({'title' : 'Hollywood Hi Tech',}, index, mode='newznab&newznab=28765',thumb='http://thetvdb.com/banners/posters/250443-1.jpg')
                add_posts({'title' : 'Mega Dens',}, index, mode='newznab&newznab=27394')
                add_posts({'title' : 'Million Dollar Contractor',}, index, mode='newznab&newznab=29475',thumb='http://thetvdb.com/banners/posters/253090-1.jpg')
                add_posts({'title' : 'Yard Crashers',}, index, mode='newznab&newznab=25971',thumb='http://thetvdb.com/banners/posters/111281-1.jpg')
            if newznab_id == 'DR1':
                add_posts({'title' : 'Borgen',}, index, mode='newznab&newznab=26716',thumb='http://thetvdb.com/banners/posters/193261-1.jpg')
            if newznab_id == 'E':
                add_posts({'title' : 'After Lately',}, index, mode='newznab&newznab=27702',thumb='http://thetvdb.com/banners/posters/235961-1.jpg')
                add_posts({'title' : 'Dirty Soap',}, index, mode='newznab&newznab=29094',thumb='http://thetvdb.com/banners/posters/252165-1.jpg')
                add_posts({'title' : 'Hollys World',}, index, mode='newznab&newznab=25248',thumb='http://thetvdb.com/banners/posters/171271-1.jpg')
                add_posts({'title' : 'Ice Loves Coco',}, index, mode='newznab&newznab=28581',thumb='http://thetvdb.com/banners/posters/248698-1.jpg')
                add_posts({'title' : 'Keeping up with the Kardashians',}, index, mode='newznab&newznab=17638',thumb='http://thetvdb.com/banners/posters/80725-1.jpg')
                add_posts({'title' : 'Kendra',}, index, mode='newznab&newznab=22691',thumb='http://thetvdb.com/banners/posters/98371-1.jpg')
                add_posts({'title' : 'Khloe and Lamar',}, index, mode='newznab&newznab=27826',thumb='http://thetvdb.com/banners/posters/239961-1.jpg')
                add_posts({'title' : 'Kourtney and Khloe Take Miami',}, index, mode='newznab&newznab=23204')
                add_posts({'title' : 'Kourtney And Kim Take New York',}, index, mode='newznab&newznab=27220',thumb='http://thetvdb.com/banners/posters/212391-1.jpg')
                add_posts({'title' : 'Love You Mean It with Whitney Cummings',}, index, mode='newznab&newznab=33144',thumb='http://thetvdb.com/banners/posters/263967-1.jpg')
                add_posts({'title' : 'Married to Jonas',}, index, mode='newznab&newznab=31994',thumb='http://thetvdb.com/banners/posters/261647-1.jpg')
                add_posts({'title' : 'Opening Act',}, index, mode='newznab&newznab=31853',thumb='http://thetvdb.com/banners/posters/260379-1.jpg')
                add_posts({'title' : 'The Dance Scene',}, index, mode='newznab&newznab=27744',thumb='http://thetvdb.com/banners/posters/247929-1.jpg')
                add_posts({'title' : 'The Girls Next Door',}, index, mode='newznab&newznab=6827',thumb='http://thetvdb.com/banners/posters/78834-1.jpg')
            if newznab_id == 'E4':
                add_posts({'title' : 'Beauty and the Geek AU',}, index, mode='newznab&newznab=8214',thumb='http://thetvdb.com/banners/posters/252837-1.jpg')
                add_posts({'title' : 'Beaver Falls',}, index, mode='newznab&newznab=28998',thumb='http://thetvdb.com/banners/posters/250203-1.jpg')
                add_posts({'title' : 'Desperate Scousewives',}, index, mode='newznab&newznab=30193',thumb='http://thetvdb.com/banners/posters/254413-1.jpg')
                add_posts({'title' : 'Great British Hairdresser',}, index, mode='newznab&newznab=27626',thumb='http://thetvdb.com/banners/posters/238281-1.jpg')
                add_posts({'title' : 'Made In Chelsea',}, index, mode='newznab&newznab=28201',thumb='http://thetvdb.com/banners/posters/248888-1.jpg')
                add_posts({'title' : 'Misfits',}, index, mode='newznab&newznab=8784',thumb='http://thetvdb.com/banners/posters/124051-1.jpg')
                add_posts({'title' : 'Nearly Famous',}, index, mode='newznab&newznab=17881',thumb='http://thetvdb.com/banners/posters/134061-1.jpg')
                add_posts({'title' : 'Noel Fieldings Luxury Comedy',}, index, mode='newznab&newznab=30354',thumb='http://thetvdb.com/banners/posters/255005-1.jpg')
                add_posts({'title' : 'PhoneShop',}, index, mode='newznab&newznab=26730',thumb='http://thetvdb.com/banners/posters/194261-1.jpg')
                add_posts({'title' : 'School Of Comedy',}, index, mode='newznab&newznab=23942',thumb='http://thetvdb.com/banners/posters/120671-1.jpg')
                add_posts({'title' : 'Skins',}, index, mode='newznab&newznab=15114',thumb='http://thetvdb.com/banners/posters/79773-1.jpg')
                add_posts({'title' : 'Sorority Girls',}, index, mode='newznab&newznab=29952',thumb='http://thetvdb.com/banners/posters/253908-1.jpg')
                add_posts({'title' : 'The Inbetweeners',}, index, mode='newznab&newznab=18753',thumb='http://thetvdb.com/banners/posters/81950-1.jpg')
                add_posts({'title' : 'The Midnight Beast',}, index, mode='newznab&newznab=32217',thumb='http://thetvdb.com/banners/posters/260474-1.jpg')
                add_posts({'title' : 'The Work Experience',}, index, mode='newznab&newznab=33247',thumb='http://thetvdb.com/banners/posters/263593-1.jpg')
            if newznab_id == 'Eleven':
                add_posts({'title' : 'Neighbours',}, index, mode='newznab&newznab=4634',thumb='http://thetvdb.com/banners/posters/76719-1.jpg')
            if newznab_id == 'ESPN':
                add_posts({'title' : 'Rise Up',}, index, mode='newznab&newznab=29131')
                add_posts({'title' : 'Tilt',}, index, mode='newznab&newznab=6356',thumb='http://thetvdb.com/banners/posters/74974-1.jpg')
            if newznab_id == 'Facebook and Cambio com':
                add_posts({'title' : 'Aim High',}, index, mode='newznab&newznab=30305')
            if newznab_id == 'Family Channel':
                add_posts({'title' : 'Radio Free Roscoe',}, index, mode='newznab&newznab=4936')
            if newznab_id == 'FEARnet':
                add_posts({'title' : 'Holliston',}, index, mode='newznab&newznab=31393',thumb='http://thetvdb.com/banners/posters/256276-1.jpg')
            if newznab_id == 'five':
                add_posts({'title' : 'A Twist In The Tale',}, index, mode='newznab&newznab=2671',thumb='http://thetvdb.com/banners/posters/78106-1.jpg')
                add_posts({'title' : 'Angelos',}, index, mode='newznab&newznab=17880',thumb='http://thetvdb.com/banners/posters/81316-1.jpg')
                add_posts({'title' : 'Big Brothers Bit On The Side',}, index, mode='newznab&newznab=29142',thumb='http://thetvdb.com/banners/posters/250481-1.jpg')
                add_posts({'title' : 'Candy Bar Girls',}, index, mode='newznab&newznab=28815',thumb='http://thetvdb.com/banners/posters/250087-1.jpg')
                add_posts({'title' : 'Celebrity Wedding Planner',}, index, mode='newznab&newznab=30386',thumb='http://thetvdb.com/banners/posters/254965-1.jpg')
                add_posts({'title' : 'Celebrity Wish List',}, index, mode='newznab&newznab=29597')
                add_posts({'title' : 'Charley Boormans Extreme Frontiers',}, index, mode='newznab&newznab=30139',thumb='http://thetvdb.com/banners/posters/254047-1.jpg')
                add_posts({'title' : 'Classic Car Rescue',}, index, mode='newznab&newznab=32794',thumb='http://thetvdb.com/banners/posters/262688-1.jpg')
                add_posts({'title' : 'Cowboy Builders',}, index, mode='newznab&newznab=20913',thumb='http://thetvdb.com/banners/posters/85047-1.jpg')
                add_posts({'title' : 'Cowboy Traders',}, index, mode='newznab&newznab=31213')
                add_posts({'title' : 'Croc Man',}, index, mode='newznab&newznab=29093',thumb='http://thetvdb.com/banners/posters/250930-1.jpg')
                add_posts({'title' : 'Danger Diggers At Work',}, index, mode='newznab&newznab=28816',thumb='http://thetvdb.com/banners/posters/250107-1.jpg')
                add_posts({'title' : 'Dangerous Drivers School',}, index, mode='newznab&newznab=29734',thumb='http://thetvdb.com/banners/posters/253464-1.jpg')
                add_posts({'title' : 'Dirty Great Machines',}, index, mode='newznab&newznab=31380',thumb='http://thetvdb.com/banners/posters/258589-1.jpg')
                add_posts({'title' : 'Eddie Stobart Trucks And Trailers',}, index, mode='newznab&newznab=26543',thumb='http://thetvdb.com/banners/posters/192901-1.jpg')
                add_posts({'title' : 'Emergency Bikers',}, index, mode='newznab&newznab=26084',thumb='http://thetvdb.com/banners/posters/185071-1.jpg')
                add_posts({'title' : 'Essex Jungle',}, index, mode='newznab&newznab=28033',thumb='http://thetvdb.com/banners/posters/248076-1.jpg')
                add_posts({'title' : 'Extraordinary Dogs',}, index, mode='newznab&newznab=27473',thumb='http://thetvdb.com/banners/posters/245151-1.jpg')
                add_posts({'title' : 'Extreme Fishing With Robson Green At The Ends Of The Earth',}, index, mode='newznab&newznab=32157')
                add_posts({'title' : 'Extreme Fishing With Robson Green',}, index, mode='newznab&newznab=19890',thumb='http://thetvdb.com/banners/posters/83834-1.jpg')
                add_posts({'title' : 'Fairground Attractions',}, index, mode='newznab&newznab=30041',thumb='http://thetvdb.com/banners/posters/253699-1.jpg')
                add_posts({'title' : 'Frontline Police',}, index, mode='newznab&newznab=32242',thumb='http://thetvdb.com/banners/posters/261483-1.jpg')
                add_posts({'title' : 'Giant Animal Moves',}, index, mode='newznab&newznab=28318',thumb='http://thetvdb.com/banners/posters/249226-1.jpg')
                add_posts({'title' : 'Half Built House',}, index, mode='newznab&newznab=32172',thumb='http://thetvdb.com/banners/posters/260817-1.jpg')
                add_posts({'title' : 'Highland Emergency',}, index, mode='newznab&newznab=29395',thumb='http://thetvdb.com/banners/posters/264693-1.jpg')
                add_posts({'title' : 'Holiday Heaven On Earth',}, index, mode='newznab&newznab=30727')
                add_posts({'title' : 'Ice Patrol',}, index, mode='newznab&newznab=25083',thumb='http://thetvdb.com/banners/posters/112301-1.jpg')
                add_posts({'title' : 'Impossible',}, index, mode='newznab&newznab=28224')
                add_posts({'title' : 'Its All About Amy',}, index, mode='newznab&newznab=30140',thumb='http://thetvdb.com/banners/posters/254071-1.jpg')
                add_posts({'title' : 'John Barrowmans Dallas',}, index, mode='newznab&newznab=32476')
                add_posts({'title' : 'Justin Lee Collins Living Las Vegas',}, index, mode='newznab&newznab=29258',thumb='http://thetvdb.com/banners/posters/251725-1.jpg')
                add_posts({'title' : 'London The Inside Story',}, index, mode='newznab&newznab=30000',thumb='http://thetvdb.com/banners/posters/253850-1.jpg')
                add_posts({'title' : 'Lost Heroes Of World War One',}, index, mode='newznab&newznab=29954')
                add_posts({'title' : 'Marco Pierre Whites Kitchen Wars',}, index, mode='newznab&newznab=31746',thumb='http://thetvdb.com/banners/posters/259789-1.jpg')
                add_posts({'title' : 'Max And Sallys Excellent Gypsy Adventure',}, index, mode='newznab&newznab=32660',thumb='http://thetvdb.com/banners/posters/262851-1.jpg')
                add_posts({'title' : 'Mexican Food Made Simple',}, index, mode='newznab&newznab=28760',thumb='http://thetvdb.com/banners/posters/249976-1.jpg')
                add_posts({'title' : 'North Pole Ice Airport',}, index, mode='newznab&newznab=33530',thumb='http://thetvdb.com/banners/posters/264711-1.jpg')
                add_posts({'title' : 'Paddy And Sallys Excellent Gypsy Adventure',}, index, mode='newznab&newznab=32660',thumb='http://thetvdb.com/banners/posters/262851-1.jpg')
                add_posts({'title' : 'Paul Mertons Adventures',}, index, mode='newznab&newznab=29735',thumb='http://thetvdb.com/banners/posters/252934-1.jpg')
                add_posts({'title' : 'Police Interceptors',}, index, mode='newznab&newznab=18781',thumb='http://thetvdb.com/banners/posters/82148-1.jpg')
                add_posts({'title' : 'Real Food Family Cook Off',}, index, mode='newznab&newznab=29481')
                add_posts({'title' : 'Revealed',}, index, mode='newznab&newznab=19322',thumb='http://thetvdb.com/banners/posters/82813-1.jpg')
                add_posts({'title' : 'Robsons Extreme Fishing Challenge',}, index, mode='newznab&newznab=31235',thumb='http://thetvdb.com/banners/posters/258054-1.jpg')
                add_posts({'title' : 'Rory McGraths Pub Dig',}, index, mode='newznab&newznab=31189',thumb='http://thetvdb.com/banners/posters/257876-1.jpg')
                add_posts({'title' : 'Royal Navy Caribbean Patrol',}, index, mode='newznab&newznab=27500',thumb='http://thetvdb.com/banners/posters/228741-1.jpg')
                add_posts({'title' : 'Royal Navy Submarine Mission',}, index, mode='newznab&newznab=29287',thumb='http://thetvdb.com/banners/posters/251698-1.jpg')
                add_posts({'title' : 'Secret Interview',}, index, mode='newznab&newznab=32475',thumb='http://thetvdb.com/banners/posters/261716-1.jpg')
                add_posts({'title' : 'Soho Blues',}, index, mode='newznab&newznab=21193',thumb='http://thetvdb.com/banners/posters/205941-1.jpg')
                add_posts({'title' : 'Stansted The Inside Story',}, index, mode='newznab&newznab=27507')
                add_posts({'title' : 'Submarine School',}, index, mode='newznab&newznab=28632',thumb='http://thetvdb.com/banners/posters/249716-1.jpg')
                add_posts({'title' : 'Superior Interiors With Kelly Hoppen',}, index, mode='newznab&newznab=29555',thumb='http://thetvdb.com/banners/posters/252481-1.jpg')
                add_posts({'title' : 'Supersize Grime',}, index, mode='newznab&newznab=28207',thumb='http://thetvdb.com/banners/posters/248649-1.jpg')
                add_posts({'title' : 'The Bachelor UK',}, index, mode='newznab&newznab=29141',thumb='http://thetvdb.com/banners/posters/251277-1.jpg')
                add_posts({'title' : 'The Gadget Show',}, index, mode='newznab&newznab=6911',thumb='http://thetvdb.com/banners/posters/80747-1.jpg')
                add_posts({'title' : 'The Hotel Inspector',}, index, mode='newznab&newznab=19508',thumb='http://thetvdb.com/banners/posters/80691-1.jpg')
                add_posts({'title' : 'The Removal Men Pickfords',}, index, mode='newznab&newznab=28811',thumb='http://thetvdb.com/banners/posters/263957-1.jpg')
                add_posts({'title' : 'The Restaurant Inspector',}, index, mode='newznab&newznab=28487',thumb='http://thetvdb.com/banners/posters/262288-1.jpg')
                add_posts({'title' : 'The Tribe',}, index, mode='newznab&newznab=6254',thumb='http://thetvdb.com/banners/posters/76656-1.jpg')
                add_posts({'title' : 'Theres Something About Josie',}, index, mode='newznab&newznab=28195',thumb='http://thetvdb.com/banners/posters/253673-1.jpg')
                add_posts({'title' : 'Ultimate Police Interceptors',}, index, mode='newznab&newznab=29085',thumb='http://thetvdb.com/banners/posters/251040-1.jpg')
                add_posts({'title' : 'When Paddy Met Sally',}, index, mode='newznab&newznab=30431')
                add_posts({'title' : 'White Van Man 2011',}, index, mode='newznab&newznab=26831')
                add_posts({'title' : 'Wild Things With Dominic Monaghan',}, index, mode='newznab&newznab=33089',thumb='http://thetvdb.com/banners/posters/264029-1.jpg')
                add_posts({'title' : 'Winter Road Rescue',}, index, mode='newznab&newznab=30721',thumb='http://thetvdb.com/banners/posters/256124-1.jpg')
                add_posts({'title' : 'Worlds Toughest Trucker',}, index, mode='newznab&newznab=30393',thumb='http://thetvdb.com/banners/posters/254968-1.jpg')
            if newznab_id == 'Fiver':
                add_posts({'title' : 'Silent Library US',}, index, mode='newznab&newznab=28940')
            if newznab_id == 'FMC':
                add_posts({'title' : 'Conspiracy 365',}, index, mode='newznab&newznab=30668',thumb='http://thetvdb.com/banners/posters/255292-1.jpg')
            if newznab_id == 'Food Network':
                add_posts({'title' : '24 Hour Restaurant Battle',}, index, mode='newznab&newznab=25826')
                add_posts({'title' : '3 Days to Open with Bobby Flay',}, index, mode='newznab&newznab=32012',thumb='http://thetvdb.com/banners/posters/261224-1.jpg')
                add_posts({'title' : 'Chopped',}, index, mode='newznab&newznab=20628',thumb='http://thetvdb.com/banners/posters/85019-1.jpg')
                add_posts({'title' : 'Crave',}, index, mode='newznab&newznab=29275',thumb='http://thetvdb.com/banners/posters/251384-1.jpg')
                add_posts({'title' : 'Cupcake Wars',}, index, mode='newznab&newznab=25651',thumb='http://thetvdb.com/banners/posters/169981-1.jpg')
                add_posts({'title' : 'Diners Drive Ins and Dives',}, index, mode='newznab&newznab=16247',thumb='http://thetvdb.com/banners/posters/82918-1.jpg')
                add_posts({'title' : 'Diners Driveins and Dives',}, index, mode='newznab&newznab=16247',thumb='http://thetvdb.com/banners/posters/82918-1.jpg')
                add_posts({'title' : 'Everday Italian',}, index, mode='newznab&newznab=6836',thumb='http://thetvdb.com/banners/posters/79482-1.jpg')
                add_posts({'title' : 'Everyday Italian',}, index, mode='newznab&newznab=6836',thumb='http://thetvdb.com/banners/posters/79482-1.jpg')
                add_posts({'title' : 'Extreme Chef',}, index, mode='newznab&newznab=28672',thumb='http://thetvdb.com/banners/posters/249892-1.jpg')
                add_posts({'title' : 'Food Attack',}, index, mode='newznab&newznab=30454',thumb='http://thetvdb.com/banners/posters/254583-1.jpg')
                add_posts({'title' : 'Giada at Home',}, index, mode='newznab&newznab=20294',thumb='http://thetvdb.com/banners/posters/85062-1.jpg')
                add_posts({'title' : 'Good Eats',}, index, mode='newznab&newznab=1297',thumb='http://thetvdb.com/banners/posters/73067-1.jpg')
                add_posts({'title' : 'Guys Big Bite',}, index, mode='newznab&newznab=12291',thumb='http://thetvdb.com/banners/posters/100481-1.jpg')
                add_posts({'title' : 'Heat Seekers',}, index, mode='newznab&newznab=28766',thumb='http://thetvdb.com/banners/posters/250214-1.jpg')
                add_posts({'title' : 'Ice Brigade',}, index, mode='newznab&newznab=27576',thumb='http://thetvdb.com/banners/posters/239011-1.jpg')
                add_posts({'title' : 'Invention Hunters',}, index, mode='newznab&newznab=31660',thumb='http://thetvdb.com/banners/posters/258735-1.jpg')
                add_posts({'title' : 'Iron Chef America',}, index, mode='newznab&newznab=3994',thumb='http://thetvdb.com/banners/posters/74325-1.jpg')
                add_posts({'title' : 'Kitchen Inventors',}, index, mode='newznab&newznab=30155',thumb='http://thetvdb.com/banners/posters/253635-1.jpg')
                add_posts({'title' : 'Meat and Potatoes',}, index, mode='newznab&newznab=26579')
                add_posts({'title' : 'Meat and Potatos',}, index, mode='newznab&newznab=26579')
                add_posts({'title' : 'Nigella Feasts',}, index, mode='newznab&newznab=19563',thumb='http://thetvdb.com/banners/posters/80718-1.jpg')
                add_posts({'title' : 'Rachael vs Guy Celebrity Cook Off',}, index, mode='newznab&newznab=30425')
                add_posts({'title' : 'Restaurant Impossible',}, index, mode='newznab&newznab=27401',thumb='http://thetvdb.com/banners/posters/224361-1.jpg')
                add_posts({'title' : 'Sandwich King',}, index, mode='newznab&newznab=31607',thumb='http://thetvdb.com/banners/posters/251478-1.jpg')
                add_posts({'title' : 'Sugar Dome',}, index, mode='newznab&newznab=33113',thumb='http://thetvdb.com/banners/posters/264695-1.jpg')
                add_posts({'title' : 'Sugar High',}, index, mode='newznab&newznab=28796',thumb='http://thetvdb.com/banners/posters/250854-1.jpg')
                add_posts({'title' : 'Sweet Genius',}, index, mode='newznab&newznab=29368',thumb='http://thetvdb.com/banners/posters/252171-1.jpg')
                add_posts({'title' : 'The Best Thing I Ever Ate',}, index, mode='newznab&newznab=22934',thumb='http://thetvdb.com/banners/posters/123501-1.jpg')
                add_posts({'title' : 'The Best Thing I Ever Made',}, index, mode='newznab&newznab=29762',thumb='http://thetvdb.com/banners/posters/254168-1.jpg')
                add_posts({'title' : 'The Great Food Truck Race',}, index, mode='newznab&newznab=26350',thumb='http://thetvdb.com/banners/posters/187741-1.jpg')
                add_posts({'title' : 'The Next Food Network Star',}, index, mode='newznab&newznab=7005',thumb='http://thetvdb.com/banners/posters/82166-1.jpg')
                add_posts({'title' : 'The Next Iron Chef',}, index, mode='newznab&newznab=17538',thumb='http://thetvdb.com/banners/posters/80665-1.jpg')
                add_posts({'title' : 'The Three Chocolatiers',}, index, mode='newznab&newznab=29096',thumb='http://thetvdb.com/banners/posters/250683-1.jpg')
                add_posts({'title' : 'Unwrapped',}, index, mode='newznab&newznab=701',thumb='http://thetvdb.com/banners/posters/71142-1.jpg')
                add_posts({'title' : 'Worst Cooks In America',}, index, mode='newznab&newznab=22950',thumb='http://thetvdb.com/banners/posters/134441-1.jpg')
            if newznab_id == 'Food Network Canada':
                add_posts({'title' : 'Top Chef Canada',}, index, mode='newznab&newznab=28150',thumb='http://thetvdb.com/banners/posters/246941-1.jpg')
            if newznab_id == 'FOX':
                add_posts({'title' : '24',}, index, mode='newznab&newznab=2445',thumb='http://thetvdb.com/banners/posters/76290-1.jpg')
                add_posts({'title' : 'Alcatraz',}, index, mode='newznab&newznab=27523',thumb='http://thetvdb.com/banners/posters/248646-1.jpg')
                add_posts({'title' : 'Allen Gregory',}, index, mode='newznab&newznab=28377',thumb='http://thetvdb.com/banners/posters/249081-1.jpg')
                add_posts({'title' : 'American Dad',}, index, mode='newznab&newznab=2594',thumb='http://thetvdb.com/banners/posters/73141-1.jpg')
                add_posts({'title' : 'American Idol',}, index, mode='newznab&newznab=2601',thumb='http://thetvdb.com/banners/posters/70814-1.jpg')
                add_posts({'title' : 'Ben and Kate',}, index, mode='newznab&newznab=31683',thumb='http://thetvdb.com/banners/posters/259009-1.jpg')
                add_posts({'title' : 'Biker Mice From Mars 2006',}, index, mode='newznab&newznab=13262',thumb='http://thetvdb.com/banners/posters/249504-1.jpg')
                add_posts({'title' : 'Bobs Burgers',}, index, mode='newznab&newznab=24607',thumb='http://thetvdb.com/banners/posters/194031-1.jpg')
                add_posts({'title' : 'Bones',}, index, mode='newznab&newznab=2870',thumb='http://thetvdb.com/banners/posters/75682-1.jpg')
                add_posts({'title' : 'Breaking In',}, index, mode='newznab&newznab=26082',thumb='http://thetvdb.com/banners/posters/206751-1.jpg')
                add_posts({'title' : 'Buried Treasure',}, index, mode='newznab&newznab=29119',thumb='http://thetvdb.com/banners/posters/250792-1.jpg')
                add_posts({'title' : 'Canterburys Law',}, index, mode='newznab&newznab=15767',thumb='http://thetvdb.com/banners/posters/81502-1.jpg')
                add_posts({'title' : 'Cops',}, index, mode='newznab&newznab=3138',thumb='http://thetvdb.com/banners/posters/74709-1.jpg')
                add_posts({'title' : 'Dark Angel',}, index, mode='newznab&newznab=3237',thumb='http://thetvdb.com/banners/posters/76148-1.jpg')
                add_posts({'title' : 'Dollhouse',}, index, mode='newznab&newznab=17816',thumb='http://thetvdb.com/banners/posters/82046-1.jpg')
                add_posts({'title' : 'Family Guy',}, index, mode='newznab&newznab=3506',thumb='http://thetvdb.com/banners/posters/75978-1.jpg')
                add_posts({'title' : 'Firefly',}, index, mode='newznab&newznab=3548',thumb='http://thetvdb.com/banners/posters/78874-1.jpg')
                add_posts({'title' : 'Fringe',}, index, mode='newznab&newznab=18388',thumb='http://thetvdb.com/banners/posters/82066-1.jpg')
                add_posts({'title' : 'Glee',}, index, mode='newznab&newznab=21704',thumb='http://thetvdb.com/banners/posters/83610-1.jpg')
                add_posts({'title' : 'Harsh Realm',}, index, mode='newznab&newznab=3797',thumb='http://thetvdb.com/banners/posters/71768-1.jpg')
                add_posts({'title' : 'Hells Kitchen US',}, index, mode='newznab&newznab=3828',thumb='http://thetvdb.com/banners/posters/74897-1.jpg')
                add_posts({'title' : 'Hotel Hell',}, index, mode='newznab&newznab=30890',thumb='http://thetvdb.com/banners/posters/257609-1.jpg')
                add_posts({'title' : 'house',}, index, mode='newznab&newznab=3908',thumb='http://thetvdb.com/banners/posters/73255-1.jpg')
                add_posts({'title' : 'Human Target 2010',}, index, mode='newznab&newznab=22699',thumb='http://thetvdb.com/banners/posters/94801-1.jpg')
                add_posts({'title' : 'I Hate My Teenage Daughter',}, index, mode='newznab&newznab=28303',thumb='http://thetvdb.com/banners/posters/248793-1.jpg')
                add_posts({'title' : 'In Living Color',}, index, mode='newznab&newznab=3961',thumb='http://thetvdb.com/banners/posters/78441-1.jpg')
                add_posts({'title' : 'In the Flow with Affion Crockett',}, index, mode='newznab&newznab=28408',thumb='http://thetvdb.com/banners/posters/251033-1.jpg')
                add_posts({'title' : 'King of the Hill',}, index, mode='newznab&newznab=4134',thumb='http://thetvdb.com/banners/posters/73903-1.jpg')
                add_posts({'title' : 'Lie to Me',}, index, mode='newznab&newznab=19295',thumb='http://thetvdb.com/banners/posters/83602-1.jpg')
                add_posts({'title' : 'Living Single',}, index, mode='newznab&newznab=4266',thumb='http://thetvdb.com/banners/posters/76728-1.jpg')
                add_posts({'title' : 'Malcolm in the Middle',}, index, mode='newznab&newznab=4355',thumb='http://thetvdb.com/banners/posters/73838-1.jpg')
                add_posts({'title' : 'Married With Children',}, index, mode='newznab&newznab=4375',thumb='http://thetvdb.com/banners/posters/76385-1.jpg')
                add_posts({'title' : 'MasterChef US',}, index, mode='newznab&newznab=25644',thumb='http://thetvdb.com/banners/posters/167751-1.jpg')
                add_posts({'title' : 'Millennium',}, index, mode='newznab&newznab=4475',thumb='http://thetvdb.com/banners/posters/70940-1.jpg')
                add_posts({'title' : 'Mobbed',}, index, mode='newznab&newznab=27995',thumb='http://thetvdb.com/banners/posters/241421-1.jpg')
                add_posts({'title' : 'Napoleon Dynamite',}, index, mode='newznab&newznab=28378',thumb='http://thetvdb.com/banners/posters/249363-1.jpg')
                add_posts({'title' : 'New Girl',}, index, mode='newznab&newznab=28304',thumb='http://thetvdb.com/banners/posters/248682-1.jpg')
                add_posts({'title' : 'New York',}, index, mode='newznab&newznab=13469',thumb='http://thetvdb.com/banners/posters/259062-1.jpg')
                add_posts({'title' : 'Ninja Turtles The Next Mutation',}, index, mode='newznab&newznab=4676',thumb='http://thetvdb.com/banners/posters/78064-1.jpg')
                add_posts({'title' : 'Point Pleasant',}, index, mode='newznab&newznab=4846',thumb='http://thetvdb.com/banners/posters/73745-1.jpg')
                add_posts({'title' : 'prison break',}, index, mode='newznab&newznab=4895',thumb='http://thetvdb.com/banners/posters/75340-1.jpg')
                add_posts({'title' : 'Q Viva The Chosen',}, index, mode='newznab&newznab=30926',thumb='http://thetvdb.com/banners/posters/257302-1.jpg')
                add_posts({'title' : 'Raising Hope',}, index, mode='newznab&newznab=25742',thumb='http://thetvdb.com/banners/posters/164021-1.jpg')
                add_posts({'title' : 'Raisng Hope',}, index, mode='newznab&newznab=25742',thumb='http://thetvdb.com/banners/posters/164021-1.jpg')
                add_posts({'title' : 'Roar',}, index, mode='newznab&newznab=5019',thumb='http://thetvdb.com/banners/posters/71196-1.jpg')
                add_posts({'title' : 'So You Think You Can Dance',}, index, mode='newznab&newznab=5270',thumb='http://thetvdb.com/banners/posters/78956-1.jpg')
                add_posts({'title' : 'Sons of Tucson',}, index, mode='newznab&newznab=22674',thumb='http://thetvdb.com/banners/posters/94831-1.jpg')
                add_posts({'title' : 'Take Me Out US',}, index, mode='newznab&newznab=31515',thumb='http://thetvdb.com/banners/posters/259421-1.jpg')
                add_posts({'title' : 'Terminator The Sarah Connor Chronicles',}, index, mode='newznab&newznab=13445',thumb='http://thetvdb.com/banners/posters/80344-1.jpg')
                add_posts({'title' : 'Terra Nova',}, index, mode='newznab&newznab=25729',thumb='http://thetvdb.com/banners/posters/164091-1.jpg')
                add_posts({'title' : 'That 70s Show',}, index, mode='newznab&newznab=5497',thumb='http://thetvdb.com/banners/posters/73787-1.jpg')
                add_posts({'title' : 'The Ben Stiller Show',}, index, mode='newznab&newznab=5608',thumb='http://thetvdb.com/banners/posters/78730-1.jpg')
                add_posts({'title' : 'The Bernie Mac Show',}, index, mode='newznab&newznab=5610',thumb='http://thetvdb.com/banners/posters/75825-1.jpg')
                add_posts({'title' : 'The Chicago Code',}, index, mode='newznab&newznab=25051',thumb='http://thetvdb.com/banners/posters/164011-1.jpg')
                add_posts({'title' : 'The Choice',}, index, mode='newznab&newznab=31689',thumb='http://thetvdb.com/banners/posters/258886-1.jpg')
                add_posts({'title' : 'The Cleveland Show',}, index, mode='newznab&newznab=18740',thumb='http://thetvdb.com/banners/posters/93991-1.jpg')
                add_posts({'title' : 'The Finder',}, index, mode='newznab&newznab=28173',thumb='http://thetvdb.com/banners/posters/248651-1.jpg')
                add_posts({'title' : 'The Mindy Project',}, index, mode='newznab&newznab=31682',thumb='http://thetvdb.com/banners/posters/259007-1.jpg')
                add_posts({'title' : 'The Mob Doctor',}, index, mode='newznab&newznab=31649',thumb='http://thetvdb.com/banners/posters/259011-1.jpg')
                add_posts({'title' : 'The Simpsons',}, index, mode='newznab&newznab=6190',thumb='http://thetvdb.com/banners/posters/71663-1.jpg')
                add_posts({'title' : 'The X Factor US',}, index, mode='newznab&newznab=25062',thumb='http://thetvdb.com/banners/posters/230121-1.jpg')
                add_posts({'title' : 'the x files',}, index, mode='newznab&newznab=6312',thumb='http://thetvdb.com/banners/posters/77398-1.jpg')
                add_posts({'title' : 'Touch',}, index, mode='newznab&newznab=28055',thumb='http://thetvdb.com/banners/posters/83105-1.jpg')
                add_posts({'title' : 'Traffic Light',}, index, mode='newznab&newznab=25743',thumb='http://thetvdb.com/banners/posters/164311-1.jpg')
                add_posts({'title' : 'Where On Earth Is Carmen Sandiego',}, index, mode='newznab&newznab=6585',thumb='http://thetvdb.com/banners/posters/74586-1.jpg')
            if newznab_id == 'FOX Soccer Channel':
                add_posts({'title' : 'The Contender',}, index, mode='newznab&newznab=24958')
            if newznab_id == 'Fox Sports':
                add_posts({'title' : 'World Poker Tour',}, index, mode='newznab&newznab=6649',thumb='http://thetvdb.com/banners/posters/80192-1.jpg')
            if newznab_id == 'FOX8':
                add_posts({'title' : 'Australias Next Top Model',}, index, mode='newznab&newznab=2676',thumb='http://thetvdb.com/banners/posters/79073-1.jpg')
                add_posts({'title' : 'Hardliners',}, index, mode='newznab&newznab=27748',thumb='http://thetvdb.com/banners/posters/228051-1.jpg')
                add_posts({'title' : 'Rove LA',}, index, mode='newznab&newznab=29756',thumb='http://thetvdb.com/banners/posters/252107-1.jpg')
                add_posts({'title' : 'Slide',}, index, mode='newznab&newznab=29460',thumb='http://thetvdb.com/banners/posters/251158-1.jpg')
            if newznab_id == 'France 3':
                add_posts({'title' : 'Wakfu',}, index, mode='newznab&newznab=24462',thumb='http://thetvdb.com/banners/posters/94121-1.jpg')
            if newznab_id == 'Fuji TV':
                add_posts({'title' : 'Astro Boy 1963',}, index, mode='newznab&newznab=2661',thumb='http://thetvdb.com/banners/posters/71952-1.jpg')
                add_posts({'title' : 'Days',}, index, mode='newznab&newznab=13722')
                add_posts({'title' : 'Samurai Champloo',}, index, mode='newznab&newznab=5093',thumb='http://thetvdb.com/banners/posters/79089-1.jpg')
                add_posts({'title' : 'Shiki',}, index, mode='newznab&newznab=26257',thumb='http://thetvdb.com/banners/posters/172941-1.jpg')
            if newznab_id == 'Fuse':
                add_posts({'title' : 'Funny or Dies Billy on the Street',}, index, mode='newznab&newznab=30448')
            if newznab_id == 'FX':
                add_posts({'title' : 'American Horror Story',}, index, mode='newznab&newznab=28776',thumb='http://thetvdb.com/banners/posters/250487-1.jpg')
                add_posts({'title' : 'Anger Management',}, index, mode='newznab&newznab=29999',thumb='http://thetvdb.com/banners/posters/253350-1.jpg')
                add_posts({'title' : 'Archer 2009',}, index, mode='newznab&newznab=23354',thumb='http://thetvdb.com/banners/posters/110381-1.jpg')
                add_posts({'title' : 'Brand X with Russell Brand',}, index, mode='newznab&newznab=31824',thumb='http://thetvdb.com/banners/posters/259286-1.jpg')
                add_posts({'title' : 'Its Always Sunny in Philadelphia',}, index, mode='newznab&newznab=4004',thumb='http://thetvdb.com/banners/posters/75805-1.jpg')
                add_posts({'title' : 'Its Always Sunny in Phildelphia',}, index, mode='newznab&newznab=4004',thumb='http://thetvdb.com/banners/posters/75805-1.jpg')
                add_posts({'title' : 'Justified',}, index, mode='newznab&newznab=23472',thumb='http://thetvdb.com/banners/posters/134241-1.jpg')
                add_posts({'title' : 'Lights Out 2011',}, index, mode='newznab&newznab=27061',thumb='http://thetvdb.com/banners/posters/194051-1.jpg')
                add_posts({'title' : 'Louie',}, index, mode='newznab&newznab=24504',thumb='http://thetvdb.com/banners/posters/80732-1.jpg')
                add_posts({'title' : 'Nip Tuck',}, index, mode='newznab&newznab=4677',thumb='http://thetvdb.com/banners/posters/72201-1.jpg')
                add_posts({'title' : 'Outlaw Country',}, index, mode='newznab&newznab=32595')
                add_posts({'title' : 'Rescue Me',}, index, mode='newznab&newznab=4985',thumb='http://thetvdb.com/banners/posters/73741-1.jpg')
                add_posts({'title' : 'Running Wilde',}, index, mode='newznab&newznab=25304',thumb='http://thetvdb.com/banners/posters/164031-1.jpg')
                add_posts({'title' : 'Sons of Anarchy',}, index, mode='newznab&newznab=18174',thumb='http://thetvdb.com/banners/posters/82696-1.jpg')
                add_posts({'title' : 'Testees',}, index, mode='newznab&newznab=19587',thumb='http://thetvdb.com/banners/posters/83339-1.jpg')
                add_posts({'title' : 'The League',}, index, mode='newznab&newznab=24173',thumb='http://thetvdb.com/banners/posters/114701-1.jpg')
                add_posts({'title' : 'The Shield',}, index, mode='newznab&newznab=6185',thumb='http://thetvdb.com/banners/posters/78261-1.jpg')
                add_posts({'title' : 'The Ultimate Fighter',}, index, mode='newznab&newznab=6263',thumb='http://thetvdb.com/banners/posters/75382-1.jpg')
                add_posts({'title' : 'Totally Biased with W Kamau Bell',}, index, mode='newznab&newznab=31952',thumb='http://thetvdb.com/banners/posters/260797-1.jpg')
                add_posts({'title' : 'Unsupervised',}, index, mode='newznab&newznab=30294',thumb='http://thetvdb.com/banners/posters/254561-1.jpg')
                add_posts({'title' : 'Wilfred US',}, index, mode='newznab&newznab=25709',thumb='http://thetvdb.com/banners/posters/239761-1.jpg')
            if newznab_id == 'G4':
                add_posts({'title' : 'American Ninja Warrior',}, index, mode='newznab&newznab=24537',thumb='http://thetvdb.com/banners/posters/212411-1.jpg')
                add_posts({'title' : 'Bomb Patrol Afghanistan',}, index, mode='newznab&newznab=29696',thumb='http://thetvdb.com/banners/posters/253095-1.jpg')
                add_posts({'title' : 'Campus PD',}, index, mode='newznab&newznab=24536',thumb='http://thetvdb.com/banners/posters/184231-1.jpg')
                add_posts({'title' : 'G4 Underground',}, index, mode='newznab&newznab=24538')
                add_posts({'title' : 'iron man 2010',}, index, mode='newznab&newznab=28450')
                add_posts({'title' : 'Iron Man 2011',}, index, mode='newznab&newznab=28450')
                add_posts({'title' : 'Jump City Seattle',}, index, mode='newznab&newznab=27600')
                add_posts({'title' : 'Ninja Warrior',}, index, mode='newznab&newznab=13963',thumb='http://thetvdb.com/banners/posters/126991-1.jpg')
                add_posts({'title' : 'Women of Ninja Warrior',}, index, mode='newznab&newznab=24539',thumb='http://thetvdb.com/banners/posters/205001-1.jpg')
                add_posts({'title' : 'X Men 2011',}, index, mode='newznab&newznab=28452',thumb='http://thetvdb.com/banners/posters/236061-1.jpg')
            if newznab_id == 'GEM':
                add_posts({'title' : 'Top Gear Australia',}, index, mode='newznab&newznab=20324',thumb='http://thetvdb.com/banners/posters/83234-1.jpg')
            if newznab_id == 'Global':
                add_posts({'title' : 'Bomb Girls',}, index, mode='newznab&newznab=30600',thumb='http://thetvdb.com/banners/posters/254378-1.jpg')
                add_posts({'title' : 'Canada Sings',}, index, mode='newznab&newznab=29363')
                add_posts({'title' : 'Combat Hospital',}, index, mode='newznab&newznab=27941',thumb='http://thetvdb.com/banners/posters/248799-1.jpg')
                add_posts({'title' : 'Rookie Blue',}, index, mode='newznab&newznab=22464',thumb='http://thetvdb.com/banners/posters/157631-1.jpg')
                add_posts({'title' : 'Shattered 2010',}, index, mode='newznab&newznab=26214')
            if newznab_id == 'GO':
                add_posts({'title' : 'Excess Baggage',}, index, mode='newznab&newznab=31105',thumb='http://thetvdb.com/banners/posters/255488-1.jpg')
            if newznab_id == 'GSN':
                add_posts({'title' : 'Catch 21',}, index, mode='newznab&newznab=20169',thumb='http://thetvdb.com/banners/posters/260951-1.jpg')
                add_posts({'title' : 'Drew Carey Improv a Ganza',}, index, mode='newznab&newznab=27637',thumb='http://thetvdb.com/banners/posters/238431-1.jpg')
                add_posts({'title' : 'Drew Careys Improv A Ganza',}, index, mode='newznab&newznab=27637',thumb='http://thetvdb.com/banners/posters/238431-1.jpg')
                add_posts({'title' : 'High Stakes Poker',}, index, mode='newznab&newznab=7942',thumb='http://thetvdb.com/banners/posters/79191-1.jpg')
                add_posts({'title' : 'The American Bible Challenge',}, index, mode='newznab&newznab=32489',thumb='http://thetvdb.com/banners/posters/261845-1.jpg')
            if newznab_id == 'H2 TV':
                add_posts({'title' : '10 Things You Don t Know About',}, index, mode='newznab&newznab=31067',thumb='http://thetvdb.com/banners/posters/257161-1.jpg')
                add_posts({'title' : 'America Unearthed',}, index, mode='newznab&newznab=33915',thumb='http://thetvdb.com/banners/posters/265052-1.jpg')
                add_posts({'title' : 'Americas Book of Secrets',}, index, mode='newznab&newznab=30735',thumb='http://thetvdb.com/banners/posters/256002-1.jpg')
                add_posts({'title' : 'Ancient Aliens',}, index, mode='newznab&newznab=25490',thumb='http://thetvdb.com/banners/posters/101501-1.jpg')
                add_posts({'title' : 'Countdown to Apocalypse',}, index, mode='newznab&newznab=33617',thumb='http://thetvdb.com/banners/posters/264079-1.jpg')
                add_posts({'title' : 'How the States Got Their Shapes',}, index, mode='newznab&newznab=27988',thumb='http://thetvdb.com/banners/posters/159241-1.jpg')
                add_posts({'title' : 'Modern Marvels',}, index, mode='newznab&newznab=4505',thumb='http://thetvdb.com/banners/posters/71697-1.jpg')
                add_posts({'title' : 'Serial Killer Earth',}, index, mode='newznab&newznab=31773',thumb='http://thetvdb.com/banners/posters/260248-1.jpg')
                add_posts({'title' : 'The Universe',}, index, mode='newznab&newznab=16083',thumb='http://thetvdb.com/banners/posters/80198-1.jpg')
                add_posts({'title' : 'Top Guns',}, index, mode='newznab&newznab=30933',thumb='http://thetvdb.com/banners/posters/256191-1.jpg')
            if newznab_id == 'HBO':
                add_posts({'title' : 'Angels in America',}, index, mode='newznab&newznab=16446',thumb='http://thetvdb.com/banners/posters/79311-1.jpg')
                add_posts({'title' : 'Babar',}, index, mode='newznab&newznab=2690',thumb='http://thetvdb.com/banners/posters/77278-1.jpg')
                add_posts({'title' : 'Big Love',}, index, mode='newznab&newznab=2797',thumb='http://thetvdb.com/banners/posters/74156-1.jpg')
                add_posts({'title' : 'Boardwalk Empire',}, index, mode='newznab&newznab=23561',thumb='http://thetvdb.com/banners/posters/84947-1.jpg')
                add_posts({'title' : 'Bored To Death',}, index, mode='newznab&newznab=22338',thumb='http://thetvdb.com/banners/posters/104641-1.jpg')
                add_posts({'title' : 'Carnivale',}, index, mode='newznab&newznab=2990',thumb='http://thetvdb.com/banners/posters/70860-1.jpg')
                add_posts({'title' : 'Curb Your Enthusiasm',}, index, mode='newznab&newznab=3188',thumb='http://thetvdb.com/banners/posters/76203-1.jpg')
                add_posts({'title' : 'Deadwood',}, index, mode='newznab&newznab=3267',thumb='http://thetvdb.com/banners/posters/72023-1.jpg')
                add_posts({'title' : 'Eastbound and Down',}, index, mode='newznab&newznab=21051',thumb='http://thetvdb.com/banners/posters/82467-1.jpg')
                add_posts({'title' : 'Enlightened',}, index, mode='newznab&newznab=24655',thumb='http://thetvdb.com/banners/posters/197101-1.jpg')
                add_posts({'title' : 'Entourage',}, index, mode='newznab&newznab=3449',thumb='http://thetvdb.com/banners/posters/74543-1.jpg')
                add_posts({'title' : 'Fraggle Rock',}, index, mode='newznab&newznab=3591',thumb='http://thetvdb.com/banners/posters/76085-1.jpg')
                add_posts({'title' : 'From The Earth To The Moon',}, index, mode='newznab&newznab=1851',thumb='http://thetvdb.com/banners/posters/77831-1.jpg')
                add_posts({'title' : 'Funny or Die Presents',}, index, mode='newznab&newznab=24988',thumb='http://thetvdb.com/banners/posters/143041-1.jpg')
                add_posts({'title' : 'Game of Thrones',}, index, mode='newznab&newznab=24493',thumb='http://thetvdb.com/banners/posters/121361-1.jpg')
                add_posts({'title' : 'generation kill',}, index, mode='newznab&newznab=18102',thumb='http://thetvdb.com/banners/posters/82109-1.jpg')
                add_posts({'title' : 'Girls',}, index, mode='newznab&newznab=30124',thumb='http://thetvdb.com/banners/posters/220411-1.jpg')
                add_posts({'title' : 'Hard Knocks',}, index, mode='newznab&newznab=10244',thumb='http://thetvdb.com/banners/posters/76765-1.jpg')
                add_posts({'title' : 'How to Make It in America',}, index, mode='newznab&newznab=24569',thumb='http://thetvdb.com/banners/posters/134231-1.jpg')
                add_posts({'title' : 'Hung',}, index, mode='newznab&newznab=21942',thumb='http://thetvdb.com/banners/posters/82091-1.jpg')
                add_posts({'title' : 'In Treatment',}, index, mode='newznab&newznab=18262',thumb='http://thetvdb.com/banners/posters/81248-1.jpg')
                add_posts({'title' : 'K Street',}, index, mode='newznab&newznab=4161',thumb='http://thetvdb.com/banners/posters/72835-1.jpg')
                add_posts({'title' : 'Luck',}, index, mode='newznab&newznab=25055',thumb='http://thetvdb.com/banners/posters/219381-1.jpg')
                add_posts({'title' : 'On Freddie Roach',}, index, mode='newznab&newznab=30531',thumb='http://thetvdb.com/banners/posters/254984-1.jpg')
                add_posts({'title' : 'Oz',}, index, mode='newznab&newznab=4760',thumb='http://thetvdb.com/banners/posters/70682-1.jpg')
                add_posts({'title' : 'Real Time With Bill Maher',}, index, mode='newznab&newznab=4950',thumb='http://thetvdb.com/banners/posters/72231-1.jpg')
                add_posts({'title' : 'Rome',}, index, mode='newznab&newznab=5047',thumb='http://thetvdb.com/banners/posters/73508-1.jpg')
                add_posts({'title' : 'Russell Simmons Presents Def Poetry',}, index, mode='newznab&newznab=15188')
                add_posts({'title' : 'Sex And The City',}, index, mode='newznab&newznab=5155',thumb='http://thetvdb.com/banners/posters/76648-1.jpg')
                add_posts({'title' : 'Six Feet Under',}, index, mode='newznab&newznab=5214',thumb='http://thetvdb.com/banners/posters/75450-1.jpg')
                add_posts({'title' : 'The Hitchhiker',}, index, mode='newznab&newznab=5853',thumb='http://thetvdb.com/banners/posters/78513-1.jpg')
                add_posts({'title' : 'The Life and Times of Tim',}, index, mode='newznab&newznab=18401')
                add_posts({'title' : 'The Newsroom 2012',}, index, mode='newznab&newznab=31286',thumb='http://thetvdb.com/banners/posters/256227-1.jpg')
                add_posts({'title' : 'The Ricky Gervais Show',}, index, mode='newznab&newznab=24803',thumb='http://thetvdb.com/banners/posters/142581-1.jpg')
                add_posts({'title' : 'The Sopranos',}, index, mode='newznab&newznab=6206',thumb='http://thetvdb.com/banners/posters/75299-1.jpg')
                add_posts({'title' : 'The Wire',}, index, mode='newznab&newznab=6296',thumb='http://thetvdb.com/banners/posters/79126-1.jpg')
                add_posts({'title' : 'Treme',}, index, mode='newznab&newznab=22606',thumb='http://thetvdb.com/banners/posters/84946-1.jpg')
                add_posts({'title' : 'True Blood',}, index, mode='newznab&newznab=12662',thumb='http://thetvdb.com/banners/posters/82283-1.jpg')
                add_posts({'title' : 'Veep',}, index, mode='newznab&newznab=28149',thumb='http://thetvdb.com/banners/posters/237831-1.jpg')
            if newznab_id == 'HBO Canada':
                add_posts({'title' : 'Call Me Fitz',}, index, mode='newznab&newznab=26774',thumb='http://thetvdb.com/banners/posters/191101-1.jpg')
                add_posts({'title' : 'Funny As Hell',}, index, mode='newznab&newznab=30590',thumb='http://thetvdb.com/banners/posters/248016-1.jpg')
                add_posts({'title' : 'Less Than Kind',}, index, mode='newznab&newznab=18244',thumb='http://thetvdb.com/banners/posters/83710-1.jpg')
            if newznab_id == 'HGTV':
                add_posts({'title' : 'All American Handyman',}, index, mode='newznab&newznab=26432')
                add_posts({'title' : 'Holmes Makes It Right',}, index, mode='newznab&newznab=33097',thumb='http://thetvdb.com/banners/posters/263011-1.jpg')
                add_posts({'title' : 'Holmes On Homes',}, index, mode='newznab&newznab=14611',thumb='http://thetvdb.com/banners/posters/80258-1.jpg')
                add_posts({'title' : 'House Hunters International',}, index, mode='newznab&newznab=16886',thumb='http://thetvdb.com/banners/posters/183411-1.jpg')
                add_posts({'title' : 'House Hunters',}, index, mode='newznab&newznab=3910',thumb='http://thetvdb.com/banners/posters/73182-1.jpg')
                add_posts({'title' : 'My Yard Goes Disney',}, index, mode='newznab&newznab=28520',thumb='http://thetvdb.com/banners/posters/249314-1.jpg')
                add_posts({'title' : 'The Unsellables',}, index, mode='newznab&newznab=20892')
            if newznab_id == 'History Channel':
                add_posts({'title' : 'American Pickers',}, index, mode='newznab&newznab=24796',thumb='http://thetvdb.com/banners/posters/141181-1.jpg')
                add_posts({'title' : 'American Restoration',}, index, mode='newznab&newznab=26839',thumb='http://thetvdb.com/banners/posters/199011-1.jpg')
                add_posts({'title' : 'Ancient Discoveries',}, index, mode='newznab&newznab=15219',thumb='http://thetvdb.com/banners/posters/82052-1.jpg')
                add_posts({'title' : 'Around the World in 80 Ways',}, index, mode='newznab&newznab=28406',thumb='http://thetvdb.com/banners/posters/252269-1.jpg')
                add_posts({'title' : 'Ax Men',}, index, mode='newznab&newznab=18481',thumb='http://thetvdb.com/banners/posters/81578-1.jpg')
                add_posts({'title' : 'Bamazon',}, index, mode='newznab&newznab=33396',thumb='http://thetvdb.com/banners/posters/263659-1.jpg')
                add_posts({'title' : 'Battle 360',}, index, mode='newznab&newznab=18514',thumb='http://thetvdb.com/banners/posters/81551-1.jpg')
                add_posts({'title' : 'Big Shrimpin',}, index, mode='newznab&newznab=30064',thumb='http://thetvdb.com/banners/posters/253700-1.jpg')
                add_posts({'title' : 'Brad Beltzers Decoded',}, index, mode='newznab&newznab=26972',thumb='http://thetvdb.com/banners/posters/208101-1.jpg')
                add_posts({'title' : 'Brad Meltzers Decoded',}, index, mode='newznab&newznab=26972',thumb='http://thetvdb.com/banners/posters/208101-1.jpg')
                add_posts({'title' : 'Cajun Pawn Stars',}, index, mode='newznab&newznab=30518',thumb='http://thetvdb.com/banners/posters/254650-1.jpg')
                add_posts({'title' : 'Chasing Mummies',}, index, mode='newznab&newznab=26101',thumb='http://thetvdb.com/banners/posters/173841-1.jpg')
                add_posts({'title' : 'Cities of the Underworld',}, index, mode='newznab&newznab=15561',thumb='http://thetvdb.com/banners/posters/80373-1.jpg')
                add_posts({'title' : 'Counting Cars',}, index, mode='newznab&newznab=32440',thumb='http://thetvdb.com/banners/posters/261181-1.jpg')
                add_posts({'title' : 'Expedition Africa',}, index, mode='newznab&newznab=22634',thumb='http://thetvdb.com/banners/posters/97281-1.jpg')
                add_posts({'title' : 'Extreme Trains',}, index, mode='newznab&newznab=20337',thumb='http://thetvdb.com/banners/posters/84127-1.jpg')
                add_posts({'title' : 'Full Metal Jousting',}, index, mode='newznab&newznab=30114',thumb='http://thetvdb.com/banners/posters/255477-1.jpg')
                add_posts({'title' : 'Gangland',}, index, mode='newznab&newznab=17845',thumb='http://thetvdb.com/banners/posters/81213-1.jpg')
                add_posts({'title' : 'Great Lake Warriors',}, index, mode='newznab&newznab=32296',thumb='http://thetvdb.com/banners/posters/260728-1.jpg')
                add_posts({'title' : 'Hairy Bikers',}, index, mode='newznab&newznab=29765',thumb='http://thetvdb.com/banners/posters/81556-1.jpg')
                add_posts({'title' : 'Harvest',}, index, mode='newznab&newznab=29788',thumb='http://thetvdb.com/banners/posters/252818-1.jpg')
                add_posts({'title' : 'History Mysteries',}, index, mode='newznab&newznab=3868',thumb='http://thetvdb.com/banners/posters/83330-1.jpg')
                add_posts({'title' : 'How The Earth Was Made',}, index, mode='newznab&newznab=22027',thumb='http://thetvdb.com/banners/posters/85168-1.jpg')
                add_posts({'title' : 'Human Weapon',}, index, mode='newznab&newznab=16964',thumb='http://thetvdb.com/banners/posters/80353-1.jpg')
                add_posts({'title' : 'I Love the 1880s',}, index, mode='newznab&newznab=33985',thumb='http://thetvdb.com/banners/posters/264288-1.jpg')
                add_posts({'title' : 'Ice Road Truckers',}, index, mode='newznab&newznab=16471',thumb='http://thetvdb.com/banners/posters/80273-1.jpg')
                add_posts({'title' : 'Inspector America',}, index, mode='newznab&newznab=27921',thumb='http://thetvdb.com/banners/posters/247922-1.jpg')
                add_posts({'title' : 'Invention USA',}, index, mode='newznab&newznab=29969',thumb='http://thetvdb.com/banners/posters/254080-1.jpg')
                add_posts({'title' : 'IRT Deadliest Roads',}, index, mode='newznab&newznab=26728',thumb='http://thetvdb.com/banners/posters/194271-1.jpg')
                add_posts({'title' : 'Jurassic Fight Club',}, index, mode='newznab&newznab=19588',thumb='http://thetvdb.com/banners/posters/82642-1.jpg')
                add_posts({'title' : 'Life after People',}, index, mode='newznab&newznab=18249',thumb='http://thetvdb.com/banners/posters/83897-1.jpg')
                add_posts({'title' : 'Lost Worlds',}, index, mode='newznab&newznab=13373',thumb='http://thetvdb.com/banners/posters/80685-1.jpg')
                add_posts({'title' : 'Mankind The Story of All of Us',}, index, mode='newznab&newznab=32230',thumb='http://thetvdb.com/banners/posters/263092-1.jpg')
                add_posts({'title' : 'Modern Marvels Essentials',}, index, mode='newznab&newznab=26179')
                add_posts({'title' : 'MonsterQuest',}, index, mode='newznab&newznab=17807',thumb='http://thetvdb.com/banners/posters/84767-1.jpg')
                add_posts({'title' : 'Mountain Men',}, index, mode='newznab&newznab=31767',thumb='http://thetvdb.com/banners/posters/259203-1.jpg')
                add_posts({'title' : 'Mounted In Alaska',}, index, mode='newznab&newznab=27746',thumb='http://thetvdb.com/banners/posters/247771-1.jpg')
                add_posts({'title' : 'MysteryQuest',}, index, mode='newznab&newznab=23461',thumb='http://thetvdb.com/banners/posters/114241-1.jpg')
                add_posts({'title' : 'Noreaster Men',}, index, mode='newznab&newznab=32853')
                add_posts({'title' : 'Only In America with Larry the Cable Guy',}, index, mode='newznab&newznab=27572',thumb='http://thetvdb.com/banners/posters/222551-1.jpg')
                add_posts({'title' : 'Outback Hunters',}, index, mode='newznab&newznab=32860',thumb='http://thetvdb.com/banners/posters/263213-1.jpg')
                add_posts({'title' : 'Patton 360',}, index, mode='newznab&newznab=22341',thumb='http://thetvdb.com/banners/posters/90061-1.jpg')
                add_posts({'title' : 'Pawn Star',}, index, mode='newznab&newznab=23281')
                add_posts({'title' : 'Pawn Stars',}, index, mode='newznab&newznab=23281')
                add_posts({'title' : 'Picked Off',}, index, mode='newznab&newznab=32074',thumb='http://thetvdb.com/banners/posters/260323-1.jpg')
                add_posts({'title' : 'Shark Wranglers',}, index, mode='newznab&newznab=32108',thumb='http://thetvdb.com/banners/posters/260397-1.jpg')
                add_posts({'title' : 'Sliced',}, index, mode='newznab&newznab=25495',thumb='http://thetvdb.com/banners/posters/171101-1.jpg')
                add_posts({'title' : 'Stan Lees Superhumans',}, index, mode='newznab&newznab=26227',thumb='http://thetvdb.com/banners/posters/181571-1.jpg')
                add_posts({'title' : 'Swamp People',}, index, mode='newznab&newznab=26351',thumb='http://thetvdb.com/banners/posters/183231-1.jpg')
                add_posts({'title' : 'Thats Impossible',}, index, mode='newznab&newznab=23151',thumb='http://thetvdb.com/banners/posters/103011-1.jpg')
                add_posts({'title' : 'The Brain',}, index, mode='newznab&newznab=26984',thumb='http://thetvdb.com/banners/posters/172391-1.jpg')
                add_posts({'title' : 'The Revolution 2006',}, index, mode='newznab&newznab=21858')
                add_posts({'title' : 'Top Gear US',}, index, mode='newznab&newznab=20568',thumb='http://thetvdb.com/banners/posters/199051-1.jpg')
                add_posts({'title' : 'Top Shot',}, index, mode='newznab&newznab=24826',thumb='http://thetvdb.com/banners/posters/165841-1.jpg')
                add_posts({'title' : 'Underwater Universe',}, index, mode='newznab&newznab=27750',thumb='http://thetvdb.com/banners/posters/193001-1.jpg')
                add_posts({'title' : 'United Stats of America',}, index, mode='newznab&newznab=30115',thumb='http://thetvdb.com/banners/posters/258550-1.jpg')
                add_posts({'title' : 'Vietnam In HD',}, index, mode='newznab&newznab=29847',thumb='http://thetvdb.com/banners/posters/253471-1.jpg')
                add_posts({'title' : 'Warriors',}, index, mode='newznab&newznab=22040',thumb='http://thetvdb.com/banners/posters/85467-1.jpg')
            if newznab_id == 'History Television':
                add_posts({'title' : 'Bomb Hunters',}, index, mode='newznab&newznab=32648',thumb='http://thetvdb.com/banners/posters/261853-1.jpg')
                add_posts({'title' : 'Canadian Pickers',}, index, mode='newznab&newznab=29362',thumb='http://thetvdb.com/banners/posters/251800-1.jpg')
                add_posts({'title' : 'Ice Pilots',}, index, mode='newznab&newznab=27985',thumb='http://thetvdb.com/banners/posters/248197-1.jpg')
                add_posts({'title' : 'Trashopolis',}, index, mode='newznab&newznab=29846',thumb='http://thetvdb.com/banners/posters/249335-1.jpg')
            if newznab_id == 'HUB':
                add_posts({'title' : 'Care Bears Welcome to Care a Lot',}, index, mode='newznab&newznab=31627',thumb='http://thetvdb.com/banners/posters/260218-1.jpg')
                add_posts({'title' : 'Dan Vs',}, index, mode='newznab&newznab=27120',thumb='http://thetvdb.com/banners/posters/219851-1.jpg')
                add_posts({'title' : 'Family Game Night',}, index, mode='newznab&newznab=29405')
                add_posts({'title' : 'G I Joe Renegades',}, index, mode='newznab&newznab=26769',thumb='http://thetvdb.com/banners/posters/208561-1.jpg')
                add_posts({'title' : 'Kaijudo Rise of the Duel Masters',}, index, mode='newznab&newznab=31790')
                add_posts({'title' : 'Littlest Pet Shop 2012',}, index, mode='newznab&newznab=33627',thumb='http://thetvdb.com/banners/posters/264017-1.jpg')
                add_posts({'title' : 'Majors and Minors',}, index, mode='newznab&newznab=29411')
                add_posts({'title' : 'My Little Pony Friendship is Magic',}, index, mode='newznab&newznab=27689',thumb='http://thetvdb.com/banners/posters/212171-1.jpg')
                add_posts({'title' : 'R L Stines The Haunting Hour',}, index, mode='newznab&newznab=27117')
                add_posts({'title' : 'Scrabble Showdown',}, index, mode='newznab&newznab=29439')
                add_posts({'title' : 'The Adventures of Chuck and Friends',}, index, mode='newznab&newznab=32565',thumb='http://thetvdb.com/banners/posters/206181-1.jpg')
                add_posts({'title' : 'Transformers Prime',}, index, mode='newznab&newznab=26766',thumb='http://thetvdb.com/banners/posters/205901-1.jpg')
                add_posts({'title' : 'Transformers Rescue Bots',}, index, mode='newznab&newznab=30355',thumb='http://thetvdb.com/banners/posters/256349-1.jpg')
                add_posts({'title' : 'TransformerS0Prime',}, index, mode='newznab&newznab=26766',thumb='http://thetvdb.com/banners/posters/205901-1.jpg')
            if newznab_id == 'Hulu iTunes':
                add_posts({'title' : 'The Booth at the End',}, index, mode='newznab&newznab=28474',thumb='http://thetvdb.com/banners/posters/240971-1.jpg')
            if newznab_id == 'ID Investigation Discovery':
                add_posts({'title' : 'Behind Mansion Walls',}, index, mode='newznab&newznab=28515',thumb='http://thetvdb.com/banners/posters/249411-1.jpg')
                add_posts({'title' : 'Big Law Deputy Butterbean',}, index, mode='newznab&newznab=28797')
                add_posts({'title' : 'Cuff Me If You Can',}, index, mode='newznab&newznab=27752',thumb='http://thetvdb.com/banners/posters/250707-1.jpg')
                add_posts({'title' : 'FBI Criminal Pursuit',}, index, mode='newznab&newznab=27758',thumb='http://thetvdb.com/banners/posters/249651-1.jpg')
                add_posts({'title' : 'I Married a Mobster',}, index, mode='newznab&newznab=28684',thumb='http://thetvdb.com/banners/posters/250338-1.jpg')
                add_posts({'title' : 'Motives and Murders',}, index, mode='newznab&newznab=31373',thumb='http://thetvdb.com/banners/posters/258253-1.jpg')
                add_posts({'title' : 'Sins and Secrets',}, index, mode='newznab&newznab=27609')
                add_posts({'title' : 'The Injustice Files',}, index, mode='newznab&newznab=27578')
                add_posts({'title' : 'True Grime Crime Scene Clean Up',}, index, mode='newznab&newznab=28690')
            if newznab_id == 'IFC':
                add_posts({'title' : 'Bullet in the Face',}, index, mode='newznab&newznab=30118',thumb='http://thetvdb.com/banners/posters/258273-1.jpg')
                add_posts({'title' : 'Bunk',}, index, mode='newznab&newznab=31806',thumb='http://thetvdb.com/banners/posters/258813-1.jpg')
                add_posts({'title' : 'Comedy Bang Bang',}, index, mode='newznab&newznab=31483',thumb='http://thetvdb.com/banners/posters/258310-1.jpg')
                add_posts({'title' : 'Onion News Network',}, index, mode='newznab&newznab=27253')
                add_posts({'title' : 'Portlandia',}, index, mode='newznab&newznab=27219',thumb='http://thetvdb.com/banners/posters/213221-1.jpg')
                add_posts({'title' : 'Rhett and Link Commercial Kings',}, index, mode='newznab&newznab=28648',thumb='http://thetvdb.com/banners/posters/249720-1.jpg')
                add_posts({'title' : 'The Increasingly Poor Decisions of Todd Margaret',}, index, mode='newznab&newznab=25891',thumb='http://thetvdb.com/banners/posters/140681-1.jpg')
                add_posts({'title' : 'The Whitest Kids U Know',}, index, mode='newznab&newznab=15351',thumb='http://thetvdb.com/banners/posters/80728-1.jpg')
                add_posts({'title' : 'Whisker Wars',}, index, mode='newznab&newznab=28794',thumb='http://thetvdb.com/banners/posters/250900-1.jpg')
            if newznab_id == 'Investigation Discovery':
                add_posts({'title' : 'Alaska Ice Cold Killers',}, index, mode='newznab&newznab=31116',thumb='http://thetvdb.com/banners/posters/260075-1.jpg')
                add_posts({'title' : 'Dallas DNA',}, index, mode='newznab&newznab=21954')
                add_posts({'title' : 'Deadly Women',}, index, mode='newznab&newznab=23789',thumb='http://thetvdb.com/banners/posters/182401-1.jpg')
                add_posts({'title' : 'Disappeared',}, index, mode='newznab&newznab=22874',thumb='http://thetvdb.com/banners/posters/203411-1.jpg')
                add_posts({'title' : 'Final Cut',}, index, mode='newznab&newznab=33568')
                add_posts({'title' : 'Hardcover Mysteries',}, index, mode='newznab&newznab=26338')
                add_posts({'title' : 'Hookers Saved on the Strip',}, index, mode='newznab&newznab=27043')
                add_posts({'title' : 'I Almost Got Away With It',}, index, mode='newznab&newznab=24779',thumb='http://thetvdb.com/banners/posters/142721-1.jpg')
                add_posts({'title' : 'I Escaped Real Prison Breaks',}, index, mode='newznab&newznab=26102',thumb='http://thetvdb.com/banners/posters/176151-1.jpg')
                add_posts({'title' : 'Mystery Files',}, index, mode='newznab&newznab=24800',thumb='http://thetvdb.com/banners/posters/167031-1.jpg')
                add_posts({'title' : 'Nightmare Next Door',}, index, mode='newznab&newznab=27306',thumb='http://thetvdb.com/banners/posters/226811-1.jpg')
                add_posts({'title' : 'Only In America',}, index, mode='newznab&newznab=7869')
                add_posts({'title' : 'Prison Wives',}, index, mode='newznab&newznab=22878')
                add_posts({'title' : 'Scorned Love Kills',}, index, mode='newznab&newznab=30535',thumb='http://thetvdb.com/banners/posters/255307-1.jpg')
                add_posts({'title' : 'Stolen Voices Buried Secrets',}, index, mode='newznab&newznab=27313',thumb='http://thetvdb.com/banners/posters/222831-1.jpg')
                add_posts({'title' : 'Unusual Suspects',}, index, mode='newznab&newznab=25812',thumb='http://thetvdb.com/banners/posters/174531-1.jpg')
                add_posts({'title' : 'Who the Bleep Did I Marry',}, index, mode='newznab&newznab=26337',thumb='http://thetvdb.com/banners/posters/185611-1.jpg')
                add_posts({'title' : 'Wicked Attraction',}, index, mode='newznab&newznab=21202',thumb='http://thetvdb.com/banners/posters/217931-1.jpg')
            if newznab_id == 'ITV':
                add_posts({'title' : 'An Audience With',}, index, mode='newznab&newznab=9077')
                add_posts({'title' : 'Auf Wiedersehen Pet',}, index, mode='newznab&newznab=2672',thumb='http://thetvdb.com/banners/posters/78287-1.jpg')
                add_posts({'title' : 'Bad Girls',}, index, mode='newznab&newznab=2701',thumb='http://thetvdb.com/banners/posters/75328-1.jpg')
                add_posts({'title' : 'Bless Me Father',}, index, mode='newznab&newznab=2826',thumb='http://thetvdb.com/banners/posters/71002-1.jpg')
                add_posts({'title' : 'Cannon and Ball',}, index, mode='newznab&newznab=9168',thumb='http://thetvdb.com/banners/posters/214171-1.jpg')
                add_posts({'title' : 'Carry On Laughing',}, index, mode='newznab&newznab=835',thumb='http://thetvdb.com/banners/posters/71599-1.jpg')
                add_posts({'title' : 'Catweazle',}, index, mode='newznab&newznab=3007',thumb='http://thetvdb.com/banners/posters/72372-1.jpg')
                add_posts({'title' : 'Country Matters',}, index, mode='newznab&newznab=13163',thumb='http://thetvdb.com/banners/posters/201261-1.jpg')
                add_posts({'title' : 'Creature Comforts UK',}, index, mode='newznab&newznab=3165')
                add_posts({'title' : 'Danger Man',}, index, mode='newznab&newznab=3225',thumb='http://thetvdb.com/banners/posters/76164-1.jpg')
                add_posts({'title' : 'Doctor At Sea',}, index, mode='newznab&newznab=8859',thumb='http://thetvdb.com/banners/posters/251310-1.jpg')
                add_posts({'title' : 'Doctor Finlay',}, index, mode='newznab&newznab=3329')
                add_posts({'title' : 'Doctor On The Go',}, index, mode='newznab&newznab=8860',thumb='http://thetvdb.com/banners/posters/251302-1.jpg')
                add_posts({'title' : 'Dont Drink The Water',}, index, mode='newznab&newznab=8864',thumb='http://thetvdb.com/banners/posters/206231-1.jpg')
                add_posts({'title' : 'Fireball XL5',}, index, mode='newznab&newznab=595',thumb='http://thetvdb.com/banners/posters/70828-1.jpg')
                add_posts({'title' : 'Footballers Wives',}, index, mode='newznab&newznab=3573',thumb='http://thetvdb.com/banners/posters/78905-1.jpg')
                add_posts({'title' : 'Fresh Fields',}, index, mode='newznab&newznab=1026',thumb='http://thetvdb.com/banners/posters/72370-1.jpg')
                add_posts({'title' : 'Home To Roost',}, index, mode='newznab&newznab=1855',thumb='http://thetvdb.com/banners/posters/77838-1.jpg')
                add_posts({'title' : 'Inspector Morse',}, index, mode='newznab&newznab=3973',thumb='http://thetvdb.com/banners/posters/76582-1.jpg')
                add_posts({'title' : 'Its Tommy Cooper',}, index, mode='newznab&newznab=9586',thumb='http://thetvdb.com/banners/posters/223981-1.jpg')
                add_posts({'title' : 'London Bridge',}, index, mode='newznab&newznab=14941')
                add_posts({'title' : 'Man About The House',}, index, mode='newznab&newznab=4359',thumb='http://thetvdb.com/banners/posters/76700-1.jpg')
                add_posts({'title' : 'Metal Mickey',}, index, mode='newznab&newznab=9603',thumb='http://thetvdb.com/banners/posters/87331-1.jpg')
                add_posts({'title' : 'Nearest and Dearest',}, index, mode='newznab&newznab=1986',thumb='http://thetvdb.com/banners/posters/78408-1.jpg')
                add_posts({'title' : 'Outside Edge',}, index, mode='newznab&newznab=815',thumb='http://thetvdb.com/banners/posters/71514-1.jpg')
                add_posts({'title' : 'Piece of Cake',}, index, mode='newznab&newznab=11061',thumb='http://thetvdb.com/banners/posters/96211-1.jpg')
                add_posts({'title' : 'Reilly Ace Of Spies',}, index, mode='newznab&newznab=4967',thumb='http://thetvdb.com/banners/posters/78222-2.jpg')
                add_posts({'title' : 'Robin of Sherwood',}, index, mode='newznab&newznab=5023',thumb='http://thetvdb.com/banners/posters/75366-1.jpg')
                add_posts({'title' : 'Romany Jones',}, index, mode='newznab&newznab=8966',thumb='http://thetvdb.com/banners/posters/74648-1.jpg')
                add_posts({'title' : 'Rumpole Of The Bailey',}, index, mode='newznab&newznab=158',thumb='http://thetvdb.com/banners/posters/72995-1.jpg')
                add_posts({'title' : 'Sapphire and Steel',}, index, mode='newznab&newznab=208')
                add_posts({'title' : 'Sergeant Cork',}, index, mode='newznab&newznab=13432',thumb='http://thetvdb.com/banners/posters/259951-1.jpg')
                add_posts({'title' : 'Space 1999',}, index, mode='newznab&newznab=5271',thumb='http://thetvdb.com/banners/posters/76366-1.jpg')
                add_posts({'title' : 'Tales Of The Unexpected',}, index, mode='newznab&newznab=75',thumb='http://thetvdb.com/banners/posters/78710-1.jpg')
                add_posts({'title' : 'Thats My Boy',}, index, mode='newznab&newznab=8610',thumb='http://thetvdb.com/banners/posters/102221-1.jpg')
                add_posts({'title' : 'The Avengers',}, index, mode='newznab&newznab=5591',thumb='http://thetvdb.com/banners/posters/71020-1.jpg')
                add_posts({'title' : 'The Chief',}, index, mode='newznab&newznab=13545',thumb='http://thetvdb.com/banners/posters/72567-1.jpg')
                add_posts({'title' : 'The Dame Edna Experience',}, index, mode='newznab&newznab=9277',thumb='http://thetvdb.com/banners/posters/92971-1.jpg')
                add_posts({'title' : 'The New Adventures Of Black Beauty',}, index, mode='newznab&newznab=914',thumb='http://thetvdb.com/banners/posters/225391-1.jpg')
                add_posts({'title' : 'The Saint',}, index, mode='newznab&newznab=6158',thumb='http://thetvdb.com/banners/posters/75134-1.jpg')
                add_posts({'title' : 'The Sandbaggers',}, index, mode='newznab&newznab=1749',thumb='http://thetvdb.com/banners/posters/77420-1.jpg')
                add_posts({'title' : 'The Sweeney',}, index, mode='newznab&newznab=1653',thumb='http://thetvdb.com/banners/posters/76998-1.jpg')
                add_posts({'title' : 'Undermind',}, index, mode='newznab&newznab=12796',thumb='http://thetvdb.com/banners/posters/226681-1.jpg')
                add_posts({'title' : 'Upstairs Downstairs',}, index, mode='newznab&newznab=6490',thumb='http://thetvdb.com/banners/posters/71000-1.jpg')
                add_posts({'title' : 'Wycliffe',}, index, mode='newznab&newznab=6664',thumb='http://thetvdb.com/banners/posters/78733-1.jpg')
            if newznab_id == 'ITV1':
                add_posts({'title' : '56 Up',}, index, mode='newznab&newznab=31579',thumb='http://thetvdb.com/banners/posters/259851-1.jpg')
                add_posts({'title' : '71 Degrees North',}, index, mode='newznab&newznab=26521',thumb='http://thetvdb.com/banners/posters/189051-1.jpg')
                add_posts({'title' : 'A Mothers Son',}, index, mode='newznab&newznab=32526',thumb='http://thetvdb.com/banners/posters/262104-1.jpg')
                add_posts({'title' : 'A Touch Of Frost',}, index, mode='newznab&newznab=2667',thumb='http://thetvdb.com/banners/posters/76247-1.jpg')
                add_posts({'title' : 'Above Suspicion',}, index, mode='newznab&newznab=19374',thumb='http://thetvdb.com/banners/posters/84373-1.jpg')
                add_posts({'title' : 'Agatha Christie Marple',}, index, mode='newznab&newznab=2515',thumb='http://thetvdb.com/banners/posters/78895-1.jpg')
                add_posts({'title' : 'Agatha Christie Poirot',}, index, mode='newznab&newznab=4847',thumb='http://thetvdb.com/banners/posters/76133-1.jpg')
                add_posts({'title' : 'Agatha Christies Marple',}, index, mode='newznab&newznab=2515',thumb='http://thetvdb.com/banners/posters/78895-1.jpg')
                add_posts({'title' : 'Animal Kingdom',}, index, mode='newznab&newznab=28489')
                add_posts({'title' : 'Ant And Decks Push The Button',}, index, mode='newznab&newznab=25167')
                add_posts({'title' : 'Ant And Decs Push The Button',}, index, mode='newznab&newznab=25167')
                add_posts({'title' : 'Appropriate Adult',}, index, mode='newznab&newznab=29286',thumb='http://thetvdb.com/banners/posters/251645-1.jpg')
                add_posts({'title' : 'Babies Behind Bars',}, index, mode='newznab&newznab=28701')
                add_posts({'title' : 'Baboons With Bill Bailey',}, index, mode='newznab&newznab=27860',thumb='http://thetvdb.com/banners/posters/247711-1.jpg')
                add_posts({'title' : 'Band Of Gold',}, index, mode='newznab&newznab=825',thumb='http://thetvdb.com/banners/posters/85115-1.jpg')
                add_posts({'title' : 'Barbara',}, index, mode='newznab&newznab=2710',thumb='http://thetvdb.com/banners/posters/76574-1.jpg')
                add_posts({'title' : 'Benidorm',}, index, mode='newznab&newznab=15098',thumb='http://thetvdb.com/banners/posters/79912-1.jpg')
                add_posts({'title' : 'Billy Connollys Route 66',}, index, mode='newznab&newznab=29374',thumb='http://thetvdb.com/banners/posters/251909-1.jpg')
                add_posts({'title' : 'Born To Shine',}, index, mode='newznab&newznab=28937')
                add_posts({'title' : 'Britains Got Talent',}, index, mode='newznab&newznab=16137',thumb='http://thetvdb.com/banners/posters/80727-1.jpg')
                add_posts({'title' : 'Caroline Quentin A Passage Through India',}, index, mode='newznab&newznab=27665',thumb='http://thetvdb.com/banners/posters/240321-1.jpg')
                add_posts({'title' : 'Case Sensitive',}, index, mode='newznab&newznab=28145',thumb='http://thetvdb.com/banners/posters/248394-1.jpg')
                add_posts({'title' : 'Cheetah Kingdom',}, index, mode='newznab&newznab=26494',thumb='http://thetvdb.com/banners/posters/189481-1.jpg')
                add_posts({'title' : 'Childrens Hospital UK',}, index, mode='newznab&newznab=25308')
                add_posts({'title' : 'Cluedo UK',}, index, mode='newznab&newznab=252')
                add_posts({'title' : 'Comedy Rocks With Jason Manford',}, index, mode='newznab&newznab=25311')
                add_posts({'title' : 'Corrie Goes To Kenya',}, index, mode='newznab&newznab=32410')
                add_posts({'title' : 'Countrywise Kitchen',}, index, mode='newznab&newznab=26934',thumb='http://thetvdb.com/banners/posters/209971-1.jpg')
                add_posts({'title' : 'David Jasons Great Escapes',}, index, mode='newznab&newznab=29232')
                add_posts({'title' : 'DCI Banks',}, index, mode='newznab&newznab=26617',thumb='http://thetvdb.com/banners/posters/193691-1.jpg')
                add_posts({'title' : 'Dirty Britain',}, index, mode='newznab&newznab=31574',thumb='http://thetvdb.com/banners/posters/259075-1.jpg')
                add_posts({'title' : 'Doc Martin',}, index, mode='newznab&newznab=3327',thumb='http://thetvdb.com/banners/posters/79285-1.jpg')
                add_posts({'title' : 'Downton Abbey',}, index, mode='newznab&newznab=26615',thumb='http://thetvdb.com/banners/posters/193131-1.jpg')
                add_posts({'title' : 'Emmerdale',}, index, mode='newznab&newznab=3440',thumb='http://thetvdb.com/banners/posters/77715-1.jpg')
                add_posts({'title' : 'Eternal Law',}, index, mode='newznab&newznab=30377',thumb='http://thetvdb.com/banners/posters/238101-1.jpg')
                add_posts({'title' : 'Exposure UK',}, index, mode='newznab&newznab=29594')
                add_posts({'title' : 'Fat Friends',}, index, mode='newznab&newznab=1897',thumb='http://thetvdb.com/banners/posters/141521-1.jpg')
                add_posts({'title' : 'Father and Son',}, index, mode='newznab&newznab=25774')
                add_posts({'title' : 'Fortysomething',}, index, mode='newznab&newznab=1170',thumb='http://thetvdb.com/banners/posters/80898-1.jpg')
                add_posts({'title' : 'Greatest Cities Of The World With Griff Rhys Jones',}, index, mode='newznab&newznab=20179',thumb='http://thetvdb.com/banners/posters/83411-1.jpg')
                add_posts({'title' : 'Grimefighters',}, index, mode='newznab&newznab=23399',thumb='http://thetvdb.com/banners/posters/113101-1.jpg')
                add_posts({'title' : 'Gypsy Girls',}, index, mode='newznab&newznab=1922')
                add_posts({'title' : 'Harry Hills TV Burp',}, index, mode='newznab&newznab=1035',thumb='http://thetvdb.com/banners/posters/72404-1.jpg')
                add_posts({'title' : 'Heartbeat',}, index, mode='newznab&newznab=3819',thumb='http://thetvdb.com/banners/posters/74684-1.jpg')
                add_posts({'title' : 'Home Is Where The Heart Is',}, index, mode='newznab&newznab=28206',thumb='http://thetvdb.com/banners/posters/253385-1.jpg')
                add_posts({'title' : 'Homefront UK',}, index, mode='newznab&newznab=32797')
                add_posts({'title' : 'Homes From Hell',}, index, mode='newznab&newznab=25986',thumb='http://thetvdb.com/banners/posters/250362-1.jpg')
                add_posts({'title' : 'Injustice',}, index, mode='newznab&newznab=28427',thumb='http://thetvdb.com/banners/posters/249225-1.jpg')
                add_posts({'title' : 'Itll Be Alright On The Night',}, index, mode='newznab&newznab=22990',thumb='http://thetvdb.com/banners/posters/82360-1.jpg')
                add_posts({'title' : 'Kavanagh Q C',}, index, mode='newznab&newznab=4108',thumb='http://thetvdb.com/banners/posters/77006-1.jpg')
                add_posts({'title' : 'Keith Lemons Lemon Aid',}, index, mode='newznab&newznab=31234')
                add_posts({'title' : 'Kidnap And Ransom',}, index, mode='newznab&newznab=27189')
                add_posts({'title' : 'Kingdom',}, index, mode='newznab&newznab=15522',thumb='http://thetvdb.com/banners/posters/80201-1.jpg')
                add_posts({'title' : 'Law And Order UK',}, index, mode='newznab&newznab=18198',thumb='http://thetvdb.com/banners/posters/85228-1.jpg')
                add_posts({'title' : 'Lets Do Lunch With Gino and Me',}, index, mode='newznab&newznab=28848')
                add_posts({'title' : 'Lets Do Lunch With Gino and Mel',}, index, mode='newznab&newznab=28848')
                add_posts({'title' : 'Lewis',}, index, mode='newznab&newznab=7936',thumb='http://thetvdb.com/banners/posters/79864-1.jpg')
                add_posts({'title' : 'Lion Country',}, index, mode='newznab&newznab=24627',thumb='http://thetvdb.com/banners/posters/142741-1.jpg')
                add_posts({'title' : 'Little England',}, index, mode='newznab&newznab=29381',thumb='http://thetvdb.com/banners/posters/251847-1.jpg')
                add_posts({'title' : 'Long Lost Family',}, index, mode='newznab&newznab=28006',thumb='http://thetvdb.com/banners/posters/258255-1.jpg')
                add_posts({'title' : 'Mad Mad World',}, index, mode='newznab&newznab=31268',thumb='http://thetvdb.com/banners/posters/260835-1.jpg')
                add_posts({'title' : 'Marchlands',}, index, mode='newznab&newznab=27463',thumb='http://thetvdb.com/banners/posters/228731-1.jpg')
                add_posts({'title' : 'Martin Clunes Islands Of Britain',}, index, mode='newznab&newznab=22373',thumb='http://thetvdb.com/banners/posters/94141-1.jpg')
                add_posts({'title' : 'Mayday Mayday',}, index, mode='newznab&newznab=29385')
                add_posts({'title' : 'Midsomer Murders',}, index, mode='newznab&newznab=4466',thumb='http://thetvdb.com/banners/posters/76846-1.jpg')
                add_posts({'title' : 'Military Driving School',}, index, mode='newznab&newznab=28004',thumb='http://thetvdb.com/banners/posters/248309-1.jpg')
                add_posts({'title' : 'Missing Millions',}, index, mode='newznab&newznab=29373',thumb='http://thetvdb.com/banners/posters/251932-1.jpg')
                add_posts({'title' : 'Monroe',}, index, mode='newznab&newznab=27668',thumb='http://thetvdb.com/banners/posters/230531-1.jpg')
                add_posts({'title' : 'Mrs Biggs',}, index, mode='newznab&newznab=32529',thumb='http://thetvdb.com/banners/posters/262156-1.jpg')
                add_posts({'title' : 'Murder Investigation Team',}, index, mode='newznab&newznab=4559',thumb='http://thetvdb.com/banners/posters/72605-1.jpg')
                add_posts({'title' : 'My Childs Not Perfect',}, index, mode='newznab&newznab=30171',thumb='http://thetvdb.com/banners/posters/254701-1.jpg')
                add_posts({'title' : 'Natural Born Dealers',}, index, mode='newznab&newznab=18027',thumb='http://thetvdb.com/banners/posters/260834-1.jpg')
                add_posts({'title' : 'Odd One In',}, index, mode='newznab&newznab=26115',thumb='http://thetvdb.com/banners/posters/249692-1.jpg')
                add_posts({'title' : 'Paul O Grady Live',}, index, mode='newznab&newznab=26495')
                add_posts({'title' : 'Penn And Teller Fool Us',}, index, mode='newznab&newznab=27139',thumb='http://thetvdb.com/banners/posters/239851-1.jpg')
                add_posts({'title' : 'Piers Morgans Life Stories',}, index, mode='newznab&newznab=21818',thumb='http://thetvdb.com/banners/posters/121221-1.jpg')
                add_posts({'title' : 'Poms In Paradise',}, index, mode='newznab&newznab=28200',thumb='http://thetvdb.com/banners/posters/248866-1.jpg')
                add_posts({'title' : 'Real Crime',}, index, mode='newznab&newznab=23000',thumb='http://thetvdb.com/banners/posters/100091-1.jpg')
                add_posts({'title' : 'Red Or Black',}, index, mode='newznab&newznab=29216',thumb='http://thetvdb.com/banners/posters/250955-1.jpg')
                add_posts({'title' : 'Ronnie Corbetts Comedy Britain',}, index, mode='newznab&newznab=29079',thumb='http://thetvdb.com/banners/posters/250790-1.jpg')
                add_posts({'title' : 'Rosemary Shragers School For Cooks',}, index, mode='newznab&newznab=17793',thumb='http://thetvdb.com/banners/posters/83690-1.jpg')
                add_posts({'title' : 'Ruth Rendells Thirteen Steps Down',}, index, mode='newznab&newznab=32406',thumb='http://thetvdb.com/banners/posters/261448-1.jpg')
                add_posts({'title' : 'Safari Vet School',}, index, mode='newznab&newznab=30376',thumb='http://thetvdb.com/banners/posters/255106-1.jpg')
                add_posts({'title' : 'Scot And Bailey',}, index, mode='newznab&newznab=28381')
                add_posts({'title' : 'Scott And Bailey',}, index, mode='newznab&newznab=28381')
                add_posts({'title' : 'Show Me The Funny',}, index, mode='newznab&newznab=28938',thumb='http://thetvdb.com/banners/posters/70830-1.jpg')
                add_posts({'title' : 'Sing If You Can',}, index, mode='newznab&newznab=27947',thumb='http://thetvdb.com/banners/posters/248008-1.jpg')
                add_posts({'title' : 'Smugglers',}, index, mode='newznab&newznab=27853',thumb='http://thetvdb.com/banners/posters/247918-1.jpg')
                add_posts({'title' : 'Someones Daughter Someones Son',}, index, mode='newznab&newznab=29037',thumb='http://thetvdb.com/banners/posters/251022-1.jpg')
                add_posts({'title' : 'Strangeways',}, index, mode='newznab&newznab=28194',thumb='http://thetvdb.com/banners/posters/248639-1.jpg')
                add_posts({'title' : 'Strictly Kosher',}, index, mode='newznab&newznab=28886',thumb='http://thetvdb.com/banners/posters/260352-1.jpg')
                add_posts({'title' : 'Super Tiny Animals',}, index, mode='newznab&newznab=30143',thumb='http://thetvdb.com/banners/posters/254057-1.jpg')
                add_posts({'title' : 'Survivor US',}, index, mode='newznab&newznab=5419',thumb='http://thetvdb.com/banners/posters/78576-1.jpg')
                add_posts({'title' : 'Take Me Out UK',}, index, mode='newznab&newznab=24624')
                add_posts({'title' : 'That Sunday Night Show',}, index, mode='newznab&newznab=27187',thumb='http://thetvdb.com/banners/posters/225131-1.jpg')
                add_posts({'title' : 'The Adventurers Guide To Britain',}, index, mode='newznab&newznab=30085',thumb='http://thetvdb.com/banners/posters/254185-1.jpg')
                add_posts({'title' : 'The Bill',}, index, mode='newznab&newznab=5623',thumb='http://thetvdb.com/banners/posters/70474-1.jpg')
                add_posts({'title' : 'The Bletchley Circle',}, index, mode='newznab&newznab=32530',thumb='http://thetvdb.com/banners/posters/262168-1.jpg')
                add_posts({'title' : 'The Brief',}, index, mode='newznab&newznab=2085',thumb='http://thetvdb.com/banners/posters/74374-1.jpg')
                add_posts({'title' : 'The Briefs',}, index, mode='newznab&newznab=32322',thumb='http://thetvdb.com/banners/posters/261200-1.jpg')
                add_posts({'title' : 'The Choir That Rocks',}, index, mode='newznab&newznab=28593')
                add_posts({'title' : 'The Cube',}, index, mode='newznab&newznab=23626',thumb='http://thetvdb.com/banners/posters/110861-1.jpg')
                add_posts({'title' : 'The Dales',}, index, mode='newznab&newznab=27796',thumb='http://thetvdb.com/banners/posters/247976-1.jpg')
                add_posts({'title' : 'The Darling Buds Of May',}, index, mode='newznab&newznab=5716',thumb='http://thetvdb.com/banners/posters/76306-1.jpg')
                add_posts({'title' : 'The Fugitive',}, index, mode='newznab&newznab=5798')
                add_posts({'title' : 'The Great British Taste Tour',}, index, mode='newznab&newznab=31214',thumb='http://thetvdb.com/banners/posters/258008-1.jpg')
                add_posts({'title' : 'The Jonathan Ross Show',}, index, mode='newznab&newznab=29282',thumb='http://thetvdb.com/banners/posters/251527-1.jpg')
                add_posts({'title' : 'The Krypton Factor 2009',}, index, mode='newznab&newznab=20772')
                add_posts({'title' : 'The Lakes 2010',}, index, mode='newznab&newznab=24626')
                add_posts({'title' : 'The Last Weekend',}, index, mode='newznab&newznab=32442',thumb='http://thetvdb.com/banners/posters/261674-1.jpg')
                add_posts({'title' : 'The Martin Lewis Money Show',}, index, mode='newznab&newznab=32798',thumb='http://thetvdb.com/banners/posters/262788-1.jpg')
                add_posts({'title' : 'The Mighty Mississippi with Trevor McDonald',}, index, mode='newznab&newznab=31240')
                add_posts({'title' : 'The New Avengers',}, index, mode='newznab&newznab=6026',thumb='http://thetvdb.com/banners/posters/76360-1.jpg')
                add_posts({'title' : 'The Poison Tree',}, index, mode='newznab&newznab=33565',thumb='http://thetvdb.com/banners/posters/264796-1.jpg')
                add_posts({'title' : 'The Real Thumbelina',}, index, mode='newznab&newznab=30223')
                add_posts({'title' : 'The Royal',}, index, mode='newznab&newznab=6152',thumb='http://thetvdb.com/banners/posters/72038-1.jpg')
                add_posts({'title' : 'The Scapegoat',}, index, mode='newznab&newznab=32633')
                add_posts({'title' : 'The Secret Mediterranean With Trevor McDonald',}, index, mode='newznab&newznab=27137',thumb='http://thetvdb.com/banners/posters/226291-1.jpg')
                add_posts({'title' : 'The Town',}, index, mode='newznab&newznab=33516',thumb='http://thetvdb.com/banners/posters/264656-1.jpg')
                add_posts({'title' : 'The Vice',}, index, mode='newznab&newznab=6272',thumb='http://thetvdb.com/banners/posters/76819-1.jpg')
                add_posts({'title' : 'The X Factor UK',}, index, mode='newznab&newznab=6313')
                add_posts({'title' : 'The Zoo UK',}, index, mode='newznab&newznab=26849',thumb='http://thetvdb.com/banners/posters/238861-1.jpg')
                add_posts({'title' : 'Titanic 2012',}, index, mode='newznab&newznab=31070')
                add_posts({'title' : 'Trash To Treasure',}, index, mode='newznab&newznab=31633')
                add_posts({'title' : 'Trial and Retribution',}, index, mode='newznab&newznab=6421',thumb='http://thetvdb.com/banners/posters/72382-1.jpg')
                add_posts({'title' : 'Van der Valk',}, index, mode='newznab&newznab=6498',thumb='http://thetvdb.com/banners/posters/78290-1.jpg')
                add_posts({'title' : 'Vera',}, index, mode='newznab&newznab=28144',thumb='http://thetvdb.com/banners/posters/248393-1.jpg')
                add_posts({'title' : 'Whitechapel',}, index, mode='newznab&newznab=21527',thumb='http://thetvdb.com/banners/posters/84926-1.jpg')
                add_posts({'title' : 'Wild At Heart',}, index, mode='newznab&newznab=7975',thumb='http://thetvdb.com/banners/posters/81390-1.jpg')
                add_posts({'title' : 'Wild Britain With Ray Mears',}, index, mode='newznab&newznab=26724',thumb='http://thetvdb.com/banners/posters/197171-1.jpg')
                add_posts({'title' : 'Wish Me Luck',}, index, mode='newznab&newznab=7861',thumb='http://thetvdb.com/banners/posters/135121-1.jpg')
                add_posts({'title' : 'Without You',}, index, mode='newznab&newznab=30173',thumb='http://thetvdb.com/banners/posters/254215-1.jpg')
                add_posts({'title' : 'Youve Been Framed',}, index, mode='newznab&newznab=7318',thumb='http://thetvdb.com/banners/posters/71560-1.jpg')
            if newznab_id == 'ITV2':
                add_posts({'title' : 'Britains Got More Talent',}, index, mode='newznab&newznab=16431',thumb='http://thetvdb.com/banners/posters/83497-1.jpg')
                add_posts({'title' : 'Celebrity Juice',}, index, mode='newznab&newznab=20089',thumb='http://thetvdb.com/banners/posters/84041-1.jpg')
                add_posts({'title' : 'Fearne And',}, index, mode='newznab&newznab=24139',thumb='http://thetvdb.com/banners/posters/262011-1.jpg')
                add_posts({'title' : 'Im A Celebrity Get Me Out Of Here UK',}, index, mode='newznab&newznab=20610')
                add_posts({'title' : 'Kerry Katona The Next Chapter',}, index, mode='newznab&newznab=26964')
                add_posts({'title' : 'Lemon La Vida Loca',}, index, mode='newznab&newznab=32279',thumb='http://thetvdb.com/banners/posters/261183-1.jpg')
                add_posts({'title' : 'Olly Life On Murs',}, index, mode='newznab&newznab=31283')
                add_posts({'title' : 'OMG With Peaches Geldof',}, index, mode='newznab&newznab=27628')
                add_posts({'title' : 'Perez Hilton Superfan',}, index, mode='newznab&newznab=30172',thumb='http://thetvdb.com/banners/posters/255222-1.jpg')
                add_posts({'title' : 'Peter Andre Here 2 Help',}, index, mode='newznab&newznab=28885')
                add_posts({'title' : 'Peter Andre My Life',}, index, mode='newznab&newznab=29738')
                add_posts({'title' : 'Peter Andre The Next Chapter',}, index, mode='newznab&newznab=23912',thumb='http://thetvdb.com/banners/posters/124141-1.jpg')
                add_posts({'title' : 'Secret Diary of a Call Girl',}, index, mode='newznab&newznab=17378',thumb='http://thetvdb.com/banners/posters/80621-1.jpg')
                add_posts({'title' : 'Switch UK',}, index, mode='newznab&newznab=33015')
                add_posts({'title' : 'The Only Way Is Essex',}, index, mode='newznab&newznab=26727',thumb='http://thetvdb.com/banners/posters/196981-1.jpg')
                add_posts({'title' : 'The Xtra Factor',}, index, mode='newznab&newznab=12949',thumb='http://thetvdb.com/banners/posters/75567-1.jpg')
                add_posts({'title' : 'Totally Bonkers Guinness World Records',}, index, mode='newznab&newznab=31011',thumb='http://thetvdb.com/banners/posters/257616-1.jpg')
                add_posts({'title' : 'Under Pressure',}, index, mode='newznab&newznab=27513')
            if newznab_id == 'ITV4':
                add_posts({'title' : 'Freddie Flintoff Versus The World',}, index, mode='newznab&newznab=27506')
                add_posts({'title' : 'Jean Claude Van Damme Behind Closed Doors',}, index, mode='newznab&newznab=27759',thumb='http://thetvdb.com/banners/posters/243271-1.jpg')
            if newznab_id == 'Kanal 5':
                add_posts({'title' : 'arga snickaren',}, index, mode='newznab&newznab=21880',thumb='http://thetvdb.com/banners/posters/84600-1.jpg')
                add_posts({'title' : 'roast pa berns',}, index, mode='newznab&newznab=23889',thumb='http://thetvdb.com/banners/posters/112731-1.jpg')
                add_posts({'title' : 'tunnelbanan',}, index, mode='newznab&newznab=30728',thumb='http://thetvdb.com/banners/posters/255533-1.jpg')
                add_posts({'title' : 'vem kan sla filip och fredrik',}, index, mode='newznab&newznab=20059',thumb='http://thetvdb.com/banners/posters/82996-1.jpg')
            if newznab_id == 'Kanal D':
                add_posts({'title' : 'Yalan Dunya',}, index, mode='newznab&newznab=33304',thumb='http://thetvdb.com/banners/posters/255983-1.jpg')
            if newznab_id == 'Lifestyle Channel':
                add_posts({'title' : 'Bargain Hunt AU',}, index, mode='newznab&newznab=30620',thumb='http://thetvdb.com/banners/posters/254425-1.jpg')
                add_posts({'title' : 'Grand Designs Australia',}, index, mode='newznab&newznab=26898',thumb='http://thetvdb.com/banners/posters/196901-1.jpg')
                add_posts({'title' : 'Relocation Relocation Australia',}, index, mode='newznab&newznab=30347',thumb='http://thetvdb.com/banners/posters/252272-1.jpg')
            if newznab_id == 'Lifetime':
                add_posts({'title' : 'After the Runway',}, index, mode='newznab&newznab=29707')
                add_posts({'title' : 'Against the Wall',}, index, mode='newznab&newznab=28761',thumb='http://thetvdb.com/banners/posters/249881-1.jpg')
                add_posts({'title' : 'Americas Most Wanted',}, index, mode='newznab&newznab=2588',thumb='http://thetvdb.com/banners/posters/74943-1.jpg')
                add_posts({'title' : 'Army Wives',}, index, mode='newznab&newznab=15594',thumb='http://thetvdb.com/banners/posters/80231-1.jpg')
                add_posts({'title' : 'Dance Moms',}, index, mode='newznab&newznab=28444',thumb='http://thetvdb.com/banners/posters/250379-1.jpg')
                add_posts({'title' : 'Drop Dead Diva',}, index, mode='newznab&newznab=21886',thumb='http://thetvdb.com/banners/posters/95771-1.jpg')
                add_posts({'title' : 'Picker Sisters',}, index, mode='newznab&newznab=29040',thumb='http://thetvdb.com/banners/posters/250511-1.jpg')
                add_posts({'title' : 'Project Accessory',}, index, mode='newznab&newznab=28769',thumb='http://thetvdb.com/banners/posters/252577-1.jpg')
                add_posts({'title' : 'Project Runaway All Stars',}, index, mode='newznab&newznab=28767')
                add_posts({'title' : 'Project Runway All Stars',}, index, mode='newznab&newznab=28767')
                add_posts({'title' : 'Project Runway Allstars',}, index, mode='newznab&newznab=28767')
                add_posts({'title' : 'Project Runway',}, index, mode='newznab&newznab=4903',thumb='http://thetvdb.com/banners/posters/74285-1.jpg')
                add_posts({'title' : 'Roseannes Nuts',}, index, mode='newznab&newznab=28686',thumb='http://thetvdb.com/banners/posters/250221-1.jpg')
                add_posts({'title' : 'Russian Dolls',}, index, mode='newznab&newznab=28442',thumb='http://thetvdb.com/banners/posters/250959-1.jpg')
                add_posts({'title' : 'Seriously Funny Kids',}, index, mode='newznab&newznab=27546')
                add_posts({'title' : 'The Client List',}, index, mode='newznab&newznab=29471',thumb='http://thetvdb.com/banners/posters/255266-1.jpg')
                add_posts({'title' : 'The Protector',}, index, mode='newznab&newznab=28572',thumb='http://thetvdb.com/banners/posters/248929-1.jpg')
            if newznab_id == 'Logo':
                add_posts({'title' : 'Rick and Steve The Happiest Gay Couple In All The World',}, index, mode='newznab&newznab=20727',thumb='http://thetvdb.com/banners/posters/80520-1.jpg')
                add_posts({'title' : 'Rick and Steve The Happiest Gay Couple in the World',}, index, mode='newznab&newznab=20727',thumb='http://thetvdb.com/banners/posters/80520-1.jpg')
                add_posts({'title' : 'RuPauls Drag Race Untucked',}, index, mode='newznab&newznab=27244',thumb='http://thetvdb.com/banners/posters/142501-1.jpg')
                add_posts({'title' : 'RuPauls Drag Race',}, index, mode='newznab&newznab=21652',thumb='http://thetvdb.com/banners/posters/85002-1.jpg')
                add_posts({'title' : 'RuPauls Drag U',}, index, mode='newznab&newznab=24975',thumb='http://thetvdb.com/banners/posters/178221-1.jpg')
                add_posts({'title' : 'Sordid Lives The Series',}, index, mode='newznab&newznab=18775',thumb='http://thetvdb.com/banners/posters/84503-1.jpg')
                add_posts({'title' : 'The Big Gay Sketch Show',}, index, mode='newznab&newznab=15332',thumb='http://thetvdb.com/banners/posters/80286-1.jpg')
            if newznab_id == 'M Net':
                add_posts({'title' : 'Survivor SA',}, index, mode='newznab&newznab=25451')
            if newznab_id == 'Machinima':
                add_posts({'title' : 'Halo 4 Forward Unto Dawn',}, index, mode='newznab&newznab=33353',thumb='http://thetvdb.com/banners/posters/260715-1.jpg')
            if newznab_id == 'Machinima com':
                add_posts({'title' : 'Battlestar Galactica Blood And Chrome',}, index, mode='newznab&newznab=26832',thumb='http://thetvdb.com/banners/posters/204781-1.jpg')
            if newznab_id == 'MBC':
                add_posts({'title' : 'Over the Rainbow CA',}, index, mode='newznab&newznab=14609')
                add_posts({'title' : 'The Next',}, index, mode='newznab&newznab=14283',thumb='http://thetvdb.com/banners/posters/260495-1.jpg')
            if newznab_id == 'MBS':
                add_posts({'title' : 'Darker Than Black',}, index, mode='newznab&newznab=15491',thumb='http://thetvdb.com/banners/posters/80042-1.jpg')
                add_posts({'title' : 'Xam d Lost Memories',}, index, mode='newznab&newznab=19820',thumb='http://thetvdb.com/banners/posters/82834-1.jpg')
            if newznab_id == 'Military Channel':
                add_posts({'title' : 'Missions That Changed The War',}, index, mode='newznab&newznab=27777',thumb='http://thetvdb.com/banners/posters/249713-1.jpg')
                add_posts({'title' : 'Nazi Collaborators',}, index, mode='newznab&newznab=29705',thumb='http://thetvdb.com/banners/posters/207641-1.jpg')
            if newznab_id == 'MOJO':
                add_posts({'title' : 'Beer Nutz',}, index, mode='newznab&newznab=14812',thumb='http://thetvdb.com/banners/posters/80627-1.jpg')
            if newznab_id == 'Movie Central':
                add_posts({'title' : 'Durham County',}, index, mode='newznab&newznab=15660',thumb='http://thetvdb.com/banners/posters/80144-1.jpg')
            if newznab_id == 'Movie Extra':
                add_posts({'title' : 'Small Time Gangster',}, index, mode='newznab&newznab=27927',thumb='http://thetvdb.com/banners/posters/247311-1.jpg')
                add_posts({'title' : 'The Jesters',}, index, mode='newznab&newznab=23978',thumb='http://thetvdb.com/banners/posters/110881-1.jpg')
            if newznab_id == 'MSNBC':
                add_posts({'title' : 'The Squeeze',}, index, mode='newznab&newznab=24715',thumb='http://thetvdb.com/banners/posters/132471-1.jpg')
            if newznab_id == 'MTV':
                add_posts({'title' : '16 and Pregnant',}, index, mode='newznab&newznab=22842')
                add_posts({'title' : 'adventures in hollyhood',}, index, mode='newznab&newznab=15438',thumb='http://thetvdb.com/banners/posters/83786-1.jpg')
                add_posts({'title' : 'Apartment 23',}, index, mode='newznab&newznab=8406')
                add_posts({'title' : 'Awkward',}, index, mode='newznab&newznab=28691',thumb='http://thetvdb.com/banners/posters/249882-1.jpg')
                add_posts({'title' : 'Beavis and Butt Head',}, index, mode='newznab&newznab=2746',thumb='http://thetvdb.com/banners/posters/75863-1.jpg')
                add_posts({'title' : 'Beavis And Butthead',}, index, mode='newznab&newznab=2746',thumb='http://thetvdb.com/banners/posters/75863-1.jpg')
                add_posts({'title' : 'Caged',}, index, mode='newznab&newznab=30519',thumb='http://thetvdb.com/banners/posters/254691-1.jpg')
                add_posts({'title' : 'Catfish The TV Show',}, index, mode='newznab&newznab=32713',thumb='http://thetvdb.com/banners/posters/262754-1.jpg')
                add_posts({'title' : 'Chelsea Settles',}, index, mode='newznab&newznab=29426',thumb='http://thetvdb.com/banners/posters/252733-1.jpg')
                add_posts({'title' : 'Death Valley',}, index, mode='newznab&newznab=28446',thumb='http://thetvdb.com/banners/posters/249905-1.jpg')
                add_posts({'title' : 'Disaster Date',}, index, mode='newznab&newznab=23932',thumb='http://thetvdb.com/banners/posters/250462-1.jpg')
                add_posts({'title' : 'Geordie Shore',}, index, mode='newznab&newznab=28512',thumb='http://thetvdb.com/banners/posters/248683-1.jpg')
                add_posts({'title' : 'Good Vibes',}, index, mode='newznab&newznab=29433',thumb='http://thetvdb.com/banners/posters/252969-1.jpg')
                add_posts({'title' : 'I Just Want My Pants Back',}, index, mode='newznab&newznab=28460',thumb='http://thetvdb.com/banners/posters/251406-1.jpg')
                add_posts({'title' : 'I Used To Be Fat',}, index, mode='newznab&newznab=27118',thumb='http://thetvdb.com/banners/posters/226341-1.jpg')
                add_posts({'title' : 'Jersey Shore',}, index, mode='newznab&newznab=24425',thumb='http://thetvdb.com/banners/posters/127351-1.jpg')
                add_posts({'title' : 'Money From Strangers',}, index, mode='newznab&newznab=31591',thumb='http://thetvdb.com/banners/posters/258349-1.jpg')
                add_posts({'title' : 'my life as liz',}, index, mode='newznab&newznab=24790',thumb='http://thetvdb.com/banners/posters/142911-1.jpg')
                add_posts({'title' : 'Pimp My Ride',}, index, mode='newznab&newznab=4829',thumb='http://thetvdb.com/banners/posters/74210-1.jpg')
                add_posts({'title' : 'Pranked',}, index, mode='newznab&newznab=23518',thumb='http://thetvdb.com/banners/posters/111091-1.jpg')
                add_posts({'title' : 'Punk d',}, index, mode='newznab&newznab=4914',thumb='http://thetvdb.com/banners/posters/72268-1.jpg')
                add_posts({'title' : 'Randy Jackson Presents Americas Best Dance Crew',}, index, mode='newznab&newznab=18366',thumb='http://thetvdb.com/banners/posters/81659-1.jpg')
                add_posts({'title' : 'Ridiculousness',}, index, mode='newznab&newznab=27731',thumb='http://thetvdb.com/banners/posters/250793-1.jpg')
                add_posts({'title' : 'Rob and Big',}, index, mode='newznab&newznab=14535',thumb='http://thetvdb.com/banners/posters/80193-1.jpg')
                add_posts({'title' : 'Rob Dyrdeks Fantasy Factory',}, index, mode='newznab&newznab=21695',thumb='http://thetvdb.com/banners/posters/85038-1.jpg')
                add_posts({'title' : 'Savage U',}, index, mode='newznab&newznab=31359',thumb='http://thetvdb.com/banners/posters/257445-1.jpg')
                add_posts({'title' : 'Skins US',}, index, mode='newznab&newznab=25843',thumb='http://thetvdb.com/banners/posters/174991-1.jpg')
                add_posts({'title' : 'Snooki And JWOWW',}, index, mode='newznab&newznab=31527')
                add_posts({'title' : 'Son of a Gun',}, index, mode='newznab&newznab=27969',thumb='http://thetvdb.com/banners/posters/227571-1.jpg')
                add_posts({'title' : 'Teen Mom 2',}, index, mode='newznab&newznab=27391',thumb='http://thetvdb.com/banners/posters/221141-1.jpg')
                add_posts({'title' : 'Teen Mom',}, index, mode='newznab&newznab=24465',thumb='http://thetvdb.com/banners/posters/148561-1.jpg')
                add_posts({'title' : 'Teen Wolf',}, index, mode='newznab&newznab=27575',thumb='http://thetvdb.com/banners/posters/175001-1.jpg')
                add_posts({'title' : 'The Challenge',}, index, mode='newznab&newznab=6126',thumb='http://thetvdb.com/banners/posters/70870-1.jpg')
                add_posts({'title' : 'The Electric Barbarellas',}, index, mode='newznab&newznab=28256')
                add_posts({'title' : 'The Hard Times of RJ Berger',}, index, mode='newznab&newznab=23450',thumb='http://thetvdb.com/banners/posters/165851-1.jpg')
                add_posts({'title' : 'The Hills',}, index, mode='newznab&newznab=6890',thumb='http://thetvdb.com/banners/posters/79550-1.jpg')
                add_posts({'title' : 'The Inbetweeners US',}, index, mode='newznab&newznab=32126',thumb='http://thetvdb.com/banners/posters/260189-1.jpg')
                add_posts({'title' : 'The Osbournes',}, index, mode='newznab&newznab=6065',thumb='http://thetvdb.com/banners/posters/78379-1.jpg')
                add_posts({'title' : 'The Pauly D Project',}, index, mode='newznab&newznab=30878',thumb='http://thetvdb.com/banners/posters/257491-1.jpg')
                add_posts({'title' : 'The Real World',}, index, mode='newznab&newznab=6125',thumb='http://thetvdb.com/banners/posters/76522-1.jpg')
                add_posts({'title' : 'The Substitute',}, index, mode='newznab&newznab=29448')
                add_posts({'title' : 'This Is How I Made It',}, index, mode='newznab&newznab=31197',thumb='http://thetvdb.com/banners/posters/262965-1.jpg')
                add_posts({'title' : 'Totally Clueless',}, index, mode='newznab&newznab=33240',thumb='http://thetvdb.com/banners/posters/263632-1.jpg')
                add_posts({'title' : 'Underemployed',}, index, mode='newznab&newznab=32459',thumb='http://thetvdb.com/banners/posters/261832-1.jpg')
                add_posts({'title' : 'Wake Brothers',}, index, mode='newznab&newznab=32335')
                add_posts({'title' : 'When I Was 17',}, index, mode='newznab&newznab=25552',thumb='http://thetvdb.com/banners/posters/187651-1.jpg')
            if newznab_id == 'MTV One':
                add_posts({'title' : 'Dirty Sanchez',}, index, mode='newznab&newznab=2116',thumb='http://thetvdb.com/banners/posters/79165-1.jpg')
            if newznab_id == 'MTV UK':
                add_posts({'title' : 'The Valleys',}, index, mode='newznab&newznab=33430',thumb='http://thetvdb.com/banners/posters/262765-1.jpg')
            if newznab_id == 'MTV2':
                add_posts({'title' : 'Crank Yankers',}, index, mode='newznab&newznab=583',thumb='http://thetvdb.com/banners/posters/79009-1.jpg')
                add_posts({'title' : 'Lucha Libre USA Masked Warriors',}, index, mode='newznab&newznab=26183',thumb='http://thetvdb.com/banners/posters/260358-1.jpg')
                add_posts({'title' : 'nitro circus',}, index, mode='newznab&newznab=21698',thumb='http://thetvdb.com/banners/posters/85031-1.jpg')
                add_posts({'title' : 'The Andy Milonakis Show',}, index, mode='newznab&newznab=5575',thumb='http://thetvdb.com/banners/posters/76086-1.jpg')
            if newznab_id == 'MuchMusic':
                add_posts({'title' : 'Degrassi',}, index, mode='newznab&newznab=3275',thumb='http://thetvdb.com/banners/posters/77733-1.jpg')
                add_posts({'title' : 'The L A Complex',}, index, mode='newznab&newznab=30411',thumb='http://thetvdb.com/banners/posters/255045-1.jpg')
                add_posts({'title' : 'The LA Complex',}, index, mode='newznab&newznab=30411',thumb='http://thetvdb.com/banners/posters/255045-1.jpg')
            if newznab_id == 'National Geographic Channel':
                add_posts({'title' : 'Abandoned',}, index, mode='newznab&newznab=32488',thumb='http://thetvdb.com/banners/posters/261380-1.jpg')
                add_posts({'title' : 'Alaska State Troopers',}, index, mode='newznab&newznab=24000',thumb='http://thetvdb.com/banners/posters/122511-1.jpg')
                add_posts({'title' : 'Alaska Wing Men',}, index, mode='newznab&newznab=27312',thumb='http://thetvdb.com/banners/posters/221261-1.jpg')
                add_posts({'title' : 'Alien Deep With Bob Ballard',}, index, mode='newznab&newznab=32545',thumb='http://thetvdb.com/banners/posters/262429-1.jpg')
                add_posts({'title' : 'American Chainsaw',}, index, mode='newznab&newznab=33047',thumb='http://thetvdb.com/banners/posters/264208-1.jpg')
                add_posts({'title' : 'American Colony Meet the Hutterites',}, index, mode='newznab&newznab=32127',thumb='http://thetvdb.com/banners/posters/259064-1.jpg')
                add_posts({'title' : 'American Weed',}, index, mode='newznab&newznab=30426',thumb='http://thetvdb.com/banners/posters/255920-1.jpg')
                add_posts({'title' : 'Amish Out of Order',}, index, mode='newznab&newznab=31397',thumb='http://thetvdb.com/banners/posters/258525-1.jpg')
                add_posts({'title' : 'Ancient X Files',}, index, mode='newznab&newznab=28346',thumb='http://thetvdb.com/banners/posters/214961-1.jpg')
                add_posts({'title' : 'Australian Pirate Patrol',}, index, mode='newznab&newznab=27309',thumb='http://thetvdb.com/banners/posters/199351-1.jpg')
                add_posts({'title' : 'Beast Hunter',}, index, mode='newznab&newznab=27660',thumb='http://thetvdb.com/banners/posters/231911-1.jpg')
                add_posts({'title' : 'Beyond The Cosmos',}, index, mode='newznab&newznab=31751',thumb='http://thetvdb.com/banners/posters/257422-1.jpg')
                add_posts({'title' : 'Big Bigger Biggest',}, index, mode='newznab&newznab=18690',thumb='http://thetvdb.com/banners/posters/81863-1.jpg')
                add_posts({'title' : 'Border Wars',}, index, mode='newznab&newznab=24777',thumb='http://thetvdb.com/banners/posters/134381-1.jpg')
                add_posts({'title' : 'Break It Down',}, index, mode='newznab&newznab=26172',thumb='http://thetvdb.com/banners/posters/179711-1.jpg')
                add_posts({'title' : 'Breakout',}, index, mode='newznab&newznab=25227',thumb='http://thetvdb.com/banners/posters/144311-1.jpg')
                add_posts({'title' : 'CIA Confidential',}, index, mode='newznab&newznab=29418',thumb='http://thetvdb.com/banners/posters/222681-1.jpg')
                add_posts({'title' : 'Cocaine Wars',}, index, mode='newznab&newznab=33134',thumb='http://thetvdb.com/banners/posters/263550-1.jpg')
                add_posts({'title' : 'Critical Situation',}, index, mode='newznab&newznab=16461')
                add_posts({'title' : 'Doomsday Preppers Bugged Out',}, index, mode='newznab&newznab=33208',thumb='http://thetvdb.com/banners/posters/264072-1.jpg')
                add_posts({'title' : 'Doomsday Preppers',}, index, mode='newznab&newznab=30544',thumb='http://thetvdb.com/banners/posters/255608-1.jpg')
                add_posts({'title' : 'Drugged',}, index, mode='newznab&newznab=27433',thumb='http://thetvdb.com/banners/posters/240301-1.jpg')
                add_posts({'title' : 'Drugs Inc',}, index, mode='newznab&newznab=25909',thumb='http://thetvdb.com/banners/posters/174501-1.jpg')
                add_posts({'title' : 'Family Guns',}, index, mode='newznab&newznab=32535',thumb='http://thetvdb.com/banners/posters/261979-1.jpg')
                add_posts({'title' : 'Fish Warrior',}, index, mode='newznab&newznab=26177',thumb='http://thetvdb.com/banners/posters/179041-1.jpg')
                add_posts({'title' : 'Frontier Force',}, index, mode='newznab&newznab=29298',thumb='http://thetvdb.com/banners/posters/251839-1.jpg')
                add_posts({'title' : 'Hard Time',}, index, mode='newznab&newznab=21565',thumb='http://thetvdb.com/banners/posters/228041-1.jpg')
                add_posts({'title' : 'Hell On The Highway',}, index, mode='newznab&newznab=33024',thumb='http://thetvdb.com/banners/posters/264131-1.jpg')
                add_posts({'title' : 'How It Was',}, index, mode='newznab&newznab=18578')
                add_posts({'title' : 'Is It Real',}, index, mode='newznab&newznab=14691',thumb='http://thetvdb.com/banners/posters/79630-1.jpg')
                add_posts({'title' : 'Jurassic CSI',}, index, mode='newznab&newznab=29113',thumb='http://thetvdb.com/banners/posters/253030-1.jpg')
                add_posts({'title' : 'Known Universe',}, index, mode='newznab&newznab=21856',thumb='http://thetvdb.com/banners/posters/92361-1.jpg')
                add_posts({'title' : 'Lockdown',}, index, mode='newznab&newznab=17338')
                add_posts({'title' : 'Locked Up Abroad',}, index, mode='newznab&newznab=17091',thumb='http://thetvdb.com/banners/posters/84014-1.jpg')
                add_posts({'title' : 'Mad Scientists',}, index, mode='newznab&newznab=29335',thumb='http://thetvdb.com/banners/posters/252126-1.jpg')
                add_posts({'title' : 'Making History',}, index, mode='newznab&newznab=26745',thumb='http://thetvdb.com/banners/posters/193611-1.jpg')
                add_posts({'title' : 'Megastructures US',}, index, mode='newznab&newznab=6968')
                add_posts({'title' : 'Monster Fish',}, index, mode='newznab&newznab=26043',thumb='http://thetvdb.com/banners/posters/178681-1.jpg')
                add_posts({'title' : 'Monster Moves',}, index, mode='newznab&newznab=23872',thumb='http://thetvdb.com/banners/posters/93681-1.jpg')
                add_posts({'title' : 'Mudcats',}, index, mode='newznab&newznab=30904',thumb='http://thetvdb.com/banners/posters/256385-1.jpg')
                add_posts({'title' : 'Naked Science',}, index, mode='newznab&newznab=2288',thumb='http://thetvdb.com/banners/posters/262992-1.jpg')
                add_posts({'title' : 'National Geographic Explorer',}, index, mode='newznab&newznab=1306')
                add_posts({'title' : 'Navajo Cops',}, index, mode='newznab&newznab=31127',thumb='http://thetvdb.com/banners/posters/257413-1.jpg')
                add_posts({'title' : 'Nazi Hunters',}, index, mode='newznab&newznab=27075',thumb='http://thetvdb.com/banners/posters/158211-1.jpg')
                add_posts({'title' : 'Pricing The Priceless',}, index, mode='newznab&newznab=29977',thumb='http://thetvdb.com/banners/posters/251450-1.jpg')
                add_posts({'title' : 'Prison Women',}, index, mode='newznab&newznab=27435')
                add_posts({'title' : 'Repossessed',}, index, mode='newznab&newznab=23283')
                add_posts({'title' : 'Rock Stars',}, index, mode='newznab&newznab=29769',thumb='http://thetvdb.com/banners/posters/254166-1.jpg')
                add_posts({'title' : 'Rocket City Rednecks',}, index, mode='newznab&newznab=29334',thumb='http://thetvdb.com/banners/posters/251955-1.jpg')
                add_posts({'title' : 'Scam City',}, index, mode='newznab&newznab=33579',thumb='http://thetvdb.com/banners/posters/263599-1.jpg')
                add_posts({'title' : 'Seconds from Disaster',}, index, mode='newznab&newznab=10255',thumb='http://thetvdb.com/banners/posters/79772-1.jpg')
                add_posts({'title' : 'Secret Service Files',}, index, mode='newznab&newznab=27436',thumb='http://thetvdb.com/banners/posters/233821-1.jpg')
                add_posts({'title' : 'Taboo',}, index, mode='newznab&newznab=17035',thumb='http://thetvdb.com/banners/posters/71985-1.jpg')
                add_posts({'title' : 'The Truth Behind',}, index, mode='newznab&newznab=29986',thumb='http://thetvdb.com/banners/posters/253523-1.jpg')
                add_posts({'title' : 'The Witch Doctor Will See You Now',}, index, mode='newznab&newznab=29354',thumb='http://thetvdb.com/banners/posters/253417-1.jpg')
                add_posts({'title' : 'Ultimate Factories',}, index, mode='newznab&newznab=17934',thumb='http://thetvdb.com/banners/posters/82374-1.jpg')
                add_posts({'title' : 'Weird Or What',}, index, mode='newznab&newznab=25493',thumb='http://thetvdb.com/banners/posters/158831-1.jpg')
                add_posts({'title' : 'When Rome Ruled',}, index, mode='newznab&newznab=27073',thumb='http://thetvdb.com/banners/posters/212461-1.jpg')
                add_posts({'title' : 'Wicked Tuna',}, index, mode='newznab&newznab=31233',thumb='http://thetvdb.com/banners/posters/257494-1.jpg')
                add_posts({'title' : 'Wild Justice',}, index, mode='newznab&newznab=27000',thumb='http://thetvdb.com/banners/posters/210301-1.jpg')
                add_posts({'title' : 'Worlds Toughest Fixes',}, index, mode='newznab&newznab=20191',thumb='http://thetvdb.com/banners/posters/90771-1.jpg')
            if newznab_id == 'National Geographic Channel Canada':
                add_posts({'title' : 'Air Crash Investigation',}, index, mode='newznab&newznab=10188')
            if newznab_id == 'National Geographic Wild':
                add_posts({'title' : 'Animal Mega Moves',}, index, mode='newznab&newznab=28068')
                add_posts({'title' : 'Big Cat Week',}, index, mode='newznab&newznab=27040',thumb='http://thetvdb.com/banners/posters/82069-1.jpg')
                add_posts({'title' : 'Blue Collar Dogs',}, index, mode='newznab&newznab=27337')
                add_posts({'title' : 'Cameramen Who Dare',}, index, mode='newznab&newznab=27262')
                add_posts({'title' : 'Dangerous Encounters',}, index, mode='newznab&newznab=18257',thumb='http://thetvdb.com/banners/posters/139051-1.jpg')
                add_posts({'title' : 'Live Like An Animal',}, index, mode='newznab&newznab=30525')
                add_posts({'title' : 'Man V Monster',}, index, mode='newznab&newznab=28287',thumb='http://thetvdb.com/banners/posters/258890-1.jpg')
                add_posts({'title' : 'Maneater Manhunt',}, index, mode='newznab&newznab=29932',thumb='http://thetvdb.com/banners/posters/259542-1.jpg')
                add_posts({'title' : 'My Life Is A Zoo',}, index, mode='newznab&newznab=25372',thumb='http://thetvdb.com/banners/posters/218101-1.jpg')
                add_posts({'title' : 'Philly Undercover',}, index, mode='newznab&newznab=29933',thumb='http://thetvdb.com/banners/posters/255692-1.jpg')
                add_posts({'title' : 'The Incredible Dr Pol',}, index, mode='newznab&newznab=29767',thumb='http://thetvdb.com/banners/posters/258118-1.jpg')
                add_posts({'title' : 'The Lion Ranger',}, index, mode='newznab&newznab=26260',thumb='http://thetvdb.com/banners/posters/250578-1.jpg')
                add_posts({'title' : 'Untamed Americas',}, index, mode='newznab&newznab=31859',thumb='http://thetvdb.com/banners/posters/260040-1.jpg')
                add_posts({'title' : 'Wild Mississippi',}, index, mode='newznab&newznab=30638',thumb='http://thetvdb.com/banners/posters/259308-1.jpg')
            if newznab_id == 'NBC':
                add_posts({'title' : '1600 Penn',}, index, mode='newznab&newznab=30983',thumb='http://thetvdb.com/banners/posters/259016-1.jpg')
                add_posts({'title' : '30 Rock',}, index, mode='newznab&newznab=11215',thumb='http://thetvdb.com/banners/posters/79488-1.jpg')
                add_posts({'title' : '3rd Rock from the Sun',}, index, mode='newznab&newznab=2454',thumb='http://thetvdb.com/banners/posters/72389-1.jpg')
                add_posts({'title' : 'Americas Got Talent',}, index, mode='newznab&newznab=10408',thumb='http://thetvdb.com/banners/posters/79490-1.jpg')
                add_posts({'title' : 'Americas Next Great Restaurant',}, index, mode='newznab&newznab=25748',thumb='http://thetvdb.com/banners/posters/211151-1.jpg')
                add_posts({'title' : 'Animal Practice',}, index, mode='newznab&newznab=30758',thumb='http://thetvdb.com/banners/posters/259069-1.jpg')
                add_posts({'title' : 'Are You There Chelsea',}, index, mode='newznab&newznab=28368',thumb='http://thetvdb.com/banners/posters/248813-1.jpg')
                add_posts({'title' : 'Awake',}, index, mode='newznab&newznab=28361',thumb='http://thetvdb.com/banners/posters/248735-1.jpg')
                add_posts({'title' : 'Bent',}, index, mode='newznab&newznab=28369',thumb='http://thetvdb.com/banners/posters/248950-1.jpg')
                add_posts({'title' : 'Best Friends Forever',}, index, mode='newznab&newznab=28370',thumb='http://thetvdb.com/banners/posters/248959-1.jpg')
                add_posts({'title' : 'Betty Whites Off Their Rockers',}, index, mode='newznab&newznab=27936',thumb='http://thetvdb.com/banners/posters/253273-1.jpg')
                add_posts({'title' : 'Black Sheep Squadron',}, index, mode='newznab&newznab=2819',thumb='http://thetvdb.com/banners/posters/77912-1.jpg')
                add_posts({'title' : 'Boomtown',}, index, mode='newznab&newznab=2874',thumb='http://thetvdb.com/banners/posters/78619-1.jpg')
                add_posts({'title' : 'California Dreams',}, index, mode='newznab&newznab=2958',thumb='http://thetvdb.com/banners/posters/74680-1.jpg')
                add_posts({'title' : 'Captain N And The New Super Mario World',}, index, mode='newznab&newznab=2977',thumb='http://thetvdb.com/banners/posters/78523-1.jpg')
                add_posts({'title' : 'Captain N The Game Master',}, index, mode='newznab&newznab=2976',thumb='http://thetvdb.com/banners/posters/76792-1.jpg')
                add_posts({'title' : 'Car 54 Where Are You',}, index, mode='newznab&newznab=2987',thumb='http://thetvdb.com/banners/posters/77869-1.jpg')
                add_posts({'title' : 'Caroline In The City',}, index, mode='newznab&newznab=2994',thumb='http://thetvdb.com/banners/posters/72345-1.jpg')
                add_posts({'title' : 'Chase 2010',}, index, mode='newznab&newznab=24635',thumb='http://thetvdb.com/banners/posters/163541-1.jpg')
                add_posts({'title' : 'Cheers',}, index, mode='newznab&newznab=3044',thumb='http://thetvdb.com/banners/posters/77623-1.jpg')
                add_posts({'title' : 'Chicago Fire',}, index, mode='newznab&newznab=30748',thumb='http://thetvdb.com/banners/posters/258541-1.jpg')
                add_posts({'title' : 'Chuck',}, index, mode='newznab&newznab=15614',thumb='http://thetvdb.com/banners/posters/80348-1.jpg')
                add_posts({'title' : 'Community',}, index, mode='newznab&newznab=22589',thumb='http://thetvdb.com/banners/posters/94571-1.jpg')
                add_posts({'title' : 'Crime Story',}, index, mode='newznab&newznab=3168',thumb='http://thetvdb.com/banners/posters/72619-1.jpg')
                add_posts({'title' : 'Crusoe',}, index, mode='newznab&newznab=18491',thumb='http://thetvdb.com/banners/posters/83226-1.jpg')
                add_posts({'title' : 'Days of Our Lives',}, index, mode='newznab&newznab=3256',thumb='http://thetvdb.com/banners/posters/70366-1.jpg')
                add_posts({'title' : 'Deadline',}, index, mode='newznab&newznab=3262',thumb='http://thetvdb.com/banners/posters/81699-1.jpg')
                add_posts({'title' : 'Deception',}, index, mode='newznab&newznab=31646',thumb='http://thetvdb.com/banners/posters/259087-1.jpg')
                add_posts({'title' : 'evolution 2012',}, index, mode='newznab&newznab=30897')
                add_posts({'title' : 'Fashion Star',}, index, mode='newznab&newznab=28373',thumb='http://thetvdb.com/banners/posters/253277-1.jpg')
                add_posts({'title' : 'Fear Factor US',}, index, mode='newznab&newznab=3533')
                add_posts({'title' : 'Frasier',}, index, mode='newznab&newznab=3597',thumb='http://thetvdb.com/banners/posters/77811-1.jpg')
                add_posts({'title' : 'Freaks and Geeks',}, index, mode='newznab&newznab=3601',thumb='http://thetvdb.com/banners/posters/76321-1.jpg')
                add_posts({'title' : 'Free Agents US',}, index, mode='newznab&newznab=28356',thumb='http://thetvdb.com/banners/posters/248942-1.jpg')
                add_posts({'title' : 'Friends With Benefits',}, index, mode='newznab&newznab=24665',thumb='http://thetvdb.com/banners/posters/163571-1.jpg')
                add_posts({'title' : 'Friends',}, index, mode='newznab&newznab=3616',thumb='http://thetvdb.com/banners/posters/79168-1.jpg')
                add_posts({'title' : 'Gimme A Break',}, index, mode='newznab&newznab=3684',thumb='http://thetvdb.com/banners/posters/77726-1.jpg')
                add_posts({'title' : 'Go On',}, index, mode='newznab&newznab=30756',thumb='http://thetvdb.com/banners/posters/258616-1.jpg')
                add_posts({'title' : 'Grimm',}, index, mode='newznab&newznab=28352',thumb='http://thetvdb.com/banners/posters/248736-1.jpg')
                add_posts({'title' : 'Guys With Kids',}, index, mode='newznab&newznab=31674',thumb='http://thetvdb.com/banners/posters/259070-1.jpg')
                add_posts({'title' : 'Harrys Law',}, index, mode='newznab&newznab=25720',thumb='http://thetvdb.com/banners/posters/163581-1.jpg')
                add_posts({'title' : 'Heroes',}, index, mode='newznab&newznab=8172',thumb='http://thetvdb.com/banners/posters/79501-1.jpg')
                add_posts({'title' : 'Highway To Heaven',}, index, mode='newznab&newznab=3860',thumb='http://thetvdb.com/banners/posters/76862-1.jpg')
                add_posts({'title' : 'Hill Street Blues',}, index, mode='newznab&newznab=3865',thumb='http://thetvdb.com/banners/posters/74449-1.jpg')
                add_posts({'title' : 'Homicide Life On The Street',}, index, mode='newznab&newznab=3889',thumb='http://thetvdb.com/banners/posters/70727-1.jpg')
                add_posts({'title' : 'Im And Celebrity Get Me Out Of Here UK',}, index, mode='newznab&newznab=791',thumb='http://thetvdb.com/banners/posters/71443-1.jpg')
                add_posts({'title' : 'Inch High Private Eye',}, index, mode='newznab&newznab=329',thumb='http://thetvdb.com/banners/posters/76211-1.jpg')
                add_posts({'title' : 'Ironside',}, index, mode='newznab&newznab=3995',thumb='http://thetvdb.com/banners/posters/78677-1.jpg')
                add_posts({'title' : 'Its Punky Brewster',}, index, mode='newznab&newznab=345',thumb='http://thetvdb.com/banners/posters/76281-1.jpg')
                add_posts({'title' : 'Its Worth What',}, index, mode='newznab&newznab=28409',thumb='http://thetvdb.com/banners/posters/250186-1.jpg')
                add_posts({'title' : 'Jim Hensons The Storyteller',}, index, mode='newznab&newznab=4053',thumb='http://thetvdb.com/banners/posters/77747-1.jpg')
                add_posts({'title' : 'Joey',}, index, mode='newznab&newznab=4061',thumb='http://thetvdb.com/banners/posters/72920-1.jpg')
                add_posts({'title' : 'Kings',}, index, mode='newznab&newznab=18685',thumb='http://thetvdb.com/banners/posters/84068-1.jpg')
                add_posts({'title' : 'L A Law',}, index, mode='newznab&newznab=4170',thumb='http://thetvdb.com/banners/posters/72419-1.jpg')
                add_posts({'title' : 'Laredo',}, index, mode='newznab&newznab=4182',thumb='http://thetvdb.com/banners/posters/76652-1.jpg')
                add_posts({'title' : 'Las Vegas',}, index, mode='newznab&newznab=4192',thumb='http://thetvdb.com/banners/posters/72229-1.jpg')
                add_posts({'title' : 'Law and Order Los Angeles',}, index, mode='newznab&newznab=25450',thumb='http://thetvdb.com/banners/posters/168161-1.jpg')
                add_posts({'title' : 'Law and Order Special Victims Unit',}, index, mode='newznab&newznab=4204',thumb='http://thetvdb.com/banners/posters/75692-1.jpg')
                add_posts({'title' : 'Law and Order',}, index, mode='newznab&newznab=4202',thumb='http://thetvdb.com/banners/posters/72368-1.jpg')
                add_posts({'title' : 'Lights Out',}, index, mode='newznab&newznab=4244',thumb='http://thetvdb.com/banners/posters/77303-1.jpg')
                add_posts({'title' : 'Lipstick Jungle',}, index, mode='newznab&newznab=7887',thumb='http://thetvdb.com/banners/posters/80392-1.jpg')
                add_posts({'title' : 'Love Bites',}, index, mode='newznab&newznab=25660',thumb='http://thetvdb.com/banners/posters/77615-1.jpg')
                add_posts({'title' : 'Love in the Wild',}, index, mode='newznab&newznab=28172',thumb='http://thetvdb.com/banners/posters/249026-1.jpg')
                add_posts({'title' : 'Mad About You',}, index, mode='newznab&newznab=4321',thumb='http://thetvdb.com/banners/posters/74340-1.jpg')
                add_posts({'title' : 'Manimal',}, index, mode='newznab&newznab=4365',thumb='http://thetvdb.com/banners/posters/73058-1.jpg')
                add_posts({'title' : 'McMillan And Wife',}, index, mode='newznab&newznab=4419',thumb='http://thetvdb.com/banners/posters/78625-1.jpg')
                add_posts({'title' : 'Minute To Win It',}, index, mode='newznab&newznab=24485',thumb='http://thetvdb.com/banners/posters/149091-1.jpg')
                add_posts({'title' : 'Misfits of Science',}, index, mode='newznab&newznab=4481',thumb='http://thetvdb.com/banners/posters/76951-1.jpg')
                add_posts({'title' : 'Mister Peepers',}, index, mode='newznab&newznab=8665')
                add_posts({'title' : 'Mockingbird Lane',}, index, mode='newznab&newznab=33175',thumb='http://thetvdb.com/banners/posters/259860-1.jpg')
                add_posts({'title' : 'Mommas Boys',}, index, mode='newznab&newznab=19129',thumb='http://thetvdb.com/banners/posters/84145-1.jpg')
                add_posts({'title' : 'Mrs Columbo',}, index, mode='newznab&newznab=4546')
                add_posts({'title' : 'My Name Is Earl',}, index, mode='newznab&newznab=4590',thumb='http://thetvdb.com/banners/posters/75397-1.jpg')
                add_posts({'title' : 'My Two Dads',}, index, mode='newznab&newznab=4609',thumb='http://thetvdb.com/banners/posters/77417-1.jpg')
                add_posts({'title' : 'NewsRadio',}, index, mode='newznab&newznab=4651',thumb='http://thetvdb.com/banners/posters/72355-1.jpg')
                add_posts({'title' : 'Night Gallery',}, index, mode='newznab&newznab=4664',thumb='http://thetvdb.com/banners/posters/70382-1.jpg')
                add_posts({'title' : 'Once an Eagle',}, index, mode='newznab&newznab=18934')
                add_posts({'title' : 'Outsourced',}, index, mode='newznab&newznab=25704',thumb='http://thetvdb.com/banners/posters/163561-1.jpg')
                add_posts({'title' : 'Parenthood 2010',}, index, mode='newznab&newznab=22586',thumb='http://thetvdb.com/banners/posters/94551-1.jpg')
                add_posts({'title' : 'Parenthood 2012',}, index, mode='newznab&newznab=22586',thumb='http://thetvdb.com/banners/posters/94551-1.jpg')
                add_posts({'title' : 'Parks and Recreation',}, index, mode='newznab&newznab=21686',thumb='http://thetvdb.com/banners/posters/84912-1.jpg')
                add_posts({'title' : 'Perfect Couples',}, index, mode='newznab&newznab=25657',thumb='http://thetvdb.com/banners/posters/171251-1.jpg')
                add_posts({'title' : 'Poker After Dark',}, index, mode='newznab&newznab=15023',thumb='http://thetvdb.com/banners/posters/79715-1.jpg')
                add_posts({'title' : 'Police Woman',}, index, mode='newznab&newznab=4855',thumb='http://thetvdb.com/banners/posters/77517-1.jpg')
                add_posts({'title' : 'Police Women',}, index, mode='newznab&newznab=4855',thumb='http://thetvdb.com/banners/posters/77517-1.jpg')
                add_posts({'title' : 'Quantum Leap',}, index, mode='newznab&newznab=4921',thumb='http://thetvdb.com/banners/posters/72248-1.jpg')
                add_posts({'title' : 'Quincy M E',}, index, mode='newznab&newznab=4931',thumb='http://thetvdb.com/banners/posters/77236-1.jpg')
                add_posts({'title' : 'Remington Steele',}, index, mode='newznab&newznab=4972',thumb='http://thetvdb.com/banners/posters/78189-1.jpg')
                add_posts({'title' : 'Revolution 2012',}, index, mode='newznab&newznab=30897')
                add_posts({'title' : 'Riverboat',}, index, mode='newznab&newznab=5015',thumb='http://thetvdb.com/banners/posters/76663-1.jpg')
                add_posts({'title' : 'Rock Center with Brian Williams',}, index, mode='newznab&newznab=29820',thumb='http://thetvdb.com/banners/posters/253274-1.jpg')
                add_posts({'title' : 'Sanford And Son',}, index, mode='newznab&newznab=5097',thumb='http://thetvdb.com/banners/posters/78193-1.jpg')
                add_posts({'title' : 'Saturday Night Live',}, index, mode='newznab&newznab=5098',thumb='http://thetvdb.com/banners/posters/76177-1.jpg')
                add_posts({'title' : 'Seinfeld',}, index, mode='newznab&newznab=5145',thumb='http://thetvdb.com/banners/posters/79169-1.jpg')
                add_posts({'title' : 'Smash',}, index, mode='newznab&newznab=28337',thumb='http://thetvdb.com/banners/posters/83003-1.jpg')
                add_posts({'title' : 'Stars Earn Stripes',}, index, mode='newznab&newznab=31338',thumb='http://thetvdb.com/banners/posters/260390-1.jpg')
                add_posts({'title' : 'Surface',}, index, mode='newznab&newznab=5414',thumb='http://thetvdb.com/banners/posters/78906-1.jpg')
                add_posts({'title' : 'Tate',}, index, mode='newznab&newznab=1773',thumb='http://thetvdb.com/banners/posters/77506-1.jpg')
                add_posts({'title' : 'The Apprentice US',}, index, mode='newznab&newznab=5580')
                add_posts({'title' : 'The Biggest Loser',}, index, mode='newznab&newznab=5618',thumb='http://thetvdb.com/banners/posters/75166-1.jpg')
                add_posts({'title' : 'The Bill Cosby Show',}, index, mode='newznab&newznab=5624',thumb='http://thetvdb.com/banners/posters/77583-1.jpg')
                add_posts({'title' : 'The Cape',}, index, mode='newznab&newznab=24633',thumb='http://thetvdb.com/banners/posters/71394-1.jpg')
                add_posts({'title' : 'The Cosby Show',}, index, mode='newznab&newznab=5698',thumb='http://thetvdb.com/banners/posters/76772-1.jpg')
                add_posts({'title' : 'The Deputy',}, index, mode='newznab&newznab=5724',thumb='http://thetvdb.com/banners/posters/73500-1.jpg')
                add_posts({'title' : 'The Event',}, index, mode='newznab&newznab=25703',thumb='http://thetvdb.com/banners/posters/163531-1.jpg')
                add_posts({'title' : 'The Facts of Life',}, index, mode='newznab&newznab=5759',thumb='http://thetvdb.com/banners/posters/76130-1.jpg')
                add_posts({'title' : 'The Firm',}, index, mode='newznab&newznab=28374',thumb='http://thetvdb.com/banners/posters/248936-1.jpg')
                add_posts({'title' : 'The Fresh Prince of Bel Air',}, index, mode='newznab&newznab=5795',thumb='http://thetvdb.com/banners/posters/76738-1.jpg')
                add_posts({'title' : 'The Golden Girls',}, index, mode='newznab&newznab=5820',thumb='http://thetvdb.com/banners/posters/71292-1.jpg')
                add_posts({'title' : 'The Incredible Hulk 1966',}, index, mode='newznab&newznab=5871',thumb='http://thetvdb.com/banners/posters/72215-1.jpg')
                add_posts({'title' : 'The Invisible Man 1958',}, index, mode='newznab&newznab=5879',thumb='http://thetvdb.com/banners/posters/76793-1.jpg')
                add_posts({'title' : 'The Invisible Man 1975',}, index, mode='newznab&newznab=5879',thumb='http://thetvdb.com/banners/posters/76793-1.jpg')
                add_posts({'title' : 'The Life And Times Of Grizzly Adams',}, index, mode='newznab&newznab=5932',thumb='http://thetvdb.com/banners/posters/75054-1.jpg')
                add_posts({'title' : 'The Man From U N C L E',}, index, mode='newznab&newznab=5966',thumb='http://thetvdb.com/banners/posters/75663-1.jpg')
                add_posts({'title' : 'The New Normal',}, index, mode='newznab&newznab=31384',thumb='http://thetvdb.com/banners/posters/258979-1.jpg')
                add_posts({'title' : 'The Office US',}, index, mode='newznab&newznab=6061',thumb='http://thetvdb.com/banners/posters/73244-1.jpg')
                add_posts({'title' : 'The Paul Reiser Show',}, index, mode='newznab&newznab=25724',thumb='http://thetvdb.com/banners/posters/216741-1.jpg')
                add_posts({'title' : 'The Playboy Club',}, index, mode='newznab&newznab=28375',thumb='http://thetvdb.com/banners/posters/248830-1.jpg')
                add_posts({'title' : 'The Pretender',}, index, mode='newznab&newznab=6107',thumb='http://thetvdb.com/banners/posters/70704-1.jpg')
                add_posts({'title' : 'the rockford files',}, index, mode='newznab&newznab=24839',thumb='http://thetvdb.com/banners/posters/71219-1.jpg')
                add_posts({'title' : 'The Roy Rogers Show',}, index, mode='newznab&newznab=6156',thumb='http://thetvdb.com/banners/posters/77296-1.jpg')
                add_posts({'title' : 'The Sing Off',}, index, mode='newznab&newznab=22819')
                add_posts({'title' : 'The Smurfs',}, index, mode='newznab&newznab=6202',thumb='http://thetvdb.com/banners/posters/75719-1.jpg')
                add_posts({'title' : 'The Voice US',}, index, mode='newznab&newznab=27447',thumb='http://thetvdb.com/banners/posters/247824-1.jpg')
                add_posts({'title' : 'the west wing',}, index, mode='newznab&newznab=6289',thumb='http://thetvdb.com/banners/posters/72521-1.jpg')
                add_posts({'title' : 'Up All Night 2011',}, index, mode='newznab&newznab=28358')
                add_posts({'title' : 'Voyagers',}, index, mode='newznab&newznab=6523',thumb='http://thetvdb.com/banners/posters/74579-1.jpg')
                add_posts({'title' : 'Whitney',}, index, mode='newznab&newznab=28357',thumb='http://thetvdb.com/banners/posters/248951-1.jpg')
                add_posts({'title' : 'Who Do You Think You Are US',}, index, mode='newznab&newznab=22820',thumb='http://thetvdb.com/banners/posters/146651-1.jpg')
                add_posts({'title' : 'Whoopi',}, index, mode='newznab&newznab=6594',thumb='http://thetvdb.com/banners/posters/72297-1.jpg')
                add_posts({'title' : 'Whos Still Standing',}, index, mode='newznab&newznab=28410',thumb='http://thetvdb.com/banners/posters/253272-1.jpg')
                add_posts({'title' : 'Will And Grace',}, index, mode='newznab&newznab=6614',thumb='http://thetvdb.com/banners/posters/71814-1.jpg')
            if newznab_id == 'NBC CBS':
                add_posts({'title' : 'Hazel',}, index, mode='newznab&newznab=203',thumb='http://thetvdb.com/banners/posters/74067-1.jpg')
            if newznab_id == 'Net 5':
                add_posts({'title' : 'nederlandse hollywood vrouwen',}, index, mode='newznab&newznab=28160')
                add_posts({'title' : 'Peking Express',}, index, mode='newznab&newznab=19532',thumb='http://thetvdb.com/banners/posters/81505-1.jpg')
            if newznab_id == 'Netflix':
                add_posts({'title' : 'Arrested Development',}, index, mode='newznab&newznab=2649',thumb='http://thetvdb.com/banners/posters/72173-1.jpg')
            if newznab_id == 'Network Ten':
                add_posts({'title' : 'Good News World',}, index, mode='newznab&newznab=29686',thumb='http://thetvdb.com/banners/posters/251677-1.jpg')
                add_posts({'title' : 'Offspring',}, index, mode='newznab&newznab=25992',thumb='http://thetvdb.com/banners/posters/182541-1.jpg')
                add_posts({'title' : 'The Bolt Report',}, index, mode='newznab&newznab=28347',thumb='http://thetvdb.com/banners/posters/249797-1.jpg')
                add_posts({'title' : 'Undercover Boss Australia',}, index, mode='newznab&newznab=30045')
            if newznab_id == 'NFL Network':
                add_posts({'title' : 'A Football Life',}, index, mode='newznab&newznab=32755',thumb='http://thetvdb.com/banners/posters/252053-1.jpg')
            if newznab_id == 'Nick at Nite':
                add_posts({'title' : 'See Dad Run',}, index, mode='newznab&newznab=32703',thumb='http://thetvdb.com/banners/posters/262266-1.jpg')
            if newznab_id == 'Nick Jr':
                add_posts({'title' : 'LazyTown',}, index, mode='newznab&newznab=4211',thumb='http://thetvdb.com/banners/posters/74928-1.jpg')
                add_posts({'title' : 'Roary the Racing Car',}, index, mode='newznab&newznab=23386',thumb='http://thetvdb.com/banners/posters/84800-1.jpg')
                add_posts({'title' : 'Thomas The Tank Engine And Friends',}, index, mode='newznab&newznab=6340',thumb='http://thetvdb.com/banners/posters/78949-1.jpg')
            if newznab_id == 'Nickelodeon':
                add_posts({'title' : 'Aaahh Real Monsters',}, index, mode='newznab&newznab=2470',thumb='http://thetvdb.com/banners/posters/71492-1.jpg')
                add_posts({'title' : 'All Grown Up',}, index, mode='newznab&newznab=2557',thumb='http://thetvdb.com/banners/posters/71148-1.jpg')
                add_posts({'title' : 'Are You Afraid Of The Dark',}, index, mode='newznab&newznab=2644',thumb='http://thetvdb.com/banners/posters/77960-1.jpg')
                add_posts({'title' : 'Avatar The Last Airbender',}, index, mode='newznab&newznab=2680',thumb='http://thetvdb.com/banners/posters/74852-1.jpg')
                add_posts({'title' : 'Big Time Rush',}, index, mode='newznab&newznab=24951',thumb='http://thetvdb.com/banners/posters/142831-1.jpg')
                add_posts({'title' : 'Bubble Guppies',}, index, mode='newznab&newznab=25192',thumb='http://thetvdb.com/banners/posters/226391-1.jpg')
                add_posts({'title' : 'Danger Mouse',}, index, mode='newznab&newznab=3226',thumb='http://thetvdb.com/banners/posters/76308-1.jpg')
                add_posts({'title' : 'Dora the Explorer',}, index, mode='newznab&newznab=3348',thumb='http://thetvdb.com/banners/posters/74697-1.jpg')
                add_posts({'title' : 'Drake And Josh',}, index, mode='newznab&newznab=3378',thumb='http://thetvdb.com/banners/posters/79357-1.jpg')
                add_posts({'title' : 'Fanboy And Chum Chum',}, index, mode='newznab&newznab=23199',thumb='http://thetvdb.com/banners/posters/160861-1.jpg')
                add_posts({'title' : 'Figure It Out',}, index, mode='newznab&newznab=286',thumb='http://thetvdb.com/banners/posters/75612-1.jpg')
                add_posts({'title' : 'Fred the Show',}, index, mode='newznab&newznab=30686',thumb='http://thetvdb.com/banners/posters/255473-1.jpg')
                add_posts({'title' : 'H2O Just Add Water',}, index, mode='newznab&newznab=12930',thumb='http://thetvdb.com/banners/posters/81061-1.jpg')
                add_posts({'title' : 'Hey Dude',}, index, mode='newznab&newznab=3843',thumb='http://thetvdb.com/banners/posters/75342-1.jpg')
                add_posts({'title' : 'House Of Anubis',}, index, mode='newznab&newznab=27307',thumb='http://thetvdb.com/banners/posters/219621-1.jpg')
                add_posts({'title' : 'How to Rock',}, index, mode='newznab&newznab=30637',thumb='http://thetvdb.com/banners/posters/255727-1.jpg')
                add_posts({'title' : 'iCarly',}, index, mode='newznab&newznab=15498',thumb='http://thetvdb.com/banners/posters/82493-1.jpg')
                add_posts({'title' : 'Invader ZIM',}, index, mode='newznab&newznab=3985',thumb='http://thetvdb.com/banners/posters/75545-1.jpg')
                add_posts({'title' : 'Kung Fu Panda Legends of Awesomeness',}, index, mode='newznab&newznab=22713',thumb='http://thetvdb.com/banners/posters/250632-1.jpg')
                add_posts({'title' : 'Marvin Marvin',}, index, mode='newznab&newznab=30687',thumb='http://thetvdb.com/banners/posters/264033-1.jpg')
                add_posts({'title' : 'Neds Declassified School Survival Guide',}, index, mode='newznab&newznab=4631',thumb='http://thetvdb.com/banners/posters/79821-1.jpg')
                add_posts({'title' : 'Rockos Modern Life',}, index, mode='newznab&newznab=5038',thumb='http://thetvdb.com/banners/posters/75729-1.jpg')
                add_posts({'title' : 'Spongebob Squarepants',}, index, mode='newznab&newznab=5304',thumb='http://thetvdb.com/banners/posters/75886-1.jpg')
                add_posts({'title' : 'Supah Ninjas',}, index, mode='newznab&newznab=27478',thumb='http://thetvdb.com/banners/posters/220991-1.jpg')
                add_posts({'title' : 'Super Duper Sumos',}, index, mode='newznab&newznab=5400')
                add_posts({'title' : 'Team Umizoomi',}, index, mode='newznab&newznab=24962',thumb='http://thetvdb.com/banners/posters/145951-1.jpg')
                add_posts({'title' : 'Teenage Mutant Ninja Turtles 2012',}, index, mode='newznab&newznab=27772',thumb='http://thetvdb.com/banners/posters/261451-1.jpg')
                add_posts({'title' : 'The Adventures of Jimmy Neutron Boy Genius',}, index, mode='newznab&newznab=5531',thumb='http://thetvdb.com/banners/posters/77612-1.jpg')
                add_posts({'title' : 'The Amanda Show',}, index, mode='newznab&newznab=5563',thumb='http://thetvdb.com/banners/posters/74916-1.jpg')
                add_posts({'title' : 'The Angry Beavers',}, index, mode='newznab&newznab=5576',thumb='http://thetvdb.com/banners/posters/76386-1.jpg')
                add_posts({'title' : 'The Legend of Korra',}, index, mode='newznab&newznab=26254',thumb='http://thetvdb.com/banners/posters/251085-1.jpg')
                add_posts({'title' : 'The Penguins of Madagascar',}, index, mode='newznab&newznab=21572',thumb='http://thetvdb.com/banners/posters/85075-1.jpg')
                add_posts({'title' : 'The Wild Thornberrys',}, index, mode='newznab&newznab=6293',thumb='http://thetvdb.com/banners/posters/75402-1.jpg')
                add_posts({'title' : 'Victorious',}, index, mode='newznab&newznab=25190',thumb='http://thetvdb.com/banners/posters/152721-1.jpg')
                add_posts({'title' : 'Wonder Pets',}, index, mode='newznab&newznab=10663')
                add_posts({'title' : 'Yo Gabba Gabba',}, index, mode='newznab&newznab=17329',thumb='http://thetvdb.com/banners/posters/80964-1.jpg')
                add_posts({'title' : 'Zoey 101',}, index, mode='newznab&newznab=6700',thumb='http://thetvdb.com/banners/posters/74647-1.jpg')
            if newznab_id == 'NickToons':
                add_posts({'title' : 'Dragon Ball Z Kai',}, index, mode='newznab&newznab=25859')
                add_posts({'title' : 'Hero Factory',}, index, mode='newznab&newznab=26412',thumb='http://thetvdb.com/banners/posters/190011-1.jpg')
                add_posts({'title' : 'Iron Man Armored Adventures',}, index, mode='newznab&newznab=19586',thumb='http://thetvdb.com/banners/posters/83826-1.jpg')
                add_posts({'title' : 'Planet Sheen',}, index, mode='newznab&newznab=23205',thumb='http://thetvdb.com/banners/posters/195041-1.jpg')
                add_posts({'title' : 'The Troop',}, index, mode='newznab&newznab=23548',thumb='http://thetvdb.com/banners/posters/114381-1.jpg')
                add_posts({'title' : 'Voltron Force',}, index, mode='newznab&newznab=28196',thumb='http://thetvdb.com/banners/posters/249174-1.jpg')
                add_posts({'title' : 'Wolverine and the X Men',}, index, mode='newznab&newznab=11165',thumb='http://thetvdb.com/banners/posters/82870-1.jpg')
            if newznab_id == 'Nine':
                add_posts({'title' : 'Australias Got Talent',}, index, mode='newznab&newznab=13024',thumb='http://thetvdb.com/banners/posters/87581-1.jpg')
                add_posts({'title' : 'Between The Lines AU',}, index, mode='newznab&newznab=28792')
                add_posts({'title' : 'Big Brother AU',}, index, mode='newznab&newznab=2790')
                add_posts({'title' : 'BIG Extreme Makeover',}, index, mode='newznab&newznab=28735')
                add_posts({'title' : 'Customs',}, index, mode='newznab&newznab=21779',thumb='http://thetvdb.com/banners/posters/85030-1.jpg')
                add_posts({'title' : 'Halifax FP',}, index, mode='newznab&newznab=3776',thumb='http://thetvdb.com/banners/posters/77179-1.jpg')
                add_posts({'title' : 'Hamish And Andys Gap Year',}, index, mode='newznab&newznab=29148')
                add_posts({'title' : 'Hot Property AU',}, index, mode='newznab&newznab=7674')
                add_posts({'title' : 'House Husbands',}, index, mode='newznab&newznab=31989',thumb='http://thetvdb.com/banners/posters/262026-1.jpg')
                add_posts({'title' : 'In Their Footsteps',}, index, mode='newznab&newznab=29239',thumb='http://thetvdb.com/banners/posters/248604-1.jpg')
                add_posts({'title' : 'Lockie Leonard',}, index, mode='newznab&newznab=24230',thumb='http://thetvdb.com/banners/posters/80414-1.jpg')
                add_posts({'title' : 'Lukes Kingdom',}, index, mode='newznab&newznab=4311',thumb='http://thetvdb.com/banners/posters/72064-1.jpg')
                add_posts({'title' : 'Micallef Tonight',}, index, mode='newznab&newznab=1132',thumb='http://thetvdb.com/banners/posters/72718-1.jpg')
                add_posts({'title' : 'Money',}, index, mode='newznab&newznab=11536',thumb='http://thetvdb.com/banners/posters/164961-1.jpg')
                add_posts({'title' : 'Rescue Special Ops',}, index, mode='newznab&newznab=23496',thumb='http://thetvdb.com/banners/posters/107381-1.jpg')
                add_posts({'title' : 'RPA',}, index, mode='newznab&newznab=11428',thumb='http://thetvdb.com/banners/posters/251844-1.jpg')
                add_posts({'title' : 'Sea Patrol',}, index, mode='newznab&newznab=16593',thumb='http://thetvdb.com/banners/posters/80546-1.jpg')
                add_posts({'title' : 'Spellbinder',}, index, mode='newznab&newznab=130',thumb='http://thetvdb.com/banners/posters/71894-1.jpg')
                add_posts({'title' : 'Stingers',}, index, mode='newznab&newznab=5354',thumb='http://thetvdb.com/banners/posters/71501-1.jpg')
                add_posts({'title' : 'the block',}, index, mode='newznab&newznab=2185',thumb='http://thetvdb.com/banners/posters/74768-1.jpg')
                add_posts({'title' : 'The Celebrity Apprentice AU',}, index, mode='newznab&newznab=29979')
                add_posts({'title' : 'The Farmer Wants A Wife AU',}, index, mode='newznab&newznab=17851')
                add_posts({'title' : 'The Joy Of Sets',}, index, mode='newznab&newznab=30009',thumb='http://thetvdb.com/banners/posters/252068-1.jpg')
                add_posts({'title' : 'The Saddle Club',}, index, mode='newznab&newznab=6157',thumb='http://thetvdb.com/banners/posters/81993-1.jpg')
                add_posts({'title' : 'The Secret Millionaire UK',}, index, mode='newznab&newznab=27287')
                add_posts({'title' : 'The Voice AU',}, index, mode='newznab&newznab=28655',thumb='http://thetvdb.com/banners/posters/258204-1.jpg')
                add_posts({'title' : 'Tricky Business AU',}, index, mode='newznab&newznab=30669')
                add_posts({'title' : 'Underbelly Razor',}, index, mode='newznab&newznab=29369')
            if newznab_id == 'NRK1':
                add_posts({'title' : 'Koselig Med Peis',}, index, mode='newznab&newznab=23570',thumb='http://thetvdb.com/banners/posters/220181-1.jpg')
                add_posts({'title' : 'Lilyhammer',}, index, mode='newznab&newznab=30626',thumb='http://thetvdb.com/banners/posters/254854-1.jpg')
            if newznab_id == 'NTV':
                add_posts({'title' : 'Claymore',}, index, mode='newznab&newznab=15433',thumb='http://thetvdb.com/banners/posters/79995-1.jpg')
            if newznab_id == 'nuvoTV':
                add_posts({'title' : 'Fight Factory',}, index, mode='newznab&newznab=32484',thumb='http://thetvdb.com/banners/posters/262010-1.jpg')
            if newznab_id == 'OLN':
                add_posts({'title' : 'Deals From The Dark Side',}, index, mode='newznab&newznab=30345',thumb='http://thetvdb.com/banners/posters/260926-1.jpg')
                add_posts({'title' : 'Departures',}, index, mode='newznab&newznab=25329',thumb='http://thetvdb.com/banners/posters/84870-1.jpg')
            if newznab_id == 'OWN':
                add_posts({'title' : '10 Kids 2 Dads',}, index, mode='newznab&newznab=32568')
                add_posts({'title' : 'Americas Money Class with Suze Orman',}, index, mode='newznab&newznab=29972',thumb='http://thetvdb.com/banners/posters/255302-1.jpg')
                add_posts({'title' : 'Are You Normal America',}, index, mode='newznab&newznab=31794')
                add_posts({'title' : 'Ask Oprahs All Stars',}, index, mode='newznab&newznab=27152')
                add_posts({'title' : 'Beyond Belief US',}, index, mode='newznab&newznab=30737')
                add_posts({'title' : 'Confronting',}, index, mode='newznab&newznab=28123')
                add_posts({'title' : 'Don t Tell the Bride US',}, index, mode='newznab&newznab=29833',thumb='http://thetvdb.com/banners/posters/258978-1.jpg')
                add_posts({'title' : 'Dont Tell The Bride UK',}, index, mode='newznab&newznab=29833',thumb='http://thetvdb.com/banners/posters/258978-1.jpg')
                add_posts({'title' : 'Dont Tell The Bride USA',}, index, mode='newznab&newznab=29833',thumb='http://thetvdb.com/banners/posters/258978-1.jpg')
                add_posts({'title' : 'Extraordinary Acts of Courage',}, index, mode='newznab&newznab=29039')
                add_posts({'title' : 'Extreme Clutter',}, index, mode='newznab&newznab=27054',thumb='http://thetvdb.com/banners/posters/254687-1.jpg')
                add_posts({'title' : 'In the Bedroom with Dr Laura Berman',}, index, mode='newznab&newznab=23729',thumb='http://thetvdb.com/banners/posters/225781-1.jpg')
                add_posts({'title' : 'Love Thy Neighbour 2011',}, index, mode='newznab&newznab=33877')
                add_posts({'title' : 'Lovetown USA',}, index, mode='newznab&newznab=32041')
                add_posts({'title' : 'Mystery Diagnosis',}, index, mode='newznab&newznab=7992',thumb='http://thetvdb.com/banners/posters/236691-1.jpg')
                add_posts({'title' : 'Oprah Presents Master Class',}, index, mode='newznab&newznab=27053',thumb='http://thetvdb.com/banners/posters/227161-1.jpg')
                add_posts({'title' : 'Oprahs Lifeclass',}, index, mode='newznab&newznab=29429',thumb='http://thetvdb.com/banners/posters/252828-1.jpg')
                add_posts({'title' : 'Oprahs Next Chapter',}, index, mode='newznab&newznab=30424',thumb='http://thetvdb.com/banners/posters/255690-1.jpg')
                add_posts({'title' : 'Our America with Lisa Ling',}, index, mode='newznab&newznab=27603',thumb='http://thetvdb.com/banners/posters/234781-1.jpg')
                add_posts({'title' : 'Party At Tiffanys',}, index, mode='newznab&newznab=30351')
                add_posts({'title' : 'Rollin With Zach',}, index, mode='newznab&newznab=29968',thumb='http://thetvdb.com/banners/posters/253618-1.jpg')
                add_posts({'title' : 'Searching For',}, index, mode='newznab&newznab=27148',thumb='http://thetvdb.com/banners/posters/249705-1.jpg')
                add_posts({'title' : 'Season 25 Oprah Behind the Scenes',}, index, mode='newznab&newznab=27056',thumb='http://thetvdb.com/banners/posters/218001-1.jpg')
                add_posts({'title' : 'Super Soul Sunday',}, index, mode='newznab&newznab=32080',thumb='http://thetvdb.com/banners/posters/258845-1.jpg')
                add_posts({'title' : 'The Ambush Cook',}, index, mode='newznab&newznab=30156',thumb='http://thetvdb.com/banners/posters/253619-1.jpg')
                add_posts({'title' : 'The Dr Laura Berman Show',}, index, mode='newznab&newznab=28514',thumb='http://thetvdb.com/banners/posters/249841-1.jpg')
                add_posts({'title' : 'The Judds',}, index, mode='newznab&newznab=27639',thumb='http://thetvdb.com/banners/posters/248923-1.jpg')
                add_posts({'title' : 'The Rosie Show',}, index, mode='newznab&newznab=29428',thumb='http://thetvdb.com/banners/posters/252734-1.jpg')
                add_posts({'title' : 'Visionaries Inside the Creative Mind',}, index, mode='newznab&newznab=28619',thumb='http://thetvdb.com/banners/posters/253284-1.jpg')
                add_posts({'title' : 'Welcome to Sweetie Pies',}, index, mode='newznab&newznab=29427',thumb='http://thetvdb.com/banners/posters/254248-1.jpg')
                add_posts({'title' : 'Why Not With Shania Twain',}, index, mode='newznab&newznab=28066',thumb='http://thetvdb.com/banners/posters/248627-1.jpg')
            if newznab_id == 'Oxygen':
                add_posts({'title' : 'All About Aubrey',}, index, mode='newznab&newznab=27741',thumb='http://thetvdb.com/banners/posters/222491-1.jpg')
                add_posts({'title' : 'Bachelorette Party Las Vegas',}, index, mode='newznab&newznab=25757',thumb='http://thetvdb.com/banners/posters/260897-1.jpg')
                add_posts({'title' : 'Best Ink',}, index, mode='newznab&newznab=30116',thumb='http://thetvdb.com/banners/posters/257709-1.jpg')
                add_posts({'title' : 'Brooklyn 11223',}, index, mode='newznab&newznab=31223',thumb='http://thetvdb.com/banners/posters/257642-1.jpg')
                add_posts({'title' : 'Girlfriend Confidential LA',}, index, mode='newznab&newznab=32523',thumb='http://thetvdb.com/banners/posters/260401-1.jpg')
                add_posts({'title' : 'Girls Behaving Badly',}, index, mode='newznab&newznab=3687',thumb='http://thetvdb.com/banners/posters/259367-1.jpg')
                add_posts({'title' : 'Hair Battle Spectacular',}, index, mode='newznab&newznab=25710',thumb='http://thetvdb.com/banners/posters/180181-1.jpg')
                add_posts({'title' : 'Im Having Their Baby',}, index, mode='newznab&newznab=32073',thumb='http://thetvdb.com/banners/posters/261020-1.jpg')
                add_posts({'title' : 'Love Games Bad Girls Need Love Too',}, index, mode='newznab&newznab=25019',thumb='http://thetvdb.com/banners/posters/222501-1.jpg')
                add_posts({'title' : 'The Bad Girls Club',}, index, mode='newznab&newznab=14714',thumb='http://thetvdb.com/banners/posters/134161-1.jpg')
                add_posts({'title' : 'The Glee Project',}, index, mode='newznab&newznab=28606',thumb='http://thetvdb.com/banners/posters/221391-1.jpg')
                add_posts({'title' : 'The World According To Paris',}, index, mode='newznab&newznab=28225',thumb='http://thetvdb.com/banners/posters/222481-1.jpg')
            if newznab_id == 'PAX':
                add_posts({'title' : 'Sue Thomas F B Eye',}, index, mode='newznab&newznab=5387',thumb='http://thetvdb.com/banners/posters/78849-1.jpg')
            if newznab_id == 'PBS':
                add_posts({'title' : 'America in Primetime',}, index, mode='newznab&newznab=29072',thumb='http://thetvdb.com/banners/posters/253250-1.jpg')
                add_posts({'title' : 'America Revealed',}, index, mode='newznab&newznab=31368',thumb='http://thetvdb.com/banners/posters/256484-1.jpg')
                add_posts({'title' : 'American Experience',}, index, mode='newznab&newznab=18193')
                add_posts({'title' : 'American Masters',}, index, mode='newznab&newznab=11612')
                add_posts({'title' : 'Americas Test Kitchen',}, index, mode='newznab&newznab=10581',thumb='http://thetvdb.com/banners/posters/80297-1.jpg')
                add_posts({'title' : 'Angelina Ballerina',}, index, mode='newznab&newznab=2611',thumb='http://thetvdb.com/banners/posters/83466-1.jpg')
                add_posts({'title' : 'Antiques Roadshow UK',}, index, mode='newznab&newznab=17788',thumb='http://thetvdb.com/banners/posters/75117-1.jpg')
                add_posts({'title' : 'Antiques Roadshow US',}, index, mode='newznab&newznab=17788',thumb='http://thetvdb.com/banners/posters/75117-1.jpg')
                add_posts({'title' : 'Ask This Old House',}, index, mode='newznab&newznab=2657',thumb='http://thetvdb.com/banners/posters/74326-1.jpg')
                add_posts({'title' : 'Austin City Limits',}, index, mode='newznab&newznab=2674',thumb='http://thetvdb.com/banners/posters/71649-1.jpg')
                add_posts({'title' : 'Barney and Friends',}, index, mode='newznab&newznab=2715')
                add_posts({'title' : 'Black in Latin America',}, index, mode='newznab&newznab=27215',thumb='http://thetvdb.com/banners/posters/248228-1.jpg')
                add_posts({'title' : 'Broadway or Bust',}, index, mode='newznab&newznab=32686',thumb='http://thetvdb.com/banners/posters/262287-1.jpg')
                add_posts({'title' : 'Click and Clack As the Wrench Turns',}, index, mode='newznab&newznab=19486',thumb='http://thetvdb.com/banners/posters/199031-1.jpg')
                add_posts({'title' : 'Clifford the Big Red Dog',}, index, mode='newznab&newznab=3088',thumb='http://thetvdb.com/banners/posters/73734-1.jpg')
                add_posts({'title' : 'Finding Your Roots with Henry Louis Gates Jr',}, index, mode='newznab&newznab=31222',thumb='http://thetvdb.com/banners/posters/257587-1.jpg')
                add_posts({'title' : 'Frontier House',}, index, mode='newznab&newznab=3618',thumb='http://thetvdb.com/banners/posters/79558-1.jpg')
                add_posts({'title' : 'Frontline US',}, index, mode='newznab&newznab=8258')
                add_posts({'title' : 'Great Performances at the Met',}, index, mode='newznab&newznab=22209')
                add_posts({'title' : 'Great Performances',}, index, mode='newznab&newznab=10777',thumb='http://thetvdb.com/banners/posters/76548-1.jpg')
                add_posts({'title' : 'History Detectives',}, index, mode='newznab&newznab=3869',thumb='http://thetvdb.com/banners/posters/74267-1.jpg')
                add_posts({'title' : 'Independent Lens',}, index, mode='newznab&newznab=17675',thumb='http://thetvdb.com/banners/posters/84082-1.jpg')
                add_posts({'title' : 'Inside Natures Giants PBS',}, index, mode='newznab&newznab=30710')
                add_posts({'title' : 'Inside Natures Giants US',}, index, mode='newznab&newznab=30710')
                add_posts({'title' : 'Keeping Score',}, index, mode='newznab&newznab=28821',thumb='http://thetvdb.com/banners/posters/258306-1.jpg')
                add_posts({'title' : 'Lidia Celebrates America',}, index, mode='newznab&newznab=30453')
                add_posts({'title' : 'Life On Fire',}, index, mode='newznab&newznab=33999',thumb='http://thetvdb.com/banners/posters/250184-1.jpg')
                add_posts({'title' : 'Live from the Artists Den',}, index, mode='newznab&newznab=23422',thumb='http://thetvdb.com/banners/posters/106161-1.jpg')
                add_posts({'title' : 'Market Warriors',}, index, mode='newznab&newznab=31942',thumb='http://thetvdb.com/banners/posters/260769-1.jpg')
                add_posts({'title' : 'Nature',}, index, mode='newznab&newznab=6773',thumb='http://thetvdb.com/banners/posters/81157-1.jpg')
                add_posts({'title' : 'NOVA scienceNOW',}, index, mode='newznab&newznab=19290',thumb='http://thetvdb.com/banners/posters/81526-1.jpg')
                add_posts({'title' : 'NOVA',}, index, mode='newznab&newznab=6771',thumb='http://thetvdb.com/banners/posters/76119-1.jpg')
                add_posts({'title' : 'Pioneers Of Television',}, index, mode='newznab&newznab=18131',thumb='http://thetvdb.com/banners/posters/198531-1.jpg')
                add_posts({'title' : 'Prohibition',}, index, mode='newznab&newznab=29073',thumb='http://thetvdb.com/banners/posters/251965-1.jpg')
                add_posts({'title' : 'Secrets of the Dead',}, index, mode='newznab&newznab=18774',thumb='http://thetvdb.com/banners/posters/73986-1.jpg')
                add_posts({'title' : 'Sesame Street',}, index, mode='newznab&newznab=5152',thumb='http://thetvdb.com/banners/posters/78419-1.jpg')
                add_posts({'title' : 'Super Why',}, index, mode='newznab&newznab=17939',thumb='http://thetvdb.com/banners/posters/81164-1.jpg')
                add_posts({'title' : 'The Adams Chronicles',}, index, mode='newznab&newznab=325',thumb='http://thetvdb.com/banners/posters/76175-1.jpg')
                add_posts({'title' : 'The Adams Cronicles',}, index, mode='newznab&newznab=325',thumb='http://thetvdb.com/banners/posters/76175-1.jpg')
                add_posts({'title' : 'The Dust Bowl',}, index, mode='newznab&newznab=33045',thumb='http://thetvdb.com/banners/posters/264098-1.jpg')
                add_posts({'title' : 'The Electric Company',}, index, mode='newznab&newznab=5746',thumb='http://thetvdb.com/banners/posters/73666-1.jpg')
                add_posts({'title' : 'This Old House',}, index, mode='newznab&newznab=6338',thumb='http://thetvdb.com/banners/posters/77444-1.jpg')
                add_posts({'title' : 'Wishbone',}, index, mode='newznab&newznab=316',thumb='http://thetvdb.com/banners/posters/76132-1.jpg')
            if newznab_id == 'PBS Kids':
                add_posts({'title' : 'Daniel Tigers Neighborhood',}, index, mode='newznab&newznab=32504',thumb='http://thetvdb.com/banners/posters/261511-1.jpg')
                add_posts({'title' : 'Dinosaur Train',}, index, mode='newznab&newznab=23545',thumb='http://thetvdb.com/banners/posters/116291-1.jpg')
                add_posts({'title' : 'Martha Speaks',}, index, mode='newznab&newznab=25535',thumb='http://thetvdb.com/banners/posters/100341-1.jpg')
                add_posts({'title' : 'The Cat in the Hat Knows a Lot About That',}, index, mode='newznab&newznab=26555',thumb='http://thetvdb.com/banners/posters/188231-1.jpg')
                add_posts({'title' : 'Wild Kratts',}, index, mode='newznab&newznab=30915',thumb='http://thetvdb.com/banners/posters/216851-1.jpg')
                add_posts({'title' : 'WordWorld',}, index, mode='newznab&newznab=22427')
            if newznab_id == 'Planet Green':
                add_posts({'title' : 'Boomtown 2011',}, index, mode='newznab&newznab=27256',thumb='http://thetvdb.com/banners/posters/217311-1.jpg')
                add_posts({'title' : 'Coastwatch',}, index, mode='newznab&newznab=26173',thumb='http://thetvdb.com/banners/posters/262342-1.jpg')
                add_posts({'title' : 'Conviction Kitchen',}, index, mode='newznab&newznab=24766')
                add_posts({'title' : 'Detroit In Overdrive',}, index, mode='newznab&newznab=29075',thumb='http://thetvdb.com/banners/posters/250881-1.jpg')
                add_posts({'title' : 'Last Man Standing US',}, index, mode='newznab&newznab=27392')
            if newznab_id == 'Playboy TV':
                add_posts({'title' : 'Camp Playboy',}, index, mode='newznab&newznab=28978',thumb='http://thetvdb.com/banners/posters/250388-1.jpg')
            if newznab_id == 'Prime':
                add_posts({'title' : 'New Zealands Got Talent',}, index, mode='newznab&newznab=19920',thumb='http://thetvdb.com/banners/posters/262281-1.jpg')
            if newznab_id == 'ProTV':
                add_posts({'title' : 'las fierbinti',}, index, mode='newznab&newznab=31482')
                add_posts({'title' : 'Romanii Au Talent',}, index, mode='newznab&newznab=28220')
                add_posts({'title' : 'Vocea Romaniei',}, index, mode='newznab&newznab=28664')
            if newznab_id == 'Quest':
                add_posts({'title' : 'Salvage Hunters',}, index, mode='newznab&newznab=32086',thumb='http://thetvdb.com/banners/posters/256816-1.jpg')
            if newznab_id == 'Real Time':
                add_posts({'title' : 'London Ink',}, index, mode='newznab&newznab=17916',thumb='http://thetvdb.com/banners/posters/81279-1.jpg')
            if newznab_id == 'Rede Globo':
                add_posts({'title' : 'Suburbia',}, index, mode='newznab&newznab=33432',thumb='http://thetvdb.com/banners/posters/263409-1.jpg')
                add_posts({'title' : 'The Voice Brasil',}, index, mode='newznab&newznab=32992',thumb='http://thetvdb.com/banners/posters/262639-1.jpg')
            if newznab_id == 'ReelzChannel':
                add_posts({'title' : 'Coach',}, index, mode='newznab&newznab=3095',thumb='http://thetvdb.com/banners/posters/76905-1.jpg')
                add_posts({'title' : 'True Justice',}, index, mode='newznab&newznab=30798',thumb='http://thetvdb.com/banners/posters/248298-1.jpg')
            if newznab_id == 'RTE 1':
                add_posts({'title' : 'Love Hate',}, index, mode='newznab&newznab=29133',thumb='http://thetvdb.com/banners/posters/213211-1.jpg')
                add_posts({'title' : 'Single Handed',}, index, mode='newznab&newznab=23286',thumb='http://thetvdb.com/banners/posters/107501-1.jpg')
            if newznab_id == 'RTL 4':
                add_posts({'title' : 'Buch In De Bajes',}, index, mode='newznab&newznab=31365')
                add_posts({'title' : 'Goede Tijden Slechte Tijden',}, index, mode='newznab&newznab=19056',thumb='http://thetvdb.com/banners/posters/104271-1.jpg')
                add_posts({'title' : 'Het Spijt Me',}, index, mode='newznab&newznab=29342')
                add_posts({'title' : 'Hollands Got Talent',}, index, mode='newznab&newznab=19157',thumb='http://thetvdb.com/banners/posters/173991-1.jpg')
                add_posts({'title' : 'Iederee Is Gek Op Jack',}, index, mode='newznab&newznab=27469',thumb='http://thetvdb.com/banners/posters/230041-1.jpg')
                add_posts({'title' : 'Iedereen Is Gek Op Jack',}, index, mode='newznab&newznab=27469',thumb='http://thetvdb.com/banners/posters/230041-1.jpg')
                add_posts({'title' : 'The voice of Holland',}, index, mode='newznab&newznab=26546',thumb='http://thetvdb.com/banners/posters/191201-1.jpg')
            if newznab_id == 'RTL 5':
                add_posts({'title' : 'Take Me Out',}, index, mode='newznab&newznab=21952',thumb='http://thetvdb.com/banners/posters/132141-1.jpg')
            if newznab_id == 'RTL 7':
                add_posts({'title' : 'Tour Du Jour',}, index, mode='newznab&newznab=28592',thumb='http://thetvdb.com/banners/posters/259605-1.jpg')
                add_posts({'title' : 'VI Oranje',}, index, mode='newznab&newznab=25885',thumb='http://thetvdb.com/banners/posters/259065-1.jpg')
            if newznab_id == 'RTL Klub':
                add_posts({'title' : 'X Faktor HU',}, index, mode='newznab&newznab=26501')
            if newznab_id == 'SBS':
                add_posts({'title' : 'Costas Garden Odyssey',}, index, mode='newznab&newznab=23909',thumb='http://thetvdb.com/banners/posters/115581-1.jpg')
                add_posts({'title' : 'Danger 5',}, index, mode='newznab&newznab=30245',thumb='http://thetvdb.com/banners/posters/253823-1.jpg')
                add_posts({'title' : 'East West 101',}, index, mode='newznab&newznab=18008',thumb='http://thetvdb.com/banners/posters/81590-1.jpg')
                add_posts({'title' : 'Gourmet Farmer',}, index, mode='newznab&newznab=24881',thumb='http://thetvdb.com/banners/posters/133291-1.jpg')
                add_posts({'title' : 'Housos',}, index, mode='newznab&newznab=29807',thumb='http://thetvdb.com/banners/posters/252277-1.jpg')
                add_posts({'title' : 'In Between',}, index, mode='newznab&newznab=11653')
                add_posts({'title' : 'John Safrans Music Jamboree',}, index, mode='newznab&newznab=642',thumb='http://thetvdb.com/banners/posters/81220-1.jpg')
                add_posts({'title' : 'Luke Nguyens Vietnam',}, index, mode='newznab&newznab=24521')
                add_posts({'title' : 'Once Upon A Time In Cabramatta',}, index, mode='newznab&newznab=30603',thumb='http://thetvdb.com/banners/posters/254542-1.jpg')
                add_posts({'title' : 'RocKwiz',}, index, mode='newznab&newznab=7582',thumb='http://thetvdb.com/banners/posters/97041-1.jpg')
                add_posts({'title' : 'Swift And Shift Couriers',}, index, mode='newznab&newznab=20547',thumb='http://thetvdb.com/banners/posters/83596-1.jpg')
                add_posts({'title' : 'Who Do You Think You Are AU',}, index, mode='newznab&newznab=24273')
                add_posts({'title' : 'Wilfred',}, index, mode='newznab&newznab=15352',thumb='http://thetvdb.com/banners/posters/80331-1.jpg')
            if newznab_id == 'SBS 6':
                add_posts({'title' : 'Undercover Boss US',}, index, mode='newznab&newznab=26279')
                add_posts({'title' : 'Wegmisbruikers',}, index, mode='newznab&newznab=19855',thumb='http://thetvdb.com/banners/posters/83902-1.jpg')
            if newznab_id == 'Science Channel':
                add_posts({'title' : 'Against the Elements',}, index, mode='newznab&newznab=21957',thumb='http://thetvdb.com/banners/posters/253247-1.jpg')
                add_posts({'title' : 'Build It Bigger',}, index, mode='newznab&newznab=16701',thumb='http://thetvdb.com/banners/posters/80355-1.jpg')
                add_posts({'title' : 'Danger by Design',}, index, mode='newznab&newznab=31885')
                add_posts({'title' : 'Dark Matters Twisted But True',}, index, mode='newznab&newznab=29222')
                add_posts({'title' : 'Death Dealers',}, index, mode='newznab&newznab=33699',thumb='http://thetvdb.com/banners/posters/264582-1.jpg')
                add_posts({'title' : 'Factory Made',}, index, mode='newznab&newznab=19143',thumb='http://thetvdb.com/banners/posters/185791-1.jpg')
                add_posts({'title' : 'Head Games',}, index, mode='newznab&newznab=23464',thumb='http://thetvdb.com/banners/posters/259377-1.jpg')
                add_posts({'title' : 'Head Rush',}, index, mode='newznab&newznab=26447')
                add_posts({'title' : 'headgames',}, index, mode='newznab&newznab=23464',thumb='http://thetvdb.com/banners/posters/259377-1.jpg')
                add_posts({'title' : 'How Its Made',}, index, mode='newznab&newznab=13490',thumb='http://thetvdb.com/banners/posters/79485-1.jpg')
                add_posts({'title' : 'How The Universe Works',}, index, mode='newznab&newznab=25537',thumb='http://thetvdb.com/banners/posters/159651-1.jpg')
                add_posts({'title' : 'Inside the Design',}, index, mode='newznab&newznab=30739',thumb='http://thetvdb.com/banners/posters/262033-1.jpg')
                add_posts({'title' : 'Mega Builders',}, index, mode='newznab&newznab=15012')
                add_posts({'title' : 'MegaBuilders',}, index, mode='newznab&newznab=15012')
                add_posts({'title' : 'Meteorite Men',}, index, mode='newznab&newznab=24791',thumb='http://thetvdb.com/banners/posters/136211-1.jpg')
                add_posts({'title' : 'Monster Bug Wars',}, index, mode='newznab&newznab=27009',thumb='http://thetvdb.com/banners/posters/249714-1.jpg')
                add_posts({'title' : 'Odd Folks Home',}, index, mode='newznab&newznab=31306',thumb='http://thetvdb.com/banners/posters/264209-1.jpg')
                add_posts({'title' : 'Oddities San Francisco',}, index, mode='newznab&newznab=32034',thumb='http://thetvdb.com/banners/posters/259975-1.jpg')
                add_posts({'title' : 'Oddities',}, index, mode='newznab&newznab=26890',thumb='http://thetvdb.com/banners/posters/204361-1.jpg')
                add_posts({'title' : 'Prophets of Science Fiction',}, index, mode='newznab&newznab=29958',thumb='http://thetvdb.com/banners/posters/219301-1.jpg')
                add_posts({'title' : 'Sci Fi Science Physics of the Impossible',}, index, mode='newznab&newznab=24423',thumb='http://thetvdb.com/banners/posters/131791-1.jpg')
                add_posts({'title' : 'Stuck with Hackett',}, index, mode='newznab&newznab=27049',thumb='http://thetvdb.com/banners/posters/214381-1.jpg')
                add_posts({'title' : 'Surviving Zombies',}, index, mode='newznab&newznab=31308',thumb='http://thetvdb.com/banners/posters/265034-1.jpg')
                add_posts({'title' : 'Through the Wormhole',}, index, mode='newznab&newznab=24909',thumb='http://thetvdb.com/banners/posters/168571-1.jpg')
            if newznab_id == 'Seven':
                add_posts({'title' : 'Acropolis Now',}, index, mode='newznab&newznab=1788',thumb='http://thetvdb.com/banners/posters/77568-1.jpg')
                add_posts({'title' : 'Air Ways',}, index, mode='newznab&newznab=24014',thumb='http://thetvdb.com/banners/posters/104171-1.jpg')
                add_posts({'title' : 'All Saints',}, index, mode='newznab&newznab=2564',thumb='http://thetvdb.com/banners/posters/71815-1.jpg')
                add_posts({'title' : 'Australias Got Amazing Talent',}, index, mode='newznab&newznab=30619')
                add_posts({'title' : 'Beyond The Darklands',}, index, mode='newznab&newznab=22127',thumb='http://thetvdb.com/banners/posters/109521-1.jpg')
                add_posts({'title' : 'Blue Heelers',}, index, mode='newznab&newznab=2842',thumb='http://thetvdb.com/banners/posters/75680-1.jpg')
                add_posts({'title' : 'Brynne My Bedazzled Life',}, index, mode='newznab&newznab=33060',thumb='http://thetvdb.com/banners/posters/262981-1.jpg')
                add_posts({'title' : 'City Homicide',}, index, mode='newznab&newznab=17228',thumb='http://thetvdb.com/banners/posters/80480-1.jpg')
                add_posts({'title' : 'Dancing With The Stars AU',}, index, mode='newznab&newznab=3219')
                add_posts({'title' : 'Forensic Investigators',}, index, mode='newznab&newznab=6743',thumb='http://thetvdb.com/banners/posters/82058-1.jpg')
                add_posts({'title' : 'Full Frontal',}, index, mode='newznab&newznab=469',thumb='http://thetvdb.com/banners/posters/78607-1.jpg')
                add_posts({'title' : 'Gangs Of Oz',}, index, mode='newznab&newznab=24012',thumb='http://thetvdb.com/banners/posters/85155-1.jpg')
                add_posts({'title' : 'Killing Time',}, index, mode='newznab&newznab=26261',thumb='http://thetvdb.com/banners/posters/249255-1.jpg')
                add_posts({'title' : 'My Kitchen Rules',}, index, mode='newznab&newznab=24017',thumb='http://thetvdb.com/banners/posters/138981-1.jpg')
                add_posts({'title' : 'Packed To The Rafters',}, index, mode='newznab&newznab=19837',thumb='http://thetvdb.com/banners/posters/82820-1.jpg')
                add_posts({'title' : 'pictures of you',}, index, mode='newznab&newznab=31488',thumb='http://thetvdb.com/banners/posters/258459-1.jpg')
                add_posts({'title' : 'Please Marry My Boy',}, index, mode='newznab&newznab=31505',thumb='http://thetvdb.com/banners/posters/255695-1.jpg')
                add_posts({'title' : 'RSPCA Animal Rescue',}, index, mode='newznab&newznab=16831')
                add_posts({'title' : 'Sugar And Spice AU',}, index, mode='newznab&newznab=26092')
                add_posts({'title' : 'Surveillance Oz',}, index, mode='newznab&newznab=32939',thumb='http://thetvdb.com/banners/posters/262944-1.jpg')
                add_posts({'title' : 'Thank God Youre Here',}, index, mode='newznab&newznab=10537')
                add_posts({'title' : 'The Amazing Race Australia',}, index, mode='newznab&newznab=26744',thumb='http://thetvdb.com/banners/posters/248618-1.jpg')
                add_posts({'title' : 'The Force Behind The Line',}, index, mode='newznab&newznab=13494',thumb='http://thetvdb.com/banners/posters/97311-1.jpg')
                add_posts({'title' : 'The Great Outdoors',}, index, mode='newznab&newznab=11721',thumb='http://thetvdb.com/banners/posters/179411-1.jpg')
                add_posts({'title' : 'The Unbelievable Truth',}, index, mode='newznab&newznab=33061',thumb='http://thetvdb.com/banners/posters/263188-1.jpg')
                add_posts({'title' : 'the woodlies',}, index, mode='newznab&newznab=32433',thumb='http://thetvdb.com/banners/posters/256321-1.jpg')
                add_posts({'title' : 'The X Factor AU',}, index, mode='newznab&newznab=6314',thumb='http://thetvdb.com/banners/posters/75393-1.jpg')
                add_posts({'title' : 'The Zoo',}, index, mode='newznab&newznab=18424',thumb='http://thetvdb.com/banners/posters/100211-1.jpg')
                add_posts({'title' : 'Wild Boys',}, index, mode='newznab&newznab=29459',thumb='http://thetvdb.com/banners/posters/251453-1.jpg')
                add_posts({'title' : 'Winners And Losers',}, index, mode='newznab&newznab=27172',thumb='http://thetvdb.com/banners/posters/242671-1.jpg')
            if newznab_id == 'Showcase':
                add_posts({'title' : 'Almost Heroes',}, index, mode='newznab&newznab=28614',thumb='http://thetvdb.com/banners/posters/248533-1.jpg')
                add_posts({'title' : 'Continuum',}, index, mode='newznab&newznab=30789',thumb='http://thetvdb.com/banners/posters/258171-1.jpg')
                add_posts({'title' : 'Endgame',}, index, mode='newznab&newznab=27743',thumb='http://thetvdb.com/banners/posters/228031-1.jpg')
                add_posts({'title' : 'Kenny Vs Spenny',}, index, mode='newznab&newznab=1295',thumb='http://thetvdb.com/banners/posters/73062-1.jpg')
                add_posts({'title' : 'Lost Girl',}, index, mode='newznab&newznab=26401',thumb='http://thetvdb.com/banners/posters/182061-1.jpg')
                add_posts({'title' : 'Single White Spenny',}, index, mode='newznab&newznab=28628',thumb='http://thetvdb.com/banners/posters/248625-1.jpg')
                add_posts({'title' : 'World Without End',}, index, mode='newznab&newznab=28588',thumb='http://thetvdb.com/banners/posters/261656-1.jpg')
                add_posts({'title' : 'XIII The Series',}, index, mode='newznab&newznab=27727')
            if newznab_id == 'Showtime':
                add_posts({'title' : 'Brotherhood',}, index, mode='newznab&newznab=6823',thumb='http://thetvdb.com/banners/posters/79356-1.jpg')
                add_posts({'title' : 'Californication',}, index, mode='newznab&newznab=15319',thumb='http://thetvdb.com/banners/posters/80349-1.jpg')
                add_posts({'title' : 'Daves Old Porn',}, index, mode='newznab&newznab=29829',thumb='http://thetvdb.com/banners/posters/252798-1.jpg')
                add_posts({'title' : 'Dead Mans Gun',}, index, mode='newznab&newznab=3264',thumb='http://thetvdb.com/banners/posters/73600-1.jpg')
                add_posts({'title' : 'Dexter',}, index, mode='newznab&newznab=7926',thumb='http://thetvdb.com/banners/posters/79349-1.jpg')
                add_posts({'title' : 'Episodes',}, index, mode='newznab&newznab=23953',thumb='http://thetvdb.com/banners/posters/123581-1.jpg')
                add_posts({'title' : 'Gigolos',}, index, mode='newznab&newznab=27884',thumb='http://thetvdb.com/banners/posters/245941-1.jpg')
                add_posts({'title' : 'Homeland',}, index, mode='newznab&newznab=27811',thumb='http://thetvdb.com/banners/posters/247897-1.jpg')
                add_posts({'title' : 'House of Lies',}, index, mode='newznab&newznab=27561',thumb='http://thetvdb.com/banners/posters/247909-1.jpg')
                add_posts({'title' : 'Huff',}, index, mode='newznab&newznab=3925',thumb='http://thetvdb.com/banners/posters/74663-1.jpg')
                add_posts({'title' : 'Inside Comedy',}, index, mode='newznab&newznab=30538',thumb='http://thetvdb.com/banners/posters/255569-1.jpg')
                add_posts({'title' : 'Look',}, index, mode='newznab&newznab=30610',thumb='http://thetvdb.com/banners/posters/87821-1.jpg')
                add_posts({'title' : 'Next Stop for Charlie',}, index, mode='newznab&newznab=33416',thumb='http://thetvdb.com/banners/posters/264884-1.jpg')
                add_posts({'title' : 'Nurse Jackie',}, index, mode='newznab&newznab=19651',thumb='http://thetvdb.com/banners/posters/95731-1.jpg')
                add_posts({'title' : 'Odyssey 5',}, index, mode='newznab&newznab=4705',thumb='http://thetvdb.com/banners/posters/70694-1.jpg')
                add_posts({'title' : 'Penn and Teller Bullshit',}, index, mode='newznab&newznab=4795',thumb='http://thetvdb.com/banners/posters/72301-1.jpg')
                add_posts({'title' : 'Polyamory Married and Dating',}, index, mode='newznab&newznab=32234')
                add_posts({'title' : 'Reality Show',}, index, mode='newznab&newznab=33480',thumb='http://thetvdb.com/banners/posters/263449-1.jpg')
                add_posts({'title' : 'Shameless UK',}, index, mode='newznab&newznab=25117',thumb='http://thetvdb.com/banners/posters/161511-1.jpg')
                add_posts({'title' : 'Shameless US',}, index, mode='newznab&newznab=25117',thumb='http://thetvdb.com/banners/posters/161511-1.jpg')
                add_posts({'title' : 'Sleeper Cell',}, index, mode='newznab&newznab=6767',thumb='http://thetvdb.com/banners/posters/74843-1.jpg')
                add_posts({'title' : 'The Borgias',}, index, mode='newznab&newznab=24608',thumb='http://thetvdb.com/banners/posters/187881-1.jpg')
                add_posts({'title' : 'The L Word',}, index, mode='newznab&newznab=5957',thumb='http://thetvdb.com/banners/posters/72477-1.jpg')
                add_posts({'title' : 'The Paper Chase',}, index, mode='newznab&newznab=190',thumb='http://thetvdb.com/banners/posters/73769-1.jpg')
                add_posts({'title' : 'The Real L Word',}, index, mode='newznab&newznab=25554',thumb='http://thetvdb.com/banners/posters/171241-1.jpg')
                add_posts({'title' : 'The Tudors',}, index, mode='newznab&newznab=7927',thumb='http://thetvdb.com/banners/posters/79925-1.jpg')
                add_posts({'title' : 'United States of Tara',}, index, mode='newznab&newznab=20601',thumb='http://thetvdb.com/banners/posters/83463-1.jpg')
                add_posts({'title' : 'Unites States of Tara',}, index, mode='newznab&newznab=20601',thumb='http://thetvdb.com/banners/posters/83463-1.jpg')
                add_posts({'title' : 'Web Therapy',}, index, mode='newznab&newznab=28687',thumb='http://thetvdb.com/banners/posters/144201-1.jpg')
                add_posts({'title' : 'Weeds',}, index, mode='newznab&newznab=6554',thumb='http://thetvdb.com/banners/posters/74845-1.jpg')
            if newznab_id == 'Sky Arts 1':
                add_posts({'title' : 'The South Bank Show',}, index, mode='newznab&newznab=6208',thumb='http://thetvdb.com/banners/posters/74728-1.jpg')
            if newznab_id == 'Sky Atlantic':
                add_posts({'title' : 'Hit and Miss',}, index, mode='newznab&newznab=30125',thumb='http://thetvdb.com/banners/posters/256637-1.jpg')
                add_posts({'title' : 'Hunderby',}, index, mode='newznab&newznab=32483',thumb='http://thetvdb.com/banners/posters/261711-1.jpg')
                add_posts({'title' : 'The British',}, index, mode='newznab&newznab=32470',thumb='http://thetvdb.com/banners/posters/262192-1.jpg')
                add_posts({'title' : 'This Is Jinsy',}, index, mode='newznab&newznab=29407',thumb='http://thetvdb.com/banners/posters/150231-1.jpg')
                add_posts({'title' : 'Walking And Talking',}, index, mode='newznab&newznab=31938',thumb='http://thetvdb.com/banners/posters/259818-1.jpg')
            if newznab_id == 'Sky Living':
                add_posts({'title' : 'Battle Of The Brides',}, index, mode='newznab&newznab=31491',thumb='http://thetvdb.com/banners/posters/259183-1.jpg')
                add_posts({'title' : 'Bedlam',}, index, mode='newznab&newznab=27496',thumb='http://thetvdb.com/banners/posters/220801-1.jpg')
                add_posts({'title' : 'Cooks to Market',}, index, mode='newznab&newznab=32469',thumb='http://thetvdb.com/banners/posters/262161-1.jpg')
                add_posts({'title' : 'Dating In The Dark AU',}, index, mode='newznab&newznab=23798')
                add_posts({'title' : 'Four Weddings',}, index, mode='newznab&newznab=23066',thumb='http://thetvdb.com/banners/posters/103001-1.jpg')
                add_posts({'title' : 'Gates',}, index, mode='newznab&newznab=32447',thumb='http://thetvdb.com/banners/posters/261481-1.jpg')
                add_posts({'title' : 'Katie',}, index, mode='newznab&newznab=27754',thumb='http://thetvdb.com/banners/posters/246021-1.jpg')
                add_posts({'title' : 'Mount Pleasant',}, index, mode='newznab&newznab=29115',thumb='http://thetvdb.com/banners/posters/250049-1.jpg')
                add_posts({'title' : 'Psychic Sally On The Road',}, index, mode='newznab&newznab=24763')
                add_posts({'title' : 'Styled to Rock',}, index, mode='newznab&newznab=32235',thumb='http://thetvdb.com/banners/posters/261585-1.jpg')
                add_posts({'title' : 'The Biggest Loser UK',}, index, mode='newznab&newznab=8238',thumb='http://thetvdb.com/banners/posters/92371-1.jpg')
            if newznab_id == 'Sky1':
                add_posts({'title' : 'A Different Breed',}, index, mode='newznab&newznab=27831')
                add_posts({'title' : 'A Touch Of Cloth',}, index, mode='newznab&newznab=30988',thumb='http://thetvdb.com/banners/posters/260750-1.jpg')
                add_posts({'title' : 'An Idiot Abroad',}, index, mode='newznab&newznab=26548',thumb='http://thetvdb.com/banners/posters/187071-1.jpg')
                add_posts({'title' : 'Brainiac History Abuse',}, index, mode='newznab&newznab=13919',thumb='http://thetvdb.com/banners/posters/73653-1.jpg')
                add_posts({'title' : 'Brainiac Science Abuse',}, index, mode='newznab&newznab=2891',thumb='http://thetvdb.com/banners/posters/75052-1.jpg')
                add_posts({'title' : 'Emergency With Angela Griffin',}, index, mode='newznab&newznab=28034',thumb='http://thetvdb.com/banners/posters/255405-1.jpg')
                add_posts({'title' : 'Mad Dogs',}, index, mode='newznab&newznab=27437',thumb='http://thetvdb.com/banners/posters/217071-1.jpg')
                add_posts({'title' : 'Martina Coles The Runaway',}, index, mode='newznab&newznab=27784')
                add_posts({'title' : 'Moone Boy',}, index, mode='newznab&newznab=30779',thumb='http://thetvdb.com/banners/posters/260871-1.jpg')
                add_posts({'title' : 'Must Be The Music',}, index, mode='newznab&newznab=26259',thumb='http://thetvdb.com/banners/posters/184061-1.jpg')
                add_posts({'title' : 'Parents',}, index, mode='newznab&newznab=32022',thumb='http://thetvdb.com/banners/posters/260497-1.jpg')
                add_posts({'title' : 'Ross Kemp Extreme World',}, index, mode='newznab&newznab=27554',thumb='http://thetvdb.com/banners/posters/233931-1.jpg')
                add_posts({'title' : 'Sinbad',}, index, mode='newznab&newznab=31744',thumb='http://thetvdb.com/banners/posters/258743-1.jpg')
                add_posts({'title' : 'Spy 2011',}, index, mode='newznab&newznab=28453',thumb='http://thetvdb.com/banners/posters/252115-1.jpg')
                add_posts({'title' : 'Starlings',}, index, mode='newznab&newznab=31540',thumb='http://thetvdb.com/banners/posters/258966-1.jpg')
                add_posts({'title' : 'Stella UK',}, index, mode='newznab&newznab=30379')
                add_posts({'title' : 'The Angel',}, index, mode='newznab&newznab=32207',thumb='http://thetvdb.com/banners/posters/260970-1.jpg')
                add_posts({'title' : 'The Take',}, index, mode='newznab&newznab=23324',thumb='http://thetvdb.com/banners/posters/100002-1.jpg')
                add_posts({'title' : 'Trollied',}, index, mode='newznab&newznab=28897',thumb='http://thetvdb.com/banners/posters/250436-1.jpg')
            if newznab_id == 'Slice':
                add_posts({'title' : 'The Real Housewives of Vancouver',}, index, mode='newznab&newznab=31344',thumb='http://thetvdb.com/banners/posters/256513-1.jpg')
            if newznab_id == 'Smithsonian Channel':
                add_posts({'title' : 'Helicopter Missions',}, index, mode='newznab&newznab=26980',thumb='http://thetvdb.com/banners/posters/262547-1.jpg')
                add_posts({'title' : 'Mussolini in Color',}, index, mode='newznab&newznab=30289')
                add_posts({'title' : 'Nick Bakers Weird Creatures',}, index, mode='newznab&newznab=24219',thumb='http://thetvdb.com/banners/posters/124161-1.jpg')
                add_posts({'title' : 'Pioneers Turned Millionaires',}, index, mode='newznab&newznab=30046',thumb='http://thetvdb.com/banners/posters/254671-1.jpg')
                add_posts({'title' : 'Stories From The Vaults',}, index, mode='newznab&newznab=24292',thumb='http://thetvdb.com/banners/posters/197621-1.jpg')
            if newznab_id == 'Southern Cross Ten':
                add_posts({'title' : 'Let The Blood Run Free',}, index, mode='newznab&newznab=11589',thumb='http://thetvdb.com/banners/posters/113751-1.jpg')
                add_posts({'title' : 'Russell Coights All Aussie Adventures',}, index, mode='newznab&newznab=12002',thumb='http://thetvdb.com/banners/posters/71297-1.jpg')
            if newznab_id == 'SPACE':
                add_posts({'title' : 'Charlie Jade',}, index, mode='newznab&newznab=3037',thumb='http://thetvdb.com/banners/posters/73873-2.jpg')
                add_posts({'title' : 'Lexx',}, index, mode='newznab&newznab=4225',thumb='http://thetvdb.com/banners/posters/72854-1.jpg')
                add_posts({'title' : 'Primeval New World',}, index, mode='newznab&newznab=29754',thumb='http://thetvdb.com/banners/posters/253042-1.jpg')
                add_posts({'title' : 'Stormworld',}, index, mode='newznab&newznab=22088',thumb='http://thetvdb.com/banners/posters/85651-1.jpg')
                add_posts({'title' : 'Todd and the Book of Pure Evil',}, index, mode='newznab&newznab=26726',thumb='http://thetvdb.com/banners/posters/194041-1.jpg')
            if newznab_id == 'SPEED':
                add_posts({'title' : 'Dumbest Stuff on Wheels',}, index, mode='newznab&newznab=29104',thumb='http://thetvdb.com/banners/posters/254577-1.jpg')
                add_posts({'title' : 'My Ride Rules',}, index, mode='newznab&newznab=29105',thumb='http://thetvdb.com/banners/posters/250712-1.jpg')
                add_posts({'title' : 'The Car Show 2011',}, index, mode='newznab&newznab=28944')
            if newznab_id == 'Speed Channel':
                add_posts({'title' : 'Car Warriors',}, index, mode='newznab&newznab=27733',thumb='http://thetvdb.com/banners/posters/234731-1.jpg')
                add_posts({'title' : 'Hard Parts South Bronx',}, index, mode='newznab&newznab=31690',thumb='http://thetvdb.com/banners/posters/258942-1.jpg')
            if newznab_id == 'Spike TV':
                add_posts({'title' : '1 000 Ways to Die',}, index, mode='newznab&newznab=25210')
                add_posts({'title' : '1000 Ways to Die',}, index, mode='newznab&newznab=21012',thumb='http://thetvdb.com/banners/posters/82083-1.jpg')
                add_posts({'title' : 'American Digger',}, index, mode='newznab&newznab=29465',thumb='http://thetvdb.com/banners/posters/256657-1.jpg')
                add_posts({'title' : 'Auction Hunters',}, index, mode='newznab&newznab=26960',thumb='http://thetvdb.com/banners/posters/204371-1.jpg')
                add_posts({'title' : 'Bar Rescue',}, index, mode='newznab&newznab=28764',thumb='http://thetvdb.com/banners/posters/250071-1.jpg')
                add_posts({'title' : 'big easy justice',}, index, mode='newznab&newznab=29466',thumb='http://thetvdb.com/banners/posters/258127-1.jpg')
                add_posts({'title' : 'Blue Mountain State',}, index, mode='newznab&newznab=22667',thumb='http://thetvdb.com/banners/posters/134511-1.jpg')
                add_posts({'title' : 'Coal',}, index, mode='newznab&newznab=26802',thumb='http://thetvdb.com/banners/posters/218481-1.jpg')
                add_posts({'title' : 'DEA 2008',}, index, mode='newznab&newznab=18680')
                add_posts({'title' : 'Deadliest Warrior',}, index, mode='newznab&newznab=21624',thumb='http://thetvdb.com/banners/posters/89211-1.jpg')
                add_posts({'title' : 'Diamond Divers',}, index, mode='newznab&newznab=30122',thumb='http://thetvdb.com/banners/posters/259816-1.jpg')
                add_posts({'title' : 'Flip Men',}, index, mode='newznab&newznab=29698',thumb='http://thetvdb.com/banners/posters/252799-1.jpg')
                add_posts({'title' : 'GameTrailers TV With Geoff Keighley',}, index, mode='newznab&newznab=22192')
                add_posts({'title' : 'Ink Master',}, index, mode='newznab&newznab=30528',thumb='http://thetvdb.com/banners/posters/254986-1.jpg')
                add_posts({'title' : 'Jail',}, index, mode='newznab&newznab=17307',thumb='http://thetvdb.com/banners/posters/83051-1.jpg')
                add_posts({'title' : 'Manswers',}, index, mode='newznab&newznab=17700',thumb='http://thetvdb.com/banners/posters/80556-1.jpg')
                add_posts({'title' : 'Rat Bastards',}, index, mode='newznab&newznab=30817',thumb='http://thetvdb.com/banners/posters/260876-1.jpg')
                add_posts({'title' : 'Repo Games',}, index, mode='newznab&newznab=27987',thumb='http://thetvdb.com/banners/posters/248328-1.jpg')
                add_posts({'title' : 'Tattoo Nightmares',}, index, mode='newznab&newznab=30816',thumb='http://thetvdb.com/banners/posters/262998-1.jpg')
                add_posts({'title' : 'Tattoo Rescue',}, index, mode='newznab&newznab=32697',thumb='http://thetvdb.com/banners/posters/262914-1.jpg')
                add_posts({'title' : 'Undercover Stings',}, index, mode='newznab&newznab=29468',thumb='http://thetvdb.com/banners/posters/258857-1.jpg')
                add_posts({'title' : 'Worlds Wildest Police Videos',}, index, mode='newznab&newznab=2376',thumb='http://thetvdb.com/banners/posters/75626-1.jpg')
                add_posts({'title' : 'Worlds Worst Tenants',}, index, mode='newznab&newznab=29467',thumb='http://thetvdb.com/banners/posters/259295-1.jpg')
            if newznab_id == 'Starz':
                add_posts({'title' : 'Boss',}, index, mode='newznab&newznab=28380',thumb='http://thetvdb.com/banners/posters/97221-1.jpg')
                add_posts({'title' : 'Camelot',}, index, mode='newznab&newznab=23669',thumb='http://thetvdb.com/banners/posters/208791-1.jpg')
                add_posts({'title' : 'Gravity',}, index, mode='newznab&newznab=24920',thumb='http://thetvdb.com/banners/posters/142861-1.jpg')
                add_posts({'title' : 'Head Case',}, index, mode='newznab&newznab=18286',thumb='http://thetvdb.com/banners/posters/81414-1.jpg')
                add_posts({'title' : 'Magic City',}, index, mode='newznab&newznab=29628',thumb='http://thetvdb.com/banners/posters/210961-1.jpg')
                add_posts({'title' : 'Martin Lawrence Presents 1st Amendment Stand Up',}, index, mode='newznab&newznab=19263',thumb='http://thetvdb.com/banners/posters/84209-1.jpg')
                add_posts({'title' : 'Spartacus Gods Of The Arena',}, index, mode='newznab&newznab=26886')
            if newznab_id == 'STV Scotland TV':
                add_posts({'title' : 'Taggart',}, index, mode='newznab&newznab=5444',thumb='http://thetvdb.com/banners/posters/71545-1.jpg')
            if newznab_id == 'Style':
                add_posts({'title' : 'Big Rich Texas',}, index, mode='newznab&newznab=28933',thumb='http://thetvdb.com/banners/posters/250339-1.jpg')
                add_posts({'title' : 'Chicagolicious',}, index, mode='newznab&newznab=31811',thumb='http://thetvdb.com/banners/posters/259917-1.jpg')
                add_posts({'title' : 'Clean House New York',}, index, mode='newznab&newznab=28445')
                add_posts({'title' : 'Clean House',}, index, mode='newznab&newznab=3082',thumb='http://thetvdb.com/banners/posters/74140-1.jpg')
                add_posts({'title' : 'Empire Girls Julissa And Adrienne',}, index, mode='newznab&newznab=31778',thumb='http://thetvdb.com/banners/posters/258803-1.jpg')
                add_posts({'title' : 'Giuliana and Bill',}, index, mode='newznab&newznab=23231')
                add_posts({'title' : 'Glam Fairy',}, index, mode='newznab&newznab=28463',thumb='http://thetvdb.com/banners/posters/252499-1.jpg')
                add_posts({'title' : 'How Do I Look',}, index, mode='newznab&newznab=3915',thumb='http://thetvdb.com/banners/posters/73660-1.jpg')
                add_posts({'title' : 'Jerseylicious',}, index, mode='newznab&newznab=24906',thumb='http://thetvdb.com/banners/posters/185651-1.jpg')
                add_posts({'title' : 'Mel B Its A Scary World',}, index, mode='newznab&newznab=26228',thumb='http://thetvdb.com/banners/posters/189291-1.jpg')
                add_posts({'title' : 'Momster of the Bride',}, index, mode='newznab&newznab=29076',thumb='http://thetvdb.com/banners/posters/252039-1.jpg')
                add_posts({'title' : 'Style Exposed',}, index, mode='newznab&newznab=28879',thumb='http://thetvdb.com/banners/posters/250340-1.jpg')
                add_posts({'title' : 'Tia And Tamera',}, index, mode='newznab&newznab=27431',thumb='http://thetvdb.com/banners/posters/250830-1.jpg')
                add_posts({'title' : 'Too Fat For 15 Fighting Back',}, index, mode='newznab&newznab=26216')
                add_posts({'title' : 'Wicked Fit',}, index, mode='newznab&newznab=29694',thumb='http://thetvdb.com/banners/posters/253749-1.jpg')
            if newznab_id == 'SUN TV':
                add_posts({'title' : 'Birdy The Mighty Decode',}, index, mode='newznab&newznab=19809',thumb='http://thetvdb.com/banners/posters/82884-1.jpg')
            if newznab_id == 'Sundance':
                add_posts({'title' : 'Brick City',}, index, mode='newznab&newznab=23236',thumb='http://thetvdb.com/banners/posters/148231-1.jpg')
                add_posts({'title' : 'Love Lust',}, index, mode='newznab&newznab=27611')
                add_posts({'title' : 'Push Girls',}, index, mode='newznab&newznab=31795',thumb='http://thetvdb.com/banners/posters/258674-1.jpg')
                add_posts({'title' : 'Spectacle Elvis Costello With',}, index, mode='newznab&newznab=20626',thumb='http://thetvdb.com/banners/posters/84270-1.jpg')
                add_posts({'title' : 'The Mortified Sessions',}, index, mode='newznab&newznab=30161')
            if newznab_id == 'SVT1':
                add_posts({'title' : 'starke man',}, index, mode='newznab&newznab=26706',thumb='http://thetvdb.com/banners/posters/193341-1.jpg')
            if newznab_id == 'Syfy':
                add_posts({'title' : 'Alphas',}, index, mode='newznab&newznab=19268',thumb='http://thetvdb.com/banners/posters/210841-1.jpg')
                add_posts({'title' : 'Andromeda',}, index, mode='newznab&newznab=2608',thumb='http://thetvdb.com/banners/posters/77544-1.jpg')
                add_posts({'title' : 'Battlestar Galactica',}, index, mode='newznab&newznab=2730',thumb='http://thetvdb.com/banners/posters/71173-1.jpg')
                add_posts({'title' : 'Being Human US',}, index, mode='newznab&newznab=24595',thumb='http://thetvdb.com/banners/posters/196921-1.jpg')
                add_posts({'title' : 'Caprica',}, index, mode='newznab&newznab=11011',thumb='http://thetvdb.com/banners/posters/85040-1.jpg')
                add_posts({'title' : 'Collection Intervention',}, index, mode='newznab&newznab=31507',thumb='http://thetvdb.com/banners/posters/261221-1.jpg')
                add_posts({'title' : 'Destination Truth',}, index, mode='newznab&newznab=11110',thumb='http://thetvdb.com/banners/posters/80251-1.jpg')
                add_posts({'title' : 'Dream Machines',}, index, mode='newznab&newznab=29598',thumb='http://thetvdb.com/banners/posters/257713-1.jpg')
                add_posts({'title' : 'Eureka',}, index, mode='newznab&newznab=7506',thumb='http://thetvdb.com/banners/posters/79334-1.jpg')
                add_posts({'title' : 'Face Off',}, index, mode='newznab&newznab=27213',thumb='http://thetvdb.com/banners/posters/214831-1.jpg')
                add_posts({'title' : 'Fact or Faked Paranormal Files',}, index, mode='newznab&newznab=25861',thumb='http://thetvdb.com/banners/posters/175861-1.jpg')
                add_posts({'title' : 'Farscape',}, index, mode='newznab&newznab=3519',thumb='http://thetvdb.com/banners/posters/70522-1.jpg')
                add_posts({'title' : 'First Wave',}, index, mode='newznab&newznab=3552',thumb='http://thetvdb.com/banners/posters/74476-1.jpg')
                add_posts({'title' : 'Ghost Hunters International',}, index, mode='newznab&newznab=17809',thumb='http://thetvdb.com/banners/posters/81120-1.jpg')
                add_posts({'title' : 'Ghost Hunters',}, index, mode='newznab&newznab=3673',thumb='http://thetvdb.com/banners/posters/77949-1.jpg')
                add_posts({'title' : 'Haunted Collector',}, index, mode='newznab&newznab=28283',thumb='http://thetvdb.com/banners/posters/248838-1.jpg')
                add_posts({'title' : 'Haunted Highway',}, index, mode='newznab&newznab=32057',thumb='http://thetvdb.com/banners/posters/260443-1.jpg')
                add_posts({'title' : 'Haven',}, index, mode='newznab&newznab=24496',thumb='http://thetvdb.com/banners/posters/158661-1.jpg')
                add_posts({'title' : 'Hollywood Treasure',}, index, mode='newznab&newznab=26761',thumb='http://thetvdb.com/banners/posters/201611-1.jpg')
                add_posts({'title' : 'Hot Set',}, index, mode='newznab&newznab=31510',thumb='http://thetvdb.com/banners/posters/261701-1.jpg')
                add_posts({'title' : 'Legend Quest',}, index, mode='newznab&newznab=28680',thumb='http://thetvdb.com/banners/posters/249750-1.jpg')
                add_posts({'title' : 'Monster Man',}, index, mode='newznab&newznab=29866',thumb='http://thetvdb.com/banners/posters/256575-1.jpg')
                add_posts({'title' : 'Neverland',}, index, mode='newznab&newznab=29279',thumb='http://thetvdb.com/banners/posters/249004-1.jpg')
                add_posts({'title' : 'Paranormal Witness',}, index, mode='newznab&newznab=28927',thumb='http://thetvdb.com/banners/posters/251207-1.jpg')
                add_posts({'title' : 'Sanctuary US',}, index, mode='newznab&newznab=18682')
                add_posts({'title' : 'Scare Tactics',}, index, mode='newznab&newznab=5105',thumb='http://thetvdb.com/banners/posters/79263-1.jpg')
                add_posts({'title' : 'School Spirits',}, index, mode='newznab&newznab=29872',thumb='http://thetvdb.com/banners/posters/259817-1.jpg')
                add_posts({'title' : 'Sliders',}, index, mode='newznab&newznab=5222',thumb='http://thetvdb.com/banners/posters/76557-1.jpg')
                add_posts({'title' : 'Stargate Atlantis',}, index, mode='newznab&newznab=5324',thumb='http://thetvdb.com/banners/posters/70851-1.jpg')
                add_posts({'title' : 'Stargate SG 1',}, index, mode='newznab&newznab=5325',thumb='http://thetvdb.com/banners/posters/72449-1.jpg')
                add_posts({'title' : 'Stargate SG1',}, index, mode='newznab&newznab=5325',thumb='http://thetvdb.com/banners/posters/72449-1.jpg')
                add_posts({'title' : 'Stargate Universe',}, index, mode='newznab&newznab=15343',thumb='http://thetvdb.com/banners/posters/83237-1.jpg')
                add_posts({'title' : 'The Phantom',}, index, mode='newznab&newznab=25525',thumb='http://thetvdb.com/banners/posters/158881-1.jpg')
                add_posts({'title' : 'Three Inches',}, index, mode='newznab&newznab=26835',thumb='http://thetvdb.com/banners/posters/254643-1.jpg')
                add_posts({'title' : 'Total Blackout US',}, index, mode='newznab&newznab=30661',thumb='http://thetvdb.com/banners/posters/258154-1.jpg')
                add_posts({'title' : 'Urban Legends',}, index, mode='newznab&newznab=17526',thumb='http://thetvdb.com/banners/posters/96731-1.jpg')
                add_posts({'title' : 'Viral Video Showdown',}, index, mode='newznab&newznab=31508',thumb='http://thetvdb.com/banners/posters/263399-1.jpg')
                add_posts({'title' : 'Warehouse 13',}, index, mode='newznab&newznab=7884',thumb='http://thetvdb.com/banners/posters/84676-1.jpg')
            if newznab_id == 'Syndicated':
                add_posts({'title' : '21 Jump Street',}, index, mode='newznab&newznab=2443',thumb='http://thetvdb.com/banners/posters/77585-1.jpg')
                add_posts({'title' : 'Adventure Inc',}, index, mode='newznab&newznab=2498',thumb='http://thetvdb.com/banners/posters/83647-1.jpg')
                add_posts({'title' : 'Adventures Of Superman',}, index, mode='newznab&newznab=2504',thumb='http://thetvdb.com/banners/posters/77403-1.jpg')
                add_posts({'title' : 'BeastMaster',}, index, mode='newznab&newznab=2740',thumb='http://thetvdb.com/banners/posters/73848-1.jpg')
                add_posts({'title' : 'Bionix Six',}, index, mode='newznab&newznab=2808',thumb='http://thetvdb.com/banners/posters/77816-1.jpg')
                add_posts({'title' : 'Bloopers',}, index, mode='newznab&newznab=32776',thumb='http://thetvdb.com/banners/posters/262474-1.jpg')
                add_posts({'title' : 'Bucky OHare And The Toad Wars',}, index, mode='newznab&newznab=1599',thumb='http://thetvdb.com/banners/posters/76788-1.jpg')
                add_posts({'title' : 'Captain Planet And The Planeteers',}, index, mode='newznab&newznab=2979',thumb='http://thetvdb.com/banners/posters/74142-1.jpg')
                add_posts({'title' : 'Charles In Charge',}, index, mode='newznab&newznab=3032',thumb='http://thetvdb.com/banners/posters/75563-1.jpg')
                add_posts({'title' : 'Chuck Norris Karate Kommandos',}, index, mode='newznab&newznab=10223',thumb='http://thetvdb.com/banners/posters/76276-1.jpg')
                add_posts({'title' : 'Cleopatra 2525',}, index, mode='newznab&newznab=3085',thumb='http://thetvdb.com/banners/posters/71906-1.jpg')
                add_posts({'title' : 'Cobra',}, index, mode='newznab&newznab=1944',thumb='http://thetvdb.com/banners/posters/78278-1.jpg')
                add_posts({'title' : 'Dragnet 1969',}, index, mode='newznab&newznab=3369',thumb='http://thetvdb.com/banners/posters/74467-1.jpg')
                add_posts({'title' : 'DuckTales',}, index, mode='newznab&newznab=3394',thumb='http://thetvdb.com/banners/posters/75931-1.jpg')
                add_posts({'title' : 'Excused',}, index, mode='newznab&newznab=29127',thumb='http://thetvdb.com/banners/posters/262529-1.jpg')
                add_posts({'title' : 'G I Joe',}, index, mode='newznab&newznab=3632',thumb='http://thetvdb.com/banners/posters/77780-1.jpg')
                add_posts({'title' : 'Hercules The Legendary Journeys',}, index, mode='newznab&newznab=3835',thumb='http://thetvdb.com/banners/posters/72497-1.jpg')
                add_posts({'title' : 'Hercules The Lengendary Journeys',}, index, mode='newznab&newznab=3835',thumb='http://thetvdb.com/banners/posters/72497-1.jpg')
                add_posts({'title' : 'Highlander',}, index, mode='newznab&newznab=3850',thumb='http://thetvdb.com/banners/posters/75160-1.jpg')
                add_posts({'title' : 'Inspector Gadget',}, index, mode='newznab&newznab=3971',thumb='http://thetvdb.com/banners/posters/73693-1.jpg')
                add_posts({'title' : 'Jayce and The Wheeled Warriors',}, index, mode='newznab&newznab=4041',thumb='http://thetvdb.com/banners/posters/73016-1.jpg')
                add_posts({'title' : 'Jem',}, index, mode='newznab&newznab=4045',thumb='http://thetvdb.com/banners/posters/78306-1.jpg')
                add_posts({'title' : 'Judge Judy',}, index, mode='newznab&newznab=7960',thumb='http://thetvdb.com/banners/posters/71221-1.jpg')
                add_posts({'title' : 'Legend of the Seeker',}, index, mode='newznab&newznab=19609',thumb='http://thetvdb.com/banners/posters/82672-1.jpg')
                add_posts({'title' : 'Mike Hammer Private Eye',}, index, mode='newznab&newznab=4473',thumb='http://thetvdb.com/banners/posters/76041-1.jpg')
                add_posts({'title' : 'Mr Box Office',}, index, mode='newznab&newznab=31752',thumb='http://thetvdb.com/banners/posters/262885-1.jpg')
                add_posts({'title' : 'Mutant X',}, index, mode='newznab&newznab=4568',thumb='http://thetvdb.com/banners/posters/76533-1.jpg')
                add_posts({'title' : 'Punky Brewster',}, index, mode='newznab&newznab=4915',thumb='http://thetvdb.com/banners/posters/74362-1.jpg')
                add_posts({'title' : 'Rambo',}, index, mode='newznab&newznab=4941',thumb='http://thetvdb.com/banners/posters/76275-1.jpg')
                add_posts({'title' : 'Relic Hunter',}, index, mode='newznab&newznab=4970',thumb='http://thetvdb.com/banners/posters/73810-1.jpg')
                add_posts({'title' : 'Rocky Jones Space Ranger',}, index, mode='newznab&newznab=5042',thumb='http://thetvdb.com/banners/posters/70515-1.jpg')
                add_posts({'title' : 'Saber Rider And The Star Sheriffs',}, index, mode='newznab&newznab=5080',thumb='http://thetvdb.com/banners/posters/70525-1.jpg')
                add_posts({'title' : 'SilverHawks',}, index, mode='newznab&newznab=1867',thumb='http://thetvdb.com/banners/posters/77918-1.jpg')
                add_posts({'title' : 'Small Wonder',}, index, mode='newznab&newznab=5228',thumb='http://thetvdb.com/banners/posters/72206-1.jpg')
                add_posts({'title' : 'Star Blazers US',}, index, mode='newznab&newznab=1838')
                add_posts({'title' : 'Stories Of The Century',}, index, mode='newznab&newznab=1900',thumb='http://thetvdb.com/banners/posters/78108-1.jpg')
                add_posts({'title' : 'Street Justice',}, index, mode='newznab&newznab=5371',thumb='http://thetvdb.com/banners/posters/71052-1.jpg')
                add_posts({'title' : 'TaleSpin',}, index, mode='newznab&newznab=5457',thumb='http://thetvdb.com/banners/posters/75476-1.jpg')
                add_posts({'title' : 'The Adventures Of Sinbad',}, index, mode='newznab&newznab=5541',thumb='http://thetvdb.com/banners/posters/76425-1.jpg')
                add_posts({'title' : 'The Cisco Kid',}, index, mode='newznab&newznab=5684',thumb='http://thetvdb.com/banners/posters/77404-1.jpg')
                add_posts({'title' : 'The First Family',}, index, mode='newznab&newznab=31271',thumb='http://thetvdb.com/banners/posters/262883-1.jpg')
                add_posts({'title' : 'The Pink Panther',}, index, mode='newznab&newznab=6091',thumb='http://thetvdb.com/banners/posters/71554-1.jpg')
                add_posts({'title' : 'The Three Stooges',}, index, mode='newznab&newznab=6236',thumb='http://thetvdb.com/banners/posters/79173-1.jpg')
                add_posts({'title' : 'The Twilight Zone 1961',}, index, mode='newznab&newznab=6259',thumb='http://thetvdb.com/banners/posters/72176-1.jpg')
                add_posts({'title' : 'The Twilight Zone 1962',}, index, mode='newznab&newznab=6259',thumb='http://thetvdb.com/banners/posters/72176-1.jpg')
                add_posts({'title' : 'The Twilight Zone 1963',}, index, mode='newznab&newznab=6259',thumb='http://thetvdb.com/banners/posters/72176-1.jpg')
                add_posts({'title' : 'The Twilight Zone 1964',}, index, mode='newznab&newznab=6259',thumb='http://thetvdb.com/banners/posters/72176-1.jpg')
                add_posts({'title' : 'The Twilight Zone 1985',}, index, mode='newznab&newznab=6259',thumb='http://thetvdb.com/banners/posters/72176-1.jpg')
                add_posts({'title' : 'The Yogi Bear Show',}, index, mode='newznab&newznab=6317',thumb='http://thetvdb.com/banners/posters/72562-1.jpg')
                add_posts({'title' : 'Thundercats',}, index, mode='newznab&newznab=6352',thumb='http://thetvdb.com/banners/posters/70355-1.jpg')
                add_posts({'title' : 'Too Close For Comfort',}, index, mode='newznab&newznab=9',thumb='http://thetvdb.com/banners/posters/78479-1.jpg')
                add_posts({'title' : 'Webster',}, index, mode='newznab&newznab=6552',thumb='http://thetvdb.com/banners/posters/77783-1.jpg')
                add_posts({'title' : 'Xena Warrior Princess',}, index, mode='newznab&newznab=6668',thumb='http://thetvdb.com/banners/posters/77799-1.jpg')
            if newznab_id == 'T E':
                add_posts({'title' : 'Destination Fear',}, index, mode='newznab&newznab=32698',thumb='http://thetvdb.com/banners/posters/263131-1.jpg')
            if newznab_id == 'TBS':
                add_posts({'title' : '10 Items Or Less',}, index, mode='newznab&newznab=10418',thumb='http://thetvdb.com/banners/posters/79599-1.jpg')
                add_posts({'title' : 'are we there yet',}, index, mode='newznab&newznab=24588',thumb='http://thetvdb.com/banners/posters/161491-1.jpg')
                add_posts({'title' : 'Chobits',}, index, mode='newznab&newznab=959',thumb='http://thetvdb.com/banners/posters/72070-1.jpg')
                add_posts({'title' : 'Cougar Town',}, index, mode='newznab&newznab=22626',thumb='http://thetvdb.com/banners/posters/94991-1.jpg')
                add_posts({'title' : 'For Better or Worse 2011',}, index, mode='newznab&newznab=29455')
                add_posts({'title' : 'Men at Work',}, index, mode='newznab&newznab=30613',thumb='http://thetvdb.com/banners/posters/258618-1.jpg')
                add_posts({'title' : 'Sullivan and Son',}, index, mode='newznab&newznab=29677',thumb='http://thetvdb.com/banners/posters/253457-1.jpg')
                add_posts({'title' : 'Tyler Perrys House of Payne',}, index, mode='newznab&newznab=15533',thumb='http://thetvdb.com/banners/posters/80311-1.jpg')
                add_posts({'title' : 'Tyler Perrys Meet the Browns',}, index, mode='newznab&newznab=20623',thumb='http://thetvdb.com/banners/posters/141331-1.jpg')
                add_posts({'title' : 'Wedding Band',}, index, mode='newznab&newznab=29531',thumb='http://thetvdb.com/banners/posters/261765-1.jpg')
            if newznab_id == 'TeleToon':
                add_posts({'title' : 'Clone High USA',}, index, mode='newznab&newznab=3089')
                add_posts({'title' : 'Crash Canyon',}, index, mode='newznab&newznab=31132',thumb='http://thetvdb.com/banners/posters/256623-1.jpg')
            if newznab_id == 'Ten':
                add_posts({'title' : 'Being Lara Bingle',}, index, mode='newznab&newznab=31890',thumb='http://thetvdb.com/banners/posters/259883-1.jpg')
                add_posts({'title' : 'Bondi Rescue',}, index, mode='newznab&newznab=8348',thumb='http://thetvdb.com/banners/posters/81967-1.jpg')
                add_posts({'title' : 'Bondi Vet',}, index, mode='newznab&newznab=24025',thumb='http://thetvdb.com/banners/posters/158701-1.jpg')
                add_posts({'title' : 'Can of Worms',}, index, mode='newznab&newznab=28932',thumb='http://thetvdb.com/banners/posters/249847-1.jpg')
                add_posts({'title' : 'Cybergirl',}, index, mode='newznab&newznab=1853',thumb='http://thetvdb.com/banners/posters/77835-1.jpg')
                add_posts({'title' : 'Dont Tell The Bride AU',}, index, mode='newznab&newznab=32460',thumb='http://thetvdb.com/banners/posters/261663-1.jpg')
                add_posts({'title' : 'Every Body Dance Now',}, index, mode='newznab&newznab=32332',thumb='http://thetvdb.com/banners/posters/261495-1.jpg')
                add_posts({'title' : 'Good News Week',}, index, mode='newznab&newznab=11709',thumb='http://thetvdb.com/banners/posters/85357-1.jpg')
                add_posts({'title' : 'Junior MasterChef Australia',}, index, mode='newznab&newznab=26643',thumb='http://thetvdb.com/banners/posters/189261-1.jpg')
                add_posts({'title' : 'Lightning Point',}, index, mode='newznab&newznab=31760',thumb='http://thetvdb.com/banners/posters/259014-1.jpg')
                add_posts({'title' : 'Masterchef Australia',}, index, mode='newznab&newznab=25606',thumb='http://thetvdb.com/banners/posters/92091-1.jpg')
                add_posts({'title' : 'Number 96',}, index, mode='newznab&newznab=1582',thumb='http://thetvdb.com/banners/posters/76723-1.jpg')
                add_posts({'title' : 'Prisoner Cell Block H',}, index, mode='newznab&newznab=4896',thumb='http://thetvdb.com/banners/posters/76724-1.jpg')
                add_posts({'title' : 'Puberty Blues',}, index, mode='newznab&newznab=32287',thumb='http://thetvdb.com/banners/posters/261251-1.jpg')
                add_posts({'title' : 'State Coroner',}, index, mode='newznab&newznab=1732',thumb='http://thetvdb.com/banners/posters/77379-1.jpg')
                add_posts({'title' : 'Talkin Bout Your Generation',}, index, mode='newznab&newznab=23032',thumb='http://thetvdb.com/banners/posters/96001-1.jpg')
                add_posts({'title' : 'The Biggest Loser AU',}, index, mode='newznab&newznab=8237')
                add_posts({'title' : 'The Living Room',}, index, mode='newznab&newznab=31584',thumb='http://thetvdb.com/banners/posters/259381-1.jpg')
                add_posts({'title' : 'The Secret Life Of Us',}, index, mode='newznab&newznab=6177',thumb='http://thetvdb.com/banners/posters/81636-1.jpg')
                add_posts({'title' : 'The Shire',}, index, mode='newznab&newznab=32231',thumb='http://thetvdb.com/banners/posters/260677-1.jpg')
                add_posts({'title' : 'Young Talent Time 2012',}, index, mode='newznab&newznab=30649',thumb='http://thetvdb.com/banners/posters/255457-1.jpg')
                add_posts({'title' : 'Young Talent Time',}, index, mode='newznab&newznab=1963')
            if newznab_id == 'The 101':
                add_posts({'title' : 'Friday Night Lights',}, index, mode='newznab&newznab=7990',thumb='http://thetvdb.com/banners/posters/79337-1.jpg')
            if newznab_id == 'The Comedy Channel':
                add_posts({'title' : 'You Have Been Watching AU',}, index, mode='newznab&newznab=27889')
            if newznab_id == 'The Comedy Channel Australia':
                add_posts({'title' : 'Balls Of Steel Australia',}, index, mode='newznab&newznab=28169',thumb='http://thetvdb.com/banners/posters/248103-1.jpg')
            if newznab_id == 'The Comedy Network':
                add_posts({'title' : 'Just For Laughs Gags',}, index, mode='newznab&newznab=7822',thumb='http://thetvdb.com/banners/posters/210491-1.jpg')
            if newznab_id == 'The CW':
                add_posts({'title' : '90210',}, index, mode='newznab&newznab=18813',thumb='http://thetvdb.com/banners/posters/82716-1.jpg')
                add_posts({'title' : 'Amazon',}, index, mode='newznab&newznab=32759',thumb='http://thetvdb.com/banners/posters/83082-1.jpg')
                add_posts({'title' : 'Americas Next Top Model',}, index, mode='newznab&newznab=2589',thumb='http://thetvdb.com/banners/posters/71721-1.jpg')
                add_posts({'title' : 'Arrow',}, index, mode='newznab&newznab=30715',thumb='http://thetvdb.com/banners/posters/257655-1.jpg')
                add_posts({'title' : 'Beauty and the Beast 2012',}, index, mode='newznab&newznab=30717',thumb='http://thetvdb.com/banners/posters/258959-1.jpg')
                add_posts({'title' : 'Breaking Pointe',}, index, mode='newznab&newznab=31072',thumb='http://thetvdb.com/banners/posters/258502-1.jpg')
                add_posts({'title' : 'Emily Owens M D',}, index, mode='newznab&newznab=31711',thumb='http://thetvdb.com/banners/posters/259106-1.jpg')
                add_posts({'title' : 'Emily Owens MD',}, index, mode='newznab&newznab=31711',thumb='http://thetvdb.com/banners/posters/259106-1.jpg')
                add_posts({'title' : 'Farmer Wants A Wife AU',}, index, mode='newznab&newznab=15812')
                add_posts({'title' : 'Gilmore Girls',}, index, mode='newznab&newznab=3683',thumb='http://thetvdb.com/banners/posters/76568-1.jpg')
                add_posts({'title' : 'Gossip Girl',}, index, mode='newznab&newznab=15619',thumb='http://thetvdb.com/banners/posters/80547-1.jpg')
                add_posts({'title' : 'H8R',}, index, mode='newznab&newznab=28425',thumb='http://thetvdb.com/banners/posters/249491-1.jpg')
                add_posts({'title' : 'Hart if Dixie',}, index, mode='newznab&newznab=28422',thumb='http://thetvdb.com/banners/posters/248880-1.jpg')
                add_posts({'title' : 'Hart of Dixie',}, index, mode='newznab&newznab=28422',thumb='http://thetvdb.com/banners/posters/248880-1.jpg')
                add_posts({'title' : 'Hellcats',}, index, mode='newznab&newznab=25658',thumb='http://thetvdb.com/banners/posters/164401-1.jpg')
                add_posts({'title' : 'Kamen Rider Dragon Knight',}, index, mode='newznab&newznab=17061',thumb='http://thetvdb.com/banners/posters/84758-1.jpg')
                add_posts({'title' : 'Life Unexpected',}, index, mode='newznab&newznab=23114',thumb='http://thetvdb.com/banners/posters/95511-1.jpg')
                add_posts({'title' : 'Nikita',}, index, mode='newznab&newznab=25189',thumb='http://thetvdb.com/banners/posters/164301-1.jpg')
                add_posts({'title' : 'Oh Sit',}, index, mode='newznab&newznab=31953',thumb='http://thetvdb.com/banners/posters/260088-1.jpg')
                add_posts({'title' : 'One Tree Hill',}, index, mode='newznab&newznab=4724',thumb='http://thetvdb.com/banners/posters/72158-1.jpg')
                add_posts({'title' : 'Reba',}, index, mode='newznab&newznab=4952',thumb='http://thetvdb.com/banners/posters/71550-1.jpg')
                add_posts({'title' : 'Remodeled',}, index, mode='newznab&newznab=28426',thumb='http://thetvdb.com/banners/posters/253313-1.jpg')
                add_posts({'title' : 'Ringer',}, index, mode='newznab&newznab=27457',thumb='http://thetvdb.com/banners/posters/248868-1.jpg')
                add_posts({'title' : 'Shedding for the Wedding',}, index, mode='newznab&newznab=25789',thumb='http://thetvdb.com/banners/posters/213141-1.jpg')
                add_posts({'title' : 'Smallville',}, index, mode='newznab&newznab=5227',thumb='http://thetvdb.com/banners/posters/72218-1.jpg')
                add_posts({'title' : 'Supernatural',}, index, mode='newznab&newznab=5410',thumb='http://thetvdb.com/banners/posters/78901-1.jpg')
                add_posts({'title' : 'The Batman',}, index, mode='newznab&newznab=5602',thumb='http://thetvdb.com/banners/posters/73180-1.jpg')
                add_posts({'title' : 'The Catalina',}, index, mode='newznab&newznab=31073',thumb='http://thetvdb.com/banners/posters/258501-1.jpg')
                add_posts({'title' : 'The Secret Circle',}, index, mode='newznab&newznab=28423',thumb='http://thetvdb.com/banners/posters/248884-1.jpg')
                add_posts({'title' : 'The Vampire Diaries',}, index, mode='newznab&newznab=21766',thumb='http://thetvdb.com/banners/posters/95491-1.jpg')
                add_posts({'title' : 'Veronica Mars',}, index, mode='newznab&newznab=6507',thumb='http://thetvdb.com/banners/posters/73730-1.jpg')
                add_posts({'title' : 'World of Quest',}, index, mode='newznab&newznab=18987',thumb='http://thetvdb.com/banners/posters/81576-1.jpg')
            if newznab_id == 'The Family Channel':
                add_posts({'title' : 'The Adventures Of The Black Stallion',}, index, mode='newznab&newznab=5549',thumb='http://thetvdb.com/banners/posters/76878-1.jpg')
                add_posts({'title' : 'Zorro 1990',}, index, mode='newznab&newznab=6707',thumb='http://thetvdb.com/banners/posters/73662-1.jpg')
            if newznab_id == 'The History Channel AU':
                add_posts({'title' : 'Tony Robinson Explores Australia',}, index, mode='newznab&newznab=28768',thumb='http://thetvdb.com/banners/posters/248470-1.jpg')
            if newznab_id == 'The Movie Network':
                add_posts({'title' : 'G Spot',}, index, mode='newznab&newznab=3630',thumb='http://thetvdb.com/banners/posters/81757-1.jpg')
                add_posts({'title' : 'Good God',}, index, mode='newznab&newznab=31748',thumb='http://thetvdb.com/banners/posters/257408-1.jpg')
                add_posts({'title' : 'Living in Your Car',}, index, mode='newznab&newznab=24531',thumb='http://thetvdb.com/banners/posters/161921-1.jpg')
                add_posts({'title' : 'ReGenesis',}, index, mode='newznab&newznab=4964',thumb='http://thetvdb.com/banners/posters/74948-1.jpg')
                add_posts({'title' : 'Slings and Arrows',}, index, mode='newznab&newznab=1358',thumb='http://thetvdb.com/banners/posters/79874-1.jpg')
            if newznab_id == 'The Outdoor Channel':
                add_posts({'title' : 'Shawn Michaels MacMillan River Adventures',}, index, mode='newznab&newznab=28854',thumb='http://thetvdb.com/banners/posters/251155-1.jpg')
            if newznab_id == 'The Science Channel':
                add_posts({'title' : 'Colossal Construction',}, index, mode='newznab&newznab=24056',thumb='http://thetvdb.com/banners/posters/149231-1.jpg')
            if newznab_id == 'The WB':
                add_posts({'title' : 'Blue Collar TV',}, index, mode='newznab&newznab=2840',thumb='http://thetvdb.com/banners/posters/73815-1.jpg')
                add_posts({'title' : 'Charmed',}, index, mode='newznab&newznab=3039',thumb='http://thetvdb.com/banners/posters/70626-1.jpg')
                add_posts({'title' : 'Dawsons Creek',}, index, mode='newznab&newznab=3255',thumb='http://thetvdb.com/banners/posters/72584-1.jpg')
                add_posts({'title' : 'Everwood',}, index, mode='newznab&newznab=3464',thumb='http://thetvdb.com/banners/posters/78465-1.jpg')
                add_posts({'title' : 'Men in Black The Series',}, index, mode='newznab&newznab=4447',thumb='http://thetvdb.com/banners/posters/77743-1.jpg')
                add_posts({'title' : 'The Jamie Foxx Show',}, index, mode='newznab&newznab=5883',thumb='http://thetvdb.com/banners/posters/74084-1.jpg')
                add_posts({'title' : 'The New Batman Adventures',}, index, mode='newznab&newznab=2720',thumb='http://thetvdb.com/banners/posters/77084-1.jpg')
                add_posts({'title' : 'The Oblongs',}, index, mode='newznab&newznab=6056',thumb='http://thetvdb.com/banners/posters/73302-1.jpg')
                add_posts({'title' : 'The PJs',}, index, mode='newznab&newznab=6096',thumb='http://thetvdb.com/banners/posters/74052-1.jpg')
                add_posts({'title' : 'X Men Evolution',}, index, mode='newznab&newznab=6666',thumb='http://thetvdb.com/banners/posters/71168-1.jpg')
            if newznab_id == 'The Weather Channel':
                add_posts({'title' : 'Pyros',}, index, mode='newznab&newznab=33038',thumb='http://thetvdb.com/banners/posters/258367-1.jpg')
            if newznab_id == 'TLC':
                add_posts({'title' : '19 Kids and Counting',}, index, mode='newznab&newznab=20203',thumb='http://thetvdb.com/banners/posters/139481-1.jpg')
                add_posts({'title' : 'A Baby Story',}, index, mode='newznab&newznab=16955',thumb='http://thetvdb.com/banners/posters/260808-1.jpg')
                add_posts({'title' : 'Abby and Brittany',}, index, mode='newznab&newznab=32494',thumb='http://thetvdb.com/banners/posters/261395-1.jpg')
                add_posts({'title' : 'Accidental Fortune',}, index, mode='newznab&newznab=24698',thumb='http://thetvdb.com/banners/posters/246141-2.jpg')
                add_posts({'title' : 'All American Muslim',}, index, mode='newznab&newznab=29366',thumb='http://thetvdb.com/banners/posters/253543-1.jpg')
                add_posts({'title' : 'American Hotrod',}, index, mode='newznab&newznab=10119',thumb='http://thetvdb.com/banners/posters/80389-1.jpg')
                add_posts({'title' : 'Americas Worst Tattoos',}, index, mode='newznab&newznab=32033',thumb='http://thetvdb.com/banners/posters/260478-1.jpg')
                add_posts({'title' : 'Big Tiny Life with the Jordans',}, index, mode='newznab&newznab=32011')
                add_posts({'title' : 'Breaking Amish',}, index, mode='newznab&newznab=32524',thumb='http://thetvdb.com/banners/posters/261926-1.jpg')
                add_posts({'title' : 'Cake Boss Next Great Baker',}, index, mode='newznab&newznab=25935')
                add_posts({'title' : 'Cake Boss',}, index, mode='newznab&newznab=22395',thumb='http://thetvdb.com/banners/posters/107671-1.jpg')
                add_posts({'title' : 'Cell Block 6 Female Lockup',}, index, mode='newznab&newznab=26125',thumb='http://thetvdb.com/banners/posters/227581-1.jpg')
                add_posts({'title' : 'Cellblock 6 Female Lock Up',}, index, mode='newznab&newznab=26125',thumb='http://thetvdb.com/banners/posters/227581-1.jpg')
                add_posts({'title' : 'Cheer Perfection',}, index, mode='newznab&newznab=32596',thumb='http://thetvdb.com/banners/posters/265015-1.jpg')
                add_posts({'title' : 'Craft Wars',}, index, mode='newznab&newznab=31261',thumb='http://thetvdb.com/banners/posters/260229-1.jpg')
                add_posts({'title' : 'D U I',}, index, mode='newznab&newznab=30138',thumb='http://thetvdb.com/banners/posters/254067-1.jpg')
                add_posts({'title' : 'DC Cupcakes',}, index, mode='newznab&newznab=25689',thumb='http://thetvdb.com/banners/posters/176261-1.jpg')
                add_posts({'title' : 'Extreme Cheapskates',}, index, mode='newznab&newznab=30973',thumb='http://thetvdb.com/banners/posters/255277-1.jpg')
                add_posts({'title' : 'Extreme Couponing',}, index, mode='newznab&newznab=27734',thumb='http://thetvdb.com/banners/posters/219591-1.jpg')
                add_posts({'title' : 'Fabulous Cakes',}, index, mode='newznab&newznab=25686',thumb='http://thetvdb.com/banners/posters/183251-1.jpg')
                add_posts({'title' : 'Freaky Eaters US',}, index, mode='newznab&newznab=26423',thumb='http://thetvdb.com/banners/posters/246411-1.jpg')
                add_posts({'title' : 'Geek Love',}, index, mode='newznab&newznab=30205',thumb='http://thetvdb.com/banners/posters/254272-1.jpg')
                add_posts({'title' : 'Here Comes Honey Boo Boo',}, index, mode='newznab&newznab=32058',thumb='http://thetvdb.com/banners/posters/261286-1.jpg')
                add_posts({'title' : 'Hoarding Buried Alive',}, index, mode='newznab&newznab=25290',thumb='http://thetvdb.com/banners/posters/149111-1.jpg')
                add_posts({'title' : 'Hook Line And Sisters',}, index, mode='newznab&newznab=30429')
                add_posts({'title' : 'I Didnt Know I Was Pregnant',}, index, mode='newznab&newznab=21669',thumb='http://thetvdb.com/banners/posters/147711-1.jpg')
                add_posts({'title' : 'I Found the Gown',}, index, mode='newznab&newznab=32490',thumb='http://thetvdb.com/banners/posters/261801-1.jpg')
                add_posts({'title' : 'I Kid With Brad Garrett',}, index, mode='newznab&newznab=28671')
                add_posts({'title' : 'Kate Plus 8',}, index, mode='newznab&newznab=25981',thumb='http://thetvdb.com/banners/posters/168061-1.jpg')
                add_posts({'title' : 'Kitchen Boss',}, index, mode='newznab&newznab=27481',thumb='http://thetvdb.com/banners/posters/230981-1.jpg')
                add_posts({'title' : 'LA Ink',}, index, mode='newznab&newznab=16930',thumb='http://thetvdb.com/banners/posters/80469-1.jpg')
                add_posts({'title' : 'Little People Big World Wedding Farm',}, index, mode='newznab&newznab=33142',thumb='http://thetvdb.com/banners/posters/263722-1.jpg')
                add_posts({'title' : 'Little People Big World',}, index, mode='newznab&newznab=8442',thumb='http://thetvdb.com/banners/posters/80112-1.jpg')
                add_posts({'title' : 'Little Shop of Gypsies',}, index, mode='newznab&newznab=33041',thumb='http://thetvdb.com/banners/posters/263350-1.jpg')
                add_posts({'title' : 'Long Island Medium',}, index, mode='newznab&newznab=29291',thumb='http://thetvdb.com/banners/posters/252125-1.jpg')
                add_posts({'title' : 'Lottery Changed My Life',}, index, mode='newznab&newznab=23755')
                add_posts({'title' : 'Mall Cops',}, index, mode='newznab&newznab=24168')
                add_posts({'title' : 'Miami Ink',}, index, mode='newznab&newznab=7177',thumb='http://thetvdb.com/banners/posters/78816-1.jpg')
                add_posts({'title' : 'My 600 lb Life',}, index, mode='newznab&newznab=30813',thumb='http://thetvdb.com/banners/posters/257540-1.jpg')
                add_posts({'title' : 'My Big Fat American Gypsy Wedding',}, index, mode='newznab&newznab=31545',thumb='http://thetvdb.com/banners/posters/258632-1.jpg')
                add_posts({'title' : 'My Crazy Obsession',}, index, mode='newznab&newznab=30849',thumb='http://thetvdb.com/banners/posters/256876-1.jpg')
                add_posts({'title' : 'My Strange Addiction',}, index, mode='newznab&newznab=27145',thumb='http://thetvdb.com/banners/posters/211391-1.jpg')
                add_posts({'title' : 'NY Ink',}, index, mode='newznab&newznab=28521',thumb='http://thetvdb.com/banners/posters/249028-1.jpg')
                add_posts({'title' : 'On The Fly',}, index, mode='newznab&newznab=31692',thumb='http://thetvdb.com/banners/posters/258791-1.jpg')
                add_posts({'title' : 'Outrageous Kid Parties',}, index, mode='newznab&newznab=27740')
                add_posts({'title' : 'Pawn Queens',}, index, mode='newznab&newznab=26986',thumb='http://thetvdb.com/banners/posters/241121-1.jpg')
                add_posts({'title' : 'Prison Diares',}, index, mode='newznab&newznab=29365',thumb='http://thetvdb.com/banners/posters/252270-1.jpg')
                add_posts({'title' : 'Prison Diaries',}, index, mode='newznab&newznab=29365',thumb='http://thetvdb.com/banners/posters/252270-1.jpg')
                add_posts({'title' : 'Quints By Surprise',}, index, mode='newznab&newznab=26419',thumb='http://thetvdb.com/banners/posters/187671-1.jpg')
                add_posts({'title' : 'Sarah Palins Alaska',}, index, mode='newznab&newznab=26382',thumb='http://thetvdb.com/banners/posters/203131-1.jpg')
                add_posts({'title' : 'Say Yes To The Dress Atlanta',}, index, mode='newznab&newznab=25691',thumb='http://thetvdb.com/banners/posters/183491-1.jpg')
                add_posts({'title' : 'Say Yes To The Dress Big Bliss',}, index, mode='newznab&newznab=27970',thumb='http://thetvdb.com/banners/posters/250670-1.jpg')
                add_posts({'title' : 'Say Yes To The Dress Bridesmaids',}, index, mode='newznab&newznab=28678',thumb='http://thetvdb.com/banners/posters/250496-1.jpg')
                add_posts({'title' : 'Say Yes To The Dress',}, index, mode='newznab&newznab=17627',thumb='http://thetvdb.com/banners/posters/80836-1.jpg')
                add_posts({'title' : 'Secret Princes',}, index, mode='newznab&newznab=32639',thumb='http://thetvdb.com/banners/posters/262645-1.jpg')
                add_posts({'title' : 'Sin City Rules',}, index, mode='newznab&newznab=33629',thumb='http://thetvdb.com/banners/posters/264759-1.jpg')
                add_posts({'title' : 'Sister Wives',}, index, mode='newznab&newznab=26381',thumb='http://thetvdb.com/banners/posters/193711-1.jpg')
                add_posts({'title' : 'Solved',}, index, mode='newznab&newznab=20956',thumb='http://thetvdb.com/banners/posters/171161-1.jpg')
                add_posts({'title' : 'Spouse Vs House',}, index, mode='newznab&newznab=28259',thumb='http://thetvdb.com/banners/posters/249260-1.jpg')
                add_posts({'title' : 'Strange Sex',}, index, mode='newznab&newznab=26139',thumb='http://thetvdb.com/banners/posters/178371-1.jpg')
                add_posts({'title' : 'Surprise Homecoming',}, index, mode='newznab&newznab=28288',thumb='http://thetvdb.com/banners/posters/249212-1.jpg')
                add_posts({'title' : 'Tattoo School',}, index, mode='newznab&newznab=31693',thumb='http://thetvdb.com/banners/posters/250215-1.jpg')
                add_posts({'title' : 'The Little Couple',}, index, mode='newznab&newznab=22683',thumb='http://thetvdb.com/banners/posters/98481-1.jpg')
                add_posts({'title' : 'Toddlers and Tiaras',}, index, mode='newznab&newznab=20667')
                add_posts({'title' : 'Ultimate Cake Off',}, index, mode='newznab&newznab=23339',thumb='http://thetvdb.com/banners/posters/107991-1.jpg')
                add_posts({'title' : 'Ultimate Cleaners',}, index, mode='newznab&newznab=27814')
                add_posts({'title' : 'United Bates of America',}, index, mode='newznab&newznab=32439',thumb='http://thetvdb.com/banners/posters/261348-1.jpg')
                add_posts({'title' : 'Unleased K9 Broward County',}, index, mode='newznab&newznab=27882',thumb='http://thetvdb.com/banners/posters/247601-1.jpg')
                add_posts({'title' : 'Unleashed K 9 Broward County',}, index, mode='newznab&newznab=27882',thumb='http://thetvdb.com/banners/posters/247601-1.jpg')
                add_posts({'title' : 'Unleashed K9 Broward County',}, index, mode='newznab&newznab=27882',thumb='http://thetvdb.com/banners/posters/247601-1.jpg')
            if newznab_id == 'TNT':
                add_posts({'title' : 'Dallas 2012',}, index, mode='newznab&newznab=28960',thumb='http://thetvdb.com/banners/posters/242521-1.jpg')
                add_posts({'title' : 'Dark Blue',}, index, mode='newznab&newznab=21649',thumb='http://thetvdb.com/banners/posters/95781-1.jpg')
                add_posts({'title' : 'Falling Skies',}, index, mode='newznab&newznab=26205',thumb='http://thetvdb.com/banners/posters/205281-1.jpg')
                add_posts({'title' : 'Franklin and Bash',}, index, mode='newznab&newznab=25844',thumb='http://thetvdb.com/banners/posters/164041-1.jpg')
                add_posts({'title' : 'HawthoRNe',}, index, mode='newznab&newznab=21648',thumb='http://thetvdb.com/banners/posters/95741-1.jpg')
                add_posts({'title' : 'Heartland',}, index, mode='newznab&newznab=15312',thumb='http://thetvdb.com/banners/posters/70598-1.jpg')
                add_posts({'title' : 'Leverage',}, index, mode='newznab&newznab=18411',thumb='http://thetvdb.com/banners/posters/82339-1.jpg')
                add_posts({'title' : 'Major Crimes',}, index, mode='newznab&newznab=28497',thumb='http://thetvdb.com/banners/posters/257248-1.jpg')
                add_posts({'title' : 'Memphis Beat',}, index, mode='newznab&newznab=19699',thumb='http://thetvdb.com/banners/posters/157621-1.jpg')
                add_posts({'title' : 'Men of a Certain Age',}, index, mode='newznab&newznab=19206',thumb='http://thetvdb.com/banners/posters/121431-1.jpg')
                add_posts({'title' : 'Perception',}, index, mode='newznab&newznab=29470',thumb='http://thetvdb.com/banners/posters/248757-1.jpg')
                add_posts({'title' : 'Rizzoli and Isles',}, index, mode='newznab&newznab=24996',thumb='http://thetvdb.com/banners/posters/161461-1.jpg')
                add_posts({'title' : 'Saved',}, index, mode='newznab&newznab=10100',thumb='http://thetvdb.com/banners/posters/79401-1.jpg')
                add_posts({'title' : 'Southland',}, index, mode='newznab&newznab=21197',thumb='http://thetvdb.com/banners/posters/84645-1.jpg')
                add_posts({'title' : 'The Closer',}, index, mode='newznab&newznab=5685',thumb='http://thetvdb.com/banners/posters/74875-1.jpg')
                add_posts({'title' : 'The Great Escape',}, index, mode='newznab&newznab=30612',thumb='http://thetvdb.com/banners/posters/258603-1.jpg')
            if newznab_id == 'TNT Serie':
                add_posts({'title' : 'Add a Friend',}, index, mode='newznab&newznab=32253',thumb='http://thetvdb.com/banners/posters/261970-1.jpg')
            if newznab_id == 'Tokyo MX':
                add_posts({'title' : 'Kannagi Crazy Shrine Maidens',}, index, mode='newznab&newznab=20130')
            if newznab_id == 'Travel Channel':
                add_posts({'title' : 'Airport 24 7 Miami',}, index, mode='newznab&newznab=30365',thumb='http://thetvdb.com/banners/posters/262588-1.jpg')
                add_posts({'title' : 'All You Can Meat',}, index, mode='newznab&newznab=31502',thumb='http://thetvdb.com/banners/posters/261179-1.jpg')
                add_posts({'title' : 'Amazing Eats',}, index, mode='newznab&newznab=30522',thumb='http://thetvdb.com/banners/posters/255110-1.jpg')
                add_posts({'title' : 'Anthony Bourdain No Reservations',}, index, mode='newznab&newznab=14983',thumb='http://thetvdb.com/banners/posters/79668-1.jpg')
                add_posts({'title' : 'Baggage Battles',}, index, mode='newznab&newznab=30363',thumb='http://thetvdb.com/banners/posters/257960-1.jpg')
                add_posts({'title' : 'Bite Me With Dr Mike',}, index, mode='newznab&newznab=23063',thumb='http://thetvdb.com/banners/posters/104871-1.jpg')
                add_posts({'title' : 'Bizarre Foods',}, index, mode='newznab&newznab=15226',thumb='http://thetvdb.com/banners/posters/80399-1.jpg')
                add_posts({'title' : 'Burger Land',}, index, mode='newznab&newznab=32587')
                add_posts({'title' : 'Dining With Death',}, index, mode='newznab&newznab=27216')
                add_posts({'title' : 'Extreme Houseboats',}, index, mode='newznab&newznab=33361',thumb='http://thetvdb.com/banners/posters/264104-1.jpg')
                add_posts({'title' : 'Extreme RV',}, index, mode='newznab&newznab=30741',thumb='http://thetvdb.com/banners/posters/255948-1.jpg')
                add_posts({'title' : 'Extreme Waterparks',}, index, mode='newznab&newznab=31497',thumb='http://thetvdb.com/banners/posters/260356-1.jpg')
                add_posts({'title' : 'Food Paradise',}, index, mode='newznab&newznab=21959',thumb='http://thetvdb.com/banners/posters/174971-1.jpg')
                add_posts({'title' : 'Food Wars',}, index, mode='newznab&newznab=25237',thumb='http://thetvdb.com/banners/posters/141141-1.jpg')
                add_posts({'title' : 'Ghost Adventures',}, index, mode='newznab&newznab=20338',thumb='http://thetvdb.com/banners/posters/83929-1.jpg')
                add_posts({'title' : 'Hidden City',}, index, mode='newznab&newznab=29864',thumb='http://thetvdb.com/banners/posters/253577-1.jpg')
                add_posts({'title' : 'Hotel Impossible',}, index, mode='newznab&newznab=30364',thumb='http://thetvdb.com/banners/posters/257715-1.jpg')
                add_posts({'title' : 'Insane Coaster Wars',}, index, mode='newznab&newznab=31498',thumb='http://thetvdb.com/banners/posters/260357-1.jpg')
                add_posts({'title' : 'Made in America 2011',}, index, mode='newznab&newznab=29356')
                add_posts({'title' : 'Making Monsters',}, index, mode='newznab&newznab=29722',thumb='http://thetvdb.com/banners/posters/252291-1.jpg')
                add_posts({'title' : 'Man v Food Nation',}, index, mode='newznab&newznab=28475',thumb='http://thetvdb.com/banners/posters/249025-1.jpg')
                add_posts({'title' : 'Man v Food',}, index, mode='newznab&newznab=20717',thumb='http://thetvdb.com/banners/posters/84006-1.jpg')
                add_posts({'title' : 'Mysteries at the Museum',}, index, mode='newznab&newznab=27066',thumb='http://thetvdb.com/banners/posters/252290-1.jpg')
                add_posts({'title' : 'Off Limits',}, index, mode='newznab&newznab=28284',thumb='http://thetvdb.com/banners/posters/248726-1.jpg')
                add_posts({'title' : 'Paranormal Challenge',}, index, mode='newznab&newznab=28582',thumb='http://thetvdb.com/banners/posters/249538-1.jpg')
                add_posts({'title' : 'Paranormal Paparazzi',}, index, mode='newznab&newznab=32416',thumb='http://thetvdb.com/banners/posters/261196-1.jpg')
                add_posts({'title' : 'Samantha Browns Asia',}, index, mode='newznab&newznab=25275',thumb='http://thetvdb.com/banners/posters/177321-1.jpg')
                add_posts({'title' : 'Sand Masters',}, index, mode='newznab&newznab=28552',thumb='http://thetvdb.com/banners/posters/249027-1.jpg')
                add_posts({'title' : 'Scream If You Know The Answer US',}, index, mode='newznab&newznab=28795')
                add_posts({'title' : 'The Dead Files',}, index, mode='newznab&newznab=29290',thumb='http://thetvdb.com/banners/posters/252133-1.jpg')
                add_posts({'title' : 'The Layover',}, index, mode='newznab&newznab=29451',thumb='http://thetvdb.com/banners/posters/252207-1.jpg')
                add_posts({'title' : 'Toy Hunter',}, index, mode='newznab&newznab=30900',thumb='http://thetvdb.com/banners/posters/261223-1.jpg')
                add_posts({'title' : 'Truck Stop USA',}, index, mode='newznab&newznab=28681')
                add_posts({'title' : 'When Vacations Attack',}, index, mode='newznab&newznab=26958',thumb='http://thetvdb.com/banners/posters/237711-1.jpg')
            if newznab_id == 'Treehouse':
                add_posts({'title' : 'Franklin',}, index, mode='newznab&newznab=3594',thumb='http://thetvdb.com/banners/posters/78150-1.jpg')
            if newznab_id == 'truTV':
                add_posts({'title' : 'All Worked Up',}, index, mode='newznab&newznab=24016',thumb='http://thetvdb.com/banners/posters/157091-1.jpg')
                add_posts({'title' : 'Bait Car',}, index, mode='newznab&newznab=24216',thumb='http://thetvdb.com/banners/posters/85565-1.jpg')
                add_posts({'title' : 'Bear Swamp Recovery',}, index, mode='newznab&newznab=29116',thumb='http://thetvdb.com/banners/posters/251397-1.jpg')
                add_posts({'title' : 'Big Brian The Fortune Seller',}, index, mode='newznab&newznab=27817',thumb='http://thetvdb.com/banners/posters/243411-1.jpg')
                add_posts({'title' : 'Black Gold',}, index, mode='newznab&newznab=18864',thumb='http://thetvdb.com/banners/posters/82297-1.jpg')
                add_posts({'title' : 'Caught Red Handed',}, index, mode='newznab&newznab=30950',thumb='http://thetvdb.com/banners/posters/263522-1.jpg')
                add_posts({'title' : 'Clipaholics',}, index, mode='newznab&newznab=31847',thumb='http://thetvdb.com/banners/posters/260458-1.jpg')
                add_posts({'title' : 'Combat Pawn',}, index, mode='newznab&newznab=32255',thumb='http://thetvdb.com/banners/posters/260706-1.jpg')
                add_posts({'title' : 'Conspiracy Theory with Jesse Ventura',}, index, mode='newznab&newznab=22864',thumb='http://thetvdb.com/banners/posters/127401-1.jpg')
                add_posts({'title' : 'Forensic Files',}, index, mode='newznab&newznab=783',thumb='http://thetvdb.com/banners/posters/71415-1.jpg')
                add_posts({'title' : 'Full Throttle Saloon',}, index, mode='newznab&newznab=22866',thumb='http://thetvdb.com/banners/posters/123851-1.jpg')
                add_posts({'title' : 'hard core pawn',}, index, mode='newznab&newznab=24709',thumb='http://thetvdb.com/banners/posters/183831-1.jpg')
                add_posts({'title' : 'Hardcore Pawn',}, index, mode='newznab&newznab=24709',thumb='http://thetvdb.com/banners/posters/183831-1.jpg')
                add_posts({'title' : 'Impractical Jokers',}, index, mode='newznab&newznab=29118',thumb='http://thetvdb.com/banners/posters/254243-1.jpg')
                add_posts({'title' : 'Killer Karaoke',}, index, mode='newznab&newznab=29708',thumb='http://thetvdb.com/banners/posters/263523-1.jpg')
                add_posts({'title' : 'Las Vegas Jailhouse',}, index, mode='newznab&newznab=24964',thumb='http://thetvdb.com/banners/posters/173191-1.jpg')
                add_posts({'title' : 'Lizard Lick Towing',}, index, mode='newznab&newznab=27240',thumb='http://thetvdb.com/banners/posters/224011-1.jpg')
                add_posts({'title' : 'Lizard Lick Towning',}, index, mode='newznab&newznab=27240',thumb='http://thetvdb.com/banners/posters/224011-1.jpg')
                add_posts({'title' : 'Not Safe For Work',}, index, mode='newznab&newznab=31521',thumb='http://thetvdb.com/banners/posters/258338-1.jpg')
                add_posts({'title' : 'Operation Repo',}, index, mode='newznab&newznab=20581',thumb='http://thetvdb.com/banners/posters/148791-1.jpg')
                add_posts({'title' : 'Police POV',}, index, mode='newznab&newznab=27944',thumb='http://thetvdb.com/banners/posters/248109-1.jpg')
                add_posts({'title' : 'Possum Holler Garage',}, index, mode='newznab&newznab=32441')
                add_posts({'title' : 'South Beach Tow',}, index, mode='newznab&newznab=28934',thumb='http://thetvdb.com/banners/posters/250370-1.jpg')
                add_posts({'title' : 'Southern Fried Stings',}, index, mode='newznab&newznab=25464',thumb='http://thetvdb.com/banners/posters/198961-1.jpg')
                add_posts({'title' : 'Storage Hunters',}, index, mode='newznab&newznab=28625',thumb='http://thetvdb.com/banners/posters/249699-1.jpg')
                add_posts({'title' : 'Top 20 Most Shocking',}, index, mode='newznab&newznab=24227',thumb='http://thetvdb.com/banners/posters/179651-1.jpg')
                add_posts({'title' : 'Vegas Strip',}, index, mode='newznab&newznab=28974',thumb='http://thetvdb.com/banners/posters/250299-1.jpg')
                add_posts({'title' : 'Vegas Strips',}, index, mode='newznab&newznab=28974',thumb='http://thetvdb.com/banners/posters/250299-1.jpg')
            if newznab_id == 'TV JOJ':
                add_posts({'title' : 'Mafstory',}, index, mode='newznab&newznab=29778',thumb='http://thetvdb.com/banners/posters/83757-1.jpg')
            if newznab_id == 'TV Kanagawa':
                add_posts({'title' : 'Air',}, index, mode='newznab&newznab=12663',thumb='http://thetvdb.com/banners/posters/79101-1.jpg')
            if newznab_id == 'TV Land':
                add_posts({'title' : 'Happily Divorced',}, index, mode='newznab&newznab=27558',thumb='http://thetvdb.com/banners/posters/248330-1.jpg')
                add_posts({'title' : 'Hot in Cleveland',}, index, mode='newznab&newznab=24846',thumb='http://thetvdb.com/banners/posters/162071-1.jpg')
                add_posts({'title' : 'Retired at 35',}, index, mode='newznab&newznab=24847',thumb='http://thetvdb.com/banners/posters/213321-1.jpg')
                add_posts({'title' : 'The Exes',}, index, mode='newznab&newznab=27984',thumb='http://thetvdb.com/banners/posters/253279-1.jpg')
                add_posts({'title' : 'The Soul Man',}, index, mode='newznab&newznab=31547',thumb='http://thetvdb.com/banners/posters/257381-1.jpg')
            if newznab_id == 'TV One':
                add_posts({'title' : 'Donald J Trump Presents The Ultimate Merger',}, index, mode='newznab&newznab=25880',thumb='http://thetvdb.com/banners/posters/173981-1.jpg')
                add_posts({'title' : 'Life After',}, index, mode='newznab&newznab=24284')
                add_posts({'title' : 'Lisa Raye The Real McCoy',}, index, mode='newznab&newznab=25255')
                add_posts({'title' : 'Lisaraye The Real McCoy',}, index, mode='newznab&newznab=25255')
                add_posts({'title' : 'Love That Girl',}, index, mode='newznab&newznab=24952',thumb='http://thetvdb.com/banners/posters/143181-1.jpg')
                add_posts({'title' : 'The Rickey Smiley Show',}, index, mode='newznab&newznab=32364',thumb='http://thetvdb.com/banners/posters/262562-1.jpg')
                add_posts({'title' : 'Unsung',}, index, mode='newznab&newznab=20662',thumb='http://thetvdb.com/banners/posters/250101-1.jpg')
                add_posts({'title' : 'Will To Live',}, index, mode='newznab&newznab=29573')
            if newznab_id == 'TV Tokyo':
                add_posts({'title' : 'Bamboo Blade',}, index, mode='newznab&newznab=17496',thumb='http://thetvdb.com/banners/posters/80673-1.jpg')
                add_posts({'title' : 'Eyeshield 21',}, index, mode='newznab&newznab=3479',thumb='http://thetvdb.com/banners/posters/79183-1.jpg')
                add_posts({'title' : 'Fairy Tail',}, index, mode='newznab&newznab=24288',thumb='http://thetvdb.com/banners/posters/114801-1.jpg')
                add_posts({'title' : 'Hayate The Combat Butler',}, index, mode='newznab&newznab=15475',thumb='http://thetvdb.com/banners/posters/80554-1.jpg')
                add_posts({'title' : 'Naruto Shippuden',}, index, mode='newznab&newznab=14748',thumb='http://thetvdb.com/banners/posters/79824-1.jpg')
                add_posts({'title' : 'Outlaw Star',}, index, mode='newznab&newznab=4747',thumb='http://thetvdb.com/banners/posters/75911-1.jpg')
                add_posts({'title' : 'Project Arms',}, index, mode='newznab&newznab=1031',thumb='http://thetvdb.com/banners/posters/72394-1.jpg')
                add_posts({'title' : 'Vampire Knight',}, index, mode='newznab&newznab=18549',thumb='http://thetvdb.com/banners/posters/81816-1.jpg')
                add_posts({'title' : 'Yu Gi Oh Zexal',}, index, mode='newznab&newznab=28060',thumb='http://thetvdb.com/banners/posters/248049-1.jpg')
            if newznab_id == 'TV1':
                add_posts({'title' : 'A Night At The Classic',}, index, mode='newznab&newznab=33674',thumb='http://thetvdb.com/banners/posters/224951-1.jpg')
                add_posts({'title' : 'Auckland Daze',}, index, mode='newznab&newznab=32564',thumb='http://thetvdb.com/banners/posters/253286-1.jpg')
                add_posts({'title' : 'Border Partrol',}, index, mode='newznab&newznab=26114',thumb='http://thetvdb.com/banners/posters/126651-1.jpg')
                add_posts({'title' : 'Border Patrol',}, index, mode='newznab&newznab=26114',thumb='http://thetvdb.com/banners/posters/126651-1.jpg')
                add_posts({'title' : 'Dog Squad',}, index, mode='newznab&newznab=32659')
                add_posts({'title' : 'First Crossings',}, index, mode='newznab&newznab=32390',thumb='http://thetvdb.com/banners/posters/260954-1.jpg')
                add_posts({'title' : 'Highway Cops',}, index, mode='newznab&newznab=32096',thumb='http://thetvdb.com/banners/posters/260391-1.jpg')
                add_posts({'title' : 'Masterchef NZ',}, index, mode='newznab&newznab=28174')
                add_posts({'title' : 'Night At The Classic',}, index, mode='newznab&newznab=33674',thumb='http://thetvdb.com/banners/posters/224951-1.jpg')
                add_posts({'title' : 'Nothing Trivial',}, index, mode='newznab&newznab=29228',thumb='http://thetvdb.com/banners/posters/250418-1.jpg')
                add_posts({'title' : 'This Is Not My Life',}, index, mode='newznab&newznab=26283',thumb='http://thetvdb.com/banners/posters/179351-1.jpg')
            if newznab_id == 'TV2':
                add_posts({'title' : 'Aotearoa Social Club',}, index, mode='newznab&newznab=32986')
                add_posts({'title' : 'Go Girls',}, index, mode='newznab&newznab=21940',thumb='http://thetvdb.com/banners/posters/132271-1.jpg')
                add_posts({'title' : 'Shortland Street',}, index, mode='newznab&newznab=5187',thumb='http://thetvdb.com/banners/posters/73983-1.jpg')
            if newznab_id == 'TV3':
                add_posts({'title' : '7 Days NZ',}, index, mode='newznab&newznab=26736')
                add_posts({'title' : 'Bigger Better Faster Stronger',}, index, mode='newznab&newznab=27594',thumb='http://thetvdb.com/banners/posters/232771-2.jpg')
                add_posts({'title' : 'Chelsea New Zealands Hottest Home Baker',}, index, mode='newznab&newznab=31530')
                add_posts({'title' : 'Drug Bust NZ',}, index, mode='newznab&newznab=33810')
                add_posts({'title' : 'Funny Roots',}, index, mode='newznab&newznab=31635',thumb='http://thetvdb.com/banners/posters/259114-1.jpg')
                add_posts({'title' : 'Golden',}, index, mode='newznab&newznab=32193',thumb='http://thetvdb.com/banners/posters/260036-1.jpg')
                add_posts({'title' : 'Hounds NZ',}, index, mode='newznab&newznab=31897')
                add_posts({'title' : 'lyxfallan',}, index, mode='newznab&newznab=25771')
                add_posts({'title' : 'New Zealands Next Top Model',}, index, mode='newznab&newznab=22675',thumb='http://thetvdb.com/banners/posters/85569-1.jpg')
                add_posts({'title' : 'Road Cops',}, index, mode='newznab&newznab=26475',thumb='http://thetvdb.com/banners/posters/183641-1.jpg')
                add_posts({'title' : 'Super City',}, index, mode='newznab&newznab=27684',thumb='http://thetvdb.com/banners/posters/239301-1.jpg')
                add_posts({'title' : 'svenska hollywoodfruar',}, index, mode='newznab&newznab=23904')
                add_posts({'title' : 'Target NZ',}, index, mode='newznab&newznab=32679',thumb='http://thetvdb.com/banners/posters/179391-1.jpg')
                add_posts({'title' : 'The Almighty Johnsons',}, index, mode='newznab&newznab=27577',thumb='http://thetvdb.com/banners/posters/229981-1.jpg')
                add_posts({'title' : 'The Block NZ',}, index, mode='newznab&newznab=32222',thumb='http://thetvdb.com/banners/posters/260462-1.jpg')
                add_posts({'title' : 'The GC',}, index, mode='newznab&newznab=31653',thumb='http://thetvdb.com/banners/posters/258670-1.jpg')
                add_posts({'title' : 'Underbelly NZ Land of the Long Green Cloud',}, index, mode='newznab&newznab=29253')
                add_posts({'title' : 'Wanna BEn',}, index, mode='newznab&newznab=26894',thumb='http://thetvdb.com/banners/posters/196221-1.jpg')
            if newznab_id == 'TV4':
                add_posts({'title' : 'kontoret',}, index, mode='newznab&newznab=30799')
                add_posts({'title' : 'parlamentet',}, index, mode='newznab&newznab=17512',thumb='http://thetvdb.com/banners/posters/79625-1.jpg')
            if newznab_id == 'TV6':
                add_posts({'title' : 'karatefylla',}, index, mode='newznab&newznab=31023',thumb='http://thetvdb.com/banners/posters/252369-1.jpg')
            if newznab_id == 'TVB':
                add_posts({'title' : 'Ghost Writer',}, index, mode='newznab&newznab=27486',thumb='http://thetvdb.com/banners/posters/168741-1.jpg')
                add_posts({'title' : 'The Mysteries of Love',}, index, mode='newznab&newznab=27485',thumb='http://thetvdb.com/banners/posters/165281-1.jpg')
            if newznab_id == 'TVN':
                add_posts({'title' : 'MasterChef',}, index, mode='newznab&newznab=32673')
            if newznab_id == 'TVNorge':
                add_posts({'title' : 'Nissene Over Skog Og Hei',}, index, mode='newznab&newznab=30317',thumb='http://thetvdb.com/banners/posters/254061-1.jpg')
            if newznab_id == 'TVNZ':
                add_posts({'title' : 'Last Chance Dogs',}, index, mode='newznab&newznab=31529')
                add_posts({'title' : 'The Politically Incorrect Guide To Teenagers',}, index, mode='newznab&newznab=28209',thumb='http://thetvdb.com/banners/posters/237051-1.jpg')
            if newznab_id == 'TVP 1':
                add_posts({'title' : 'Chichot Losu',}, index, mode='newznab&newznab=32266')
            if newznab_id == 'Unknown':
                add_posts({'title' : 'The Enid Blyton Adventure Series',}, index, mode='newznab&newznab=5752',thumb='http://thetvdb.com/banners/posters/70404-1.jpg')
                add_posts({'title' : 'The Wombles',}, index, mode='newznab&newznab=7191',thumb='http://thetvdb.com/banners/posters/80104-1.jpg')
            if newznab_id == 'UPN':
                add_posts({'title' : 'Buffy the Vampire Slayer',}, index, mode='newznab&newznab=2930',thumb='http://thetvdb.com/banners/posters/70327-1.jpg')
                add_posts({'title' : 'Roswell',}, index, mode='newznab&newznab=5056',thumb='http://thetvdb.com/banners/posters/73965-1.jpg')
                add_posts({'title' : 'Star Trek Enterprise',}, index, mode='newznab&newznab=5335',thumb='http://thetvdb.com/banners/posters/73893-1.jpg')
                add_posts({'title' : 'Star Trek Voyager',}, index, mode='newznab&newznab=5338',thumb='http://thetvdb.com/banners/posters/74550-1.jpg')
                add_posts({'title' : 'Wolf Lake',}, index, mode='newznab&newznab=6635',thumb='http://thetvdb.com/banners/posters/79312-1.jpg')
            if newznab_id == 'USA':
                add_posts({'title' : 'Airwolf',}, index, mode='newznab&newznab=2525',thumb='http://thetvdb.com/banners/posters/73200-1.jpg')
                add_posts({'title' : 'Burn Notice',}, index, mode='newznab&newznab=15383',thumb='http://thetvdb.com/banners/posters/80270-1.jpg')
                add_posts({'title' : 'Common Law 2012',}, index, mode='newznab&newznab=28991',thumb='http://thetvdb.com/banners/posters/253982-1.jpg')
                add_posts({'title' : 'Covert Affairs',}, index, mode='newznab&newznab=23686',thumb='http://thetvdb.com/banners/posters/104281-1.jpg')
                add_posts({'title' : 'Fairly Legal',}, index, mode='newznab&newznab=24658',thumb='http://thetvdb.com/banners/posters/175011-1.jpg')
                add_posts({'title' : 'In Plain Sight',}, index, mode='newznab&newznab=18751',thumb='http://thetvdb.com/banners/posters/82155-1.jpg')
                add_posts({'title' : 'Law and Order Criminal Intent',}, index, mode='newznab&newznab=4203',thumb='http://thetvdb.com/banners/posters/71489-1.jpg')
                add_posts({'title' : 'Monk',}, index, mode='newznab&newznab=4514',thumb='http://thetvdb.com/banners/posters/78490-1.jpg')
                add_posts({'title' : 'Necessary Roughness',}, index, mode='newznab&newznab=27517',thumb='http://thetvdb.com/banners/posters/247809-1.jpg')
                add_posts({'title' : 'Political Animals',}, index, mode='newznab&newznab=30818',thumb='http://thetvdb.com/banners/posters/258604-1.jpg')
                add_posts({'title' : 'Psych',}, index, mode='newznab&newznab=8322',thumb='http://thetvdb.com/banners/posters/79335-1.jpg')
                add_posts({'title' : 'Renegade',}, index, mode='newznab&newznab=4975',thumb='http://thetvdb.com/banners/posters/72348-1.jpg')
                add_posts({'title' : 'Royal Pains',}, index, mode='newznab&newznab=22336',thumb='http://thetvdb.com/banners/posters/92411-1.jpg')
                add_posts({'title' : 'Suits',}, index, mode='newznab&newznab=27518',thumb='http://thetvdb.com/banners/posters/247808-1.jpg')
                add_posts({'title' : 'The 4400',}, index, mode='newznab&newznab=5514',thumb='http://thetvdb.com/banners/posters/73507-1.jpg')
                add_posts({'title' : 'The Net',}, index, mode='newznab&newznab=6012',thumb='http://thetvdb.com/banners/posters/78090-1.jpg')
                add_posts({'title' : 'The Ray Bradbury Theater',}, index, mode='newznab&newznab=6119',thumb='http://thetvdb.com/banners/posters/76259-1.jpg')
                add_posts({'title' : 'To Love and Die',}, index, mode='newznab&newznab=16825')
                add_posts({'title' : 'White Collar',}, index, mode='newznab&newznab=20720',thumb='http://thetvdb.com/banners/posters/108611-1.jpg')
            if newznab_id == 'Velocity':
                add_posts({'title' : 'all girls garage',}, index, mode='newznab&newznab=31428',thumb='http://thetvdb.com/banners/posters/258374-1.jpg')
                add_posts({'title' : 'Graveyard Carz',}, index, mode='newznab&newznab=31993',thumb='http://thetvdb.com/banners/posters/260259-1.jpg')
                add_posts({'title' : 'Inside West Coast Customs',}, index, mode='newznab&newznab=30696',thumb='http://thetvdb.com/banners/posters/247965-1.jpg')
                add_posts({'title' : 'Overhaulin',}, index, mode='newznab&newznab=4755',thumb='http://thetvdb.com/banners/posters/74618-1.jpg')
            if newznab_id == 'Veronica':
                add_posts({'title' : 'Combat',}, index, mode='newznab&newznab=19784',thumb='http://thetvdb.com/banners/posters/73534-1.jpg')
            if newznab_id == 'VH1':
                add_posts({'title' : 'Audrina',}, index, mode='newznab&newznab=23213',thumb='http://thetvdb.com/banners/posters/248039-1.jpg')
                add_posts({'title' : 'Baseball Wives',}, index, mode='newznab&newznab=29989',thumb='http://thetvdb.com/banners/posters/72913-1.jpg')
                add_posts({'title' : 'Beverly Hills Fabulous',}, index, mode='newznab&newznab=27606',thumb='http://thetvdb.com/banners/posters/226831-1.jpg')
                add_posts({'title' : 'Big Ang',}, index, mode='newznab&newznab=31456',thumb='http://thetvdb.com/banners/posters/260271-1.jpg')
                add_posts({'title' : 'Chrissy and Mr Jones',}, index, mode='newznab&newznab=32837',thumb='http://thetvdb.com/banners/posters/262684-1.jpg')
                add_posts({'title' : 'Famous Food',}, index, mode='newznab&newznab=28190',thumb='http://thetvdb.com/banners/posters/250017-1.jpg')
                add_posts({'title' : 'Hey Joel',}, index, mode='newznab&newznab=1033',thumb='http://thetvdb.com/banners/posters/72400-1.jpg')
                add_posts({'title' : 'Hollywood Exes',}, index, mode='newznab&newznab=31697',thumb='http://thetvdb.com/banners/posters/259884-1.jpg')
                add_posts({'title' : 'La Las Full Court Life',}, index, mode='newznab&newznab=29240',thumb='http://thetvdb.com/banners/posters/252749-1.jpg')
                add_posts({'title' : 'La Las Full Court Wedding',}, index, mode='newznab&newznab=26041',thumb='http://thetvdb.com/banners/posters/251173-1.jpg')
                add_posts({'title' : 'Love and Hip Hop Atlanta',}, index, mode='newznab&newznab=31826',thumb='http://thetvdb.com/banners/posters/260074-1.jpg')
                add_posts({'title' : 'Love and Hip Hop',}, index, mode='newznab&newznab=27607')
                add_posts({'title' : 'Love and HipHop',}, index, mode='newznab&newznab=27607')
                add_posts({'title' : 'MaMa Drama',}, index, mode='newznab&newznab=30233',thumb='http://thetvdb.com/banners/posters/260732-1.jpg')
                add_posts({'title' : 'Mob Wives Chicago',}, index, mode='newznab&newznab=31595',thumb='http://thetvdb.com/banners/posters/258737-1.jpg')
                add_posts({'title' : 'Mob Wives',}, index, mode='newznab&newznab=27926',thumb='http://thetvdb.com/banners/posters/248071-1.jpg')
                add_posts({'title' : 'Saddle Ranch',}, index, mode='newznab&newznab=27943',thumb='http://thetvdb.com/banners/posters/226891-1.jpg')
                add_posts({'title' : 'Scott Baio Is 46 And Pregnant',}, index, mode='newznab&newznab=16619',thumb='http://thetvdb.com/banners/posters/249565-1.jpg')
                add_posts({'title' : 'Single Ladies',}, index, mode='newznab&newznab=28141',thumb='http://thetvdb.com/banners/posters/226881-1.jpg')
                add_posts({'title' : 'Stevie TV',}, index, mode='newznab&newznab=30907',thumb='http://thetvdb.com/banners/posters/255308-1.jpg')
                add_posts({'title' : 'Styled By June',}, index, mode='newznab&newznab=31173',thumb='http://thetvdb.com/banners/posters/258524-1.jpg')
                add_posts({'title' : 'T I and Tiny The Family Hustle',}, index, mode='newznab&newznab=30162',thumb='http://thetvdb.com/banners/posters/254176-1.jpg')
                add_posts({'title' : 'The Cho Show',}, index, mode='newznab&newznab=19436')
                add_posts({'title' : 'The T O Show',}, index, mode='newznab&newznab=22849')
                add_posts({'title' : 'The X Life',}, index, mode='newznab&newznab=27198',thumb='http://thetvdb.com/banners/posters/224111-1.jpg')
                add_posts({'title' : 'Ton of Cash',}, index, mode='newznab&newznab=28688',thumb='http://thetvdb.com/banners/posters/226861-1.jpg')
                add_posts({'title' : 'Tough Love',}, index, mode='newznab&newznab=21908',thumb='http://thetvdb.com/banners/posters/85581-1.jpg')
                add_posts({'title' : 'Wedding Wars',}, index, mode='newznab&newznab=25601',thumb='http://thetvdb.com/banners/posters/226911-1.jpg')
                add_posts({'title' : 'What Chilli Wants',}, index, mode='newznab&newznab=23681',thumb='http://thetvdb.com/banners/posters/163661-1.jpg')
                add_posts({'title' : 'Why Am I Still Single',}, index, mode='newznab&newznab=29819',thumb='http://thetvdb.com/banners/posters/252846-1.jpg')
                add_posts({'title' : 'Youre Cut Off',}, index, mode='newznab&newznab=25598',thumb='http://thetvdb.com/banners/posters/169221-1.jpg')
            if newznab_id == 'VH1 Classic':
                add_posts({'title' : 'Metal Evolution',}, index, mode='newznab&newznab=29435',thumb='http://thetvdb.com/banners/posters/253448-1.jpg')
                add_posts({'title' : 'That Metal Show',}, index, mode='newznab&newznab=21537',thumb='http://thetvdb.com/banners/posters/250205-1.jpg')
            if newznab_id == 'VODO':
                add_posts({'title' : 'Pioneer One',}, index, mode='newznab&newznab=25990',thumb='http://thetvdb.com/banners/posters/170551-1.jpg')
            if newznab_id == 'VPRO':
                add_posts({'title' : 'Het Snelle Geld',}, index, mode='newznab&newznab=31722',thumb='http://thetvdb.com/banners/posters/259179-1.jpg')
            if newznab_id == 'VTM':
                add_posts({'title' : 'Aspe',}, index, mode='newznab&newznab=19743',thumb='http://thetvdb.com/banners/posters/81915-1.jpg')
                add_posts({'title' : 'De Zonen Van Van As',}, index, mode='newznab&newznab=31273',thumb='http://thetvdb.com/banners/posters/257701-1.jpg')
            if newznab_id == 'W':
                add_posts({'title' : 'Undercover Boss CA',}, index, mode='newznab&newznab=30861',thumb='http://thetvdb.com/banners/posters/255693-1.jpg')
            if newznab_id == 'W Foxtel':
                add_posts({'title' : 'Spirited',}, index, mode='newznab&newznab=24222',thumb='http://thetvdb.com/banners/posters/184951-1.jpg')
            if newznab_id == 'Warner Bros Japan':
                add_posts({'title' : 'Supernatural The Animation',}, index, mode='newznab&newznab=27870',thumb='http://thetvdb.com/banners/posters/197001-1.jpg')
            if newznab_id == 'Watch':
                add_posts({'title' : 'Dynamo Magician Impossible',}, index, mode='newznab&newznab=29074',thumb='http://thetvdb.com/banners/posters/250136-1.jpg')
                add_posts({'title' : 'Primeval',}, index, mode='newznab&newznab=15138',thumb='http://thetvdb.com/banners/posters/79809-1.jpg')
            if newznab_id == 'WE':
                add_posts({'title' : 'Amazing Wedding Cakes',}, index, mode='newznab&newznab=20007')
                add_posts({'title' : 'Amsale Girls',}, index, mode='newznab&newznab=28607',thumb='http://thetvdb.com/banners/posters/249503-1.jpg')
                add_posts({'title' : 'Braxton Family Values',}, index, mode='newznab&newznab=27586',thumb='http://thetvdb.com/banners/posters/222571-1.jpg')
                add_posts({'title' : 'Braxtons Family Values',}, index, mode='newznab&newznab=27586',thumb='http://thetvdb.com/banners/posters/222571-1.jpg')
                add_posts({'title' : 'Bridezillas',}, index, mode='newznab&newznab=8293',thumb='http://thetvdb.com/banners/posters/79417-1.jpg')
                add_posts({'title' : 'Downsized',}, index, mode='newznab&newznab=26380',thumb='http://thetvdb.com/banners/posters/218141-1.jpg')
                add_posts({'title' : 'Little Miss Perfect',}, index, mode='newznab&newznab=21107')
                add_posts({'title' : 'Raising Sextuplets',}, index, mode='newznab&newznab=22697')
                add_posts({'title' : 'Secret Lives of Women',}, index, mode='newznab&newznab=7059',thumb='http://thetvdb.com/banners/posters/89161-1.jpg')
                add_posts({'title' : 'Sinbad Its Just Family',}, index, mode='newznab&newznab=27922',thumb='http://thetvdb.com/banners/posters/247966-1.jpg')
                add_posts({'title' : 'Tamar and Vince',}, index, mode='newznab&newznab=30469',thumb='http://thetvdb.com/banners/posters/261143-1.jpg')
                add_posts({'title' : 'Texas Multi Mamas',}, index, mode='newznab&newznab=29430',thumb='http://thetvdb.com/banners/posters/253070-1.jpg')
                add_posts({'title' : 'Women Behind Bars',}, index, mode='newznab&newznab=18524')
            if newznab_id == 'Weather Channel':
                add_posts({'title' : 'Coast Guard Alaska',}, index, mode='newznab&newznab=30154',thumb='http://thetvdb.com/banners/posters/253469-1.jpg')
            if newznab_id == 'WGN America':
                add_posts({'title' : 'Inside the Vault',}, index, mode='newznab&newznab=27563',thumb='http://thetvdb.com/banners/posters/233751-1.jpg')
                add_posts({'title' : 'Nite Tales',}, index, mode='newznab&newznab=23555')
            if newznab_id == 'WOWOW':
                add_posts({'title' : 'X',}, index, mode='newznab&newznab=602',thumb='http://thetvdb.com/banners/posters/70865-1.jpg')
            if newznab_id == 'YES':
                add_posts({'title' : 'league of super evil',}, index, mode='newznab&newznab=22520',thumb='http://thetvdb.com/banners/posters/85459-1.jpg')
            if newznab_id == 'yes Comedy':
                add_posts({'title' : 'The Office IL',}, index, mode='newznab&newznab=26620',thumb='http://thetvdb.com/banners/posters/181771-1.jpg')
            if newznab_id == 'Youtube':
                add_posts({'title' : 'The Annoying Orange',}, index, mode='newznab&newznab=31493',thumb='http://thetvdb.com/banners/posters/263980-1.jpg')
                add_posts({'title' : 'The Guild',}, index, mode='newznab&newznab=27025',thumb='http://thetvdb.com/banners/posters/83949-1.jpg')
            if newznab_id == 'YTV':
                add_posts({'title' : 'Kid vs Kat',}, index, mode='newznab&newznab=23085',thumb='http://thetvdb.com/banners/posters/148621-1.jpg')
                add_posts({'title' : 'Mr Young',}, index, mode='newznab&newznab=29758',thumb='http://thetvdb.com/banners/posters/253078-1.jpg')
                add_posts({'title' : 'ReBoot',}, index, mode='newznab&newznab=4954',thumb='http://thetvdb.com/banners/posters/73025-1.jpg')
                add_posts({'title' : 'Sidekick',}, index, mode='newznab&newznab=28651',thumb='http://thetvdb.com/banners/posters/250283-1.jpg')
                add_posts({'title' : 'The Zack Files',}, index, mode='newznab&newznab=6325',thumb='http://thetvdb.com/banners/posters/72159-1.jpg')
            if newznab_id == 'ZDF':
                add_posts({'title' : 'Forsthaus Falkenau',}, index, mode='newznab&newznab=18372')
            if newznab_id == '28984':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28984&extended=1')
            if newznab_id == '31812':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31812&extended=1')
            if newznab_id == '27203':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27203&extended=1')
            if newznab_id == '21064':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21064&extended=1')
            if newznab_id == '29776':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29776&extended=1')
            if newznab_id == '24612':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24612&extended=1')
            if newznab_id == '31802':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31802&extended=1')
            if newznab_id == '31802':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31802&extended=1')
            if newznab_id == '18532':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18532&extended=1')
            if newznab_id == '6718':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6718&extended=1')
            if newznab_id == '7042':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7042&extended=1')
            if newznab_id == '21140':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21140&extended=1')
            if newznab_id == '3337':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3337&extended=1')
            if newznab_id == '30870':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30870&extended=1')
            if newznab_id == '31096':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31096&extended=1')
            if newznab_id == '31096':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31096&extended=1')
            if newznab_id == '11051':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11051&extended=1')
            if newznab_id == '11051':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11051&extended=1')
            if newznab_id == '27210':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27210&extended=1')
            if newznab_id == '23511':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23511&extended=1')
            if newznab_id == '3976':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3976&extended=1')
            if newznab_id == '19673':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19673&extended=1')
            if newznab_id == '21141':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21141&extended=1')
            if newznab_id == '30195':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30195&extended=1')
            if newznab_id == '31376':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31376&extended=1')
            if newznab_id == '29357':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29357&extended=1')
            if newznab_id == '20516':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20516&extended=1')
            if newznab_id == '29697':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29697&extended=1')
            if newznab_id == '18003':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18003&extended=1')
            if newznab_id == '18064':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18064&extended=1')
            if newznab_id == '19279':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19279&extended=1')
            if newznab_id == '27804':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27804&extended=1')
            if newznab_id == '20289':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20289&extended=1')
            if newznab_id == '22723':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22723&extended=1')
            if newznab_id == '30492':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30492&extended=1')
            if newznab_id == '20664':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20664&extended=1')
            if newznab_id == '29364':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29364&extended=1')
            if newznab_id == '26974':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26974&extended=1')
            if newznab_id == '18397':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18397&extended=1')
            if newznab_id == '28553':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28553&extended=1')
            if newznab_id == '2300':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2300&extended=1')
            if newznab_id == '25608':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25608&extended=1')
            if newznab_id == '33389':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33389&extended=1')
            if newznab_id == '27939':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27939&extended=1')
            if newznab_id == '30744':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30744&extended=1')
            if newznab_id == '2464':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2464&extended=1')
            if newznab_id == '2481':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2481&extended=1')
            if newznab_id == '27742':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27742&extended=1')
            if newznab_id == '31593':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31593&extended=1')
            if newznab_id == '2538':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2538&extended=1')
            if newznab_id == '2537':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2537&extended=1')
            if newznab_id == '2584':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2584&extended=1')
            if newznab_id == '7555':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7555&extended=1')
            if newznab_id == '2689':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2689&extended=1')
            if newznab_id == '2029':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2029&extended=1')
            if newznab_id == '31227':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31227&extended=1')
            if newznab_id == '2707':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2707&extended=1')
            if newznab_id == '18984':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18984&extended=1')
            if newznab_id == '2761':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2761&extended=1')
            if newznab_id == '19907':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19907&extended=1')
            if newznab_id == '25745':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25745&extended=1')
            if newznab_id == '2779':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2779&extended=1')
            if newznab_id == '2850':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2850&extended=1')
            if newznab_id == '25718':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25718&extended=1')
            if newznab_id == '2882':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2882&extended=1')
            if newznab_id == '2887':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2887&extended=1')
            if newznab_id == '8090':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8090&extended=1')
            if newznab_id == '107':
                url_out = (newznab_url_search + '&t=tvsearch&rid=107&extended=1')
            if newznab_id == '2937':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2937&extended=1')
            if newznab_id == '11926':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11926&extended=1')
            if newznab_id == '19267':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19267&extended=1')
            if newznab_id == '24634':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24634&extended=1')
            if newznab_id == '3114':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3114&extended=1')
            if newznab_id == '3220':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3220&extended=1')
            if newznab_id == '3294':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3294&extended=1')
            if newznab_id == '25043':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25043&extended=1')
            if newznab_id == '3299':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3299&extended=1')
            if newznab_id == '23727':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23727&extended=1')
            if newznab_id == '23727':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23727&extended=1')
            if newznab_id == '3344':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3344&extended=1')
            if newznab_id == '3344':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3344&extended=1')
            if newznab_id == '31302':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31302&extended=1')
            if newznab_id == '3426':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3426&extended=1')
            if newznab_id == '15727':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15727&extended=1')
            if newznab_id == '3441':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3441&extended=1')
            if newznab_id == '27940':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27940&extended=1')
            if newznab_id == '3476':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3476&extended=1')
            if newznab_id == '26171':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26171&extended=1')
            if newznab_id == '15840':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15840&extended=1')
            if newznab_id == '7561':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7561&extended=1')
            if newznab_id == '28393':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28393&extended=1')
            if newznab_id == '3741':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3741&extended=1')
            if newznab_id == '3747':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3747&extended=1')
            if newznab_id == '3785':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3785&extended=1')
            if newznab_id == '25661':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25661&extended=1')
            if newznab_id == '3799':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3799&extended=1')
            if newznab_id == '200':
                url_out = (newznab_url_search + '&t=tvsearch&rid=200&extended=1')
            if newznab_id == '3894':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3894&extended=1')
            if newznab_id == '23967':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23967&extended=1')
            if newznab_id == '24887':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24887&extended=1')
            if newznab_id == '11616':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11616&extended=1')
            if newznab_id == '28411':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28411&extended=1')
            if newznab_id == '4162':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4162&extended=1')
            if newznab_id == '11571':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11571&extended=1')
            if newznab_id == '4178':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4178&extended=1')
            if newznab_id == '28386':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28386&extended=1')
            if newznab_id == '30614':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30614&extended=1')
            if newznab_id == '4207':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4207&extended=1')
            if newznab_id == '4213':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4213&extended=1')
            if newznab_id == '11593':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11593&extended=1')
            if newznab_id == '4284':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4284&extended=1')
            if newznab_id == '23973':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23973&extended=1')
            if newznab_id == '30840':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30840&extended=1')
            if newznab_id == '28395':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28395&extended=1')
            if newznab_id == '8':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8&extended=1')
            if newznab_id == '4391':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4391&extended=1')
            if newznab_id == '28396':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28396&extended=1')
            if newznab_id == '22622':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22622&extended=1')
            if newznab_id == '25048':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25048&extended=1')
            if newznab_id == '4610':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4610&extended=1')
            if newznab_id == '30808':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30808&extended=1')
            if newznab_id == '4670':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4670&extended=1')
            if newznab_id == '25011':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25011&extended=1')
            if newznab_id == '7630':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7630&extended=1')
            if newznab_id == '31939':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31939&extended=1')
            if newznab_id == '4698':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4698&extended=1')
            if newznab_id == '8344':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8344&extended=1')
            if newznab_id == '24993':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24993&extended=1')
            if newznab_id == '4713':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4713&extended=1')
            if newznab_id == '28385':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28385&extended=1')
            if newznab_id == '28397':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28397&extended=1')
            if newznab_id == '24366':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24366&extended=1')
            if newznab_id == '195':
                url_out = (newznab_url_search + '&t=tvsearch&rid=195&extended=1')
            if newznab_id == '15576':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15576&extended=1')
            if newznab_id == '15716':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15716&extended=1')
            if newznab_id == '28387':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28387&extended=1')
            if newznab_id == '5055':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5055&extended=1')
            if newznab_id == '15713':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15713&extended=1')
            if newznab_id == '28398':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28398&extended=1')
            if newznab_id == '5112':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5112&extended=1')
            if newznab_id == '5118':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5118&extended=1')
            if newznab_id == '19012':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19012&extended=1')
            if newznab_id == '22610':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22610&extended=1')
            if newznab_id == '30936':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30936&extended=1')
            if newznab_id == '5220':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5220&extended=1')
            if newznab_id == '18453':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18453&extended=1')
            if newznab_id == '5292':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5292&extended=1')
            if newznab_id == '5301':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5301&extended=1')
            if newznab_id == '28399':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28399&extended=1')
            if newznab_id == '5409':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5409&extended=1')
            if newznab_id == '27690':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27690&extended=1')
            if newznab_id == '5455':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5455&extended=1')
            if newznab_id == '55':
                url_out = (newznab_url_search + '&t=tvsearch&rid=55&extended=1')
            if newznab_id == '5521':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5521&extended=1')
            if newznab_id == '5593':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5593&extended=1')
            if newznab_id == '5594':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5594&extended=1')
            if newznab_id == '5622':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5622&extended=1')
            if newznab_id == '5643':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5643&extended=1')
            if newznab_id == '17703':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17703&extended=1')
            if newznab_id == '5730':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5730&extended=1')
            if newznab_id == '5785':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5785&extended=1')
            if newznab_id == '31736':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31736&extended=1')
            if newznab_id == '5817':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5817&extended=1')
            if newznab_id == '19716':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19716&extended=1')
            if newznab_id == '17863':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17863&extended=1')
            if newznab_id == '11550':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11550&extended=1')
            if newznab_id == '8570':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8570&extended=1')
            if newznab_id == '20678':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20678&extended=1')
            if newznab_id == '31677':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31677&extended=1')
            if newznab_id == '10680':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10680&extended=1')
            if newznab_id == '6070':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6070&extended=1')
            if newznab_id == '6105':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6105&extended=1')
            if newznab_id == '28362':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28362&extended=1')
            if newznab_id == '829':
                url_out = (newznab_url_search + '&t=tvsearch&rid=829&extended=1')
            if newznab_id == '6239':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6239&extended=1')
            if newznab_id == '6302':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6302&extended=1')
            if newznab_id == '6324':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6324&extended=1')
            if newznab_id == '6331':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6331&extended=1')
            if newznab_id == '6383':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6383&extended=1')
            if newznab_id == '31854':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31854&extended=1')
            if newznab_id == '11325':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11325&extended=1')
            if newznab_id == '8089':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8089&extended=1')
            if newznab_id == '22814':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22814&extended=1')
            if newznab_id == '6524':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6524&extended=1')
            if newznab_id == '6531':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6531&extended=1')
            if newznab_id == '6566':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6566&extended=1')
            if newznab_id == '18387':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18387&extended=1')
            if newznab_id == '18959':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18959&extended=1')
            if newznab_id == '28412':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28412&extended=1')
            if newznab_id == '30065':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30065&extended=1')
            if newznab_id == '6705':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6705&extended=1')
            if newznab_id == '21702':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21702&extended=1')
            if newznab_id == '30876':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30876&extended=1')
            if newznab_id == '30877':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30877&extended=1')
            if newznab_id == '2803':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2803&extended=1')
            if newznab_id == '30871':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30871&extended=1')
            if newznab_id == '16432':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16432&extended=1')
            if newznab_id == '25632':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25632&extended=1')
            if newznab_id == '28367':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28367&extended=1')
            if newznab_id == '10629':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10629&extended=1')
            if newznab_id == '22679':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22679&extended=1')
            if newznab_id == '25864':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25864&extended=1')
            if newznab_id == '25591':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25591&extended=1')
            if newznab_id == '28360':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28360&extended=1')
            if newznab_id == '27701':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27701&extended=1')
            if newznab_id == '27661':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27661&extended=1')
            if newznab_id == '27745':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27745&extended=1')
            if newznab_id == '18837':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18837&extended=1')
            if newznab_id == '33437':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33437&extended=1')
            if newznab_id == '28421':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28421&extended=1')
            if newznab_id == '29458':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29458&extended=1')
            if newznab_id == '29458':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29458&extended=1')
            if newznab_id == '28942':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28942&extended=1')
            if newznab_id == '29688':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29688&extended=1')
            if newznab_id == '27571':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27571&extended=1')
            if newznab_id == '28901':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28901&extended=1')
            if newznab_id == '30923':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30923&extended=1')
            if newznab_id == '32111':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32111&extended=1')
            if newznab_id == '30937':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30937&extended=1')
            if newznab_id == '26845':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26845&extended=1')
            if newznab_id == '30071':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30071&extended=1')
            if newznab_id == '24221':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24221&extended=1')
            if newznab_id == '30677':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30677&extended=1')
            if newznab_id == '30939':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30939&extended=1')
            if newznab_id == '32269':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32269&extended=1')
            if newznab_id == '17719':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17719&extended=1')
            if newznab_id == '24519':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24519&extended=1')
            if newznab_id == '17315':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17315&extended=1')
            if newznab_id == '29457':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29457&extended=1')
            if newznab_id == '23999':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23999&extended=1')
            if newznab_id == '23963':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23963&extended=1')
            if newznab_id == '23963':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23963&extended=1')
            if newznab_id == '31210':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31210&extended=1')
            if newznab_id == '23974':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23974&extended=1')
            if newznab_id == '29377':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29377&extended=1')
            if newznab_id == '28979':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28979&extended=1')
            if newznab_id == '25907':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25907&extended=1')
            if newznab_id == '2638':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2638&extended=1')
            if newznab_id == '10934':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10934&extended=1')
            if newznab_id == '30112':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30112&extended=1')
            if newznab_id == '24636':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24636&extended=1')
            if newznab_id == '28441':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28441&extended=1')
            if newznab_id == '20799':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20799&extended=1')
            if newznab_id == '24654':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24654&extended=1')
            if newznab_id == '26054':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26054&extended=1')
            if newznab_id == '12636':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12636&extended=1')
            if newznab_id == '7038':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7038&extended=1')
            if newznab_id == '28439':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28439&extended=1')
            if newznab_id == '5027':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5027&extended=1')
            if newznab_id == '2292':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2292&extended=1')
            if newznab_id == '15529':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15529&extended=1')
            if newznab_id == '15528':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15528&extended=1')
            if newznab_id == '28440':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28440&extended=1')
            if newznab_id == '6270':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6270&extended=1')
            if newznab_id == '15069':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15069&extended=1')
            if newznab_id == '6379':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6379&extended=1')
            if newznab_id == '18164':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18164&extended=1')
            if newznab_id == '30604':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30604&extended=1')
            if newznab_id == '27195':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27195&extended=1')
            if newznab_id == '16356':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16356&extended=1')
            if newznab_id == '23400':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23400&extended=1')
            if newznab_id == '31941':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31941&extended=1')
            if newznab_id == '29695':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29695&extended=1')
            if newznab_id == '27387':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27387&extended=1')
            if newznab_id == '31349':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31349&extended=1')
            if newznab_id == '25056':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25056&extended=1')
            if newznab_id == '25056':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25056&extended=1')
            if newznab_id == '30516':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30516&extended=1')
            if newznab_id == '2615':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2615&extended=1')
            if newznab_id == '19592':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19592&extended=1')
            if newznab_id == '19226':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19226&extended=1')
            if newznab_id == '27781':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27781&extended=1')
            if newznab_id == '29757':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29757&extended=1')
            if newznab_id == '29757':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29757&extended=1')
            if newznab_id == '20728':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20728&extended=1')
            if newznab_id == '26161':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26161&extended=1')
            if newznab_id == '20306':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20306&extended=1')
            if newznab_id == '24806':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24806&extended=1')
            if newznab_id == '28516':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28516&extended=1')
            if newznab_id == '32866':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32866&extended=1')
            if newznab_id == '30517':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30517&extended=1')
            if newznab_id == '28969':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28969&extended=1')
            if newznab_id == '28969':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28969&extended=1')
            if newznab_id == '27199':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27199&extended=1')
            if newznab_id == '6733':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6733&extended=1')
            if newznab_id == '6733':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6733&extended=1')
            if newznab_id == '27170':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27170&extended=1')
            if newznab_id == '23233':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23233&extended=1')
            if newznab_id == '24027':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24027&extended=1')
            if newznab_id == '33514':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33514&extended=1')
            if newznab_id == '27925':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27925&extended=1')
            if newznab_id == '21191':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21191&extended=1')
            if newznab_id == '31738':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31738&extended=1')
            if newznab_id == '23072':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23072&extended=1')
            if newznab_id == '27284':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27284&extended=1')
            if newznab_id == '28065':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28065&extended=1')
            if newznab_id == '29434':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29434&extended=1')
            if newznab_id == '7902':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7902&extended=1')
            if newznab_id == '31126':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31126&extended=1')
            if newznab_id == '31947':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31947&extended=1')
            if newznab_id == '27050':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27050&extended=1')
            if newznab_id == '25875':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25875&extended=1')
            if newznab_id == '24543':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24543&extended=1')
            if newznab_id == '24447':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24447&extended=1')
            if newznab_id == '24447':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24447&extended=1')
            if newznab_id == '29478':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29478&extended=1')
            if newznab_id == '29120':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29120&extended=1')
            if newznab_id == '30925':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30925&extended=1')
            if newznab_id == '21955':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21955&extended=1')
            if newznab_id == '29130':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29130&extended=1')
            if newznab_id == '30523':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30523&extended=1')
            if newznab_id == '28527':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28527&extended=1')
            if newznab_id == '27562':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27562&extended=1')
            if newznab_id == '28995':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28995&extended=1')
            if newznab_id == '5704':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5704&extended=1')
            if newznab_id == '31057':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31057&extended=1')
            if newznab_id == '29419':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29419&extended=1')
            if newznab_id == '31585':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31585&extended=1')
            if newznab_id == '20399':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20399&extended=1')
            if newznab_id == '28449':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28449&extended=1')
            if newznab_id == '20957':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20957&extended=1')
            if newznab_id == '28312':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28312&extended=1')
            if newznab_id == '31351':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31351&extended=1')
            if newznab_id == '18213':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18213&extended=1')
            if newznab_id == '19621':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19621&extended=1')
            if newznab_id == '26295':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26295&extended=1')
            if newznab_id == '7221':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7221&extended=1')
            if newznab_id == '29818':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29818&extended=1')
            if newznab_id == '29889':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29889&extended=1')
            if newznab_id == '26841':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26841&extended=1')
            if newznab_id == '19352':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19352&extended=1')
            if newznab_id == '29902':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29902&extended=1')
            if newznab_id == '25845':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25845&extended=1')
            if newznab_id == '29890':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29890&extended=1')
            if newznab_id == '29848':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29848&extended=1')
            if newznab_id == '27565':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27565&extended=1')
            if newznab_id == '30120':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30120&extended=1')
            if newznab_id == '33237':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33237&extended=1')
            if newznab_id == '30984':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30984&extended=1')
            if newznab_id == '32232':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32232&extended=1')
            if newznab_id == '32260':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32260&extended=1')
            if newznab_id == '28812':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28812&extended=1')
            if newznab_id == '28147':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28147&extended=1')
            if newznab_id == '13011':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13011&extended=1')
            if newznab_id == '27204':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27204&extended=1')
            if newznab_id == '29231':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29231&extended=1')
            if newznab_id == '29231':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29231&extended=1')
            if newznab_id == '27873':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27873&extended=1')
            if newznab_id == '23309':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23309&extended=1')
            if newznab_id == '29042':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29042&extended=1')
            if newznab_id == '28758':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28758&extended=1')
            if newznab_id == '31290':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31290&extended=1')
            if newznab_id == '30644':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30644&extended=1')
            if newznab_id == '21949':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21949&extended=1')
            if newznab_id == '30141':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30141&extended=1')
            if newznab_id == '29674':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29674&extended=1')
            if newznab_id == '31848':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31848&extended=1')
            if newznab_id == '26537':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26537&extended=1')
            if newznab_id == '33391':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33391&extended=1')
            if newznab_id == '23123':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23123&extended=1')
            if newznab_id == '27931':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27931&extended=1')
            if newznab_id == '22135':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22135&extended=1')
            if newznab_id == '33678':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33678&extended=1')
            if newznab_id == '32746':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32746&extended=1')
            if newznab_id == '29402':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29402&extended=1')
            if newznab_id == '33438':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33438&extended=1')
            if newznab_id == '25487':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25487&extended=1')
            if newznab_id == '30762':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30762&extended=1')
            if newznab_id == '29814':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29814&extended=1')
            if newznab_id == '29991':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29991&extended=1')
            if newznab_id == '33609':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33609&extended=1')
            if newznab_id == '28072':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28072&extended=1')
            if newznab_id == '30676':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30676&extended=1')
            if newznab_id == '31296':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31296&extended=1')
            if newznab_id == '30394':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30394&extended=1')
            if newznab_id == '27656':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27656&extended=1')
            if newznab_id == '31831':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31831&extended=1')
            if newznab_id == '7108':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7108&extended=1')
            if newznab_id == '33770':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33770&extended=1')
            if newznab_id == '28744':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28744&extended=1')
            if newznab_id == '12707':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12707&extended=1')
            if newznab_id == '27788':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27788&extended=1')
            if newznab_id == '2456':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2456&extended=1')
            if newznab_id == '667':
                url_out = (newznab_url_search + '&t=tvsearch&rid=667&extended=1')
            if newznab_id == '7341':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7341&extended=1')
            if newznab_id == '2477':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2477&extended=1')
            if newznab_id == '26855':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26855&extended=1')
            if newznab_id == '32736':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32736&extended=1')
            if newznab_id == '28407':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28407&extended=1')
            if newznab_id == '7762':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7762&extended=1')
            if newznab_id == '32233':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32233&extended=1')
            if newznab_id == '26616':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26616&extended=1')
            if newznab_id == '2704':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2704&extended=1')
            if newznab_id == '23312':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23312&extended=1')
            if newznab_id == '29653':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29653&extended=1')
            if newznab_id == '1624':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1624&extended=1')
            if newznab_id == '12588':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12588&extended=1')
            if newznab_id == '2763':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2763&extended=1')
            if newznab_id == '30598':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30598&extended=1')
            if newznab_id == '5626':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5626&extended=1')
            if newznab_id == '32037':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32037&extended=1')
            if newznab_id == '2318':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2318&extended=1')
            if newznab_id == '2823':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2823&extended=1')
            if newznab_id == '2861':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2861&extended=1')
            if newznab_id == '17689':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17689&extended=1')
            if newznab_id == '33057':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33057&extended=1')
            if newznab_id == '19745':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19745&extended=1')
            if newznab_id == '29139':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29139&extended=1')
            if newznab_id == '31710':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31710&extended=1')
            if newznab_id == '2933':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2933&extended=1')
            if newznab_id == '14333':
                url_out = (newznab_url_search + '&t=tvsearch&rid=14333&extended=1')
            if newznab_id == '30579':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30579&extended=1')
            if newznab_id == '28469':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28469&extended=1')
            if newznab_id == '3005':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3005&extended=1')
            if newznab_id == '3033':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3033&extended=1')
            if newznab_id == '31573':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31573&extended=1')
            if newznab_id == '32448':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32448&extended=1')
            if newznab_id == '27012':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27012&extended=1')
            if newznab_id == '22277':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22277&extended=1')
            if newznab_id == '11083':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11083&extended=1')
            if newznab_id == '8321':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8321&extended=1')
            if newznab_id == '19329':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19329&extended=1')
            if newznab_id == '873':
                url_out = (newznab_url_search + '&t=tvsearch&rid=873&extended=1')
            if newznab_id == '3202':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3202&extended=1')
            if newznab_id == '3213':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3213&extended=1')
            if newznab_id == '29741':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29741&extended=1')
            if newznab_id == '30719':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30719&extended=1')
            if newznab_id == '3314':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3314&extended=1')
            if newznab_id == '29596':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29596&extended=1')
            if newznab_id == '10928':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10928&extended=1')
            if newznab_id == '3332':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3332&extended=1')
            if newznab_id == '3331':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3331&extended=1')
            if newznab_id == '12012':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12012&extended=1')
            if newznab_id == '30880':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30880&extended=1')
            if newznab_id == '30318':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30318&extended=1')
            if newznab_id == '3418':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3418&extended=1')
            if newznab_id == '29145':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29145&extended=1')
            if newznab_id == '27899':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27899&extended=1')
            if newznab_id == '28631':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28631&extended=1')
            if newznab_id == '27632':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27632&extended=1')
            if newznab_id == '9311':
                url_out = (newznab_url_search + '&t=tvsearch&rid=9311&extended=1')
            if newznab_id == '26530':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26530&extended=1')
            if newznab_id == '1416':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1416&extended=1')
            if newznab_id == '8889':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8889&extended=1')
            if newznab_id == '13028':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13028&extended=1')
            if newznab_id == '24045':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24045&extended=1')
            if newznab_id == '30966':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30966&extended=1')
            if newznab_id == '27911':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27911&extended=1')
            if newznab_id == '15597':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15597&extended=1')
            if newznab_id == '32449':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32449&extended=1')
            if newznab_id == '3722':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3722&extended=1')
            if newznab_id == '30234':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30234&extended=1')
            if newznab_id == '29144':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29144&extended=1')
            if newznab_id == '3804':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3804&extended=1')
            if newznab_id == '29556':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29556&extended=1')
            if newznab_id == '15567':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15567&extended=1')
            if newznab_id == '3876':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3876&extended=1')
            if newznab_id == '30820':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30820&extended=1')
            if newznab_id == '17544':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17544&extended=1')
            if newznab_id == '12290':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12290&extended=1')
            if newznab_id == '368':
                url_out = (newznab_url_search + '&t=tvsearch&rid=368&extended=1')
            if newznab_id == '27134':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27134&extended=1')
            if newznab_id == '32213':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32213&extended=1')
            if newznab_id == '1281':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1281&extended=1')
            if newznab_id == '11237':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11237&extended=1')
            if newznab_id == '28420':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28420&extended=1')
            if newznab_id == '30663':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30663&extended=1')
            if newznab_id == '8213':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8213&extended=1')
            if newznab_id == '28100':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28100&extended=1')
            if newznab_id == '15068':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15068&extended=1')
            if newznab_id == '33499':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33499&extended=1')
            if newznab_id == '26180':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26180&extended=1')
            if newznab_id == '4073':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4073&extended=1')
            if newznab_id == '785':
                url_out = (newznab_url_search + '&t=tvsearch&rid=785&extended=1')
            if newznab_id == '27077':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27077&extended=1')
            if newznab_id == '64':
                url_out = (newznab_url_search + '&t=tvsearch&rid=64&extended=1')
            if newznab_id == '30720':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30720&extended=1')
            if newznab_id == '23712':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23712&extended=1')
            if newznab_id == '17974':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17974&extended=1')
            if newznab_id == '1877':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1877&extended=1')
            if newznab_id == '32658':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32658&extended=1')
            if newznab_id == '28629':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28629&extended=1')
            if newznab_id == '21815':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21815&extended=1')
            if newznab_id == '20910':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20910&extended=1')
            if newznab_id == '7158':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7158&extended=1')
            if newznab_id == '23271':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23271&extended=1')
            if newznab_id == '12739':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12739&extended=1')
            if newznab_id == '17842':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17842&extended=1')
            if newznab_id == '19639':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19639&extended=1')
            if newznab_id == '26573':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26573&extended=1')
            if newznab_id == '23777':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23777&extended=1')
            if newznab_id == '4303':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4303&extended=1')
            if newznab_id == '4301':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4301&extended=1')
            if newznab_id == '25522':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25522&extended=1')
            if newznab_id == '13245':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13245&extended=1')
            if newznab_id == '4340':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4340&extended=1')
            if newznab_id == '32947':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32947&extended=1')
            if newznab_id == '18834':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18834&extended=1')
            if newznab_id == '22905':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22905&extended=1')
            if newznab_id == '24313':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24313&extended=1')
            if newznab_id == '17865':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17865&extended=1')
            if newznab_id == '22613':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22613&extended=1')
            if newznab_id == '27551':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27551&extended=1')
            if newznab_id == '4556':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4556&extended=1')
            if newznab_id == '4574':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4574&extended=1')
            if newznab_id == '29054':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29054&extended=1')
            if newznab_id == '21608':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21608&extended=1')
            if newznab_id == '27634':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27634&extended=1')
            if newznab_id == '23455':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23455&extended=1')
            if newznab_id == '4652':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4652&extended=1')
            if newznab_id == '33332':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33332&extended=1')
            if newznab_id == '29491':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29491&extended=1')
            if newznab_id == '23779':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23779&extended=1')
            if newznab_id == '30150':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30150&extended=1')
            if newznab_id == '10792':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10792&extended=1')
            if newznab_id == '29140':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29140&extended=1')
            if newznab_id == '31091':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31091&extended=1')
            if newznab_id == '4727':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4727&extended=1')
            if newznab_id == '26356':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26356&extended=1')
            if newznab_id == '17215':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17215&extended=1')
            if newznab_id == '10101':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10101&extended=1')
            if newznab_id == '20142':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20142&extended=1')
            if newznab_id == '4824':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4824&extended=1')
            if newznab_id == '29344':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29344&extended=1')
            if newznab_id == '31475':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31475&extended=1')
            if newznab_id == '8077':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8077&extended=1')
            if newznab_id == '1909':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1909&extended=1')
            if newznab_id == '30664':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30664&extended=1')
            if newznab_id == '27901':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27901&extended=1')
            if newznab_id == '25272':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25272&extended=1')
            if newznab_id == '28893':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28893&extended=1')
            if newznab_id == '33253':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33253&extended=1')
            if newznab_id == '24342':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24342&extended=1')
            if newznab_id == '31454':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31454&extended=1')
            if newznab_id == '10436':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10436&extended=1')
            if newznab_id == '23432':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23432&extended=1')
            if newznab_id == '5050':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5050&extended=1')
            if newznab_id == '23542':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23542&extended=1')
            if newznab_id == '11092':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11092&extended=1')
            if newznab_id == '27797':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27797&extended=1')
            if newznab_id == '15251':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15251&extended=1')
            if newznab_id == '23433':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23433&extended=1')
            if newznab_id == '5186':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5186&extended=1')
            if newznab_id == '5199':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5199&extended=1')
            if newznab_id == '27552':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27552&extended=1')
            if newznab_id == '33653':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33653&extended=1')
            if newznab_id == '24566':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24566&extended=1')
            if newznab_id == '1665':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1665&extended=1')
            if newznab_id == '8283':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8283&extended=1')
            if newznab_id == '5259':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5259&extended=1')
            if newznab_id == '27550':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27550&extended=1')
            if newznab_id == '4458':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4458&extended=1')
            if newznab_id == '5343':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5343&extended=1')
            if newznab_id == '6747':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6747&extended=1')
            if newznab_id == '6747':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6747&extended=1')
            if newznab_id == '28810':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28810&extended=1')
            if newznab_id == '28950':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28950&extended=1')
            if newznab_id == '30768':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30768&extended=1')
            if newznab_id == '28305':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28305&extended=1')
            if newznab_id == '33407':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33407&extended=1')
            if newznab_id == '27413':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27413&extended=1')
            if newznab_id == '30135':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30135&extended=1')
            if newznab_id == '5544':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5544&extended=1')
            if newznab_id == '5582':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5582&extended=1')
            if newznab_id == '27627':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27627&extended=1')
            if newznab_id == '29345':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29345&extended=1')
            if newznab_id == '29346':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29346&extended=1')
            if newznab_id == '7958':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7958&extended=1')
            if newznab_id == '13535':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13535&extended=1')
            if newznab_id == '30718':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30718&extended=1')
            if newznab_id == '5775':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5775&extended=1')
            if newznab_id == '29206':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29206&extended=1')
            if newznab_id == '32372':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32372&extended=1')
            if newznab_id == '28704':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28704&extended=1')
            if newznab_id == '15181':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15181&extended=1')
            if newznab_id == '30843':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30843&extended=1')
            if newznab_id == '28813':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28813&extended=1')
            if newznab_id == '10750':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10750&extended=1')
            if newznab_id == '24240':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24240&extended=1')
            if newznab_id == '26854':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26854&extended=1')
            if newznab_id == '3972':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3972&extended=1')
            if newznab_id == '27130':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27130&extended=1')
            if newznab_id == '30136':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30136&extended=1')
            if newznab_id == '31250':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31250&extended=1')
            if newznab_id == '30389':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30389&extended=1')
            if newznab_id == '943':
                url_out = (newznab_url_search + '&t=tvsearch&rid=943&extended=1')
            if newznab_id == '32796':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32796&extended=1')
            if newznab_id == '29382':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29382&extended=1')
            if newznab_id == '30236':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30236&extended=1')
            if newznab_id == '13365':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13365&extended=1')
            if newznab_id == '33355':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33355&extended=1')
            if newznab_id == '29147':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29147&extended=1')
            if newznab_id == '10292':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10292&extended=1')
            if newznab_id == '10853':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10853&extended=1')
            if newznab_id == '6233':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6233&extended=1')
            if newznab_id == '32035':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32035&extended=1')
            if newznab_id == '426':
                url_out = (newznab_url_search + '&t=tvsearch&rid=426&extended=1')
            if newznab_id == '28668':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28668&extended=1')
            if newznab_id == '31113':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31113&extended=1')
            if newznab_id == '6993':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6993&extended=1')
            if newznab_id == '20835':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20835&extended=1')
            if newznab_id == '10931':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10931&extended=1')
            if newznab_id == '9926':
                url_out = (newznab_url_search + '&t=tvsearch&rid=9926&extended=1')
            if newznab_id == '15124':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15124&extended=1')
            if newznab_id == '31003':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31003&extended=1')
            if newznab_id == '26821':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26821&extended=1')
            if newznab_id == '27014':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27014&extended=1')
            if newznab_id == '29053':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29053&extended=1')
            if newznab_id == '6533':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6533&extended=1')
            if newznab_id == '18175':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18175&extended=1')
            if newznab_id == '15198':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15198&extended=1')
            if newznab_id == '12515':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12515&extended=1')
            if newznab_id == '33380':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33380&extended=1')
            if newznab_id == '7963':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7963&extended=1')
            if newznab_id == '8531':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8531&extended=1')
            if newznab_id == '13164':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13164&extended=1')
            if newznab_id == '23856':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23856&extended=1')
            if newznab_id == '7436':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7436&extended=1')
            if newznab_id == '16424':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16424&extended=1')
            if newznab_id == '30235':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30235&extended=1')
            if newznab_id == '27129':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27129&extended=1')
            if newznab_id == '27347':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27347&extended=1')
            if newznab_id == '27717':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27717&extended=1')
            if newznab_id == '32413':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32413&extended=1')
            if newznab_id == '18434':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18434&extended=1')
            if newznab_id == '30460':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30460&extended=1')
            if newznab_id == '22329':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22329&extended=1')
            if newznab_id == '27867':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27867&extended=1')
            if newznab_id == '27646':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27646&extended=1')
            if newznab_id == '31830':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31830&extended=1')
            if newznab_id == '20167':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20167&extended=1')
            if newznab_id == '32811':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32811&extended=1')
            if newznab_id == '30960':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30960&extended=1')
            if newznab_id == '3333':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3333&extended=1')
            if newznab_id == '12780':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12780&extended=1')
            if newznab_id == '31256':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31256&extended=1')
            if newznab_id == '17776':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17776&extended=1')
            if newznab_id == '29043':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29043&extended=1')
            if newznab_id == '26478':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26478&extended=1')
            if newznab_id == '29883':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29883&extended=1')
            if newznab_id == '24986':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24986&extended=1')
            if newznab_id == '27156':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27156&extended=1')
            if newznab_id == '19838':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19838&extended=1')
            if newznab_id == '30436':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30436&extended=1')
            if newznab_id == '27625':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27625&extended=1')
            if newznab_id == '2073':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2073&extended=1')
            if newznab_id == '27510':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27510&extended=1')
            if newznab_id == '28594':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28594&extended=1')
            if newznab_id == '28569':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28569&extended=1')
            if newznab_id == '25872':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25872&extended=1')
            if newznab_id == '26673':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26673&extended=1')
            if newznab_id == '31714':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31714&extended=1')
            if newznab_id == '23715':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23715&extended=1')
            if newznab_id == '27865':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27865&extended=1')
            if newznab_id == '25870':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25870&extended=1')
            if newznab_id == '28419':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28419&extended=1')
            if newznab_id == '30844':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30844&extended=1')
            if newznab_id == '30919':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30919&extended=1')
            if newznab_id == '24140':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24140&extended=1')
            if newznab_id == '24140':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24140&extended=1')
            if newznab_id == '28394':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28394&extended=1')
            if newznab_id == '29209':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29209&extended=1')
            if newznab_id == '19318':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19318&extended=1')
            if newznab_id == '33333':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33333&extended=1')
            if newznab_id == '32427':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32427&extended=1')
            if newznab_id == '30667':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30667&extended=1')
            if newznab_id == '27157':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27157&extended=1')
            if newznab_id == '30459':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30459&extended=1')
            if newznab_id == '28456':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28456&extended=1')
            if newznab_id == '27470':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27470&extended=1')
            if newznab_id == '30375':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30375&extended=1')
            if newznab_id == '28895':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28895&extended=1')
            if newznab_id == '8179':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8179&extended=1')
            if newznab_id == '21017':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21017&extended=1')
            if newznab_id == '23796':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23796&extended=1')
            if newznab_id == '23796':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23796&extended=1')
            if newznab_id == '32657':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32657&extended=1')
            if newznab_id == '6457':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6457&extended=1')
            if newznab_id == '23214':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23214&extended=1')
            if newznab_id == '32426':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32426&extended=1')
            if newznab_id == '27635':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27635&extended=1')
            if newznab_id == '28488':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28488&extended=1')
            if newznab_id == '23306':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23306&extended=1')
            if newznab_id == '28146':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28146&extended=1')
            if newznab_id == '29261':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29261&extended=1')
            if newznab_id == '27428':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27428&extended=1')
            if newznab_id == '27091':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27091&extended=1')
            if newznab_id == '27091':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27091&extended=1')
            if newznab_id == '28636':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28636&extended=1')
            if newznab_id == '28636':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28636&extended=1')
            if newznab_id == '20538':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20538&extended=1')
            if newznab_id == '29486':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29486&extended=1')
            if newznab_id == '7293':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7293&extended=1')
            if newznab_id == '1370':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1370&extended=1')
            if newznab_id == '30665':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30665&extended=1')
            if newznab_id == '29610':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29610&extended=1')
            if newznab_id == '30705':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30705&extended=1')
            if newznab_id == '25222':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25222&extended=1')
            if newznab_id == '32738':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32738&extended=1')
            if newznab_id == '31466':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31466&extended=1')
            if newznab_id == '27080':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27080&extended=1')
            if newznab_id == '20773':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20773&extended=1')
            if newznab_id == '31807':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31807&extended=1')
            if newznab_id == '33337':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33337&extended=1')
            if newznab_id == '33255':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33255&extended=1')
            if newznab_id == '23917':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23917&extended=1')
            if newznab_id == '12709':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12709&extended=1')
            if newznab_id == '27135':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27135&extended=1')
            if newznab_id == '30769':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30769&extended=1')
            if newznab_id == '24884':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24884&extended=1')
            if newznab_id == '27673':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27673&extended=1')
            if newznab_id == '557':
                url_out = (newznab_url_search + '&t=tvsearch&rid=557&extended=1')
            if newznab_id == '31199':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31199&extended=1')
            if newznab_id == '30766':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30766&extended=1')
            if newznab_id == '30040':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30040&extended=1')
            if newznab_id == '27864':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27864&extended=1')
            if newznab_id == '28168':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28168&extended=1')
            if newznab_id == '28193':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28193&extended=1')
            if newznab_id == '2944':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2944&extended=1')
            if newznab_id == '27196':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27196&extended=1')
            if newznab_id == '19382':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19382&extended=1')
            if newznab_id == '29810':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29810&extended=1')
            if newznab_id == '12698':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12698&extended=1')
            if newznab_id == '31150':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31150&extended=1')
            if newznab_id == '32482':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32482&extended=1')
            if newznab_id == '33331':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33331&extended=1')
            if newznab_id == '8684':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8684&extended=1')
            if newznab_id == '10057':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10057&extended=1')
            if newznab_id == '6819':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6819&extended=1')
            if newznab_id == '33254':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33254&extended=1')
            if newznab_id == '26822':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26822&extended=1')
            if newznab_id == '32539':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32539&extended=1')
            if newznab_id == '26333':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26333&extended=1')
            if newznab_id == '31255':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31255&extended=1')
            if newznab_id == '6783':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6783&extended=1')
            if newznab_id == '10668':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10668&extended=1')
            if newznab_id == '32203':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32203&extended=1')
            if newznab_id == '31459':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31459&extended=1')
            if newznab_id == '27468':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27468&extended=1')
            if newznab_id == '3532':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3532&extended=1')
            if newznab_id == '31575':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31575&extended=1')
            if newznab_id == '27807':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27807&extended=1')
            if newznab_id == '12255':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12255&extended=1')
            if newznab_id == '25434':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25434&extended=1')
            if newznab_id == '25434':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25434&extended=1')
            if newznab_id == '30108':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30108&extended=1')
            if newznab_id == '27909':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27909&extended=1')
            if newznab_id == '23938':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23938&extended=1')
            if newznab_id == '26269':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26269&extended=1')
            if newznab_id == '30428':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30428&extended=1')
            if newznab_id == '27667':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27667&extended=1')
            if newznab_id == '10272':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10272&extended=1')
            if newznab_id == '29347':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29347&extended=1')
            if newznab_id == '32320':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32320&extended=1')
            if newznab_id == '26593':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26593&extended=1')
            if newznab_id == '33058':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33058&extended=1')
            if newznab_id == '32760':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32760&extended=1')
            if newznab_id == '25526':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25526&extended=1')
            if newznab_id == '28636':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28636&extended=1')
            if newznab_id == '29490':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29490&extended=1')
            if newznab_id == '23846':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23846&extended=1')
            if newznab_id == '7864':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7864&extended=1')
            if newznab_id == '30847':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30847&extended=1')
            if newznab_id == '29487':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29487&extended=1')
            if newznab_id == '27422':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27422&extended=1')
            if newznab_id == '3937':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3937&extended=1')
            if newznab_id == '29211':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29211&extended=1')
            if newznab_id == '31295':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31295&extended=1')
            if newznab_id == '33564':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33564&extended=1')
            if newznab_id == '26815':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26815&extended=1')
            if newznab_id == '28638':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28638&extended=1')
            if newznab_id == '8398':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8398&extended=1')
            if newznab_id == '4151':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4151&extended=1')
            if newznab_id == '4165':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4165&extended=1')
            if newznab_id == '19371':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19371&extended=1')
            if newznab_id == '25217':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25217&extended=1')
            if newznab_id == '23775':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23775&extended=1')
            if newznab_id == '18663':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18663&extended=1')
            if newznab_id == '4196':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4196&extended=1')
            if newznab_id == '13922':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13922&extended=1')
            if newznab_id == '27372':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27372&extended=1')
            if newznab_id == '27158':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27158&extended=1')
            if newznab_id == '31935':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31935&extended=1')
            if newznab_id == '1176':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1176&extended=1')
            if newznab_id == '32412':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32412&extended=1')
            if newznab_id == '28637':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28637&extended=1')
            if newznab_id == '957':
                url_out = (newznab_url_search + '&t=tvsearch&rid=957&extended=1')
            if newznab_id == '25079':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25079&extended=1')
            if newznab_id == '32726':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32726&extended=1')
            if newznab_id == '31266':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31266&extended=1')
            if newznab_id == '27197':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27197&extended=1')
            if newznab_id == '27141':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27141&extended=1')
            if newznab_id == '29489':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29489&extended=1')
            if newznab_id == '7081':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7081&extended=1')
            if newznab_id == '31179':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31179&extended=1')
            if newznab_id == '27935':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27935&extended=1')
            if newznab_id == '29089':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29089&extended=1')
            if newznab_id == '6815':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6815&extended=1')
            if newznab_id == '30589':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30589&extended=1')
            if newznab_id == '27674':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27674&extended=1')
            if newznab_id == '4641':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4641&extended=1')
            if newznab_id == '20872':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20872&extended=1')
            if newznab_id == '26623':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26623&extended=1')
            if newznab_id == '32795':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32795&extended=1')
            if newznab_id == '1713':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1713&extended=1')
            if newznab_id == '33163':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33163&extended=1')
            if newznab_id == '33163':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33163&extended=1')
            if newznab_id == '29711':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29711&extended=1')
            if newznab_id == '31198':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31198&extended=1')
            if newznab_id == '12369':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12369&extended=1')
            if newznab_id == '20871':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20871&extended=1')
            if newznab_id == '27900':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27900&extended=1')
            if newznab_id == '15100':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15100&extended=1')
            if newznab_id == '28323':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28323&extended=1')
            if newznab_id == '2381':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2381&extended=1')
            if newznab_id == '33055':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33055&extended=1')
            if newznab_id == '30666':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30666&extended=1')
            if newznab_id == '22870':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22870&extended=1')
            if newznab_id == '30414':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30414&extended=1')
            if newznab_id == '4920':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4920&extended=1')
            if newznab_id == '22274':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22274&extended=1')
            if newznab_id == '24155':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24155&extended=1')
            if newznab_id == '25077':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25077&extended=1')
            if newznab_id == '28705':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28705&extended=1')
            if newznab_id == '25915':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25915&extended=1')
            if newznab_id == '31030':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31030&extended=1')
            if newznab_id == '4996':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4996&extended=1')
            if newznab_id == '21817':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21817&extended=1')
            if newznab_id == '21817':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21817&extended=1')
            if newznab_id == '23191':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23191&extended=1')
            if newznab_id == '28896':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28896&extended=1')
            if newznab_id == '26193':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26193&extended=1')
            if newznab_id == '1800':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1800&extended=1')
            if newznab_id == '6796':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6796&extended=1')
            if newznab_id == '29742':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29742&extended=1')
            if newznab_id == '31920':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31920&extended=1')
            if newznab_id == '6799':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6799&extended=1')
            if newznab_id == '32737':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32737&extended=1')
            if newznab_id == '31828':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31828&extended=1')
            if newznab_id == '1913':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1913&extended=1')
            if newznab_id == '30392':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30392&extended=1')
            if newznab_id == '27532':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27532&extended=1')
            if newznab_id == '12160':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12160&extended=1')
            if newznab_id == '30580':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30580&extended=1')
            if newznab_id == '27081':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27081&extended=1')
            if newznab_id == '22054':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22054&extended=1')
            if newznab_id == '5352':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5352&extended=1')
            if newznab_id == '17523':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17523&extended=1')
            if newznab_id == '30879':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30879&extended=1')
            if newznab_id == '31292':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31292&extended=1')
            if newznab_id == '27934':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27934&extended=1')
            if newznab_id == '8261':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8261&extended=1')
            if newznab_id == '8260':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8260&extended=1')
            if newznab_id == '30201':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30201&extended=1')
            if newznab_id == '30353':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30353&extended=1')
            if newznab_id == '32563':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32563&extended=1')
            if newznab_id == '27675':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27675&extended=1')
            if newznab_id == '27429':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27429&extended=1')
            if newznab_id == '12711':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12711&extended=1')
            if newznab_id == '28949':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28949&extended=1')
            if newznab_id == '28205':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28205&extended=1')
            if newznab_id == '27723':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27723&extended=1')
            if newznab_id == '30487':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30487&extended=1')
            if newznab_id == '9553':
                url_out = (newznab_url_search + '&t=tvsearch&rid=9553&extended=1')
            if newznab_id == '33336':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33336&extended=1')
            if newznab_id == '32315':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32315&extended=1')
            if newznab_id == '25309':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25309&extended=1')
            if newznab_id == '30922':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30922&extended=1')
            if newznab_id == '26332':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26332&extended=1')
            if newznab_id == '31517':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31517&extended=1')
            if newznab_id == '31021':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31021&extended=1')
            if newznab_id == '7516':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7516&extended=1')
            if newznab_id == '29927':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29927&extended=1')
            if newznab_id == '29927':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29927&extended=1')
            if newznab_id == '32174':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32174&extended=1')
            if newznab_id == '27308':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27308&extended=1')
            if newznab_id == '28945':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28945&extended=1')
            if newznab_id == '5918':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5918&extended=1')
            if newznab_id == '28892':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28892&extended=1')
            if newznab_id == '28892':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28892&extended=1')
            if newznab_id == '29401':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29401&extended=1')
            if newznab_id == '31759':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31759&extended=1')
            if newznab_id == '31759':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31759&extended=1')
            if newznab_id == '32314':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32314&extended=1')
            if newznab_id == '26493':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26493&extended=1')
            if newznab_id == '30965':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30965&extended=1')
            if newznab_id == '31707':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31707&extended=1')
            if newznab_id == '27722':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27722&extended=1')
            if newznab_id == '28099':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28099&extended=1')
            if newznab_id == '27553':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27553&extended=1')
            if newznab_id == '18472':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18472&extended=1')
            if newznab_id == '28264':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28264&extended=1')
            if newznab_id == '27798':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27798&extended=1')
            if newznab_id == '30873':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30873&extended=1')
            if newznab_id == '30884':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30884&extended=1')
            if newznab_id == '30319':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30319&extended=1')
            if newznab_id == '28639':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28639&extended=1')
            if newznab_id == '6753':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6753&extended=1')
            if newznab_id == '7493':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7493&extended=1')
            if newznab_id == '27511':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27511&extended=1')
            if newznab_id == '27511':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27511&extended=1')
            if newznab_id == '29019':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29019&extended=1')
            if newznab_id == '27718':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27718&extended=1')
            if newznab_id == '28153':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28153&extended=1')
            if newznab_id == '30954':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30954&extended=1')
            if newznab_id == '26329':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26329&extended=1')
            if newznab_id == '32540':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32540&extended=1')
            if newznab_id == '32167':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32167&extended=1')
            if newznab_id == '32481':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32481&extended=1')
            if newznab_id == '30872':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30872&extended=1')
            if newznab_id == '32891':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32891&extended=1')
            if newznab_id == '33487':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33487&extended=1')
            if newznab_id == '10884':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10884&extended=1')
            if newznab_id == '27583':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27583&extended=1')
            if newznab_id == '27906':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27906&extended=1')
            if newznab_id == '33885':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33885&extended=1')
            if newznab_id == '18177':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18177&extended=1')
            if newznab_id == '27633':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27633&extended=1')
            if newznab_id == '29020':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29020&extended=1')
            if newznab_id == '29327':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29327&extended=1')
            if newznab_id == '1615':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1615&extended=1')
            if newznab_id == '30137':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30137&extended=1')
            if newznab_id == '26731':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26731&extended=1')
            if newznab_id == '25153':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25153&extended=1')
            if newznab_id == '27460':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27460&extended=1')
            if newznab_id == '25225':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25225&extended=1')
            if newznab_id == '30149':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30149&extended=1')
            if newznab_id == '32705':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32705&extended=1')
            if newznab_id == '32705':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32705&extended=1')
            if newznab_id == '27058':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27058&extended=1')
            if newznab_id == '28107':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28107&extended=1')
            if newznab_id == '23688':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23688&extended=1')
            if newznab_id == '8159':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8159&extended=1')
            if newznab_id == '27923':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27923&extended=1')
            if newznab_id == '33659':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33659&extended=1')
            if newznab_id == '28902':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28902&extended=1')
            if newznab_id == '23673':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23673&extended=1')
            if newznab_id == '32936':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32936&extended=1')
            if newznab_id == '19671':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19671&extended=1')
            if newznab_id == '21016':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21016&extended=1')
            if newznab_id == '33636':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33636&extended=1')
            if newznab_id == '18629':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18629&extended=1')
            if newznab_id == '25862':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25862&extended=1')
            if newznab_id == '31247':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31247&extended=1')
            if newznab_id == '30683':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30683&extended=1')
            if newznab_id == '17374':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17374&extended=1')
            if newznab_id == '19520':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19520&extended=1')
            if newznab_id == '33635':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33635&extended=1')
            if newznab_id == '33267':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33267&extended=1')
            if newznab_id == '32354':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32354&extended=1')
            if newznab_id == '20264':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20264&extended=1')
            if newznab_id == '19674':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19674&extended=1')
            if newznab_id == '20258':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20258&extended=1')
            if newznab_id == '31883':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31883&extended=1')
            if newznab_id == '33214':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33214&extended=1')
            if newznab_id == '25952':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25952&extended=1')
            if newznab_id == '25596':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25596&extended=1')
            if newznab_id == '16606':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16606&extended=1')
            if newznab_id == '32045':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32045&extended=1')
            if newznab_id == '3968':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3968&extended=1')
            if newznab_id == '28461':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28461&extended=1')
            if newznab_id == '4106':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4106&extended=1')
            if newznab_id == '31099':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31099&extended=1')
            if newznab_id == '32047':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32047&extended=1')
            if newznab_id == '33011':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33011&extended=1')
            if newznab_id == '25530':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25530&extended=1')
            if newznab_id == '7139':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7139&extended=1')
            if newznab_id == '28993':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28993&extended=1')
            if newznab_id == '28142':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28142&extended=1')
            if newznab_id == '25531':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25531&extended=1')
            if newznab_id == '30645':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30645&extended=1')
            if newznab_id == '32046':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32046&extended=1')
            if newznab_id == '19339':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19339&extended=1')
            if newznab_id == '18275':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18275&extended=1')
            if newznab_id == '19198':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19198&extended=1')
            if newznab_id == '18525':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18525&extended=1')
            if newznab_id == '19672':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19672&extended=1')
            if newznab_id == '25448':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25448&extended=1')
            if newznab_id == '27604':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27604&extended=1')
            if newznab_id == '22647':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22647&extended=1')
            if newznab_id == '18525':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18525&extended=1')
            if newznab_id == '7218':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7218&extended=1')
            if newznab_id == '29156':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29156&extended=1')
            if newznab_id == '26212':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26212&extended=1')
            if newznab_id == '19649':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19649&extended=1')
            if newznab_id == '6995':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6995&extended=1')
            if newznab_id == '25595':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25595&extended=1')
            if newznab_id == '19258':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19258&extended=1')
            if newznab_id == '28228':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28228&extended=1')
            if newznab_id == '24507':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24507&extended=1')
            if newznab_id == '32177':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32177&extended=1')
            if newznab_id == '27418':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27418&extended=1')
            if newznab_id == '23369':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23369&extended=1')
            if newznab_id == '28650':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28650&extended=1')
            if newznab_id == '20349':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20349&extended=1')
            if newznab_id == '18699':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18699&extended=1')
            if newznab_id == '31489':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31489&extended=1')
            if newznab_id == '23487':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23487&extended=1')
            if newznab_id == '6926':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6926&extended=1')
            if newznab_id == '3372':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3372&extended=1')
            if newznab_id == '31558':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31558&extended=1')
            if newznab_id == '3421':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3421&extended=1')
            if newznab_id == '3587':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3587&extended=1')
            if newznab_id == '23484':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23484&extended=1')
            if newznab_id == '25489':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25489&extended=1')
            if newznab_id == '26783':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26783&extended=1')
            if newznab_id == '3794':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3794&extended=1')
            if newznab_id == '23420':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23420&extended=1')
            if newznab_id == '27477':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27477&extended=1')
            if newznab_id == '29898':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29898&extended=1')
            if newznab_id == '26427':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26427&extended=1')
            if newznab_id == '31840':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31840&extended=1')
            if newznab_id == '26426':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26426&extended=1')
            if newznab_id == '5276':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5276&extended=1')
            if newznab_id == '19187':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19187&extended=1')
            if newznab_id == '23483':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23483&extended=1')
            if newznab_id == '28067':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28067&extended=1')
            if newznab_id == '5647':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5647&extended=1')
            if newznab_id == '24402':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24402&extended=1')
            if newznab_id == '27389':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27389&extended=1')
            if newznab_id == '27389':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27389&extended=1')
            if newznab_id == '5944':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5944&extended=1')
            if newznab_id == '27516':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27516&extended=1')
            if newznab_id == '23493':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23493&extended=1')
            if newznab_id == '25542':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25542&extended=1')
            if newznab_id == '156':
                url_out = (newznab_url_search + '&t=tvsearch&rid=156&extended=1')
            if newznab_id == '32200':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32200&extended=1')
            if newznab_id == '2196':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2196&extended=1')
            if newznab_id == '32754':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32754&extended=1')
            if newznab_id == '24855':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24855&extended=1')
            if newznab_id == '30357':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30357&extended=1')
            if newznab_id == '20818':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20818&extended=1')
            if newznab_id == '3276':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3276&extended=1')
            if newznab_id == '28171':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28171&extended=1')
            if newznab_id == '17878':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17878&extended=1')
            if newznab_id == '26755':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26755&extended=1')
            if newznab_id == '13474':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13474&extended=1')
            if newznab_id == '14977':
                url_out = (newznab_url_search + '&t=tvsearch&rid=14977&extended=1')
            if newznab_id == '30476':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30476&extended=1')
            if newznab_id == '29651':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29651&extended=1')
            if newznab_id == '30648':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30648&extended=1')
            if newznab_id == '4739':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4739&extended=1')
            if newznab_id == '30650':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30650&extended=1')
            if newznab_id == '24461':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24461&extended=1')
            if newznab_id == '1356':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1356&extended=1')
            if newznab_id == '2685':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2685&extended=1')
            if newznab_id == '31134':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31134&extended=1')
            if newznab_id == '6130':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6130&extended=1')
            if newznab_id == '20879':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20879&extended=1')
            if newznab_id == '6334':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6334&extended=1')
            if newznab_id == '6389':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6389&extended=1')
            if newznab_id == '25261':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25261&extended=1')
            if newznab_id == '23851':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23851&extended=1')
            if newznab_id == '10813':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10813&extended=1')
            if newznab_id == '29620':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29620&extended=1')
            if newznab_id == '25049':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25049&extended=1')
            if newznab_id == '28416':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28416&extended=1')
            if newznab_id == '30918':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30918&extended=1')
            if newznab_id == '28414':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28414&extended=1')
            if newznab_id == '22771':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22771&extended=1')
            if newznab_id == '2559':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2559&extended=1')
            if newznab_id == '2548':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2548&extended=1')
            if newznab_id == '2599':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2599&extended=1')
            if newznab_id == '2748':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2748&extended=1')
            if newznab_id == '2787':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2787&extended=1')
            if newznab_id == '25756':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25756&extended=1')
            if newznab_id == '18901':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18901&extended=1')
            if newznab_id == '2917':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2917&extended=1')
            if newznab_id == '2969':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2969&extended=1')
            if newznab_id == '18992':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18992&extended=1')
            if newznab_id == '25782':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25782&extended=1')
            if newznab_id == '3050':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3050&extended=1')
            if newznab_id == '3102':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3102&extended=1')
            if newznab_id == '25318':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25318&extended=1')
            if newznab_id == '3171':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3171&extended=1')
            if newznab_id == '3183':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3183&extended=1')
            if newznab_id == '3184':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3184&extended=1')
            if newznab_id == '3185':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3185&extended=1')
            if newznab_id == '1673':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1673&extended=1')
            if newznab_id == '3286':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3286&extended=1')
            if newznab_id == '3291':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3291&extended=1')
            if newznab_id == '3301':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3301&extended=1')
            if newznab_id == '31379':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31379&extended=1')
            if newznab_id == '3379':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3379&extended=1')
            if newznab_id == '30750':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30750&extended=1')
            if newznab_id == '3466':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3466&extended=1')
            if newznab_id == '19054':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19054&extended=1')
            if newznab_id == '8813':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8813&extended=1')
            if newznab_id == '239':
                url_out = (newznab_url_search + '&t=tvsearch&rid=239&extended=1')
            if newznab_id == '3644':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3644&extended=1')
            if newznab_id == '15887':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15887&extended=1')
            if newznab_id == '3723':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3723&extended=1')
            if newznab_id == '3766':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3766&extended=1')
            if newznab_id == '3803':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3803&extended=1')
            if newznab_id == '24840':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24840&extended=1')
            if newznab_id == '3821':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3821&extended=1')
            if newznab_id == '3836':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3836&extended=1')
            if newznab_id == '3874':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3874&extended=1')
            if newznab_id == '3918':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3918&extended=1')
            if newznab_id == '28415':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28415&extended=1')
            if newznab_id == '24551':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24551&extended=1')
            if newznab_id == '3944':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3944&extended=1')
            if newznab_id == '4032':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4032&extended=1')
            if newznab_id == '4034':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4034&extended=1')
            if newznab_id == '8141':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8141&extended=1')
            if newznab_id == '4077':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4077&extended=1')
            if newznab_id == '4104':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4104&extended=1')
            if newznab_id == '25662':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25662&extended=1')
            if newznab_id == '31673':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31673&extended=1')
            if newznab_id == '4346':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4346&extended=1')
            if newznab_id == '4368':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4368&extended=1')
            if newznab_id == '4432':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4432&extended=1')
            if newznab_id == '25050':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25050&extended=1')
            if newznab_id == '17752':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17752&extended=1')
            if newznab_id == '15753':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15753&extended=1')
            if newznab_id == '4545':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4545&extended=1')
            if newznab_id == '4554':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4554&extended=1')
            if newznab_id == '4623':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4623&extended=1')
            if newznab_id == '21934':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21934&extended=1')
            if newznab_id == '4628':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4628&extended=1')
            if newznab_id == '4696':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4696&extended=1')
            if newznab_id == '28413':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28413&extended=1')
            if newznab_id == '12457':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12457&extended=1')
            if newznab_id == '30810':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30810&extended=1')
            if newznab_id == '4804':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4804&extended=1')
            if newznab_id == '28376':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28376&extended=1')
            if newznab_id == '4813':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4813&extended=1')
            if newznab_id == '4948':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4948&extended=1')
            if newznab_id == '4997':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4997&extended=1')
            if newznab_id == '11224':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11224&extended=1')
            if newznab_id == '28372':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28372&extended=1')
            if newznab_id == '5104':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5104&extended=1')
            if newznab_id == '8490':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8490&extended=1')
            if newznab_id == '182':
                url_out = (newznab_url_search + '&t=tvsearch&rid=182&extended=1')
            if newznab_id == '5418':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5418&extended=1')
            if newznab_id == '5441':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5441&extended=1')
            if newznab_id == '5449':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5449&extended=1')
            if newznab_id == '5481':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5481&extended=1')
            if newznab_id == '5566':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5566&extended=1')
            if newznab_id == '5574':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5574&extended=1')
            if newznab_id == '8511':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8511&extended=1')
            if newznab_id == '22774':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22774&extended=1')
            if newznab_id == '5678':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5678&extended=1')
            if newznab_id == '25663':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25663&extended=1')
            if newznab_id == '5725':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5725&extended=1')
            if newznab_id == '5733':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5733&extended=1')
            if newznab_id == '5741':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5741&extended=1')
            if newznab_id == '5755':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5755&extended=1')
            if newznab_id == '22755':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22755&extended=1')
            if newznab_id == '22755':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22755&extended=1')
            if newznab_id == '5835':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5835&extended=1')
            if newznab_id == '5858':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5858&extended=1')
            if newznab_id == '5907':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5907&extended=1')
            if newznab_id == '5936':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5936&extended=1')
            if newznab_id == '5956':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5956&extended=1')
            if newznab_id == '5973':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5973&extended=1')
            if newznab_id == '18967':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18967&extended=1')
            if newznab_id == '5998':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5998&extended=1')
            if newznab_id == '7908':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7908&extended=1')
            if newznab_id == '6035':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6035&extended=1')
            if newznab_id == '6041':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6041&extended=1')
            if newznab_id == '6832':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6832&extended=1')
            if newznab_id == '6277':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6277&extended=1')
            if newznab_id == '6332':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6332&extended=1')
            if newznab_id == '6454':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6454&extended=1')
            if newznab_id == '22657':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22657&extended=1')
            if newznab_id == '28417':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28417&extended=1')
            if newznab_id == '31701':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31701&extended=1')
            if newznab_id == '6534':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6534&extended=1')
            if newznab_id == '6625':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6625&extended=1')
            if newznab_id == '6628':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6628&extended=1')
            if newznab_id == '25359':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25359&extended=1')
            if newznab_id == '18604':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18604&extended=1')
            if newznab_id == '27363':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27363&extended=1')
            if newznab_id == '27363':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27363&extended=1')
            if newznab_id == '30578':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30578&extended=1')
            if newznab_id == '30578':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30578&extended=1')
            if newznab_id == '28202':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28202&extended=1')
            if newznab_id == '7074':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7074&extended=1')
            if newznab_id == '32634':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32634&extended=1')
            if newznab_id == '31815':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31815&extended=1')
            if newznab_id == '22957':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22957&extended=1')
            if newznab_id == '29328':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29328&extended=1')
            if newznab_id == '33589':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33589&extended=1')
            if newznab_id == '27489':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27489&extended=1')
            if newznab_id == '27489':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27489&extended=1')
            if newznab_id == '26872':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26872&extended=1')
            if newznab_id == '25976':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25976&extended=1')
            if newznab_id == '27371':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27371&extended=1')
            if newznab_id == '27371':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27371&extended=1')
            if newznab_id == '2812':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2812&extended=1')
            if newznab_id == '30348':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30348&extended=1')
            if newznab_id == '30704':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30704&extended=1')
            if newznab_id == '29668':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29668&extended=1')
            if newznab_id == '27852':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27852&extended=1')
            if newznab_id == '32415':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32415&extended=1')
            if newznab_id == '26842':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26842&extended=1')
            if newznab_id == '22033':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22033&extended=1')
            if newznab_id == '27655':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27655&extended=1')
            if newznab_id == '23822':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23822&extended=1')
            if newznab_id == '32112':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32112&extended=1')
            if newznab_id == '27504':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27504&extended=1')
            if newznab_id == '26811':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26811&extended=1')
            if newznab_id == '7031':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7031&extended=1')
            if newznab_id == '20648':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20648&extended=1')
            if newznab_id == '3200':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3200&extended=1')
            if newznab_id == '30825':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30825&extended=1')
            if newznab_id == '27908':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27908&extended=1')
            if newznab_id == '33149':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33149&extended=1')
            if newznab_id == '33328':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33328&extended=1')
            if newznab_id == '29800':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29800&extended=1')
            if newznab_id == '10932':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10932&extended=1')
            if newznab_id == '32644':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32644&extended=1')
            if newznab_id == '29485':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29485&extended=1')
            if newznab_id == '28301':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28301&extended=1')
            if newznab_id == '26610':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26610&extended=1')
            if newznab_id == '28470':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28470&extended=1')
            if newznab_id == '28757':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28757&extended=1')
            if newznab_id == '25454':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25454&extended=1')
            if newznab_id == '29547':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29547&extended=1')
            if newznab_id == '32643':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32643&extended=1')
            if newznab_id == '28644':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28644&extended=1')
            if newznab_id == '28302':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28302&extended=1')
            if newznab_id == '26922':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26922&extended=1')
            if newznab_id == '29484':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29484&extended=1')
            if newznab_id == '27623':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27623&extended=1')
            if newznab_id == '33392':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33392&extended=1')
            if newznab_id == '31075':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31075&extended=1')
            if newznab_id == '31629':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31629&extended=1')
            if newznab_id == '27414':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27414&extended=1')
            if newznab_id == '30761':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30761&extended=1')
            if newznab_id == '32645':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32645&extended=1')
            if newznab_id == '24862':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24862&extended=1')
            if newznab_id == '11191':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11191&extended=1')
            if newznab_id == '18739':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18739&extended=1')
            if newznab_id == '11187':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11187&extended=1')
            if newznab_id == '3738':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3738&extended=1')
            if newznab_id == '30380':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30380&extended=1')
            if newznab_id == '26266':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26266&extended=1')
            if newznab_id == '33325':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33325&extended=1')
            if newznab_id == '21879':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21879&extended=1')
            if newznab_id == '27580':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27580&extended=1')
            if newznab_id == '31362':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31362&extended=1')
            if newznab_id == '31074':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31074&extended=1')
            if newznab_id == '30853':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30853&extended=1')
            if newznab_id == '32877':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32877&extended=1')
            if newznab_id == '30387':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30387&extended=1')
            if newznab_id == '27348':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27348&extended=1')
            if newznab_id == '30581':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30581&extended=1')
            if newznab_id == '32614':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32614&extended=1')
            if newznab_id == '23045':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23045&extended=1')
            if newznab_id == '18000':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18000&extended=1')
            if newznab_id == '716':
                url_out = (newznab_url_search + '&t=tvsearch&rid=716&extended=1')
            if newznab_id == '33147':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33147&extended=1')
            if newznab_id == '33147':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33147&extended=1')
            if newznab_id == '26723':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26723&extended=1')
            if newznab_id == '23703':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23703&extended=1')
            if newznab_id == '30222':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30222&extended=1')
            if newznab_id == '27621':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27621&extended=1')
            if newznab_id == '29802':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29802&extended=1')
            if newznab_id == '32094':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32094&extended=1')
            if newznab_id == '31694':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31694&extended=1')
            if newznab_id == '25023':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25023&extended=1')
            if newznab_id == '27756':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27756&extended=1')
            if newznab_id == '32799':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32799&extended=1')
            if newznab_id == '29709':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29709&extended=1')
            if newznab_id == '30185':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30185&extended=1')
            if newznab_id == '30185':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30185&extended=1')
            if newznab_id == '27721':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27721&extended=1')
            if newznab_id == '30127':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30127&extended=1')
            if newznab_id == '8360':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8360&extended=1')
            if newznab_id == '32305':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32305&extended=1')
            if newznab_id == '27361':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27361&extended=1')
            if newznab_id == '29595':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29595&extended=1')
            if newznab_id == '29981':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29981&extended=1')
            if newznab_id == '25014':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25014&extended=1')
            if newznab_id == '30673':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30673&extended=1')
            if newznab_id == '849':
                url_out = (newznab_url_search + '&t=tvsearch&rid=849&extended=1')
            if newznab_id == '26234':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26234&extended=1')
            if newznab_id == '29671':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29671&extended=1')
            if newznab_id == '28884':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28884&extended=1')
            if newznab_id == '4943':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4943&extended=1')
            if newznab_id == '24866':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24866&extended=1')
            if newznab_id == '18344':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18344&extended=1')
            if newznab_id == '29710':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29710&extended=1')
            if newznab_id == '27358':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27358&extended=1')
            if newznab_id == '20491':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20491&extended=1')
            if newznab_id == '13016':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13016&extended=1')
            if newznab_id == '10833':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10833&extended=1')
            if newznab_id == '31565':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31565&extended=1')
            if newznab_id == '33326':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33326&extended=1')
            if newznab_id == '29134':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29134&extended=1')
            if newznab_id == '5162':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5162&extended=1')
            if newznab_id == '32161':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32161&extended=1')
            if newznab_id == '28700':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28700&extended=1')
            if newznab_id == '31536':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31536&extended=1')
            if newznab_id == '9841':
                url_out = (newznab_url_search + '&t=tvsearch&rid=9841&extended=1')
            if newznab_id == '25906':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25906&extended=1')
            if newznab_id == '33431':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33431&extended=1')
            if newznab_id == '27795':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27795&extended=1')
            if newznab_id == '27755':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27755&extended=1')
            if newznab_id == '23001':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23001&extended=1')
            if newznab_id == '32169':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32169&extended=1')
            if newznab_id == '32646':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32646&extended=1')
            if newznab_id == '27357':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27357&extended=1')
            if newznab_id == '460':
                url_out = (newznab_url_search + '&t=tvsearch&rid=460&extended=1')
            if newznab_id == '5690':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5690&extended=1')
            if newznab_id == '27356':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27356&extended=1')
            if newznab_id == '30388':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30388&extended=1')
            if newznab_id == '26071':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26071&extended=1')
            if newznab_id == '30374':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30374&extended=1')
            if newznab_id == '32272':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32272&extended=1')
            if newznab_id == '29860':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29860&extended=1')
            if newznab_id == '6809':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6809&extended=1')
            if newznab_id == '30177':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30177&extended=1')
            if newznab_id == '31452':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31452&extended=1')
            if newznab_id == '28032':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28032&extended=1')
            if newznab_id == '31731':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31731&extended=1')
            if newznab_id == '8044':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8044&extended=1')
            if newznab_id == '27362':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27362&extended=1')
            if newznab_id == '28575':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28575&extended=1')
            if newznab_id == '30836':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30836&extended=1')
            if newznab_id == '27582':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27582&extended=1')
            if newznab_id == '10218':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10218&extended=1')
            if newznab_id == '27503':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27503&extended=1')
            if newznab_id == '27499':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27499&extended=1')
            if newznab_id == '25305':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25305&extended=1')
            if newznab_id == '29044':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29044&extended=1')
            if newznab_id == '14681':
                url_out = (newznab_url_search + '&t=tvsearch&rid=14681&extended=1')
            if newznab_id == '19970':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19970&extended=1')
            if newznab_id == '28699':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28699&extended=1')
            if newznab_id == '31183':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31183&extended=1')
            if newznab_id == '30196':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30196&extended=1')
            if newznab_id == '32209':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32209&extended=1')
            if newznab_id == '26481':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26481&extended=1')
            if newznab_id == '26481':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26481&extended=1')
            if newznab_id == '25456':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25456&extended=1')
            if newznab_id == '8551':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8551&extended=1')
            if newznab_id == '30158':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30158&extended=1')
            if newznab_id == '29861':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29861&extended=1')
            if newznab_id == '30584':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30584&extended=1')
            if newznab_id == '26074':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26074&extended=1')
            if newznab_id == '27794':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27794&extended=1')
            if newznab_id == '31363':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31363&extended=1')
            if newznab_id == '715':
                url_out = (newznab_url_search + '&t=tvsearch&rid=715&extended=1')
            if newznab_id == '19682':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19682&extended=1')
            if newznab_id == '2792':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2792&extended=1')
            if newznab_id == '3012':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3012&extended=1')
            if newznab_id == '29178':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29178&extended=1')
            if newznab_id == '30703':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30703&extended=1')
            if newznab_id == '29185':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29185&extended=1')
            if newznab_id == '29210':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29210&extended=1')
            if newznab_id == '23896':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23896&extended=1')
            if newznab_id == '18063':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18063&extended=1')
            if newznab_id == '29273':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29273&extended=1')
            if newznab_id == '28282':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28282&extended=1')
            if newznab_id == '29274':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29274&extended=1')
            if newznab_id == '4138':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4138&extended=1')
            if newznab_id == '29038':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29038&extended=1')
            if newznab_id == '33212':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33212&extended=1')
            if newznab_id == '29280':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29280&extended=1')
            if newznab_id == '29244':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29244&extended=1')
            if newznab_id == '29759':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29759&extended=1')
            if newznab_id == '33227':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33227&extended=1')
            if newznab_id == '32317':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32317&extended=1')
            if newznab_id == '24598':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24598&extended=1')
            if newznab_id == '13782':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13782&extended=1')
            if newznab_id == '31142':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31142&extended=1')
            if newznab_id == '19606':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19606&extended=1')
            if newznab_id == '31484':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31484&extended=1')
            if newznab_id == '30534':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30534&extended=1')
            if newznab_id == '31705':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31705&extended=1')
            if newznab_id == '32544':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32544&extended=1')
            if newznab_id == '31267':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31267&extended=1')
            if newznab_id == '28762':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28762&extended=1')
            if newznab_id == '28763':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28763&extended=1')
            if newznab_id == '29633':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29633&extended=1')
            if newznab_id == '26928':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26928&extended=1')
            if newznab_id == '22386':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22386&extended=1')
            if newznab_id == '21731':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21731&extended=1')
            if newznab_id == '31996':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31996&extended=1')
            if newznab_id == '3117':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3117&extended=1')
            if newznab_id == '7234':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7234&extended=1')
            if newznab_id == '3628':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3628&extended=1')
            if newznab_id == '29424':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29424&extended=1')
            if newznab_id == '24849':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24849&extended=1')
            if newznab_id == '20802':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20802&extended=1')
            if newznab_id == '24553':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24553&extended=1')
            if newznab_id == '28612':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28612&extended=1')
            if newznab_id == '30543':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30543&extended=1')
            if newznab_id == '22705':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22705&extended=1')
            if newznab_id == '26352':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26352&extended=1')
            if newznab_id == '27060':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27060&extended=1')
            if newznab_id == '5266':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5266&extended=1')
            if newznab_id == '5364':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5364&extended=1')
            if newznab_id == '32013':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32013&extended=1')
            if newznab_id == '31652':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31652&extended=1')
            if newznab_id == '8065':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8065&extended=1')
            if newznab_id == '22690':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22690&extended=1')
            if newznab_id == '22711':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22711&extended=1')
            if newznab_id == '1607':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1607&extended=1')
            if newznab_id == '23658':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23658&extended=1')
            if newznab_id == '29870':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29870&extended=1')
            if newznab_id == '25835':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25835&extended=1')
            if newznab_id == '25822':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25822&extended=1')
            if newznab_id == '30508':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30508&extended=1')
            if newznab_id == '29966':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29966&extended=1')
            if newznab_id == '28125':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28125&extended=1')
            if newznab_id == '25825':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25825&extended=1')
            if newznab_id == '28106':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28106&extended=1')
            if newznab_id == '31017':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31017&extended=1')
            if newznab_id == '32630':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32630&extended=1')
            if newznab_id == '28208':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28208&extended=1')
            if newznab_id == '3139':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3139&extended=1')
            if newznab_id == '25240':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25240&extended=1')
            if newznab_id == '18531':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18531&extended=1')
            if newznab_id == '3482':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3482&extended=1')
            if newznab_id == '23201':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23201&extended=1')
            if newznab_id == '3974':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3974&extended=1')
            if newznab_id == '30617':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30617&extended=1')
            if newznab_id == '20068':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20068&extended=1')
            if newznab_id == '21894':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21894&extended=1')
            if newznab_id == '18689':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18689&extended=1')
            if newznab_id == '18689':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18689&extended=1')
            if newznab_id == '6211':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6211&extended=1')
            if newznab_id == '28139':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28139&extended=1')
            if newznab_id == '27557':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27557&extended=1')
            if newznab_id == '28708':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28708&extended=1')
            if newznab_id == '28317':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28317&extended=1')
            if newznab_id == '28382':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28382&extended=1')
            if newznab_id == '20685':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20685&extended=1')
            if newznab_id == '32239':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32239&extended=1')
            if newznab_id == '31297':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31297&extended=1')
            if newznab_id == '29021':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29021&extended=1')
            if newznab_id == '4959':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4959&extended=1')
            if newznab_id == '13319':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13319&extended=1')
            if newznab_id == '24424':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24424&extended=1')
            if newznab_id == '33007':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33007&extended=1')
            if newznab_id == '31940':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31940&extended=1')
            if newznab_id == '15422':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15422&extended=1')
            if newznab_id == '15927':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15927&extended=1')
            if newznab_id == '27862':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27862&extended=1')
            if newznab_id == '30505':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30505&extended=1')
            if newznab_id == '25696':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25696&extended=1')
            if newznab_id == '29746':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29746&extended=1')
            if newznab_id == '21887':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21887&extended=1')
            if newznab_id == '29605':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29605&extended=1')
            if newznab_id == '33547':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33547&extended=1')
            if newznab_id == '26858':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26858&extended=1')
            if newznab_id == '26406':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26406&extended=1')
            if newznab_id == '32374':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32374&extended=1')
            if newznab_id == '30539':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30539&extended=1')
            if newznab_id == '28129':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28129&extended=1')
            if newznab_id == '32995':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32995&extended=1')
            if newznab_id == '32221':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32221&extended=1')
            if newznab_id == '33137':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33137&extended=1')
            if newznab_id == '26992':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26992&extended=1')
            if newznab_id == '30547':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30547&extended=1')
            if newznab_id == '29408':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29408&extended=1')
            if newznab_id == '24449':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24449&extended=1')
            if newznab_id == '27102':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27102&extended=1')
            if newznab_id == '24641':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24641&extended=1')
            if newznab_id == '24641':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24641&extended=1')
            if newznab_id == '31781':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31781&extended=1')
            if newznab_id == '3260':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3260&extended=1')
            if newznab_id == '31909':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31909&extended=1')
            if newznab_id == '31909':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31909&extended=1')
            if newznab_id == '28443':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28443&extended=1')
            if newznab_id == '27255':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27255&extended=1')
            if newznab_id == '29124':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29124&extended=1')
            if newznab_id == '6920':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6920&extended=1')
            if newznab_id == '29125':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29125&extended=1')
            if newznab_id == '25851':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25851&extended=1')
            if newznab_id == '1128':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1128&extended=1')
            if newznab_id == '31800':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31800&extended=1')
            if newznab_id == '6740':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6740&extended=1')
            if newznab_id == '18109':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18109&extended=1')
            if newznab_id == '33420':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33420&extended=1')
            if newznab_id == '31765':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31765&extended=1')
            if newznab_id == '30427':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30427&extended=1')
            if newznab_id == '27161':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27161&extended=1')
            if newznab_id == '23905':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23905&extended=1')
            if newznab_id == '32056':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32056&extended=1')
            if newznab_id == '26961':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26961&extended=1')
            if newznab_id == '31793':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31793&extended=1')
            if newznab_id == '32591':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32591&extended=1')
            if newznab_id == '27208':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27208&extended=1')
            if newznab_id == '32824':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32824&extended=1')
            if newznab_id == '20405':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20405&extended=1')
            if newznab_id == '29998':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29998&extended=1')
            if newznab_id == '24741':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24741&extended=1')
            if newznab_id == '20539':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20539&extended=1')
            if newznab_id == '29281':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29281&extended=1')
            if newznab_id == '33311':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33311&extended=1')
            if newznab_id == '21939':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21939&extended=1')
            if newznab_id == '33259':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33259&extended=1')
            if newznab_id == '31662':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31662&extended=1')
            if newznab_id == '28130':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28130&extended=1')
            if newznab_id == '14573':
                url_out = (newznab_url_search + '&t=tvsearch&rid=14573&extended=1')
            if newznab_id == '25983':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25983&extended=1')
            if newznab_id == '27459':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27459&extended=1')
            if newznab_id == '22991':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22991&extended=1')
            if newznab_id == '20936':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20936&extended=1')
            if newznab_id == '30576':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30576&extended=1')
            if newznab_id == '4517':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4517&extended=1')
            if newznab_id == '29973':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29973&extended=1')
            if newznab_id == '4605':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4605&extended=1')
            if newznab_id == '31334':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31334&extended=1')
            if newznab_id == '28692':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28692&extended=1')
            if newznab_id == '23183':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23183&extended=1')
            if newznab_id == '27290':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27290&extended=1')
            if newznab_id == '13473':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13473&extended=1')
            if newznab_id == '29508':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29508&extended=1')
            if newznab_id == '22287':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22287&extended=1')
            if newznab_id == '32228':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32228&extended=1')
            if newznab_id == '30529':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30529&extended=1')
            if newznab_id == '29157':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29157&extended=1')
            if newznab_id == '27201':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27201&extended=1')
            if newznab_id == '27792':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27792&extended=1')
            if newznab_id == '26218':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26218&extended=1')
            if newznab_id == '6858':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6858&extended=1')
            if newznab_id == '28128':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28128&extended=1')
            if newznab_id == '28128':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28128&extended=1')
            if newznab_id == '22948':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22948&extended=1')
            if newznab_id == '20572':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20572&extended=1')
            if newznab_id == '32594':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32594&extended=1')
            if newznab_id == '27793':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27793&extended=1')
            if newznab_id == '19141':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19141&extended=1')
            if newznab_id == '23356':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23356&extended=1')
            if newznab_id == '31624':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31624&extended=1')
            if newznab_id == '29692':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29692&extended=1')
            if newznab_id == '21068':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21068&extended=1')
            if newznab_id == '30986':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30986&extended=1')
            if newznab_id == '29773':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29773&extended=1')
            if newznab_id == '26698':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26698&extended=1')
            if newznab_id == '26698':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26698&extended=1')
            if newznab_id == '19164':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19164&extended=1')
            if newznab_id == '27209':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27209&extended=1')
            if newznab_id == '30484':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30484&extended=1')
            if newznab_id == '32491':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32491&extended=1')
            if newznab_id == '27735':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27735&extended=1')
            if newznab_id == '31303':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31303&extended=1')
            if newznab_id == '6960':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6960&extended=1')
            if newznab_id == '26677':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26677&extended=1')
            if newznab_id == '24321':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24321&extended=1')
            if newznab_id == '3359':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3359&extended=1')
            if newznab_id == '6442':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6442&extended=1')
            if newznab_id == '30560':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30560&extended=1')
            if newznab_id == '30559':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30559&extended=1')
            if newznab_id == '29728':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29728&extended=1')
            if newznab_id == '28621':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28621&extended=1')
            if newznab_id == '29965':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29965&extended=1')
            if newznab_id == '31385':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31385&extended=1')
            if newznab_id == '26510':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26510&extended=1')
            if newznab_id == '23993':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23993&extended=1')
            if newznab_id == '23993':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23993&extended=1')
            if newznab_id == '31839':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31839&extended=1')
            if newznab_id == '14506':
                url_out = (newznab_url_search + '&t=tvsearch&rid=14506&extended=1')
            if newznab_id == '7096':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7096&extended=1')
            if newznab_id == '29355':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29355&extended=1')
            if newznab_id == '12304':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12304&extended=1')
            if newznab_id == '10824':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10824&extended=1')
            if newznab_id == '10824':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10824&extended=1')
            if newznab_id == '28603':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28603&extended=1')
            if newznab_id == '28603':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28603&extended=1')
            if newznab_id == '12677':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12677&extended=1')
            if newznab_id == '28967':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28967&extended=1')
            if newznab_id == '25778':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25778&extended=1')
            if newznab_id == '28559':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28559&extended=1')
            if newznab_id == '19770':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19770&extended=1')
            if newznab_id == '32020':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32020&extended=1')
            if newznab_id == '27028':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27028&extended=1')
            if newznab_id == '18575':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18575&extended=1')
            if newznab_id == '15176':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15176&extended=1')
            if newznab_id == '31910':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31910&extended=1')
            if newznab_id == '23227':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23227&extended=1')
            if newznab_id == '31533':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31533&extended=1')
            if newznab_id == '25041':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25041&extended=1')
            if newznab_id == '28609':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28609&extended=1')
            if newznab_id == '31546':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31546&extended=1')
            if newznab_id == '24825':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24825&extended=1')
            if newznab_id == '31843':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31843&extended=1')
            if newznab_id == '28626':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28626&extended=1')
            if newznab_id == '31559':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31559&extended=1')
            if newznab_id == '27587':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27587&extended=1')
            if newznab_id == '27587':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27587&extended=1')
            if newznab_id == '25064':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25064&extended=1')
            if newznab_id == '28765':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28765&extended=1')
            if newznab_id == '27394':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27394&extended=1')
            if newznab_id == '29475':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29475&extended=1')
            if newznab_id == '25971':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25971&extended=1')
            if newznab_id == '26716':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26716&extended=1')
            if newznab_id == '27702':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27702&extended=1')
            if newznab_id == '29094':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29094&extended=1')
            if newznab_id == '25248':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25248&extended=1')
            if newznab_id == '28581':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28581&extended=1')
            if newznab_id == '17638':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17638&extended=1')
            if newznab_id == '22691':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22691&extended=1')
            if newznab_id == '27826':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27826&extended=1')
            if newznab_id == '23204':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23204&extended=1')
            if newznab_id == '27220':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27220&extended=1')
            if newznab_id == '33144':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33144&extended=1')
            if newznab_id == '31994':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31994&extended=1')
            if newznab_id == '31853':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31853&extended=1')
            if newznab_id == '27744':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27744&extended=1')
            if newznab_id == '6827':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6827&extended=1')
            if newznab_id == '8214':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8214&extended=1')
            if newznab_id == '28998':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28998&extended=1')
            if newznab_id == '30193':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30193&extended=1')
            if newznab_id == '27626':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27626&extended=1')
            if newznab_id == '28201':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28201&extended=1')
            if newznab_id == '8784':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8784&extended=1')
            if newznab_id == '17881':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17881&extended=1')
            if newznab_id == '30354':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30354&extended=1')
            if newznab_id == '26730':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26730&extended=1')
            if newznab_id == '23942':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23942&extended=1')
            if newznab_id == '15114':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15114&extended=1')
            if newznab_id == '29952':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29952&extended=1')
            if newznab_id == '18753':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18753&extended=1')
            if newznab_id == '32217':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32217&extended=1')
            if newznab_id == '33247':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33247&extended=1')
            if newznab_id == '4634':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4634&extended=1')
            if newznab_id == '29131':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29131&extended=1')
            if newznab_id == '6356':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6356&extended=1')
            if newznab_id == '30305':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30305&extended=1')
            if newznab_id == '4936':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4936&extended=1')
            if newznab_id == '31393':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31393&extended=1')
            if newznab_id == '2671':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2671&extended=1')
            if newznab_id == '17880':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17880&extended=1')
            if newznab_id == '29142':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29142&extended=1')
            if newznab_id == '28815':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28815&extended=1')
            if newznab_id == '30386':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30386&extended=1')
            if newznab_id == '29597':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29597&extended=1')
            if newznab_id == '30139':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30139&extended=1')
            if newznab_id == '32794':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32794&extended=1')
            if newznab_id == '20913':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20913&extended=1')
            if newznab_id == '31213':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31213&extended=1')
            if newznab_id == '29093':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29093&extended=1')
            if newznab_id == '28816':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28816&extended=1')
            if newznab_id == '29734':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29734&extended=1')
            if newznab_id == '31380':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31380&extended=1')
            if newznab_id == '26543':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26543&extended=1')
            if newznab_id == '26084':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26084&extended=1')
            if newznab_id == '28033':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28033&extended=1')
            if newznab_id == '27473':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27473&extended=1')
            if newznab_id == '32157':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32157&extended=1')
            if newznab_id == '19890':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19890&extended=1')
            if newznab_id == '30041':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30041&extended=1')
            if newznab_id == '32242':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32242&extended=1')
            if newznab_id == '28318':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28318&extended=1')
            if newznab_id == '32172':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32172&extended=1')
            if newznab_id == '29395':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29395&extended=1')
            if newznab_id == '30727':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30727&extended=1')
            if newznab_id == '25083':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25083&extended=1')
            if newznab_id == '28224':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28224&extended=1')
            if newznab_id == '30140':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30140&extended=1')
            if newznab_id == '32476':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32476&extended=1')
            if newznab_id == '29258':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29258&extended=1')
            if newznab_id == '30000':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30000&extended=1')
            if newznab_id == '29954':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29954&extended=1')
            if newznab_id == '31746':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31746&extended=1')
            if newznab_id == '32660':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32660&extended=1')
            if newznab_id == '28760':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28760&extended=1')
            if newznab_id == '33530':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33530&extended=1')
            if newznab_id == '32660':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32660&extended=1')
            if newznab_id == '29735':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29735&extended=1')
            if newznab_id == '18781':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18781&extended=1')
            if newznab_id == '29481':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29481&extended=1')
            if newznab_id == '19322':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19322&extended=1')
            if newznab_id == '31235':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31235&extended=1')
            if newznab_id == '31189':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31189&extended=1')
            if newznab_id == '27500':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27500&extended=1')
            if newznab_id == '29287':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29287&extended=1')
            if newznab_id == '32475':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32475&extended=1')
            if newznab_id == '21193':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21193&extended=1')
            if newznab_id == '27507':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27507&extended=1')
            if newznab_id == '28632':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28632&extended=1')
            if newznab_id == '29555':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29555&extended=1')
            if newznab_id == '28207':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28207&extended=1')
            if newznab_id == '29141':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29141&extended=1')
            if newznab_id == '6911':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6911&extended=1')
            if newznab_id == '19508':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19508&extended=1')
            if newznab_id == '28811':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28811&extended=1')
            if newznab_id == '28487':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28487&extended=1')
            if newznab_id == '6254':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6254&extended=1')
            if newznab_id == '28195':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28195&extended=1')
            if newznab_id == '29085':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29085&extended=1')
            if newznab_id == '30431':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30431&extended=1')
            if newznab_id == '26831':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26831&extended=1')
            if newznab_id == '33089':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33089&extended=1')
            if newznab_id == '30721':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30721&extended=1')
            if newznab_id == '30393':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30393&extended=1')
            if newznab_id == '28940':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28940&extended=1')
            if newznab_id == '30668':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30668&extended=1')
            if newznab_id == '25826':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25826&extended=1')
            if newznab_id == '32012':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32012&extended=1')
            if newznab_id == '20628':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20628&extended=1')
            if newznab_id == '29275':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29275&extended=1')
            if newznab_id == '25651':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25651&extended=1')
            if newznab_id == '16247':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16247&extended=1')
            if newznab_id == '16247':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16247&extended=1')
            if newznab_id == '6836':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6836&extended=1')
            if newznab_id == '6836':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6836&extended=1')
            if newznab_id == '28672':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28672&extended=1')
            if newznab_id == '30454':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30454&extended=1')
            if newznab_id == '20294':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20294&extended=1')
            if newznab_id == '1297':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1297&extended=1')
            if newznab_id == '12291':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12291&extended=1')
            if newznab_id == '28766':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28766&extended=1')
            if newznab_id == '27576':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27576&extended=1')
            if newznab_id == '31660':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31660&extended=1')
            if newznab_id == '3994':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3994&extended=1')
            if newznab_id == '30155':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30155&extended=1')
            if newznab_id == '26579':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26579&extended=1')
            if newznab_id == '26579':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26579&extended=1')
            if newznab_id == '19563':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19563&extended=1')
            if newznab_id == '30425':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30425&extended=1')
            if newznab_id == '27401':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27401&extended=1')
            if newznab_id == '31607':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31607&extended=1')
            if newznab_id == '33113':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33113&extended=1')
            if newznab_id == '28796':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28796&extended=1')
            if newznab_id == '29368':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29368&extended=1')
            if newznab_id == '22934':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22934&extended=1')
            if newznab_id == '29762':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29762&extended=1')
            if newznab_id == '26350':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26350&extended=1')
            if newznab_id == '7005':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7005&extended=1')
            if newznab_id == '17538':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17538&extended=1')
            if newznab_id == '29096':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29096&extended=1')
            if newznab_id == '701':
                url_out = (newznab_url_search + '&t=tvsearch&rid=701&extended=1')
            if newznab_id == '22950':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22950&extended=1')
            if newznab_id == '28150':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28150&extended=1')
            if newznab_id == '2445':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2445&extended=1')
            if newznab_id == '27523':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27523&extended=1')
            if newznab_id == '28377':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28377&extended=1')
            if newznab_id == '2594':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2594&extended=1')
            if newznab_id == '2601':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2601&extended=1')
            if newznab_id == '31683':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31683&extended=1')
            if newznab_id == '13262':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13262&extended=1')
            if newznab_id == '24607':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24607&extended=1')
            if newznab_id == '2870':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2870&extended=1')
            if newznab_id == '26082':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26082&extended=1')
            if newznab_id == '29119':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29119&extended=1')
            if newznab_id == '15767':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15767&extended=1')
            if newznab_id == '3138':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3138&extended=1')
            if newznab_id == '3237':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3237&extended=1')
            if newznab_id == '17816':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17816&extended=1')
            if newznab_id == '3506':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3506&extended=1')
            if newznab_id == '3548':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3548&extended=1')
            if newznab_id == '18388':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18388&extended=1')
            if newznab_id == '21704':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21704&extended=1')
            if newznab_id == '3797':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3797&extended=1')
            if newznab_id == '3828':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3828&extended=1')
            if newznab_id == '30890':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30890&extended=1')
            if newznab_id == '3908':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3908&extended=1')
            if newznab_id == '22699':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22699&extended=1')
            if newznab_id == '28303':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28303&extended=1')
            if newznab_id == '3961':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3961&extended=1')
            if newznab_id == '28408':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28408&extended=1')
            if newznab_id == '4134':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4134&extended=1')
            if newznab_id == '19295':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19295&extended=1')
            if newznab_id == '4266':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4266&extended=1')
            if newznab_id == '4355':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4355&extended=1')
            if newznab_id == '4375':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4375&extended=1')
            if newznab_id == '25644':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25644&extended=1')
            if newznab_id == '4475':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4475&extended=1')
            if newznab_id == '27995':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27995&extended=1')
            if newznab_id == '28378':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28378&extended=1')
            if newznab_id == '28304':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28304&extended=1')
            if newznab_id == '13469':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13469&extended=1')
            if newznab_id == '4676':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4676&extended=1')
            if newznab_id == '4846':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4846&extended=1')
            if newznab_id == '4895':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4895&extended=1')
            if newznab_id == '30926':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30926&extended=1')
            if newznab_id == '25742':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25742&extended=1')
            if newznab_id == '25742':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25742&extended=1')
            if newznab_id == '5019':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5019&extended=1')
            if newznab_id == '5270':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5270&extended=1')
            if newznab_id == '22674':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22674&extended=1')
            if newznab_id == '31515':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31515&extended=1')
            if newznab_id == '13445':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13445&extended=1')
            if newznab_id == '25729':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25729&extended=1')
            if newznab_id == '5497':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5497&extended=1')
            if newznab_id == '5608':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5608&extended=1')
            if newznab_id == '5610':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5610&extended=1')
            if newznab_id == '25051':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25051&extended=1')
            if newznab_id == '31689':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31689&extended=1')
            if newznab_id == '18740':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18740&extended=1')
            if newznab_id == '28173':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28173&extended=1')
            if newznab_id == '31682':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31682&extended=1')
            if newznab_id == '31649':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31649&extended=1')
            if newznab_id == '6190':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6190&extended=1')
            if newznab_id == '25062':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25062&extended=1')
            if newznab_id == '6312':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6312&extended=1')
            if newznab_id == '28055':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28055&extended=1')
            if newznab_id == '25743':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25743&extended=1')
            if newznab_id == '6585':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6585&extended=1')
            if newznab_id == '24958':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24958&extended=1')
            if newznab_id == '6649':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6649&extended=1')
            if newznab_id == '2676':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2676&extended=1')
            if newznab_id == '27748':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27748&extended=1')
            if newznab_id == '29756':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29756&extended=1')
            if newznab_id == '29460':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29460&extended=1')
            if newznab_id == '24462':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24462&extended=1')
            if newznab_id == '2661':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2661&extended=1')
            if newznab_id == '13722':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13722&extended=1')
            if newznab_id == '5093':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5093&extended=1')
            if newznab_id == '26257':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26257&extended=1')
            if newznab_id == '30448':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30448&extended=1')
            if newznab_id == '28776':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28776&extended=1')
            if newznab_id == '29999':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29999&extended=1')
            if newznab_id == '23354':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23354&extended=1')
            if newznab_id == '31824':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31824&extended=1')
            if newznab_id == '4004':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4004&extended=1')
            if newznab_id == '4004':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4004&extended=1')
            if newznab_id == '23472':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23472&extended=1')
            if newznab_id == '27061':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27061&extended=1')
            if newznab_id == '24504':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24504&extended=1')
            if newznab_id == '4677':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4677&extended=1')
            if newznab_id == '32595':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32595&extended=1')
            if newznab_id == '4985':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4985&extended=1')
            if newznab_id == '25304':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25304&extended=1')
            if newznab_id == '18174':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18174&extended=1')
            if newznab_id == '19587':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19587&extended=1')
            if newznab_id == '24173':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24173&extended=1')
            if newznab_id == '6185':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6185&extended=1')
            if newznab_id == '6263':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6263&extended=1')
            if newznab_id == '31952':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31952&extended=1')
            if newznab_id == '30294':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30294&extended=1')
            if newznab_id == '25709':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25709&extended=1')
            if newznab_id == '24537':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24537&extended=1')
            if newznab_id == '29696':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29696&extended=1')
            if newznab_id == '24536':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24536&extended=1')
            if newznab_id == '24538':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24538&extended=1')
            if newznab_id == '28450':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28450&extended=1')
            if newznab_id == '28450':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28450&extended=1')
            if newznab_id == '27600':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27600&extended=1')
            if newznab_id == '13963':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13963&extended=1')
            if newznab_id == '24539':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24539&extended=1')
            if newznab_id == '28452':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28452&extended=1')
            if newznab_id == '20324':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20324&extended=1')
            if newznab_id == '30600':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30600&extended=1')
            if newznab_id == '29363':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29363&extended=1')
            if newznab_id == '27941':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27941&extended=1')
            if newznab_id == '22464':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22464&extended=1')
            if newznab_id == '26214':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26214&extended=1')
            if newznab_id == '31105':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31105&extended=1')
            if newznab_id == '20169':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20169&extended=1')
            if newznab_id == '27637':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27637&extended=1')
            if newznab_id == '27637':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27637&extended=1')
            if newznab_id == '7942':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7942&extended=1')
            if newznab_id == '32489':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32489&extended=1')
            if newznab_id == '31067':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31067&extended=1')
            if newznab_id == '33915':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33915&extended=1')
            if newznab_id == '30735':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30735&extended=1')
            if newznab_id == '25490':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25490&extended=1')
            if newznab_id == '33617':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33617&extended=1')
            if newznab_id == '27988':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27988&extended=1')
            if newznab_id == '4505':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4505&extended=1')
            if newznab_id == '31773':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31773&extended=1')
            if newznab_id == '16083':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16083&extended=1')
            if newznab_id == '30933':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30933&extended=1')
            if newznab_id == '16446':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16446&extended=1')
            if newznab_id == '2690':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2690&extended=1')
            if newznab_id == '2797':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2797&extended=1')
            if newznab_id == '23561':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23561&extended=1')
            if newznab_id == '22338':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22338&extended=1')
            if newznab_id == '2990':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2990&extended=1')
            if newznab_id == '3188':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3188&extended=1')
            if newznab_id == '3267':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3267&extended=1')
            if newznab_id == '21051':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21051&extended=1')
            if newznab_id == '24655':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24655&extended=1')
            if newznab_id == '3449':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3449&extended=1')
            if newznab_id == '3591':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3591&extended=1')
            if newznab_id == '1851':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1851&extended=1')
            if newznab_id == '24988':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24988&extended=1')
            if newznab_id == '24493':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24493&extended=1')
            if newznab_id == '18102':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18102&extended=1')
            if newznab_id == '30124':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30124&extended=1')
            if newznab_id == '10244':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10244&extended=1')
            if newznab_id == '24569':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24569&extended=1')
            if newznab_id == '21942':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21942&extended=1')
            if newznab_id == '18262':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18262&extended=1')
            if newznab_id == '4161':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4161&extended=1')
            if newznab_id == '25055':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25055&extended=1')
            if newznab_id == '30531':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30531&extended=1')
            if newznab_id == '4760':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4760&extended=1')
            if newznab_id == '4950':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4950&extended=1')
            if newznab_id == '5047':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5047&extended=1')
            if newznab_id == '15188':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15188&extended=1')
            if newznab_id == '5155':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5155&extended=1')
            if newznab_id == '5214':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5214&extended=1')
            if newznab_id == '5853':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5853&extended=1')
            if newznab_id == '18401':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18401&extended=1')
            if newznab_id == '31286':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31286&extended=1')
            if newznab_id == '24803':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24803&extended=1')
            if newznab_id == '6206':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6206&extended=1')
            if newznab_id == '6296':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6296&extended=1')
            if newznab_id == '22606':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22606&extended=1')
            if newznab_id == '12662':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12662&extended=1')
            if newznab_id == '28149':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28149&extended=1')
            if newznab_id == '26774':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26774&extended=1')
            if newznab_id == '30590':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30590&extended=1')
            if newznab_id == '18244':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18244&extended=1')
            if newznab_id == '26432':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26432&extended=1')
            if newznab_id == '33097':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33097&extended=1')
            if newznab_id == '14611':
                url_out = (newznab_url_search + '&t=tvsearch&rid=14611&extended=1')
            if newznab_id == '16886':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16886&extended=1')
            if newznab_id == '3910':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3910&extended=1')
            if newznab_id == '28520':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28520&extended=1')
            if newznab_id == '20892':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20892&extended=1')
            if newznab_id == '24796':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24796&extended=1')
            if newznab_id == '26839':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26839&extended=1')
            if newznab_id == '15219':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15219&extended=1')
            if newznab_id == '28406':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28406&extended=1')
            if newznab_id == '18481':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18481&extended=1')
            if newznab_id == '33396':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33396&extended=1')
            if newznab_id == '18514':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18514&extended=1')
            if newznab_id == '30064':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30064&extended=1')
            if newznab_id == '26972':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26972&extended=1')
            if newznab_id == '26972':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26972&extended=1')
            if newznab_id == '30518':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30518&extended=1')
            if newznab_id == '26101':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26101&extended=1')
            if newznab_id == '15561':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15561&extended=1')
            if newznab_id == '32440':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32440&extended=1')
            if newznab_id == '22634':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22634&extended=1')
            if newznab_id == '20337':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20337&extended=1')
            if newznab_id == '30114':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30114&extended=1')
            if newznab_id == '17845':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17845&extended=1')
            if newznab_id == '32296':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32296&extended=1')
            if newznab_id == '29765':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29765&extended=1')
            if newznab_id == '29788':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29788&extended=1')
            if newznab_id == '3868':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3868&extended=1')
            if newznab_id == '22027':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22027&extended=1')
            if newznab_id == '16964':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16964&extended=1')
            if newznab_id == '33985':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33985&extended=1')
            if newznab_id == '16471':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16471&extended=1')
            if newznab_id == '27921':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27921&extended=1')
            if newznab_id == '29969':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29969&extended=1')
            if newznab_id == '26728':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26728&extended=1')
            if newznab_id == '19588':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19588&extended=1')
            if newznab_id == '18249':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18249&extended=1')
            if newznab_id == '13373':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13373&extended=1')
            if newznab_id == '32230':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32230&extended=1')
            if newznab_id == '26179':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26179&extended=1')
            if newznab_id == '17807':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17807&extended=1')
            if newznab_id == '31767':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31767&extended=1')
            if newznab_id == '27746':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27746&extended=1')
            if newznab_id == '23461':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23461&extended=1')
            if newznab_id == '32853':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32853&extended=1')
            if newznab_id == '27572':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27572&extended=1')
            if newznab_id == '32860':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32860&extended=1')
            if newznab_id == '22341':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22341&extended=1')
            if newznab_id == '23281':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23281&extended=1')
            if newznab_id == '23281':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23281&extended=1')
            if newznab_id == '32074':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32074&extended=1')
            if newznab_id == '32108':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32108&extended=1')
            if newznab_id == '25495':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25495&extended=1')
            if newznab_id == '26227':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26227&extended=1')
            if newznab_id == '26351':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26351&extended=1')
            if newznab_id == '23151':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23151&extended=1')
            if newznab_id == '26984':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26984&extended=1')
            if newznab_id == '21858':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21858&extended=1')
            if newznab_id == '20568':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20568&extended=1')
            if newznab_id == '24826':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24826&extended=1')
            if newznab_id == '27750':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27750&extended=1')
            if newznab_id == '30115':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30115&extended=1')
            if newznab_id == '29847':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29847&extended=1')
            if newznab_id == '22040':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22040&extended=1')
            if newznab_id == '32648':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32648&extended=1')
            if newznab_id == '29362':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29362&extended=1')
            if newznab_id == '27985':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27985&extended=1')
            if newznab_id == '29846':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29846&extended=1')
            if newznab_id == '31627':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31627&extended=1')
            if newznab_id == '27120':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27120&extended=1')
            if newznab_id == '29405':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29405&extended=1')
            if newznab_id == '26769':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26769&extended=1')
            if newznab_id == '31790':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31790&extended=1')
            if newznab_id == '33627':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33627&extended=1')
            if newznab_id == '29411':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29411&extended=1')
            if newznab_id == '27689':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27689&extended=1')
            if newznab_id == '27117':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27117&extended=1')
            if newznab_id == '29439':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29439&extended=1')
            if newznab_id == '32565':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32565&extended=1')
            if newznab_id == '26766':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26766&extended=1')
            if newznab_id == '30355':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30355&extended=1')
            if newznab_id == '26766':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26766&extended=1')
            if newznab_id == '28474':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28474&extended=1')
            if newznab_id == '28515':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28515&extended=1')
            if newznab_id == '28797':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28797&extended=1')
            if newznab_id == '27752':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27752&extended=1')
            if newznab_id == '27758':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27758&extended=1')
            if newznab_id == '28684':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28684&extended=1')
            if newznab_id == '31373':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31373&extended=1')
            if newznab_id == '27609':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27609&extended=1')
            if newznab_id == '27578':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27578&extended=1')
            if newznab_id == '28690':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28690&extended=1')
            if newznab_id == '30118':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30118&extended=1')
            if newznab_id == '31806':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31806&extended=1')
            if newznab_id == '31483':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31483&extended=1')
            if newznab_id == '27253':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27253&extended=1')
            if newznab_id == '27219':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27219&extended=1')
            if newznab_id == '28648':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28648&extended=1')
            if newznab_id == '25891':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25891&extended=1')
            if newznab_id == '15351':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15351&extended=1')
            if newznab_id == '28794':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28794&extended=1')
            if newznab_id == '31116':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31116&extended=1')
            if newznab_id == '21954':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21954&extended=1')
            if newznab_id == '23789':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23789&extended=1')
            if newznab_id == '22874':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22874&extended=1')
            if newznab_id == '33568':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33568&extended=1')
            if newznab_id == '26338':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26338&extended=1')
            if newznab_id == '27043':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27043&extended=1')
            if newznab_id == '24779':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24779&extended=1')
            if newznab_id == '26102':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26102&extended=1')
            if newznab_id == '24800':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24800&extended=1')
            if newznab_id == '27306':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27306&extended=1')
            if newznab_id == '7869':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7869&extended=1')
            if newznab_id == '22878':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22878&extended=1')
            if newznab_id == '30535':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30535&extended=1')
            if newznab_id == '27313':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27313&extended=1')
            if newznab_id == '25812':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25812&extended=1')
            if newznab_id == '26337':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26337&extended=1')
            if newznab_id == '21202':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21202&extended=1')
            if newznab_id == '9077':
                url_out = (newznab_url_search + '&t=tvsearch&rid=9077&extended=1')
            if newznab_id == '2672':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2672&extended=1')
            if newznab_id == '2701':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2701&extended=1')
            if newznab_id == '2826':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2826&extended=1')
            if newznab_id == '9168':
                url_out = (newznab_url_search + '&t=tvsearch&rid=9168&extended=1')
            if newznab_id == '835':
                url_out = (newznab_url_search + '&t=tvsearch&rid=835&extended=1')
            if newznab_id == '3007':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3007&extended=1')
            if newznab_id == '13163':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13163&extended=1')
            if newznab_id == '3165':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3165&extended=1')
            if newznab_id == '3225':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3225&extended=1')
            if newznab_id == '8859':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8859&extended=1')
            if newznab_id == '3329':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3329&extended=1')
            if newznab_id == '8860':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8860&extended=1')
            if newznab_id == '8864':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8864&extended=1')
            if newznab_id == '595':
                url_out = (newznab_url_search + '&t=tvsearch&rid=595&extended=1')
            if newznab_id == '3573':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3573&extended=1')
            if newznab_id == '1026':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1026&extended=1')
            if newznab_id == '1855':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1855&extended=1')
            if newznab_id == '3973':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3973&extended=1')
            if newznab_id == '9586':
                url_out = (newznab_url_search + '&t=tvsearch&rid=9586&extended=1')
            if newznab_id == '14941':
                url_out = (newznab_url_search + '&t=tvsearch&rid=14941&extended=1')
            if newznab_id == '4359':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4359&extended=1')
            if newznab_id == '9603':
                url_out = (newznab_url_search + '&t=tvsearch&rid=9603&extended=1')
            if newznab_id == '1986':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1986&extended=1')
            if newznab_id == '815':
                url_out = (newznab_url_search + '&t=tvsearch&rid=815&extended=1')
            if newznab_id == '11061':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11061&extended=1')
            if newznab_id == '4967':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4967&extended=1')
            if newznab_id == '5023':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5023&extended=1')
            if newznab_id == '8966':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8966&extended=1')
            if newznab_id == '158':
                url_out = (newznab_url_search + '&t=tvsearch&rid=158&extended=1')
            if newznab_id == '208':
                url_out = (newznab_url_search + '&t=tvsearch&rid=208&extended=1')
            if newznab_id == '13432':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13432&extended=1')
            if newznab_id == '5271':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5271&extended=1')
            if newznab_id == '75':
                url_out = (newznab_url_search + '&t=tvsearch&rid=75&extended=1')
            if newznab_id == '8610':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8610&extended=1')
            if newznab_id == '5591':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5591&extended=1')
            if newznab_id == '13545':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13545&extended=1')
            if newznab_id == '9277':
                url_out = (newznab_url_search + '&t=tvsearch&rid=9277&extended=1')
            if newznab_id == '914':
                url_out = (newznab_url_search + '&t=tvsearch&rid=914&extended=1')
            if newznab_id == '6158':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6158&extended=1')
            if newznab_id == '1749':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1749&extended=1')
            if newznab_id == '1653':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1653&extended=1')
            if newznab_id == '12796':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12796&extended=1')
            if newznab_id == '6490':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6490&extended=1')
            if newznab_id == '6664':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6664&extended=1')
            if newznab_id == '31579':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31579&extended=1')
            if newznab_id == '26521':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26521&extended=1')
            if newznab_id == '32526':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32526&extended=1')
            if newznab_id == '2667':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2667&extended=1')
            if newznab_id == '19374':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19374&extended=1')
            if newznab_id == '2515':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2515&extended=1')
            if newznab_id == '4847':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4847&extended=1')
            if newznab_id == '2515':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2515&extended=1')
            if newznab_id == '28489':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28489&extended=1')
            if newznab_id == '25167':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25167&extended=1')
            if newznab_id == '25167':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25167&extended=1')
            if newznab_id == '29286':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29286&extended=1')
            if newznab_id == '28701':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28701&extended=1')
            if newznab_id == '27860':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27860&extended=1')
            if newznab_id == '825':
                url_out = (newznab_url_search + '&t=tvsearch&rid=825&extended=1')
            if newznab_id == '2710':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2710&extended=1')
            if newznab_id == '15098':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15098&extended=1')
            if newznab_id == '29374':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29374&extended=1')
            if newznab_id == '28937':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28937&extended=1')
            if newznab_id == '16137':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16137&extended=1')
            if newznab_id == '27665':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27665&extended=1')
            if newznab_id == '28145':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28145&extended=1')
            if newznab_id == '26494':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26494&extended=1')
            if newznab_id == '25308':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25308&extended=1')
            if newznab_id == '252':
                url_out = (newznab_url_search + '&t=tvsearch&rid=252&extended=1')
            if newznab_id == '25311':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25311&extended=1')
            if newznab_id == '32410':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32410&extended=1')
            if newznab_id == '26934':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26934&extended=1')
            if newznab_id == '29232':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29232&extended=1')
            if newznab_id == '26617':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26617&extended=1')
            if newznab_id == '31574':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31574&extended=1')
            if newznab_id == '3327':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3327&extended=1')
            if newznab_id == '26615':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26615&extended=1')
            if newznab_id == '3440':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3440&extended=1')
            if newznab_id == '30377':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30377&extended=1')
            if newznab_id == '29594':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29594&extended=1')
            if newznab_id == '1897':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1897&extended=1')
            if newznab_id == '25774':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25774&extended=1')
            if newznab_id == '1170':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1170&extended=1')
            if newznab_id == '20179':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20179&extended=1')
            if newznab_id == '23399':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23399&extended=1')
            if newznab_id == '1922':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1922&extended=1')
            if newznab_id == '1035':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1035&extended=1')
            if newznab_id == '3819':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3819&extended=1')
            if newznab_id == '28206':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28206&extended=1')
            if newznab_id == '32797':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32797&extended=1')
            if newznab_id == '25986':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25986&extended=1')
            if newznab_id == '28427':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28427&extended=1')
            if newznab_id == '22990':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22990&extended=1')
            if newznab_id == '4108':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4108&extended=1')
            if newznab_id == '31234':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31234&extended=1')
            if newznab_id == '27189':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27189&extended=1')
            if newznab_id == '15522':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15522&extended=1')
            if newznab_id == '18198':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18198&extended=1')
            if newznab_id == '28848':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28848&extended=1')
            if newznab_id == '28848':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28848&extended=1')
            if newznab_id == '7936':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7936&extended=1')
            if newznab_id == '24627':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24627&extended=1')
            if newznab_id == '29381':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29381&extended=1')
            if newznab_id == '28006':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28006&extended=1')
            if newznab_id == '31268':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31268&extended=1')
            if newznab_id == '27463':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27463&extended=1')
            if newznab_id == '22373':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22373&extended=1')
            if newznab_id == '29385':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29385&extended=1')
            if newznab_id == '4466':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4466&extended=1')
            if newznab_id == '28004':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28004&extended=1')
            if newznab_id == '29373':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29373&extended=1')
            if newznab_id == '27668':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27668&extended=1')
            if newznab_id == '32529':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32529&extended=1')
            if newznab_id == '4559':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4559&extended=1')
            if newznab_id == '30171':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30171&extended=1')
            if newznab_id == '18027':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18027&extended=1')
            if newznab_id == '26115':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26115&extended=1')
            if newznab_id == '26495':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26495&extended=1')
            if newznab_id == '27139':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27139&extended=1')
            if newznab_id == '21818':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21818&extended=1')
            if newznab_id == '28200':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28200&extended=1')
            if newznab_id == '23000':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23000&extended=1')
            if newznab_id == '29216':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29216&extended=1')
            if newznab_id == '29079':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29079&extended=1')
            if newznab_id == '17793':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17793&extended=1')
            if newznab_id == '32406':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32406&extended=1')
            if newznab_id == '30376':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30376&extended=1')
            if newznab_id == '28381':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28381&extended=1')
            if newznab_id == '28381':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28381&extended=1')
            if newznab_id == '28938':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28938&extended=1')
            if newznab_id == '27947':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27947&extended=1')
            if newznab_id == '27853':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27853&extended=1')
            if newznab_id == '29037':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29037&extended=1')
            if newznab_id == '28194':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28194&extended=1')
            if newznab_id == '28886':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28886&extended=1')
            if newznab_id == '30143':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30143&extended=1')
            if newznab_id == '5419':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5419&extended=1')
            if newznab_id == '24624':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24624&extended=1')
            if newznab_id == '27187':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27187&extended=1')
            if newznab_id == '30085':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30085&extended=1')
            if newznab_id == '5623':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5623&extended=1')
            if newznab_id == '32530':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32530&extended=1')
            if newznab_id == '2085':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2085&extended=1')
            if newznab_id == '32322':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32322&extended=1')
            if newznab_id == '28593':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28593&extended=1')
            if newznab_id == '23626':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23626&extended=1')
            if newznab_id == '27796':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27796&extended=1')
            if newznab_id == '5716':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5716&extended=1')
            if newznab_id == '5798':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5798&extended=1')
            if newznab_id == '31214':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31214&extended=1')
            if newznab_id == '29282':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29282&extended=1')
            if newznab_id == '20772':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20772&extended=1')
            if newznab_id == '24626':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24626&extended=1')
            if newznab_id == '32442':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32442&extended=1')
            if newznab_id == '32798':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32798&extended=1')
            if newznab_id == '31240':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31240&extended=1')
            if newznab_id == '6026':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6026&extended=1')
            if newznab_id == '33565':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33565&extended=1')
            if newznab_id == '30223':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30223&extended=1')
            if newznab_id == '6152':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6152&extended=1')
            if newznab_id == '32633':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32633&extended=1')
            if newznab_id == '27137':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27137&extended=1')
            if newznab_id == '33516':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33516&extended=1')
            if newznab_id == '6272':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6272&extended=1')
            if newznab_id == '6313':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6313&extended=1')
            if newznab_id == '26849':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26849&extended=1')
            if newznab_id == '31070':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31070&extended=1')
            if newznab_id == '31633':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31633&extended=1')
            if newznab_id == '6421':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6421&extended=1')
            if newznab_id == '6498':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6498&extended=1')
            if newznab_id == '28144':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28144&extended=1')
            if newznab_id == '21527':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21527&extended=1')
            if newznab_id == '7975':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7975&extended=1')
            if newznab_id == '26724':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26724&extended=1')
            if newznab_id == '7861':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7861&extended=1')
            if newznab_id == '30173':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30173&extended=1')
            if newznab_id == '7318':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7318&extended=1')
            if newznab_id == '16431':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16431&extended=1')
            if newznab_id == '20089':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20089&extended=1')
            if newznab_id == '24139':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24139&extended=1')
            if newznab_id == '20610':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20610&extended=1')
            if newznab_id == '26964':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26964&extended=1')
            if newznab_id == '32279':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32279&extended=1')
            if newznab_id == '31283':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31283&extended=1')
            if newznab_id == '27628':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27628&extended=1')
            if newznab_id == '30172':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30172&extended=1')
            if newznab_id == '28885':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28885&extended=1')
            if newznab_id == '29738':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29738&extended=1')
            if newznab_id == '23912':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23912&extended=1')
            if newznab_id == '17378':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17378&extended=1')
            if newznab_id == '33015':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33015&extended=1')
            if newznab_id == '26727':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26727&extended=1')
            if newznab_id == '12949':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12949&extended=1')
            if newznab_id == '31011':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31011&extended=1')
            if newznab_id == '27513':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27513&extended=1')
            if newznab_id == '27506':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27506&extended=1')
            if newznab_id == '27759':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27759&extended=1')
            if newznab_id == '21880':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21880&extended=1')
            if newznab_id == '23889':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23889&extended=1')
            if newznab_id == '30728':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30728&extended=1')
            if newznab_id == '20059':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20059&extended=1')
            if newznab_id == '33304':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33304&extended=1')
            if newznab_id == '30620':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30620&extended=1')
            if newznab_id == '26898':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26898&extended=1')
            if newznab_id == '30347':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30347&extended=1')
            if newznab_id == '29707':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29707&extended=1')
            if newznab_id == '28761':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28761&extended=1')
            if newznab_id == '2588':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2588&extended=1')
            if newznab_id == '15594':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15594&extended=1')
            if newznab_id == '28444':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28444&extended=1')
            if newznab_id == '21886':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21886&extended=1')
            if newznab_id == '29040':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29040&extended=1')
            if newznab_id == '28769':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28769&extended=1')
            if newznab_id == '28767':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28767&extended=1')
            if newznab_id == '28767':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28767&extended=1')
            if newznab_id == '28767':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28767&extended=1')
            if newznab_id == '4903':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4903&extended=1')
            if newznab_id == '28686':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28686&extended=1')
            if newznab_id == '28442':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28442&extended=1')
            if newznab_id == '27546':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27546&extended=1')
            if newznab_id == '29471':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29471&extended=1')
            if newznab_id == '28572':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28572&extended=1')
            if newznab_id == '20727':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20727&extended=1')
            if newznab_id == '20727':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20727&extended=1')
            if newznab_id == '27244':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27244&extended=1')
            if newznab_id == '21652':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21652&extended=1')
            if newznab_id == '24975':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24975&extended=1')
            if newznab_id == '18775':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18775&extended=1')
            if newznab_id == '15332':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15332&extended=1')
            if newznab_id == '25451':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25451&extended=1')
            if newznab_id == '33353':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33353&extended=1')
            if newznab_id == '26832':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26832&extended=1')
            if newznab_id == '14609':
                url_out = (newznab_url_search + '&t=tvsearch&rid=14609&extended=1')
            if newznab_id == '14283':
                url_out = (newznab_url_search + '&t=tvsearch&rid=14283&extended=1')
            if newznab_id == '15491':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15491&extended=1')
            if newznab_id == '19820':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19820&extended=1')
            if newznab_id == '27777':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27777&extended=1')
            if newznab_id == '29705':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29705&extended=1')
            if newznab_id == '14812':
                url_out = (newznab_url_search + '&t=tvsearch&rid=14812&extended=1')
            if newznab_id == '15660':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15660&extended=1')
            if newznab_id == '27927':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27927&extended=1')
            if newznab_id == '23978':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23978&extended=1')
            if newznab_id == '24715':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24715&extended=1')
            if newznab_id == '22842':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22842&extended=1')
            if newznab_id == '15438':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15438&extended=1')
            if newznab_id == '8406':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8406&extended=1')
            if newznab_id == '28691':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28691&extended=1')
            if newznab_id == '2746':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2746&extended=1')
            if newznab_id == '2746':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2746&extended=1')
            if newznab_id == '30519':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30519&extended=1')
            if newznab_id == '32713':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32713&extended=1')
            if newznab_id == '29426':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29426&extended=1')
            if newznab_id == '28446':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28446&extended=1')
            if newznab_id == '23932':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23932&extended=1')
            if newznab_id == '28512':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28512&extended=1')
            if newznab_id == '29433':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29433&extended=1')
            if newznab_id == '28460':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28460&extended=1')
            if newznab_id == '27118':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27118&extended=1')
            if newznab_id == '24425':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24425&extended=1')
            if newznab_id == '31591':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31591&extended=1')
            if newznab_id == '24790':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24790&extended=1')
            if newznab_id == '4829':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4829&extended=1')
            if newznab_id == '23518':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23518&extended=1')
            if newznab_id == '4914':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4914&extended=1')
            if newznab_id == '18366':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18366&extended=1')
            if newznab_id == '27731':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27731&extended=1')
            if newznab_id == '14535':
                url_out = (newznab_url_search + '&t=tvsearch&rid=14535&extended=1')
            if newznab_id == '21695':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21695&extended=1')
            if newznab_id == '31359':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31359&extended=1')
            if newznab_id == '25843':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25843&extended=1')
            if newznab_id == '31527':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31527&extended=1')
            if newznab_id == '27969':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27969&extended=1')
            if newznab_id == '27391':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27391&extended=1')
            if newznab_id == '24465':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24465&extended=1')
            if newznab_id == '27575':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27575&extended=1')
            if newznab_id == '6126':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6126&extended=1')
            if newznab_id == '28256':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28256&extended=1')
            if newznab_id == '23450':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23450&extended=1')
            if newznab_id == '6890':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6890&extended=1')
            if newznab_id == '32126':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32126&extended=1')
            if newznab_id == '6065':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6065&extended=1')
            if newznab_id == '30878':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30878&extended=1')
            if newznab_id == '6125':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6125&extended=1')
            if newznab_id == '29448':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29448&extended=1')
            if newznab_id == '31197':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31197&extended=1')
            if newznab_id == '33240':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33240&extended=1')
            if newznab_id == '32459':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32459&extended=1')
            if newznab_id == '32335':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32335&extended=1')
            if newznab_id == '25552':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25552&extended=1')
            if newznab_id == '2116':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2116&extended=1')
            if newznab_id == '33430':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33430&extended=1')
            if newznab_id == '583':
                url_out = (newznab_url_search + '&t=tvsearch&rid=583&extended=1')
            if newznab_id == '26183':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26183&extended=1')
            if newznab_id == '21698':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21698&extended=1')
            if newznab_id == '5575':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5575&extended=1')
            if newznab_id == '3275':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3275&extended=1')
            if newznab_id == '30411':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30411&extended=1')
            if newznab_id == '30411':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30411&extended=1')
            if newznab_id == '32488':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32488&extended=1')
            if newznab_id == '24000':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24000&extended=1')
            if newznab_id == '27312':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27312&extended=1')
            if newznab_id == '32545':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32545&extended=1')
            if newznab_id == '33047':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33047&extended=1')
            if newznab_id == '32127':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32127&extended=1')
            if newznab_id == '30426':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30426&extended=1')
            if newznab_id == '31397':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31397&extended=1')
            if newznab_id == '28346':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28346&extended=1')
            if newznab_id == '27309':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27309&extended=1')
            if newznab_id == '27660':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27660&extended=1')
            if newznab_id == '31751':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31751&extended=1')
            if newznab_id == '18690':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18690&extended=1')
            if newznab_id == '24777':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24777&extended=1')
            if newznab_id == '26172':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26172&extended=1')
            if newznab_id == '25227':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25227&extended=1')
            if newznab_id == '29418':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29418&extended=1')
            if newznab_id == '33134':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33134&extended=1')
            if newznab_id == '16461':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16461&extended=1')
            if newznab_id == '33208':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33208&extended=1')
            if newznab_id == '30544':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30544&extended=1')
            if newznab_id == '27433':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27433&extended=1')
            if newznab_id == '25909':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25909&extended=1')
            if newznab_id == '32535':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32535&extended=1')
            if newznab_id == '26177':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26177&extended=1')
            if newznab_id == '29298':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29298&extended=1')
            if newznab_id == '21565':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21565&extended=1')
            if newznab_id == '33024':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33024&extended=1')
            if newznab_id == '18578':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18578&extended=1')
            if newznab_id == '14691':
                url_out = (newznab_url_search + '&t=tvsearch&rid=14691&extended=1')
            if newznab_id == '29113':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29113&extended=1')
            if newznab_id == '21856':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21856&extended=1')
            if newznab_id == '17338':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17338&extended=1')
            if newznab_id == '17091':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17091&extended=1')
            if newznab_id == '29335':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29335&extended=1')
            if newznab_id == '26745':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26745&extended=1')
            if newznab_id == '6968':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6968&extended=1')
            if newznab_id == '26043':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26043&extended=1')
            if newznab_id == '23872':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23872&extended=1')
            if newznab_id == '30904':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30904&extended=1')
            if newznab_id == '2288':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2288&extended=1')
            if newznab_id == '1306':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1306&extended=1')
            if newznab_id == '31127':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31127&extended=1')
            if newznab_id == '27075':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27075&extended=1')
            if newznab_id == '29977':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29977&extended=1')
            if newznab_id == '27435':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27435&extended=1')
            if newznab_id == '23283':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23283&extended=1')
            if newznab_id == '29769':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29769&extended=1')
            if newznab_id == '29334':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29334&extended=1')
            if newznab_id == '33579':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33579&extended=1')
            if newznab_id == '10255':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10255&extended=1')
            if newznab_id == '27436':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27436&extended=1')
            if newznab_id == '17035':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17035&extended=1')
            if newznab_id == '29986':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29986&extended=1')
            if newznab_id == '29354':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29354&extended=1')
            if newznab_id == '17934':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17934&extended=1')
            if newznab_id == '25493':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25493&extended=1')
            if newznab_id == '27073':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27073&extended=1')
            if newznab_id == '31233':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31233&extended=1')
            if newznab_id == '27000':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27000&extended=1')
            if newznab_id == '20191':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20191&extended=1')
            if newznab_id == '10188':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10188&extended=1')
            if newznab_id == '28068':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28068&extended=1')
            if newznab_id == '27040':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27040&extended=1')
            if newznab_id == '27337':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27337&extended=1')
            if newznab_id == '27262':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27262&extended=1')
            if newznab_id == '18257':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18257&extended=1')
            if newznab_id == '30525':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30525&extended=1')
            if newznab_id == '28287':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28287&extended=1')
            if newznab_id == '29932':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29932&extended=1')
            if newznab_id == '25372':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25372&extended=1')
            if newznab_id == '29933':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29933&extended=1')
            if newznab_id == '29767':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29767&extended=1')
            if newznab_id == '26260':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26260&extended=1')
            if newznab_id == '31859':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31859&extended=1')
            if newznab_id == '30638':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30638&extended=1')
            if newznab_id == '30983':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30983&extended=1')
            if newznab_id == '11215':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11215&extended=1')
            if newznab_id == '2454':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2454&extended=1')
            if newznab_id == '10408':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10408&extended=1')
            if newznab_id == '25748':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25748&extended=1')
            if newznab_id == '30758':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30758&extended=1')
            if newznab_id == '28368':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28368&extended=1')
            if newznab_id == '28361':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28361&extended=1')
            if newznab_id == '28369':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28369&extended=1')
            if newznab_id == '28370':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28370&extended=1')
            if newznab_id == '27936':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27936&extended=1')
            if newznab_id == '2819':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2819&extended=1')
            if newznab_id == '2874':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2874&extended=1')
            if newznab_id == '2958':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2958&extended=1')
            if newznab_id == '2977':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2977&extended=1')
            if newznab_id == '2976':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2976&extended=1')
            if newznab_id == '2987':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2987&extended=1')
            if newznab_id == '2994':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2994&extended=1')
            if newznab_id == '24635':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24635&extended=1')
            if newznab_id == '3044':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3044&extended=1')
            if newznab_id == '30748':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30748&extended=1')
            if newznab_id == '15614':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15614&extended=1')
            if newznab_id == '22589':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22589&extended=1')
            if newznab_id == '3168':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3168&extended=1')
            if newznab_id == '18491':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18491&extended=1')
            if newznab_id == '3256':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3256&extended=1')
            if newznab_id == '3262':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3262&extended=1')
            if newznab_id == '31646':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31646&extended=1')
            if newznab_id == '30897':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30897&extended=1')
            if newznab_id == '28373':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28373&extended=1')
            if newznab_id == '3533':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3533&extended=1')
            if newznab_id == '3597':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3597&extended=1')
            if newznab_id == '3601':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3601&extended=1')
            if newznab_id == '28356':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28356&extended=1')
            if newznab_id == '24665':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24665&extended=1')
            if newznab_id == '3616':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3616&extended=1')
            if newznab_id == '3684':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3684&extended=1')
            if newznab_id == '30756':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30756&extended=1')
            if newznab_id == '28352':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28352&extended=1')
            if newznab_id == '31674':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31674&extended=1')
            if newznab_id == '25720':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25720&extended=1')
            if newznab_id == '8172':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8172&extended=1')
            if newznab_id == '3860':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3860&extended=1')
            if newznab_id == '3865':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3865&extended=1')
            if newznab_id == '3889':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3889&extended=1')
            if newznab_id == '791':
                url_out = (newznab_url_search + '&t=tvsearch&rid=791&extended=1')
            if newznab_id == '329':
                url_out = (newznab_url_search + '&t=tvsearch&rid=329&extended=1')
            if newznab_id == '3995':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3995&extended=1')
            if newznab_id == '345':
                url_out = (newznab_url_search + '&t=tvsearch&rid=345&extended=1')
            if newznab_id == '28409':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28409&extended=1')
            if newznab_id == '4053':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4053&extended=1')
            if newznab_id == '4061':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4061&extended=1')
            if newznab_id == '18685':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18685&extended=1')
            if newznab_id == '4170':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4170&extended=1')
            if newznab_id == '4182':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4182&extended=1')
            if newznab_id == '4192':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4192&extended=1')
            if newznab_id == '25450':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25450&extended=1')
            if newznab_id == '4204':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4204&extended=1')
            if newznab_id == '4202':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4202&extended=1')
            if newznab_id == '4244':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4244&extended=1')
            if newznab_id == '7887':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7887&extended=1')
            if newznab_id == '25660':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25660&extended=1')
            if newznab_id == '28172':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28172&extended=1')
            if newznab_id == '4321':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4321&extended=1')
            if newznab_id == '4365':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4365&extended=1')
            if newznab_id == '4419':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4419&extended=1')
            if newznab_id == '24485':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24485&extended=1')
            if newznab_id == '4481':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4481&extended=1')
            if newznab_id == '8665':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8665&extended=1')
            if newznab_id == '33175':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33175&extended=1')
            if newznab_id == '19129':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19129&extended=1')
            if newznab_id == '4546':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4546&extended=1')
            if newznab_id == '4590':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4590&extended=1')
            if newznab_id == '4609':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4609&extended=1')
            if newznab_id == '4651':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4651&extended=1')
            if newznab_id == '4664':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4664&extended=1')
            if newznab_id == '18934':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18934&extended=1')
            if newznab_id == '25704':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25704&extended=1')
            if newznab_id == '22586':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22586&extended=1')
            if newznab_id == '22586':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22586&extended=1')
            if newznab_id == '21686':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21686&extended=1')
            if newznab_id == '25657':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25657&extended=1')
            if newznab_id == '15023':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15023&extended=1')
            if newznab_id == '4855':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4855&extended=1')
            if newznab_id == '4855':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4855&extended=1')
            if newznab_id == '4921':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4921&extended=1')
            if newznab_id == '4931':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4931&extended=1')
            if newznab_id == '4972':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4972&extended=1')
            if newznab_id == '30897':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30897&extended=1')
            if newznab_id == '5015':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5015&extended=1')
            if newznab_id == '29820':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29820&extended=1')
            if newznab_id == '5097':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5097&extended=1')
            if newznab_id == '5098':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5098&extended=1')
            if newznab_id == '5145':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5145&extended=1')
            if newznab_id == '28337':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28337&extended=1')
            if newznab_id == '31338':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31338&extended=1')
            if newznab_id == '5414':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5414&extended=1')
            if newznab_id == '1773':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1773&extended=1')
            if newznab_id == '5580':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5580&extended=1')
            if newznab_id == '5618':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5618&extended=1')
            if newznab_id == '5624':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5624&extended=1')
            if newznab_id == '24633':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24633&extended=1')
            if newznab_id == '5698':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5698&extended=1')
            if newznab_id == '5724':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5724&extended=1')
            if newznab_id == '25703':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25703&extended=1')
            if newznab_id == '5759':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5759&extended=1')
            if newznab_id == '28374':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28374&extended=1')
            if newznab_id == '5795':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5795&extended=1')
            if newznab_id == '5820':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5820&extended=1')
            if newznab_id == '5871':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5871&extended=1')
            if newznab_id == '5879':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5879&extended=1')
            if newznab_id == '5879':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5879&extended=1')
            if newznab_id == '5932':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5932&extended=1')
            if newznab_id == '5966':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5966&extended=1')
            if newznab_id == '31384':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31384&extended=1')
            if newznab_id == '6061':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6061&extended=1')
            if newznab_id == '25724':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25724&extended=1')
            if newznab_id == '28375':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28375&extended=1')
            if newznab_id == '6107':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6107&extended=1')
            if newznab_id == '24839':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24839&extended=1')
            if newznab_id == '6156':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6156&extended=1')
            if newznab_id == '22819':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22819&extended=1')
            if newznab_id == '6202':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6202&extended=1')
            if newznab_id == '27447':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27447&extended=1')
            if newznab_id == '6289':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6289&extended=1')
            if newznab_id == '28358':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28358&extended=1')
            if newznab_id == '6523':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6523&extended=1')
            if newznab_id == '28357':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28357&extended=1')
            if newznab_id == '22820':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22820&extended=1')
            if newznab_id == '6594':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6594&extended=1')
            if newznab_id == '28410':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28410&extended=1')
            if newznab_id == '6614':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6614&extended=1')
            if newznab_id == '203':
                url_out = (newznab_url_search + '&t=tvsearch&rid=203&extended=1')
            if newznab_id == '28160':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28160&extended=1')
            if newznab_id == '19532':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19532&extended=1')
            if newznab_id == '2649':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2649&extended=1')
            if newznab_id == '29686':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29686&extended=1')
            if newznab_id == '25992':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25992&extended=1')
            if newznab_id == '28347':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28347&extended=1')
            if newznab_id == '30045':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30045&extended=1')
            if newznab_id == '32755':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32755&extended=1')
            if newznab_id == '32703':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32703&extended=1')
            if newznab_id == '4211':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4211&extended=1')
            if newznab_id == '23386':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23386&extended=1')
            if newznab_id == '6340':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6340&extended=1')
            if newznab_id == '2470':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2470&extended=1')
            if newznab_id == '2557':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2557&extended=1')
            if newznab_id == '2644':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2644&extended=1')
            if newznab_id == '2680':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2680&extended=1')
            if newznab_id == '24951':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24951&extended=1')
            if newznab_id == '25192':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25192&extended=1')
            if newznab_id == '3226':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3226&extended=1')
            if newznab_id == '3348':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3348&extended=1')
            if newznab_id == '3378':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3378&extended=1')
            if newznab_id == '23199':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23199&extended=1')
            if newznab_id == '286':
                url_out = (newznab_url_search + '&t=tvsearch&rid=286&extended=1')
            if newznab_id == '30686':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30686&extended=1')
            if newznab_id == '12930':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12930&extended=1')
            if newznab_id == '3843':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3843&extended=1')
            if newznab_id == '27307':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27307&extended=1')
            if newznab_id == '30637':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30637&extended=1')
            if newznab_id == '15498':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15498&extended=1')
            if newznab_id == '3985':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3985&extended=1')
            if newznab_id == '22713':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22713&extended=1')
            if newznab_id == '30687':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30687&extended=1')
            if newznab_id == '4631':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4631&extended=1')
            if newznab_id == '5038':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5038&extended=1')
            if newznab_id == '5304':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5304&extended=1')
            if newznab_id == '27478':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27478&extended=1')
            if newznab_id == '5400':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5400&extended=1')
            if newznab_id == '24962':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24962&extended=1')
            if newznab_id == '27772':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27772&extended=1')
            if newznab_id == '5531':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5531&extended=1')
            if newznab_id == '5563':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5563&extended=1')
            if newznab_id == '5576':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5576&extended=1')
            if newznab_id == '26254':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26254&extended=1')
            if newznab_id == '21572':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21572&extended=1')
            if newznab_id == '6293':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6293&extended=1')
            if newznab_id == '25190':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25190&extended=1')
            if newznab_id == '10663':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10663&extended=1')
            if newznab_id == '17329':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17329&extended=1')
            if newznab_id == '6700':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6700&extended=1')
            if newznab_id == '25859':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25859&extended=1')
            if newznab_id == '26412':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26412&extended=1')
            if newznab_id == '19586':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19586&extended=1')
            if newznab_id == '23205':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23205&extended=1')
            if newznab_id == '23548':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23548&extended=1')
            if newznab_id == '28196':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28196&extended=1')
            if newznab_id == '11165':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11165&extended=1')
            if newznab_id == '13024':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13024&extended=1')
            if newznab_id == '28792':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28792&extended=1')
            if newznab_id == '2790':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2790&extended=1')
            if newznab_id == '28735':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28735&extended=1')
            if newznab_id == '21779':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21779&extended=1')
            if newznab_id == '3776':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3776&extended=1')
            if newznab_id == '29148':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29148&extended=1')
            if newznab_id == '7674':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7674&extended=1')
            if newznab_id == '31989':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31989&extended=1')
            if newznab_id == '29239':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29239&extended=1')
            if newznab_id == '24230':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24230&extended=1')
            if newznab_id == '4311':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4311&extended=1')
            if newznab_id == '1132':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1132&extended=1')
            if newznab_id == '11536':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11536&extended=1')
            if newznab_id == '23496':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23496&extended=1')
            if newznab_id == '11428':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11428&extended=1')
            if newznab_id == '16593':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16593&extended=1')
            if newznab_id == '130':
                url_out = (newznab_url_search + '&t=tvsearch&rid=130&extended=1')
            if newznab_id == '5354':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5354&extended=1')
            if newznab_id == '2185':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2185&extended=1')
            if newznab_id == '29979':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29979&extended=1')
            if newznab_id == '17851':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17851&extended=1')
            if newznab_id == '30009':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30009&extended=1')
            if newznab_id == '6157':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6157&extended=1')
            if newznab_id == '27287':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27287&extended=1')
            if newznab_id == '28655':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28655&extended=1')
            if newznab_id == '30669':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30669&extended=1')
            if newznab_id == '29369':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29369&extended=1')
            if newznab_id == '23570':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23570&extended=1')
            if newznab_id == '30626':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30626&extended=1')
            if newznab_id == '15433':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15433&extended=1')
            if newznab_id == '32484':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32484&extended=1')
            if newznab_id == '30345':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30345&extended=1')
            if newznab_id == '25329':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25329&extended=1')
            if newznab_id == '32568':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32568&extended=1')
            if newznab_id == '29972':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29972&extended=1')
            if newznab_id == '31794':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31794&extended=1')
            if newznab_id == '27152':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27152&extended=1')
            if newznab_id == '30737':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30737&extended=1')
            if newznab_id == '28123':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28123&extended=1')
            if newznab_id == '29833':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29833&extended=1')
            if newznab_id == '29833':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29833&extended=1')
            if newznab_id == '29833':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29833&extended=1')
            if newznab_id == '29039':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29039&extended=1')
            if newznab_id == '27054':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27054&extended=1')
            if newznab_id == '23729':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23729&extended=1')
            if newznab_id == '33877':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33877&extended=1')
            if newznab_id == '32041':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32041&extended=1')
            if newznab_id == '7992':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7992&extended=1')
            if newznab_id == '27053':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27053&extended=1')
            if newznab_id == '29429':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29429&extended=1')
            if newznab_id == '30424':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30424&extended=1')
            if newznab_id == '27603':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27603&extended=1')
            if newznab_id == '30351':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30351&extended=1')
            if newznab_id == '29968':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29968&extended=1')
            if newznab_id == '27148':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27148&extended=1')
            if newznab_id == '27056':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27056&extended=1')
            if newznab_id == '32080':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32080&extended=1')
            if newznab_id == '30156':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30156&extended=1')
            if newznab_id == '28514':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28514&extended=1')
            if newznab_id == '27639':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27639&extended=1')
            if newznab_id == '29428':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29428&extended=1')
            if newznab_id == '28619':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28619&extended=1')
            if newznab_id == '29427':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29427&extended=1')
            if newznab_id == '28066':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28066&extended=1')
            if newznab_id == '27741':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27741&extended=1')
            if newznab_id == '25757':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25757&extended=1')
            if newznab_id == '30116':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30116&extended=1')
            if newznab_id == '31223':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31223&extended=1')
            if newznab_id == '32523':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32523&extended=1')
            if newznab_id == '3687':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3687&extended=1')
            if newznab_id == '25710':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25710&extended=1')
            if newznab_id == '32073':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32073&extended=1')
            if newznab_id == '25019':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25019&extended=1')
            if newznab_id == '14714':
                url_out = (newznab_url_search + '&t=tvsearch&rid=14714&extended=1')
            if newznab_id == '28606':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28606&extended=1')
            if newznab_id == '28225':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28225&extended=1')
            if newznab_id == '5387':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5387&extended=1')
            if newznab_id == '29072':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29072&extended=1')
            if newznab_id == '31368':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31368&extended=1')
            if newznab_id == '18193':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18193&extended=1')
            if newznab_id == '11612':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11612&extended=1')
            if newznab_id == '10581':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10581&extended=1')
            if newznab_id == '2611':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2611&extended=1')
            if newznab_id == '17788':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17788&extended=1')
            if newznab_id == '17788':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17788&extended=1')
            if newznab_id == '2657':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2657&extended=1')
            if newznab_id == '2674':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2674&extended=1')
            if newznab_id == '2715':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2715&extended=1')
            if newznab_id == '27215':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27215&extended=1')
            if newznab_id == '32686':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32686&extended=1')
            if newznab_id == '19486':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19486&extended=1')
            if newznab_id == '3088':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3088&extended=1')
            if newznab_id == '31222':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31222&extended=1')
            if newznab_id == '3618':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3618&extended=1')
            if newznab_id == '8258':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8258&extended=1')
            if newznab_id == '22209':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22209&extended=1')
            if newznab_id == '10777':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10777&extended=1')
            if newznab_id == '3869':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3869&extended=1')
            if newznab_id == '17675':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17675&extended=1')
            if newznab_id == '30710':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30710&extended=1')
            if newznab_id == '30710':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30710&extended=1')
            if newznab_id == '28821':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28821&extended=1')
            if newznab_id == '30453':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30453&extended=1')
            if newznab_id == '33999':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33999&extended=1')
            if newznab_id == '23422':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23422&extended=1')
            if newznab_id == '31942':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31942&extended=1')
            if newznab_id == '6773':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6773&extended=1')
            if newznab_id == '19290':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19290&extended=1')
            if newznab_id == '6771':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6771&extended=1')
            if newznab_id == '18131':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18131&extended=1')
            if newznab_id == '29073':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29073&extended=1')
            if newznab_id == '18774':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18774&extended=1')
            if newznab_id == '5152':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5152&extended=1')
            if newznab_id == '17939':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17939&extended=1')
            if newznab_id == '325':
                url_out = (newznab_url_search + '&t=tvsearch&rid=325&extended=1')
            if newznab_id == '325':
                url_out = (newznab_url_search + '&t=tvsearch&rid=325&extended=1')
            if newznab_id == '33045':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33045&extended=1')
            if newznab_id == '5746':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5746&extended=1')
            if newznab_id == '6338':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6338&extended=1')
            if newznab_id == '316':
                url_out = (newznab_url_search + '&t=tvsearch&rid=316&extended=1')
            if newznab_id == '32504':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32504&extended=1')
            if newznab_id == '23545':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23545&extended=1')
            if newznab_id == '25535':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25535&extended=1')
            if newznab_id == '26555':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26555&extended=1')
            if newznab_id == '30915':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30915&extended=1')
            if newznab_id == '22427':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22427&extended=1')
            if newznab_id == '27256':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27256&extended=1')
            if newznab_id == '26173':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26173&extended=1')
            if newznab_id == '24766':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24766&extended=1')
            if newznab_id == '29075':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29075&extended=1')
            if newznab_id == '27392':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27392&extended=1')
            if newznab_id == '28978':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28978&extended=1')
            if newznab_id == '19920':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19920&extended=1')
            if newznab_id == '31482':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31482&extended=1')
            if newznab_id == '28220':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28220&extended=1')
            if newznab_id == '28664':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28664&extended=1')
            if newznab_id == '32086':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32086&extended=1')
            if newznab_id == '17916':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17916&extended=1')
            if newznab_id == '33432':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33432&extended=1')
            if newznab_id == '32992':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32992&extended=1')
            if newznab_id == '3095':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3095&extended=1')
            if newznab_id == '30798':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30798&extended=1')
            if newznab_id == '29133':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29133&extended=1')
            if newznab_id == '23286':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23286&extended=1')
            if newznab_id == '31365':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31365&extended=1')
            if newznab_id == '19056':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19056&extended=1')
            if newznab_id == '29342':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29342&extended=1')
            if newznab_id == '19157':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19157&extended=1')
            if newznab_id == '27469':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27469&extended=1')
            if newznab_id == '27469':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27469&extended=1')
            if newznab_id == '26546':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26546&extended=1')
            if newznab_id == '21952':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21952&extended=1')
            if newznab_id == '28592':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28592&extended=1')
            if newznab_id == '25885':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25885&extended=1')
            if newznab_id == '26501':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26501&extended=1')
            if newznab_id == '23909':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23909&extended=1')
            if newznab_id == '30245':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30245&extended=1')
            if newznab_id == '18008':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18008&extended=1')
            if newznab_id == '24881':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24881&extended=1')
            if newznab_id == '29807':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29807&extended=1')
            if newznab_id == '11653':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11653&extended=1')
            if newznab_id == '642':
                url_out = (newznab_url_search + '&t=tvsearch&rid=642&extended=1')
            if newznab_id == '24521':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24521&extended=1')
            if newznab_id == '30603':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30603&extended=1')
            if newznab_id == '7582':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7582&extended=1')
            if newznab_id == '20547':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20547&extended=1')
            if newznab_id == '24273':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24273&extended=1')
            if newznab_id == '15352':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15352&extended=1')
            if newznab_id == '26279':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26279&extended=1')
            if newznab_id == '19855':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19855&extended=1')
            if newznab_id == '21957':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21957&extended=1')
            if newznab_id == '16701':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16701&extended=1')
            if newznab_id == '31885':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31885&extended=1')
            if newznab_id == '29222':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29222&extended=1')
            if newznab_id == '33699':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33699&extended=1')
            if newznab_id == '19143':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19143&extended=1')
            if newznab_id == '23464':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23464&extended=1')
            if newznab_id == '26447':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26447&extended=1')
            if newznab_id == '23464':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23464&extended=1')
            if newznab_id == '13490':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13490&extended=1')
            if newznab_id == '25537':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25537&extended=1')
            if newznab_id == '30739':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30739&extended=1')
            if newznab_id == '15012':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15012&extended=1')
            if newznab_id == '15012':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15012&extended=1')
            if newznab_id == '24791':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24791&extended=1')
            if newznab_id == '27009':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27009&extended=1')
            if newznab_id == '31306':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31306&extended=1')
            if newznab_id == '32034':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32034&extended=1')
            if newznab_id == '26890':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26890&extended=1')
            if newznab_id == '29958':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29958&extended=1')
            if newznab_id == '24423':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24423&extended=1')
            if newznab_id == '27049':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27049&extended=1')
            if newznab_id == '31308':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31308&extended=1')
            if newznab_id == '24909':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24909&extended=1')
            if newznab_id == '1788':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1788&extended=1')
            if newznab_id == '24014':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24014&extended=1')
            if newznab_id == '2564':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2564&extended=1')
            if newznab_id == '30619':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30619&extended=1')
            if newznab_id == '22127':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22127&extended=1')
            if newznab_id == '2842':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2842&extended=1')
            if newznab_id == '33060':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33060&extended=1')
            if newznab_id == '17228':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17228&extended=1')
            if newznab_id == '3219':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3219&extended=1')
            if newznab_id == '6743':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6743&extended=1')
            if newznab_id == '469':
                url_out = (newznab_url_search + '&t=tvsearch&rid=469&extended=1')
            if newznab_id == '24012':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24012&extended=1')
            if newznab_id == '26261':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26261&extended=1')
            if newznab_id == '24017':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24017&extended=1')
            if newznab_id == '19837':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19837&extended=1')
            if newznab_id == '31488':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31488&extended=1')
            if newznab_id == '31505':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31505&extended=1')
            if newznab_id == '16831':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16831&extended=1')
            if newznab_id == '26092':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26092&extended=1')
            if newznab_id == '32939':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32939&extended=1')
            if newznab_id == '10537':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10537&extended=1')
            if newznab_id == '26744':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26744&extended=1')
            if newznab_id == '13494':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13494&extended=1')
            if newznab_id == '11721':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11721&extended=1')
            if newznab_id == '33061':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33061&extended=1')
            if newznab_id == '32433':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32433&extended=1')
            if newznab_id == '6314':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6314&extended=1')
            if newznab_id == '18424':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18424&extended=1')
            if newznab_id == '29459':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29459&extended=1')
            if newznab_id == '27172':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27172&extended=1')
            if newznab_id == '28614':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28614&extended=1')
            if newznab_id == '30789':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30789&extended=1')
            if newznab_id == '27743':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27743&extended=1')
            if newznab_id == '1295':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1295&extended=1')
            if newznab_id == '26401':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26401&extended=1')
            if newznab_id == '28628':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28628&extended=1')
            if newznab_id == '28588':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28588&extended=1')
            if newznab_id == '27727':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27727&extended=1')
            if newznab_id == '6823':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6823&extended=1')
            if newznab_id == '15319':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15319&extended=1')
            if newznab_id == '29829':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29829&extended=1')
            if newznab_id == '3264':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3264&extended=1')
            if newznab_id == '7926':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7926&extended=1')
            if newznab_id == '23953':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23953&extended=1')
            if newznab_id == '27884':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27884&extended=1')
            if newznab_id == '27811':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27811&extended=1')
            if newznab_id == '27561':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27561&extended=1')
            if newznab_id == '3925':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3925&extended=1')
            if newznab_id == '30538':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30538&extended=1')
            if newznab_id == '30610':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30610&extended=1')
            if newznab_id == '33416':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33416&extended=1')
            if newznab_id == '19651':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19651&extended=1')
            if newznab_id == '4705':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4705&extended=1')
            if newznab_id == '4795':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4795&extended=1')
            if newznab_id == '32234':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32234&extended=1')
            if newznab_id == '33480':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33480&extended=1')
            if newznab_id == '25117':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25117&extended=1')
            if newznab_id == '25117':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25117&extended=1')
            if newznab_id == '6767':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6767&extended=1')
            if newznab_id == '24608':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24608&extended=1')
            if newznab_id == '5957':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5957&extended=1')
            if newznab_id == '190':
                url_out = (newznab_url_search + '&t=tvsearch&rid=190&extended=1')
            if newznab_id == '25554':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25554&extended=1')
            if newznab_id == '7927':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7927&extended=1')
            if newznab_id == '20601':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20601&extended=1')
            if newznab_id == '20601':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20601&extended=1')
            if newznab_id == '28687':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28687&extended=1')
            if newznab_id == '6554':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6554&extended=1')
            if newznab_id == '6208':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6208&extended=1')
            if newznab_id == '30125':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30125&extended=1')
            if newznab_id == '32483':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32483&extended=1')
            if newznab_id == '32470':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32470&extended=1')
            if newznab_id == '29407':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29407&extended=1')
            if newznab_id == '31938':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31938&extended=1')
            if newznab_id == '31491':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31491&extended=1')
            if newznab_id == '27496':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27496&extended=1')
            if newznab_id == '32469':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32469&extended=1')
            if newznab_id == '23798':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23798&extended=1')
            if newznab_id == '23066':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23066&extended=1')
            if newznab_id == '32447':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32447&extended=1')
            if newznab_id == '27754':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27754&extended=1')
            if newznab_id == '29115':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29115&extended=1')
            if newznab_id == '24763':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24763&extended=1')
            if newznab_id == '32235':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32235&extended=1')
            if newznab_id == '8238':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8238&extended=1')
            if newznab_id == '27831':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27831&extended=1')
            if newznab_id == '30988':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30988&extended=1')
            if newznab_id == '26548':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26548&extended=1')
            if newznab_id == '13919':
                url_out = (newznab_url_search + '&t=tvsearch&rid=13919&extended=1')
            if newznab_id == '2891':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2891&extended=1')
            if newznab_id == '28034':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28034&extended=1')
            if newznab_id == '27437':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27437&extended=1')
            if newznab_id == '27784':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27784&extended=1')
            if newznab_id == '30779':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30779&extended=1')
            if newznab_id == '26259':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26259&extended=1')
            if newznab_id == '32022':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32022&extended=1')
            if newznab_id == '27554':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27554&extended=1')
            if newznab_id == '31744':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31744&extended=1')
            if newznab_id == '28453':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28453&extended=1')
            if newznab_id == '31540':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31540&extended=1')
            if newznab_id == '30379':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30379&extended=1')
            if newznab_id == '32207':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32207&extended=1')
            if newznab_id == '23324':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23324&extended=1')
            if newznab_id == '28897':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28897&extended=1')
            if newznab_id == '31344':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31344&extended=1')
            if newznab_id == '26980':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26980&extended=1')
            if newznab_id == '30289':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30289&extended=1')
            if newznab_id == '24219':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24219&extended=1')
            if newznab_id == '30046':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30046&extended=1')
            if newznab_id == '24292':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24292&extended=1')
            if newznab_id == '11589':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11589&extended=1')
            if newznab_id == '12002':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12002&extended=1')
            if newznab_id == '3037':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3037&extended=1')
            if newznab_id == '4225':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4225&extended=1')
            if newznab_id == '29754':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29754&extended=1')
            if newznab_id == '22088':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22088&extended=1')
            if newznab_id == '26726':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26726&extended=1')
            if newznab_id == '29104':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29104&extended=1')
            if newznab_id == '29105':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29105&extended=1')
            if newznab_id == '28944':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28944&extended=1')
            if newznab_id == '27733':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27733&extended=1')
            if newznab_id == '31690':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31690&extended=1')
            if newznab_id == '25210':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25210&extended=1')
            if newznab_id == '21012':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21012&extended=1')
            if newznab_id == '29465':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29465&extended=1')
            if newznab_id == '26960':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26960&extended=1')
            if newznab_id == '28764':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28764&extended=1')
            if newznab_id == '29466':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29466&extended=1')
            if newznab_id == '22667':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22667&extended=1')
            if newznab_id == '26802':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26802&extended=1')
            if newznab_id == '18680':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18680&extended=1')
            if newznab_id == '21624':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21624&extended=1')
            if newznab_id == '30122':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30122&extended=1')
            if newznab_id == '29698':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29698&extended=1')
            if newznab_id == '22192':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22192&extended=1')
            if newznab_id == '30528':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30528&extended=1')
            if newznab_id == '17307':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17307&extended=1')
            if newznab_id == '17700':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17700&extended=1')
            if newznab_id == '30817':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30817&extended=1')
            if newznab_id == '27987':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27987&extended=1')
            if newznab_id == '30816':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30816&extended=1')
            if newznab_id == '32697':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32697&extended=1')
            if newznab_id == '29468':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29468&extended=1')
            if newznab_id == '2376':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2376&extended=1')
            if newznab_id == '29467':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29467&extended=1')
            if newznab_id == '28380':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28380&extended=1')
            if newznab_id == '23669':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23669&extended=1')
            if newznab_id == '24920':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24920&extended=1')
            if newznab_id == '18286':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18286&extended=1')
            if newznab_id == '29628':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29628&extended=1')
            if newznab_id == '19263':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19263&extended=1')
            if newznab_id == '26886':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26886&extended=1')
            if newznab_id == '5444':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5444&extended=1')
            if newznab_id == '28933':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28933&extended=1')
            if newznab_id == '31811':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31811&extended=1')
            if newznab_id == '28445':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28445&extended=1')
            if newznab_id == '3082':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3082&extended=1')
            if newznab_id == '31778':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31778&extended=1')
            if newznab_id == '23231':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23231&extended=1')
            if newznab_id == '28463':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28463&extended=1')
            if newznab_id == '3915':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3915&extended=1')
            if newznab_id == '24906':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24906&extended=1')
            if newznab_id == '26228':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26228&extended=1')
            if newznab_id == '29076':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29076&extended=1')
            if newznab_id == '28879':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28879&extended=1')
            if newznab_id == '27431':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27431&extended=1')
            if newznab_id == '26216':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26216&extended=1')
            if newznab_id == '29694':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29694&extended=1')
            if newznab_id == '19809':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19809&extended=1')
            if newznab_id == '23236':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23236&extended=1')
            if newznab_id == '27611':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27611&extended=1')
            if newznab_id == '31795':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31795&extended=1')
            if newznab_id == '20626':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20626&extended=1')
            if newznab_id == '30161':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30161&extended=1')
            if newznab_id == '26706':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26706&extended=1')
            if newznab_id == '19268':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19268&extended=1')
            if newznab_id == '2608':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2608&extended=1')
            if newznab_id == '2730':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2730&extended=1')
            if newznab_id == '24595':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24595&extended=1')
            if newznab_id == '11011':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11011&extended=1')
            if newznab_id == '31507':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31507&extended=1')
            if newznab_id == '11110':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11110&extended=1')
            if newznab_id == '29598':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29598&extended=1')
            if newznab_id == '7506':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7506&extended=1')
            if newznab_id == '27213':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27213&extended=1')
            if newznab_id == '25861':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25861&extended=1')
            if newznab_id == '3519':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3519&extended=1')
            if newznab_id == '3552':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3552&extended=1')
            if newznab_id == '17809':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17809&extended=1')
            if newznab_id == '3673':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3673&extended=1')
            if newznab_id == '28283':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28283&extended=1')
            if newznab_id == '32057':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32057&extended=1')
            if newznab_id == '24496':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24496&extended=1')
            if newznab_id == '26761':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26761&extended=1')
            if newznab_id == '31510':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31510&extended=1')
            if newznab_id == '28680':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28680&extended=1')
            if newznab_id == '29866':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29866&extended=1')
            if newznab_id == '29279':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29279&extended=1')
            if newznab_id == '28927':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28927&extended=1')
            if newznab_id == '18682':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18682&extended=1')
            if newznab_id == '5105':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5105&extended=1')
            if newznab_id == '29872':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29872&extended=1')
            if newznab_id == '5222':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5222&extended=1')
            if newznab_id == '5324':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5324&extended=1')
            if newznab_id == '5325':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5325&extended=1')
            if newznab_id == '5325':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5325&extended=1')
            if newznab_id == '15343':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15343&extended=1')
            if newznab_id == '25525':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25525&extended=1')
            if newznab_id == '26835':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26835&extended=1')
            if newznab_id == '30661':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30661&extended=1')
            if newznab_id == '17526':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17526&extended=1')
            if newznab_id == '31508':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31508&extended=1')
            if newznab_id == '7884':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7884&extended=1')
            if newznab_id == '2443':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2443&extended=1')
            if newznab_id == '2498':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2498&extended=1')
            if newznab_id == '2504':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2504&extended=1')
            if newznab_id == '2740':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2740&extended=1')
            if newznab_id == '2808':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2808&extended=1')
            if newznab_id == '32776':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32776&extended=1')
            if newznab_id == '1599':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1599&extended=1')
            if newznab_id == '2979':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2979&extended=1')
            if newznab_id == '3032':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3032&extended=1')
            if newznab_id == '10223':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10223&extended=1')
            if newznab_id == '3085':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3085&extended=1')
            if newznab_id == '1944':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1944&extended=1')
            if newznab_id == '3369':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3369&extended=1')
            if newznab_id == '3394':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3394&extended=1')
            if newznab_id == '29127':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29127&extended=1')
            if newznab_id == '3632':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3632&extended=1')
            if newznab_id == '3835':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3835&extended=1')
            if newznab_id == '3835':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3835&extended=1')
            if newznab_id == '3850':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3850&extended=1')
            if newznab_id == '3971':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3971&extended=1')
            if newznab_id == '4041':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4041&extended=1')
            if newznab_id == '4045':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4045&extended=1')
            if newznab_id == '7960':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7960&extended=1')
            if newznab_id == '19609':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19609&extended=1')
            if newznab_id == '4473':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4473&extended=1')
            if newznab_id == '31752':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31752&extended=1')
            if newznab_id == '4568':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4568&extended=1')
            if newznab_id == '4915':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4915&extended=1')
            if newznab_id == '4941':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4941&extended=1')
            if newznab_id == '4970':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4970&extended=1')
            if newznab_id == '5042':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5042&extended=1')
            if newznab_id == '5080':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5080&extended=1')
            if newznab_id == '1867':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1867&extended=1')
            if newznab_id == '5228':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5228&extended=1')
            if newznab_id == '1838':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1838&extended=1')
            if newznab_id == '1900':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1900&extended=1')
            if newznab_id == '5371':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5371&extended=1')
            if newznab_id == '5457':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5457&extended=1')
            if newznab_id == '5541':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5541&extended=1')
            if newznab_id == '5684':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5684&extended=1')
            if newznab_id == '31271':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31271&extended=1')
            if newznab_id == '6091':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6091&extended=1')
            if newznab_id == '6236':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6236&extended=1')
            if newznab_id == '6259':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6259&extended=1')
            if newznab_id == '6259':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6259&extended=1')
            if newznab_id == '6259':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6259&extended=1')
            if newznab_id == '6259':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6259&extended=1')
            if newznab_id == '6259':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6259&extended=1')
            if newznab_id == '6317':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6317&extended=1')
            if newznab_id == '6352':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6352&extended=1')
            if newznab_id == '9':
                url_out = (newznab_url_search + '&t=tvsearch&rid=9&extended=1')
            if newznab_id == '6552':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6552&extended=1')
            if newznab_id == '6668':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6668&extended=1')
            if newznab_id == '32698':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32698&extended=1')
            if newznab_id == '10418':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10418&extended=1')
            if newznab_id == '24588':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24588&extended=1')
            if newznab_id == '959':
                url_out = (newznab_url_search + '&t=tvsearch&rid=959&extended=1')
            if newznab_id == '22626':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22626&extended=1')
            if newznab_id == '29455':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29455&extended=1')
            if newznab_id == '30613':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30613&extended=1')
            if newznab_id == '29677':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29677&extended=1')
            if newznab_id == '15533':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15533&extended=1')
            if newznab_id == '20623':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20623&extended=1')
            if newznab_id == '29531':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29531&extended=1')
            if newznab_id == '3089':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3089&extended=1')
            if newznab_id == '31132':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31132&extended=1')
            if newznab_id == '31890':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31890&extended=1')
            if newznab_id == '8348':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8348&extended=1')
            if newznab_id == '24025':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24025&extended=1')
            if newznab_id == '28932':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28932&extended=1')
            if newznab_id == '1853':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1853&extended=1')
            if newznab_id == '32460':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32460&extended=1')
            if newznab_id == '32332':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32332&extended=1')
            if newznab_id == '11709':
                url_out = (newznab_url_search + '&t=tvsearch&rid=11709&extended=1')
            if newznab_id == '26643':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26643&extended=1')
            if newznab_id == '31760':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31760&extended=1')
            if newznab_id == '25606':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25606&extended=1')
            if newznab_id == '1582':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1582&extended=1')
            if newznab_id == '4896':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4896&extended=1')
            if newznab_id == '32287':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32287&extended=1')
            if newznab_id == '1732':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1732&extended=1')
            if newznab_id == '23032':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23032&extended=1')
            if newznab_id == '8237':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8237&extended=1')
            if newznab_id == '31584':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31584&extended=1')
            if newznab_id == '6177':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6177&extended=1')
            if newznab_id == '32231':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32231&extended=1')
            if newznab_id == '30649':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30649&extended=1')
            if newznab_id == '1963':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1963&extended=1')
            if newznab_id == '7990':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7990&extended=1')
            if newznab_id == '27889':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27889&extended=1')
            if newznab_id == '28169':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28169&extended=1')
            if newznab_id == '7822':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7822&extended=1')
            if newznab_id == '18813':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18813&extended=1')
            if newznab_id == '32759':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32759&extended=1')
            if newznab_id == '2589':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2589&extended=1')
            if newznab_id == '30715':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30715&extended=1')
            if newznab_id == '30717':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30717&extended=1')
            if newznab_id == '31072':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31072&extended=1')
            if newznab_id == '31711':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31711&extended=1')
            if newznab_id == '31711':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31711&extended=1')
            if newznab_id == '15812':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15812&extended=1')
            if newznab_id == '3683':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3683&extended=1')
            if newznab_id == '15619':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15619&extended=1')
            if newznab_id == '28425':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28425&extended=1')
            if newznab_id == '28422':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28422&extended=1')
            if newznab_id == '28422':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28422&extended=1')
            if newznab_id == '25658':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25658&extended=1')
            if newznab_id == '17061':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17061&extended=1')
            if newznab_id == '23114':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23114&extended=1')
            if newznab_id == '25189':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25189&extended=1')
            if newznab_id == '31953':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31953&extended=1')
            if newznab_id == '4724':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4724&extended=1')
            if newznab_id == '4952':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4952&extended=1')
            if newznab_id == '28426':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28426&extended=1')
            if newznab_id == '27457':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27457&extended=1')
            if newznab_id == '25789':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25789&extended=1')
            if newznab_id == '5227':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5227&extended=1')
            if newznab_id == '5410':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5410&extended=1')
            if newznab_id == '5602':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5602&extended=1')
            if newznab_id == '31073':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31073&extended=1')
            if newznab_id == '28423':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28423&extended=1')
            if newznab_id == '21766':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21766&extended=1')
            if newznab_id == '6507':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6507&extended=1')
            if newznab_id == '18987':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18987&extended=1')
            if newznab_id == '5549':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5549&extended=1')
            if newznab_id == '6707':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6707&extended=1')
            if newznab_id == '28768':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28768&extended=1')
            if newznab_id == '3630':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3630&extended=1')
            if newznab_id == '31748':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31748&extended=1')
            if newznab_id == '24531':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24531&extended=1')
            if newznab_id == '4964':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4964&extended=1')
            if newznab_id == '1358':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1358&extended=1')
            if newznab_id == '28854':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28854&extended=1')
            if newznab_id == '24056':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24056&extended=1')
            if newznab_id == '2840':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2840&extended=1')
            if newznab_id == '3039':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3039&extended=1')
            if newznab_id == '3255':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3255&extended=1')
            if newznab_id == '3464':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3464&extended=1')
            if newznab_id == '4447':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4447&extended=1')
            if newznab_id == '5883':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5883&extended=1')
            if newznab_id == '2720':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2720&extended=1')
            if newznab_id == '6056':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6056&extended=1')
            if newznab_id == '6096':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6096&extended=1')
            if newznab_id == '6666':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6666&extended=1')
            if newznab_id == '33038':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33038&extended=1')
            if newznab_id == '20203':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20203&extended=1')
            if newznab_id == '16955':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16955&extended=1')
            if newznab_id == '32494':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32494&extended=1')
            if newznab_id == '24698':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24698&extended=1')
            if newznab_id == '29366':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29366&extended=1')
            if newznab_id == '10119':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10119&extended=1')
            if newznab_id == '32033':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32033&extended=1')
            if newznab_id == '32011':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32011&extended=1')
            if newznab_id == '32524':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32524&extended=1')
            if newznab_id == '25935':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25935&extended=1')
            if newznab_id == '22395':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22395&extended=1')
            if newznab_id == '26125':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26125&extended=1')
            if newznab_id == '26125':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26125&extended=1')
            if newznab_id == '32596':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32596&extended=1')
            if newznab_id == '31261':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31261&extended=1')
            if newznab_id == '30138':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30138&extended=1')
            if newznab_id == '25689':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25689&extended=1')
            if newznab_id == '30973':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30973&extended=1')
            if newznab_id == '27734':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27734&extended=1')
            if newznab_id == '25686':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25686&extended=1')
            if newznab_id == '26423':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26423&extended=1')
            if newznab_id == '30205':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30205&extended=1')
            if newznab_id == '32058':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32058&extended=1')
            if newznab_id == '25290':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25290&extended=1')
            if newznab_id == '30429':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30429&extended=1')
            if newznab_id == '21669':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21669&extended=1')
            if newznab_id == '32490':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32490&extended=1')
            if newznab_id == '28671':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28671&extended=1')
            if newznab_id == '25981':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25981&extended=1')
            if newznab_id == '27481':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27481&extended=1')
            if newznab_id == '16930':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16930&extended=1')
            if newznab_id == '33142':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33142&extended=1')
            if newznab_id == '8442':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8442&extended=1')
            if newznab_id == '33041':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33041&extended=1')
            if newznab_id == '29291':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29291&extended=1')
            if newznab_id == '23755':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23755&extended=1')
            if newznab_id == '24168':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24168&extended=1')
            if newznab_id == '7177':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7177&extended=1')
            if newznab_id == '30813':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30813&extended=1')
            if newznab_id == '31545':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31545&extended=1')
            if newznab_id == '30849':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30849&extended=1')
            if newznab_id == '27145':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27145&extended=1')
            if newznab_id == '28521':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28521&extended=1')
            if newznab_id == '31692':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31692&extended=1')
            if newznab_id == '27740':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27740&extended=1')
            if newznab_id == '26986':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26986&extended=1')
            if newznab_id == '29365':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29365&extended=1')
            if newznab_id == '29365':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29365&extended=1')
            if newznab_id == '26419':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26419&extended=1')
            if newznab_id == '26382':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26382&extended=1')
            if newznab_id == '25691':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25691&extended=1')
            if newznab_id == '27970':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27970&extended=1')
            if newznab_id == '28678':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28678&extended=1')
            if newznab_id == '17627':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17627&extended=1')
            if newznab_id == '32639':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32639&extended=1')
            if newznab_id == '33629':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33629&extended=1')
            if newznab_id == '26381':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26381&extended=1')
            if newznab_id == '20956':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20956&extended=1')
            if newznab_id == '28259':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28259&extended=1')
            if newznab_id == '26139':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26139&extended=1')
            if newznab_id == '28288':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28288&extended=1')
            if newznab_id == '31693':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31693&extended=1')
            if newznab_id == '22683':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22683&extended=1')
            if newznab_id == '20667':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20667&extended=1')
            if newznab_id == '23339':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23339&extended=1')
            if newznab_id == '27814':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27814&extended=1')
            if newznab_id == '32439':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32439&extended=1')
            if newznab_id == '27882':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27882&extended=1')
            if newznab_id == '27882':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27882&extended=1')
            if newznab_id == '27882':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27882&extended=1')
            if newznab_id == '28960':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28960&extended=1')
            if newznab_id == '21649':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21649&extended=1')
            if newznab_id == '26205':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26205&extended=1')
            if newznab_id == '25844':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25844&extended=1')
            if newznab_id == '21648':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21648&extended=1')
            if newznab_id == '15312':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15312&extended=1')
            if newznab_id == '18411':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18411&extended=1')
            if newznab_id == '28497':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28497&extended=1')
            if newznab_id == '19699':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19699&extended=1')
            if newznab_id == '19206':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19206&extended=1')
            if newznab_id == '29470':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29470&extended=1')
            if newznab_id == '24996':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24996&extended=1')
            if newznab_id == '10100':
                url_out = (newznab_url_search + '&t=tvsearch&rid=10100&extended=1')
            if newznab_id == '21197':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21197&extended=1')
            if newznab_id == '5685':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5685&extended=1')
            if newznab_id == '30612':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30612&extended=1')
            if newznab_id == '32253':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32253&extended=1')
            if newznab_id == '20130':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20130&extended=1')
            if newznab_id == '30365':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30365&extended=1')
            if newznab_id == '31502':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31502&extended=1')
            if newznab_id == '30522':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30522&extended=1')
            if newznab_id == '14983':
                url_out = (newznab_url_search + '&t=tvsearch&rid=14983&extended=1')
            if newznab_id == '30363':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30363&extended=1')
            if newznab_id == '23063':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23063&extended=1')
            if newznab_id == '15226':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15226&extended=1')
            if newznab_id == '32587':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32587&extended=1')
            if newznab_id == '27216':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27216&extended=1')
            if newznab_id == '33361':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33361&extended=1')
            if newznab_id == '30741':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30741&extended=1')
            if newznab_id == '31497':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31497&extended=1')
            if newznab_id == '21959':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21959&extended=1')
            if newznab_id == '25237':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25237&extended=1')
            if newznab_id == '20338':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20338&extended=1')
            if newznab_id == '29864':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29864&extended=1')
            if newznab_id == '30364':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30364&extended=1')
            if newznab_id == '31498':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31498&extended=1')
            if newznab_id == '29356':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29356&extended=1')
            if newznab_id == '29722':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29722&extended=1')
            if newznab_id == '28475':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28475&extended=1')
            if newznab_id == '20717':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20717&extended=1')
            if newznab_id == '27066':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27066&extended=1')
            if newznab_id == '28284':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28284&extended=1')
            if newznab_id == '28582':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28582&extended=1')
            if newznab_id == '32416':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32416&extended=1')
            if newznab_id == '25275':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25275&extended=1')
            if newznab_id == '28552':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28552&extended=1')
            if newznab_id == '28795':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28795&extended=1')
            if newznab_id == '29290':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29290&extended=1')
            if newznab_id == '29451':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29451&extended=1')
            if newznab_id == '30900':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30900&extended=1')
            if newznab_id == '28681':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28681&extended=1')
            if newznab_id == '26958':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26958&extended=1')
            if newznab_id == '3594':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3594&extended=1')
            if newznab_id == '24016':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24016&extended=1')
            if newznab_id == '24216':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24216&extended=1')
            if newznab_id == '29116':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29116&extended=1')
            if newznab_id == '27817':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27817&extended=1')
            if newznab_id == '18864':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18864&extended=1')
            if newznab_id == '30950':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30950&extended=1')
            if newznab_id == '31847':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31847&extended=1')
            if newznab_id == '32255':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32255&extended=1')
            if newznab_id == '22864':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22864&extended=1')
            if newznab_id == '783':
                url_out = (newznab_url_search + '&t=tvsearch&rid=783&extended=1')
            if newznab_id == '22866':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22866&extended=1')
            if newznab_id == '24709':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24709&extended=1')
            if newznab_id == '24709':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24709&extended=1')
            if newznab_id == '29118':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29118&extended=1')
            if newznab_id == '29708':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29708&extended=1')
            if newznab_id == '24964':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24964&extended=1')
            if newznab_id == '27240':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27240&extended=1')
            if newznab_id == '27240':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27240&extended=1')
            if newznab_id == '31521':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31521&extended=1')
            if newznab_id == '20581':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20581&extended=1')
            if newznab_id == '27944':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27944&extended=1')
            if newznab_id == '32441':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32441&extended=1')
            if newznab_id == '28934':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28934&extended=1')
            if newznab_id == '25464':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25464&extended=1')
            if newznab_id == '28625':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28625&extended=1')
            if newznab_id == '24227':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24227&extended=1')
            if newznab_id == '28974':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28974&extended=1')
            if newznab_id == '28974':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28974&extended=1')
            if newznab_id == '29778':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29778&extended=1')
            if newznab_id == '12663':
                url_out = (newznab_url_search + '&t=tvsearch&rid=12663&extended=1')
            if newznab_id == '27558':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27558&extended=1')
            if newznab_id == '24846':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24846&extended=1')
            if newznab_id == '24847':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24847&extended=1')
            if newznab_id == '27984':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27984&extended=1')
            if newznab_id == '31547':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31547&extended=1')
            if newznab_id == '25880':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25880&extended=1')
            if newznab_id == '24284':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24284&extended=1')
            if newznab_id == '25255':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25255&extended=1')
            if newznab_id == '25255':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25255&extended=1')
            if newznab_id == '24952':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24952&extended=1')
            if newznab_id == '32364':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32364&extended=1')
            if newznab_id == '20662':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20662&extended=1')
            if newznab_id == '29573':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29573&extended=1')
            if newznab_id == '17496':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17496&extended=1')
            if newznab_id == '3479':
                url_out = (newznab_url_search + '&t=tvsearch&rid=3479&extended=1')
            if newznab_id == '24288':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24288&extended=1')
            if newznab_id == '15475':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15475&extended=1')
            if newznab_id == '14748':
                url_out = (newznab_url_search + '&t=tvsearch&rid=14748&extended=1')
            if newznab_id == '4747':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4747&extended=1')
            if newznab_id == '1031':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1031&extended=1')
            if newznab_id == '18549':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18549&extended=1')
            if newznab_id == '28060':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28060&extended=1')
            if newznab_id == '33674':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33674&extended=1')
            if newznab_id == '32564':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32564&extended=1')
            if newznab_id == '26114':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26114&extended=1')
            if newznab_id == '26114':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26114&extended=1')
            if newznab_id == '32659':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32659&extended=1')
            if newznab_id == '32390':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32390&extended=1')
            if newznab_id == '32096':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32096&extended=1')
            if newznab_id == '28174':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28174&extended=1')
            if newznab_id == '33674':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33674&extended=1')
            if newznab_id == '29228':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29228&extended=1')
            if newznab_id == '26283':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26283&extended=1')
            if newznab_id == '32986':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32986&extended=1')
            if newznab_id == '21940':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21940&extended=1')
            if newznab_id == '5187':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5187&extended=1')
            if newznab_id == '26736':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26736&extended=1')
            if newznab_id == '27594':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27594&extended=1')
            if newznab_id == '31530':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31530&extended=1')
            if newznab_id == '33810':
                url_out = (newznab_url_search + '&t=tvsearch&rid=33810&extended=1')
            if newznab_id == '31635':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31635&extended=1')
            if newznab_id == '32193':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32193&extended=1')
            if newznab_id == '31897':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31897&extended=1')
            if newznab_id == '25771':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25771&extended=1')
            if newznab_id == '22675':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22675&extended=1')
            if newznab_id == '26475':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26475&extended=1')
            if newznab_id == '27684':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27684&extended=1')
            if newznab_id == '23904':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23904&extended=1')
            if newznab_id == '32679':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32679&extended=1')
            if newznab_id == '27577':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27577&extended=1')
            if newznab_id == '32222':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32222&extended=1')
            if newznab_id == '31653':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31653&extended=1')
            if newznab_id == '29253':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29253&extended=1')
            if newznab_id == '26894':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26894&extended=1')
            if newznab_id == '30799':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30799&extended=1')
            if newznab_id == '17512':
                url_out = (newznab_url_search + '&t=tvsearch&rid=17512&extended=1')
            if newznab_id == '31023':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31023&extended=1')
            if newznab_id == '27486':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27486&extended=1')
            if newznab_id == '27485':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27485&extended=1')
            if newznab_id == '32673':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32673&extended=1')
            if newznab_id == '30317':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30317&extended=1')
            if newznab_id == '31529':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31529&extended=1')
            if newznab_id == '28209':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28209&extended=1')
            if newznab_id == '32266':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32266&extended=1')
            if newznab_id == '5752':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5752&extended=1')
            if newznab_id == '7191':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7191&extended=1')
            if newznab_id == '2930':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2930&extended=1')
            if newznab_id == '5056':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5056&extended=1')
            if newznab_id == '5335':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5335&extended=1')
            if newznab_id == '5338':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5338&extended=1')
            if newznab_id == '6635':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6635&extended=1')
            if newznab_id == '2525':
                url_out = (newznab_url_search + '&t=tvsearch&rid=2525&extended=1')
            if newznab_id == '15383':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15383&extended=1')
            if newznab_id == '28991':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28991&extended=1')
            if newznab_id == '23686':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23686&extended=1')
            if newznab_id == '24658':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24658&extended=1')
            if newznab_id == '18751':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18751&extended=1')
            if newznab_id == '4203':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4203&extended=1')
            if newznab_id == '4514':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4514&extended=1')
            if newznab_id == '27517':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27517&extended=1')
            if newznab_id == '30818':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30818&extended=1')
            if newznab_id == '8322':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8322&extended=1')
            if newznab_id == '4975':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4975&extended=1')
            if newznab_id == '22336':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22336&extended=1')
            if newznab_id == '27518':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27518&extended=1')
            if newznab_id == '5514':
                url_out = (newznab_url_search + '&t=tvsearch&rid=5514&extended=1')
            if newznab_id == '6012':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6012&extended=1')
            if newznab_id == '6119':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6119&extended=1')
            if newznab_id == '16825':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16825&extended=1')
            if newznab_id == '20720':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20720&extended=1')
            if newznab_id == '31428':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31428&extended=1')
            if newznab_id == '31993':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31993&extended=1')
            if newznab_id == '30696':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30696&extended=1')
            if newznab_id == '4755':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4755&extended=1')
            if newznab_id == '19784':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19784&extended=1')
            if newznab_id == '23213':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23213&extended=1')
            if newznab_id == '29989':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29989&extended=1')
            if newznab_id == '27606':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27606&extended=1')
            if newznab_id == '31456':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31456&extended=1')
            if newznab_id == '32837':
                url_out = (newznab_url_search + '&t=tvsearch&rid=32837&extended=1')
            if newznab_id == '28190':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28190&extended=1')
            if newznab_id == '1033':
                url_out = (newznab_url_search + '&t=tvsearch&rid=1033&extended=1')
            if newznab_id == '31697':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31697&extended=1')
            if newznab_id == '29240':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29240&extended=1')
            if newznab_id == '26041':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26041&extended=1')
            if newznab_id == '31826':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31826&extended=1')
            if newznab_id == '27607':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27607&extended=1')
            if newznab_id == '27607':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27607&extended=1')
            if newznab_id == '30233':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30233&extended=1')
            if newznab_id == '31595':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31595&extended=1')
            if newznab_id == '27926':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27926&extended=1')
            if newznab_id == '27943':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27943&extended=1')
            if newznab_id == '16619':
                url_out = (newznab_url_search + '&t=tvsearch&rid=16619&extended=1')
            if newznab_id == '28141':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28141&extended=1')
            if newznab_id == '30907':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30907&extended=1')
            if newznab_id == '31173':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31173&extended=1')
            if newznab_id == '30162':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30162&extended=1')
            if newznab_id == '19436':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19436&extended=1')
            if newznab_id == '22849':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22849&extended=1')
            if newznab_id == '27198':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27198&extended=1')
            if newznab_id == '28688':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28688&extended=1')
            if newznab_id == '21908':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21908&extended=1')
            if newznab_id == '25601':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25601&extended=1')
            if newznab_id == '23681':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23681&extended=1')
            if newznab_id == '29819':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29819&extended=1')
            if newznab_id == '25598':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25598&extended=1')
            if newznab_id == '29435':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29435&extended=1')
            if newznab_id == '21537':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21537&extended=1')
            if newznab_id == '25990':
                url_out = (newznab_url_search + '&t=tvsearch&rid=25990&extended=1')
            if newznab_id == '31722':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31722&extended=1')
            if newznab_id == '19743':
                url_out = (newznab_url_search + '&t=tvsearch&rid=19743&extended=1')
            if newznab_id == '31273':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31273&extended=1')
            if newznab_id == '30861':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30861&extended=1')
            if newznab_id == '24222':
                url_out = (newznab_url_search + '&t=tvsearch&rid=24222&extended=1')
            if newznab_id == '27870':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27870&extended=1')
            if newznab_id == '29074':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29074&extended=1')
            if newznab_id == '15138':
                url_out = (newznab_url_search + '&t=tvsearch&rid=15138&extended=1')
            if newznab_id == '20007':
                url_out = (newznab_url_search + '&t=tvsearch&rid=20007&extended=1')
            if newznab_id == '28607':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28607&extended=1')
            if newznab_id == '27586':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27586&extended=1')
            if newznab_id == '27586':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27586&extended=1')
            if newznab_id == '8293':
                url_out = (newznab_url_search + '&t=tvsearch&rid=8293&extended=1')
            if newznab_id == '26380':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26380&extended=1')
            if newznab_id == '21107':
                url_out = (newznab_url_search + '&t=tvsearch&rid=21107&extended=1')
            if newznab_id == '22697':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22697&extended=1')
            if newznab_id == '7059':
                url_out = (newznab_url_search + '&t=tvsearch&rid=7059&extended=1')
            if newznab_id == '27922':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27922&extended=1')
            if newznab_id == '30469':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30469&extended=1')
            if newznab_id == '29430':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29430&extended=1')
            if newznab_id == '18524':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18524&extended=1')
            if newznab_id == '30154':
                url_out = (newznab_url_search + '&t=tvsearch&rid=30154&extended=1')
            if newznab_id == '27563':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27563&extended=1')
            if newznab_id == '23555':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23555&extended=1')
            if newznab_id == '602':
                url_out = (newznab_url_search + '&t=tvsearch&rid=602&extended=1')
            if newznab_id == '22520':
                url_out = (newznab_url_search + '&t=tvsearch&rid=22520&extended=1')
            if newznab_id == '26620':
                url_out = (newznab_url_search + '&t=tvsearch&rid=26620&extended=1')
            if newznab_id == '31493':
                url_out = (newznab_url_search + '&t=tvsearch&rid=31493&extended=1')
            if newznab_id == '27025':
                url_out = (newznab_url_search + '&t=tvsearch&rid=27025&extended=1')
            if newznab_id == '23085':
                url_out = (newznab_url_search + '&t=tvsearch&rid=23085&extended=1')
            if newznab_id == '29758':
                url_out = (newznab_url_search + '&t=tvsearch&rid=29758&extended=1')
            if newznab_id == '4954':
                url_out = (newznab_url_search + '&t=tvsearch&rid=4954&extended=1')
            if newznab_id == '28651':
                url_out = (newznab_url_search + '&t=tvsearch&rid=28651&extended=1')
            if newznab_id == '6325':
                url_out = (newznab_url_search + '&t=tvsearch&rid=6325&extended=1')
            if newznab_id == '18372':
                url_out = (newznab_url_search + '&t=tvsearch&rid=18372&extended=1')
            if newznab_id == "mycart":
                url_out = newznab_url + "&t=-2"
            if newznab_id == "myshows":
                url_out = newznab_url + "&t=-3"
            if newznab_id == "mymovies":
                url_out = newznab_url + "&t=-4"
            if newznab_id == "search":
                search_term = search(__settings__.getSetting("newznab_name_%s" % index), index)
                if search_term:
                    url_out = (newznab_url_search + "&t=search" + "&cat=" + catid + "&q=" 
                    + search_term + "&extended=1")
            if newznab_id == "search_rageid":
                rageid = get('rageid')
                url_out = (newznab_url_search + "&t=tvsearch" + "&rid=" + rageid + "&extended=1")
                if catid:
                    url_out = url_out + "&cat=" + catid
            if newznab_id == "search_imdb":
                imdb = get('imdb')
                url_out = (newznab_url_search + "&t=movie" + "&imdbid=" + imdb + "&extended=1")
        elif catid:
            url_out = newznab_url + "&t=" + catid
            key = "&catid=" + catid
            add_posts({'title' : 'Search...',}, index, url=key, mode=MODE_NEWZNAB_SEARCH)
        if url_out:
            offset = list_feed_newznab(url_out, index)
            if offset is not None and not '/rss?' in url_out:
                if offset >= 100:
                    offset_url = re.search('&offset=(\d{1,3})', url_out, re.IGNORECASE|re.DOTALL)
                    if offset_url:
                        offset_new = int(offset_url.group(1)) + 100
                        next_url = re.sub(r'(&offset=)\d{1,3}', r'\g<1>%s' % str(offset_new), url_out)
                    else:
                        next_url = '%s&offset=100' % url_out # next_url
                    print next_url
                    next_url = "&url=%s" % urllib.quote_plus(next_url)
                    add_posts({'title' : "Next..",}, index, url=next_url, mode=MODE_NEWZNAB)
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=True)
    else:
	add_posts({'title' : 'Latest Releases',}, index, mode='newznab&newznab=Latest Releases')
        add_posts({'title' : 'A and E',}, index, mode='newznab&newznab=A and E')
        add_posts({'title' : 'ABC',}, index, mode='newznab&newznab=ABC')
        add_posts({'title' : 'ABC Family',}, index, mode='newznab&newznab=ABC Family')
        add_posts({'title' : 'ABC1',}, index, mode='newznab&newznab=ABC1')
        add_posts({'title' : 'ABC2',}, index, mode='newznab&newznab=ABC2')
        add_posts({'title' : 'ABC3',}, index, mode='newznab&newznab=ABC3')
        add_posts({'title' : 'AcAcn',}, index, mode='newznab&newznab=AcAcn')
        add_posts({'title' : 'Action',}, index, mode='newznab&newznab=Action')
        add_posts({'title' : 'Adult Swim',}, index, mode='newznab&newznab=Adult Swim')
        add_posts({'title' : 'AMC',}, index, mode='newznab&newznab=AMC')
        add_posts({'title' : 'Animal Planet',}, index, mode='newznab&newznab=Animal Planet')
        add_posts({'title' : 'Animax',}, index, mode='newznab&newznab=Animax')
        add_posts({'title' : 'Antena 1',}, index, mode='newznab&newznab=Antena 1')
        add_posts({'title' : 'Antena 3',}, index, mode='newznab&newznab=Antena 3')
        add_posts({'title' : 'ARD',}, index, mode='newznab&newznab=ARD')
        add_posts({'title' : 'Arena',}, index, mode='newznab&newznab=Arena')
        add_posts({'title' : 'AT X',}, index, mode='newznab&newznab=AT X')
        add_posts({'title' : 'AXS TV',}, index, mode='newznab&newznab=AXS TV')
        add_posts({'title' : 'BBC',}, index, mode='newznab&newznab=BBC')
        add_posts({'title' : 'BBC America',}, index, mode='newznab&newznab=BBC America')
        add_posts({'title' : 'BBC FOUR',}, index, mode='newznab&newznab=BBC FOUR')
        add_posts({'title' : 'BBC One',}, index, mode='newznab&newznab=BBC One')
        add_posts({'title' : 'BBC One Scotland',}, index, mode='newznab&newznab=BBC One Scotland')
        add_posts({'title' : 'BBC THREE',}, index, mode='newznab&newznab=BBC THREE')
        add_posts({'title' : 'BBC TWO',}, index, mode='newznab&newznab=BBC TWO')
        add_posts({'title' : 'BBC TWO Scotland',}, index, mode='newznab&newznab=BBC TWO Scotland')
        add_posts({'title' : 'BBC Wales',}, index, mode='newznab&newznab=BBC Wales')
        add_posts({'title' : 'BET',}, index, mode='newznab&newznab=BET')
        add_posts({'title' : 'Biography Channel',}, index, mode='newznab&newznab=Biography Channel')
        add_posts({'title' : 'BNN',}, index, mode='newznab&newznab=BNN')
        add_posts({'title' : 'Bounce',}, index, mode='newznab&newznab=Bounce')
        add_posts({'title' : 'Bravo',}, index, mode='newznab&newznab=Bravo')
        add_posts({'title' : 'C4',}, index, mode='newznab&newznab=C4')
        add_posts({'title' : 'Canal',}, index, mode='newznab&newznab=Canal')
        add_posts({'title' : 'Cartoon Network',}, index, mode='newznab&newznab=Cartoon Network')
        add_posts({'title' : 'CBBC',}, index, mode='newznab&newznab=CBBC')
        add_posts({'title' : 'CBC',}, index, mode='newznab&newznab=CBC')
        add_posts({'title' : 'Cbeebies',}, index, mode='newznab&newznab=Cbeebies')
        add_posts({'title' : 'CBS',}, index, mode='newznab&newznab=CBS')
        add_posts({'title' : 'Centric',}, index, mode='newznab&newznab=Centric')
        add_posts({'title' : 'Channel 10',}, index, mode='newznab&newznab=Channel 10')
        add_posts({'title' : 'Channel 4',}, index, mode='newznab&newznab=Channel 4')
        add_posts({'title' : 'Channel 5',}, index, mode='newznab&newznab=Channel 5')
        add_posts({'title' : 'Channel 7',}, index, mode='newznab&newznab=Channel 7')
        add_posts({'title' : 'Chiba TV',}, index, mode='newznab&newznab=Chiba TV')
        add_posts({'title' : 'CineMax',}, index, mode='newznab&newznab=CineMax')
        add_posts({'title' : 'CITV',}, index, mode='newznab&newznab=CITV')
        add_posts({'title' : 'CityTV',}, index, mode='newznab&newznab=CityTV')
        add_posts({'title' : 'Cloo',}, index, mode='newznab&newznab=Cloo')
        add_posts({'title' : 'CMT',}, index, mode='newznab&newznab=CMT')
        add_posts({'title' : 'CNBC',}, index, mode='newznab&newznab=CNBC')
        add_posts({'title' : 'Comedy Central',}, index, mode='newznab&newznab=Comedy Central')
        add_posts({'title' : 'Comedy Central UK',}, index, mode='newznab&newznab=Comedy Central UK')
        add_posts({'title' : 'Cooking Channel',}, index, mode='newznab&newznab=Cooking Channel')
        add_posts({'title' : 'Court TV',}, index, mode='newznab&newznab=Court TV')
        add_posts({'title' : 'Crackle',}, index, mode='newznab&newznab=Crackle')
        add_posts({'title' : 'Crime and Investigation Network',}, index, mode='newznab&newznab=Crime and Investigation Network')
        add_posts({'title' : 'CTV',}, index, mode='newznab&newznab=CTV')
        add_posts({'title' : 'Current TV',}, index, mode='newznab&newznab=Current TV')
        add_posts({'title' : 'Dave',}, index, mode='newznab&newznab=Dave')
        add_posts({'title' : 'Destination America',}, index, mode='newznab&newznab=Destination America')
        add_posts({'title' : 'DIRECTV',}, index, mode='newznab&newznab=DIRECTV')
        add_posts({'title' : 'Discovery Channel',}, index, mode='newznab&newznab=Discovery Channel')
        add_posts({'title' : 'Discovery Fit and Health',}, index, mode='newznab&newznab=Discovery Fit and Health')
        add_posts({'title' : 'Discovery HD Theater',}, index, mode='newznab&newznab=Discovery HD Theater')
        add_posts({'title' : 'Discovery Health Channel',}, index, mode='newznab&newznab=Discovery Health Channel')
        add_posts({'title' : 'Discovery Kids Channel',}, index, mode='newznab&newznab=Discovery Kids Channel')
        add_posts({'title' : 'Discovery Velocity',}, index, mode='newznab&newznab=Discovery Velocity')
        add_posts({'title' : 'Disney Channel',}, index, mode='newznab&newznab=Disney Channel')
        add_posts({'title' : 'Disney Junior',}, index, mode='newznab&newznab=Disney Junior')
        add_posts({'title' : 'Disney XD',}, index, mode='newznab&newznab=Disney XD')
        add_posts({'title' : 'DIY Network',}, index, mode='newznab&newznab=DIY Network')
        add_posts({'title' : 'DR1',}, index, mode='newznab&newznab=DR1')
        add_posts({'title' : 'E',}, index, mode='newznab&newznab=E')
        add_posts({'title' : 'E4',}, index, mode='newznab&newznab=E4')
        add_posts({'title' : 'Eleven',}, index, mode='newznab&newznab=Eleven')
        add_posts({'title' : 'ESPN',}, index, mode='newznab&newznab=ESPN')
        add_posts({'title' : 'Facebook and Cambio com',}, index, mode='newznab&newznab=Facebook and Cambio com')
        add_posts({'title' : 'Family Channel',}, index, mode='newznab&newznab=Family Channel')
        add_posts({'title' : 'FEARnet',}, index, mode='newznab&newznab=FEARnet')
        add_posts({'title' : 'five',}, index, mode='newznab&newznab=five')
        add_posts({'title' : 'Fiver',}, index, mode='newznab&newznab=Fiver')
        add_posts({'title' : 'FMC',}, index, mode='newznab&newznab=FMC')
        add_posts({'title' : 'Food Network',}, index, mode='newznab&newznab=Food Network')
        add_posts({'title' : 'Food Network Canada',}, index, mode='newznab&newznab=Food Network Canada')
        add_posts({'title' : 'FOX',}, index, mode='newznab&newznab=FOX')
        add_posts({'title' : 'FOX Soccer Channel',}, index, mode='newznab&newznab=FOX Soccer Channel')
        add_posts({'title' : 'Fox Sports',}, index, mode='newznab&newznab=Fox Sports')
        add_posts({'title' : 'FOX8',}, index, mode='newznab&newznab=FOX8')
        add_posts({'title' : 'France 3',}, index, mode='newznab&newznab=France 3')
        add_posts({'title' : 'Fuji TV',}, index, mode='newznab&newznab=Fuji TV')
        add_posts({'title' : 'Fuse',}, index, mode='newznab&newznab=Fuse')
        add_posts({'title' : 'FX',}, index, mode='newznab&newznab=FX')
        add_posts({'title' : 'G4',}, index, mode='newznab&newznab=G4')
        add_posts({'title' : 'GEM',}, index, mode='newznab&newznab=GEM')
        add_posts({'title' : 'Global',}, index, mode='newznab&newznab=Global')
        add_posts({'title' : 'GO',}, index, mode='newznab&newznab=GO')
        add_posts({'title' : 'GSN',}, index, mode='newznab&newznab=GSN')
        add_posts({'title' : 'H2 TV',}, index, mode='newznab&newznab=H2 TV')
        add_posts({'title' : 'HBO',}, index, mode='newznab&newznab=HBO')
        add_posts({'title' : 'HBO Canada',}, index, mode='newznab&newznab=HBO Canada')
        add_posts({'title' : 'HGTV',}, index, mode='newznab&newznab=HGTV')
        add_posts({'title' : 'History Channel',}, index, mode='newznab&newznab=History Channel')
        add_posts({'title' : 'History Television',}, index, mode='newznab&newznab=History Television')
        add_posts({'title' : 'HUB',}, index, mode='newznab&newznab=HUB')
        add_posts({'title' : 'Hulu iTunes',}, index, mode='newznab&newznab=Hulu iTunes')
        add_posts({'title' : 'ID Investigation Discovery',}, index, mode='newznab&newznab=ID Investigation Discovery')
        add_posts({'title' : 'IFC',}, index, mode='newznab&newznab=IFC')
        add_posts({'title' : 'Investigation Discovery',}, index, mode='newznab&newznab=Investigation Discovery')
        add_posts({'title' : 'ITV',}, index, mode='newznab&newznab=ITV')
        add_posts({'title' : 'ITV1',}, index, mode='newznab&newznab=ITV1')
        add_posts({'title' : 'ITV2',}, index, mode='newznab&newznab=ITV2')
        add_posts({'title' : 'ITV4',}, index, mode='newznab&newznab=ITV4')
        add_posts({'title' : 'Kanal 5',}, index, mode='newznab&newznab=Kanal 5')
        add_posts({'title' : 'Kanal D',}, index, mode='newznab&newznab=Kanal D')
        add_posts({'title' : 'Lifestyle Channel',}, index, mode='newznab&newznab=Lifestyle Channel')
        add_posts({'title' : 'Lifetime',}, index, mode='newznab&newznab=Lifetime')
        add_posts({'title' : 'Logo',}, index, mode='newznab&newznab=Logo')
        add_posts({'title' : 'M Net',}, index, mode='newznab&newznab=M Net')
        add_posts({'title' : 'Machinima',}, index, mode='newznab&newznab=Machinima')
        add_posts({'title' : 'Machinima com',}, index, mode='newznab&newznab=Machinima com')
        add_posts({'title' : 'MBC',}, index, mode='newznab&newznab=MBC')
        add_posts({'title' : 'MBS',}, index, mode='newznab&newznab=MBS')
        add_posts({'title' : 'Military Channel',}, index, mode='newznab&newznab=Military Channel')
        add_posts({'title' : 'MOJO',}, index, mode='newznab&newznab=MOJO')
        add_posts({'title' : 'Movie Central',}, index, mode='newznab&newznab=Movie Central')
        add_posts({'title' : 'Movie Extra',}, index, mode='newznab&newznab=Movie Extra')
        add_posts({'title' : 'MSNBC',}, index, mode='newznab&newznab=MSNBC')
        add_posts({'title' : 'MTV',}, index, mode='newznab&newznab=MTV')
        add_posts({'title' : 'MTV One',}, index, mode='newznab&newznab=MTV One')
        add_posts({'title' : 'MTV UK',}, index, mode='newznab&newznab=MTV UK')
        add_posts({'title' : 'MTV2',}, index, mode='newznab&newznab=MTV2')
        add_posts({'title' : 'MuchMusic',}, index, mode='newznab&newznab=MuchMusic')
        add_posts({'title' : 'National Geographic Channel',}, index, mode='newznab&newznab=National Geographic Channel')
        add_posts({'title' : 'National Geographic Channel Canada',}, index, mode='newznab&newznab=National Geographic Channel Canada')
        add_posts({'title' : 'National Geographic Wild',}, index, mode='newznab&newznab=National Geographic Wild')
        add_posts({'title' : 'NBC',}, index, mode='newznab&newznab=NBC')
        add_posts({'title' : 'NBC CBS',}, index, mode='newznab&newznab=NBC CBS')
        add_posts({'title' : 'Net 5',}, index, mode='newznab&newznab=Net 5')
        add_posts({'title' : 'Netflix',}, index, mode='newznab&newznab=Netflix')
        add_posts({'title' : 'Network Ten',}, index, mode='newznab&newznab=Network Ten')
        add_posts({'title' : 'NFL Network',}, index, mode='newznab&newznab=NFL Network')
        add_posts({'title' : 'Nick at Nite',}, index, mode='newznab&newznab=Nick at Nite')
        add_posts({'title' : 'Nick Jr',}, index, mode='newznab&newznab=Nick Jr')
        add_posts({'title' : 'Nickelodeon',}, index, mode='newznab&newznab=Nickelodeon')
        add_posts({'title' : 'NickToons',}, index, mode='newznab&newznab=NickToons')
        add_posts({'title' : 'Nine',}, index, mode='newznab&newznab=Nine')
        add_posts({'title' : 'NRK1',}, index, mode='newznab&newznab=NRK1')
        add_posts({'title' : 'NTV',}, index, mode='newznab&newznab=NTV')
        add_posts({'title' : 'nuvoTV',}, index, mode='newznab&newznab=nuvoTV')
        add_posts({'title' : 'OLN',}, index, mode='newznab&newznab=OLN')
        add_posts({'title' : 'OWN',}, index, mode='newznab&newznab=OWN')
        add_posts({'title' : 'Oxygen',}, index, mode='newznab&newznab=Oxygen')
        add_posts({'title' : 'PAX',}, index, mode='newznab&newznab=PAX')
        add_posts({'title' : 'PBS',}, index, mode='newznab&newznab=PBS')
        add_posts({'title' : 'PBS Kids',}, index, mode='newznab&newznab=PBS Kids')
        add_posts({'title' : 'Planet Green',}, index, mode='newznab&newznab=Planet Green')
        add_posts({'title' : 'Playboy TV',}, index, mode='newznab&newznab=Playboy TV')
        add_posts({'title' : 'Prime',}, index, mode='newznab&newznab=Prime')
        add_posts({'title' : 'ProTV',}, index, mode='newznab&newznab=ProTV')
        add_posts({'title' : 'Quest',}, index, mode='newznab&newznab=Quest')
        add_posts({'title' : 'Real Time',}, index, mode='newznab&newznab=Real Time')
        add_posts({'title' : 'Rede Globo',}, index, mode='newznab&newznab=Rede Globo')
        add_posts({'title' : 'ReelzChannel',}, index, mode='newznab&newznab=ReelzChannel')
        add_posts({'title' : 'RTE 1',}, index, mode='newznab&newznab=RTE 1')
        add_posts({'title' : 'RTL 4',}, index, mode='newznab&newznab=RTL 4')
        add_posts({'title' : 'RTL 5',}, index, mode='newznab&newznab=RTL 5')
        add_posts({'title' : 'RTL 7',}, index, mode='newznab&newznab=RTL 7')
        add_posts({'title' : 'RTL Klub',}, index, mode='newznab&newznab=RTL Klub')
        add_posts({'title' : 'SBS',}, index, mode='newznab&newznab=SBS')
        add_posts({'title' : 'SBS 6',}, index, mode='newznab&newznab=SBS 6')
        add_posts({'title' : 'Science Channel',}, index, mode='newznab&newznab=Science Channel')
        add_posts({'title' : 'Seven',}, index, mode='newznab&newznab=Seven')
        add_posts({'title' : 'Showcase',}, index, mode='newznab&newznab=Showcase')
        add_posts({'title' : 'Showtime',}, index, mode='newznab&newznab=Showtime')
        add_posts({'title' : 'Sky Arts 1',}, index, mode='newznab&newznab=Sky Arts 1')
        add_posts({'title' : 'Sky Atlantic',}, index, mode='newznab&newznab=Sky Atlantic')
        add_posts({'title' : 'Sky Living',}, index, mode='newznab&newznab=Sky Living')
        add_posts({'title' : 'Sky1',}, index, mode='newznab&newznab=Sky1')
        add_posts({'title' : 'Slice',}, index, mode='newznab&newznab=Slice')
        add_posts({'title' : 'Smithsonian Channel',}, index, mode='newznab&newznab=Smithsonian Channel')
        add_posts({'title' : 'Southern Cross Ten',}, index, mode='newznab&newznab=Southern Cross Ten')
        add_posts({'title' : 'SPACE',}, index, mode='newznab&newznab=SPACE')
        add_posts({'title' : 'SPEED',}, index, mode='newznab&newznab=SPEED')
        add_posts({'title' : 'Speed Channel',}, index, mode='newznab&newznab=Speed Channel')
        add_posts({'title' : 'Spike TV',}, index, mode='newznab&newznab=Spike TV')
        add_posts({'title' : 'Starz',}, index, mode='newznab&newznab=Starz')
        add_posts({'title' : 'STV Scotland TV',}, index, mode='newznab&newznab=STV Scotland TV')
        add_posts({'title' : 'Style',}, index, mode='newznab&newznab=Style')
        add_posts({'title' : 'SUN TV',}, index, mode='newznab&newznab=SUN TV')
        add_posts({'title' : 'Sundance',}, index, mode='newznab&newznab=Sundance')
        add_posts({'title' : 'SVT1',}, index, mode='newznab&newznab=SVT1')
        add_posts({'title' : 'Syfy',}, index, mode='newznab&newznab=Syfy')
        add_posts({'title' : 'Syndicated',}, index, mode='newznab&newznab=Syndicated')
        add_posts({'title' : 'T E',}, index, mode='newznab&newznab=T E')
        add_posts({'title' : 'TBS',}, index, mode='newznab&newznab=TBS')
        add_posts({'title' : 'TeleToon',}, index, mode='newznab&newznab=TeleToon')
        add_posts({'title' : 'Ten',}, index, mode='newznab&newznab=Ten')
        add_posts({'title' : 'The 101',}, index, mode='newznab&newznab=The 101')
        add_posts({'title' : 'The Comedy Channel',}, index, mode='newznab&newznab=The Comedy Channel')
        add_posts({'title' : 'The Comedy Channel Australia',}, index, mode='newznab&newznab=The Comedy Channel Australia')
        add_posts({'title' : 'The Comedy Network',}, index, mode='newznab&newznab=The Comedy Network')
        add_posts({'title' : 'The CW',}, index, mode='newznab&newznab=The CW')
        add_posts({'title' : 'The Family Channel',}, index, mode='newznab&newznab=The Family Channel')
        add_posts({'title' : 'The History Channel AU',}, index, mode='newznab&newznab=The History Channel AU')
        add_posts({'title' : 'The Movie Network',}, index, mode='newznab&newznab=The Movie Network')
        add_posts({'title' : 'The Outdoor Channel',}, index, mode='newznab&newznab=The Outdoor Channel')
        add_posts({'title' : 'The Science Channel',}, index, mode='newznab&newznab=The Science Channel')
        add_posts({'title' : 'The WB',}, index, mode='newznab&newznab=The WB')
        add_posts({'title' : 'The Weather Channel',}, index, mode='newznab&newznab=The Weather Channel')
        add_posts({'title' : 'TLC',}, index, mode='newznab&newznab=TLC')
        add_posts({'title' : 'TNT',}, index, mode='newznab&newznab=TNT')
        add_posts({'title' : 'TNT Serie',}, index, mode='newznab&newznab=TNT Serie')
        add_posts({'title' : 'Tokyo MX',}, index, mode='newznab&newznab=Tokyo MX')
        add_posts({'title' : 'Travel Channel',}, index, mode='newznab&newznab=Travel Channel')
        add_posts({'title' : 'Treehouse',}, index, mode='newznab&newznab=Treehouse')
        add_posts({'title' : 'truTV',}, index, mode='newznab&newznab=truTV')
        add_posts({'title' : 'TV JOJ',}, index, mode='newznab&newznab=TV JOJ')
        add_posts({'title' : 'TV Kanagawa',}, index, mode='newznab&newznab=TV Kanagawa')
        add_posts({'title' : 'TV Land',}, index, mode='newznab&newznab=TV Land')
        add_posts({'title' : 'TV One',}, index, mode='newznab&newznab=TV One')
        add_posts({'title' : 'TV Tokyo',}, index, mode='newznab&newznab=TV Tokyo')
        add_posts({'title' : 'TV1',}, index, mode='newznab&newznab=TV1')
        add_posts({'title' : 'TV2',}, index, mode='newznab&newznab=TV2')
        add_posts({'title' : 'TV3',}, index, mode='newznab&newznab=TV3')
        add_posts({'title' : 'TV4',}, index, mode='newznab&newznab=TV4')
        add_posts({'title' : 'TV6',}, index, mode='newznab&newznab=TV6')
        add_posts({'title' : 'TVB',}, index, mode='newznab&newznab=TVB')
        add_posts({'title' : 'TVN',}, index, mode='newznab&newznab=TVN')
        add_posts({'title' : 'TVNorge',}, index, mode='newznab&newznab=TVNorge')
        add_posts({'title' : 'TVNZ',}, index, mode='newznab&newznab=TVNZ')
        add_posts({'title' : 'TVP 1',}, index, mode='newznab&newznab=TVP 1')
        add_posts({'title' : 'Unknown',}, index, mode='newznab&newznab=Unknown')
        add_posts({'title' : 'UPN',}, index, mode='newznab&newznab=UPN')
        add_posts({'title' : 'USA',}, index, mode='newznab&newznab=USA')
        add_posts({'title' : 'Velocity',}, index, mode='newznab&newznab=Velocity')
        add_posts({'title' : 'Veronica',}, index, mode='newznab&newznab=Veronica')
        add_posts({'title' : 'VH1',}, index, mode='newznab&newznab=VH1')
        add_posts({'title' : 'VH1 Classic',}, index, mode='newznab&newznab=VH1 Classic')
        add_posts({'title' : 'VODO',}, index, mode='newznab&newznab=VODO')
        add_posts({'title' : 'VPRO',}, index, mode='newznab&newznab=VPRO')
        add_posts({'title' : 'VTM',}, index, mode='newznab&newznab=VTM')
        add_posts({'title' : 'W',}, index, mode='newznab&newznab=W')
        add_posts({'title' : 'W Foxtel',}, index, mode='newznab&newznab=W Foxtel')
        add_posts({'title' : 'Warner Bros Japan',}, index, mode='newznab&newznab=Warner Bros Japan')
        add_posts({'title' : 'Watch',}, index, mode='newznab&newznab=Watch')
        add_posts({'title' : 'WE',}, index, mode='newznab&newznab=WE')
        add_posts({'title' : 'Weather Channel',}, index, mode='newznab&newznab=Weather Channel')
        add_posts({'title' : 'WGN America',}, index, mode='newznab&newznab=WGN America')
        add_posts({'title' : 'WOWOW',}, index, mode='newznab&newznab=WOWOW')
        add_posts({'title' : 'YES',}, index, mode='newznab&newznab=YES')
        add_posts({'title' : 'yes Comedy',}, index, mode='newznab&newznab=yes Comedy')
        add_posts({'title' : 'Youtube',}, index, mode='newznab&newznab=Youtube')
        add_posts({'title' : 'YTV',}, index, mode='newznab&newznab=YTV')
        add_posts({'title' : 'ZDF',}, index, mode='newznab&newznab=ZDF')
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=True)
    return

def list_feed_newznab(feedUrl, index):
    re_plot = __settings__.getSetting("newznab_re_plot_%s" % index)
    re_year = __settings__.getSetting("newznab_re_year_%s" % index)
    re_genre = __settings__.getSetting("newznab_re_genre_%s" % index)
    re_director = __settings__.getSetting("newznab_re_director_%s" % index)
    re_actors = __settings__.getSetting("newznab_re_actors_%s" % index)
    re_thumb = __settings__.getSetting("newznab_re_thumb_%s" % index).replace("SITE_URL", __settings__.getSetting("newznab_site_%s" % index))
    doc, state = load_xml(feedUrl)
    if doc and not state:
        if 't=-2' in feedUrl:
            mode = MODE_CART
        elif 't=search' in feedUrl:
            mode = MODE_SEARCH
            params = get_parameters(feedUrl)
            get = params.get
            search_url = urllib.quote_plus(feedUrl)
            # search_term url encoded in search(..) method
            search_term = get('q')
        elif 't=tvsearch' in feedUrl:
            mode = MODE_SEARCH_RAGEID
            params = get_parameters(feedUrl)
            get = params.get
            search_url = urllib.quote_plus(feedUrl)
        elif 't=movie' in feedUrl:
            mode = MODE_SEARCH_IMDB
        else:
            mode = MODE_PNEUMATIC_PLAY
        items = doc.getElementsByTagName("item")
        offset = len(items)
        for item in items:
            info_labels = dict()
            info_labels['title'] = get_node_value(item, "title")
            description = get_node_value(item, "description")
            plot = re.search(re_plot, description, re.IGNORECASE|re.DOTALL)
            if plot:
                info_labels['plot'] = plot.group(1)
            else:
                info_labels['plot'] = ''
            year = re.search(re_year, description, re.IGNORECASE|re.DOTALL)
            if year:
                info_labels['year'] = int(year.group(1))
            genre = re.search(re_genre, description, re.IGNORECASE|re.DOTALL)
            if genre:
                info_labels['genre'] = genre.group(1)
            director = re.search(re_director, description, re.IGNORECASE|re.DOTALL)
            if director:
                info_labels['director'] = director.group(1)
            actors = re.search(re_actors, description, re.IGNORECASE|re.DOTALL)
            if actors:
                info_labels['cast'] = actors.group(1).split(',')
            attribs = dict()
            for attr in item.getElementsByTagName("newznab:attr"):
                attribs[attr.getAttribute("name")] = attr.getAttribute("value")
            try:
                info_labels['size'] = int(attribs['size'])
            except:
                pass
            try:
                info_labels['rating'] = float(attribs['rating'])
            except:
                pass
            try:
                info_labels['imdb'] = attribs['imdb']
            except:
                pass
            else:
                info_labels['code'] = 'tt' + info_labels['imdb']
                # Append imdb id to the plot. Picked up by plugin.program.pneumatic
                text = info_labels['plot'] + " imdb:" + str(info_labels['code'])
                info_labels['plot'] = text
            try:
                info_labels['rageid'] = attribs['rageid']
            except:
                pass
            else:
                # Append rageid to the plot. Picked up by plugin.program.pneumatic
                text = info_labels['plot'] + " rage:" + str(info_labels['rageid'])
                info_labels['plot'] = text
            try:
                info_labels['tvdb-show'] = attribs['tvdb-show']
            except:
                pass
            else:
                text = info_labels['plot'] + " tvdb:" + str(info_labels['tvdb-show'])
                info_labels['plot'] = text
            regex = re.compile("([1-9]?\d$)")
            try:
                info_labels['season'] = int(regex.findall(attribs['season'])[0])
            except:
                pass
            try:
                info_labels['episode'] = int(regex.findall(attribs['episode'])[0])
            except:
                pass
            try:
                info_labels['tvshowtitle'] = attribs['tvtitle']
            except:
                pass
            try:
                info_labels['aired'] = attribs['tvairdate']
            except:
                pass
            try:
                info_labels['category'] = attribs['category']
            except:
                pass
            nzb = get_node_value(item, "link")
            thumb_re = re.search(re_thumb, description, re.IGNORECASE|re.DOTALL)
            if thumb_re:
                regex = re.compile(re_thumb,re.IGNORECASE)
                thumb = regex.findall(description)[0]
            else:
                thumb = ""
            is_hd = (False, True)[re.search("(720p|1080p)", info_labels['title'], re.IGNORECASE) is not None]
            if is_hd:
                info_labels['overlay'] = 8
            nzb = "&nzb=" + urllib.quote_plus(nzb) + "&nzbname=" + urllib.quote_plus(info_labels['title'])
            if mode == MODE_SEARCH:
                nzb = nzb + "&search_url=" + search_url + "&search_term=" + search_term
            if mode == MODE_SEARCH_RAGEID:
                nzb = nzb + "&search_url=" + search_url
            # Clear empty keys
            for key in info_labels.keys():
                if(info_labels[key] == -1):
                    del info_labels[key]
                try:
                    if (len(info_labels[key])<1):
                        del info_labels[key]
                except:
                    pass
            add_posts(info_labels, index, url=nzb, mode=mode, thumb=thumb)
        return offset
    else:
        if state == "site":
            xbmc.executebuiltin('Notification("Newznab","Site down")')
        else:
            xbmc.executebuiltin('Notification("Newznab","Malformed result")')
    return None

def add_posts(info_labels, index, **kwargs):
    url = ''
    if 'url' in kwargs:
        url = kwargs['url']
    mode = ''
    if 'mode' in kwargs:
        mode = kwargs['mode']
    thumb = ''
    if 'thumb' in kwargs:
        thumb = kwargs['thumb']
    folder = True
    if 'folder' in kwargs:
        folder = kwargs['folder']
    listitem=xbmcgui.ListItem(info_labels['title'], iconImage="DefaultVideo.png", thumbnailImage=thumb)
    fanart = thumb.replace('-cover','-backdrop')   
    listitem.setProperty("Fanart_Image", fanart)
    if mode == MODE_NEWZNAB:
        cm = []
        cm.append(cm_build("Hide", MODE_HIDE, url, index))
        listitem.addContextMenuItems(cm, replaceItems=True)
        xurl = "%s?mode=%s&index=%s" % (sys.argv[0], MODE_NEWZNAB, index)
    if mode == MODE_PNEUMATIC_PLAY or mode == MODE_CART or mode == MODE_SEARCH or\
       mode == MODE_SEARCH_RAGEID or mode == MODE_SEARCH_IMDB:
        mode_out = mode
        cm = []
        if (xbmcaddon.Addon(id='plugin.program.pneumatic').getSetting("auto_play").lower() == "true"):
            folder = False
        cm_url_download = PNEUMATIC + '?mode=' + MODE_PNEUMATIC_DOWNLOAD + url
        cm.append(("Download", "XBMC.RunPlugin(%s)" % (cm_url_download)))
        cm_url_strm = PNEUMATIC + '?mode=' + MODE_PNEUMATIC_SAVE_STRM + url
        cm.append(("Save to XBMC library", "XBMC.RunPlugin(%s)" % (cm_url_strm)))
        if mode == MODE_CART:
            cm.append(cm_build("Remove from cart", MODE_CART_DEL, url, index))
            mode_out = MODE_PNEUMATIC_PLAY
        else:
            cm_mode = MODE_CART_ADD
            cm.append(cm_build("Add to cart", MODE_CART_ADD, url, index))
        if mode == MODE_SEARCH:
            cm.append(cm_build("Add to search favorites", MODE_FAVORITE_ADD, url, index))
            mode_out = MODE_PNEUMATIC_PLAY
        if mode == MODE_SEARCH_RAGEID:
            cm.append(cm_build("Add to search favorites", MODE_FAVORITE_ADD, url, index))
            mode_out = MODE_PNEUMATIC_PLAY
        if 'rageid' in info_labels:
            if mode != MODE_SEARCH_RAGEID: 
                url_search_rage = '&rageid=' + info_labels['rageid']
                cm.append(("Search for this show", "XBMC.Container.Update(%s?mode=%s%s&index=%s)" %\
                          (sys.argv[0], MODE_NEWZNAB_SEARCH_RAGEID, url_search_rage, index)))
            if mode == MODE_SEARCH_RAGEID:
                url_search_rage = '&rageid=' + info_labels['rageid'] + "&catid=" + info_labels['category']
                cm.append(("Search for this quality", "XBMC.Container.Update(%s?mode=%s%s&index=%s)" %\
                          (sys.argv[0], MODE_NEWZNAB_SEARCH_RAGEID, url_search_rage, index)))
        if 'imdb' in info_labels: 
            url_search_imdb = '&imdb=' + info_labels['imdb']
            cm.append(("Search for this movie", "XBMC.Container.Update(%s?mode=%s%s&index=%s)" %\
                     (sys.argv[0], MODE_NEWZNAB_SEARCH_IMDB, url_search_imdb, index)))
        if mode == MODE_SEARCH_IMDB:
            mode_out = MODE_PNEUMATIC_PLAY
        listitem.addContextMenuItems(cm, replaceItems=True)
        xurl = "%s?mode=%s" % (PNEUMATIC,mode_out)
    elif mode == MODE_FAVORITES:
        cm = []
        cm.append(cm_build("Remove from search favorites", MODE_FAVORITE_DEL, url, index))
        listitem.addContextMenuItems(cm, replaceItems=True)
        xurl = "%s?mode=%s&index=%s" % (sys.argv[0], MODE_NEWZNAB, index)
    elif mode == MODE_PNEUMATIC_INCOMPLETE:
        xurl = "%s?mode=%s" % (PNEUMATIC,mode)
    elif mode == MODE_PNEUMATIC_LOCAL:
        xurl = "%s?mode=%s" % (PNEUMATIC,mode)
    else:
        xurl = "%s?mode=%s&index=%s" % (sys.argv[0], mode, index)
    xurl = xurl + url
    listitem.setInfo(type="Video", infoLabels=info_labels)
    listitem.setPath(xurl)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=xurl, listitem=listitem, isFolder=folder)

def cm_build(label, mode, url, index):
    command = "XBMC.RunPlugin(%s?mode=%s%s&index=%s)" % (sys.argv[0], mode, url, index)
    out = (label, command)
    return out

def hide_cat(index, params):
    get = params.get
    catid = get("catid")
    re_cat = '(\d)000'
    hide_cat = __settings__.getSetting("newznab_hide_cat_%s" % index)
    if re.search(re_cat, catid, re.IGNORECASE):
        regex = re.compile(re_cat,re.IGNORECASE)
        new_cat = regex.findall(catid)[0] + "\d\d\d"
        if hide_cat:
            new_cat = new_cat + "|" +  hide_cat
    else:
        new_cat = catid
        if hide_cat:
            new_cat = new_cat + "|" +  hide_cat
    __settings__.setSetting("newznab_hide_cat_%s" % index, new_cat)
    xbmc.executebuiltin("Container.Refresh")
    return

def cart_del(index, params):
    get = params.get
    nzb = get("nzb")
    re_id = 'nzb%2F(d*b*.*)\.nzb'
    regex = re.compile(re_id,re.IGNORECASE)
    id = regex.findall(nzb)[0]
    url = "http://" + __settings__.getSetting("newznab_site_%s" % index) +\
          "/api?t=cartdel&apikey=" + __settings__.getSetting("newznab_key_%s" % index) +\
          "&id=" + id
    xbmc.executebuiltin('Notification("Newznab","Removing from cart")')
    load_xml(url)
    xbmc.executebuiltin("Container.Refresh")
    return

def cart_add(index, params):
    get = params.get
    nzb = get("nzb")
    re_id = 'nzb%2F(d*b*.*)\.nzb'
    regex = re.compile(re_id,re.IGNORECASE)
    id = regex.findall(nzb)[0]
    url = "http://" + __settings__.getSetting("newznab_site_%s" % index) +\
          "/api?t=cartadd&apikey=" + __settings__.getSetting("newznab_key_%s" % index) +\
          "&id=" + id
    xbmc.executebuiltin('Notification("Newznab","Adding to cart")')
    load_xml(url)
    return

# FROM plugin.video.youtube.beta  -- converts the request url passed on by xbmc to our plugin into a dict  
def get_parameters(parameterString):
    commands = {}
    splitCommands = parameterString[parameterString.find('?')+1:].split('&')
    for command in splitCommands: 
        if (len(command) > 0):
            splitCommand = command.split('=')
            name = splitCommand[0]
            value = splitCommand[1]
            commands[name] = value
    return commands

def get_node_value(parent, name, ns=""):
    if ns:
        return parent.getElementsByTagNameNS(ns, name)[0].childNodes[0].data.encode('utf-8')
    else:
        return parent.getElementsByTagName(name)[0].childNodes[0].data.encode('utf-8')

def load_xml(url):
    return CACHE.fetch(url)

def search(dialog_name, index):
    searchString = unikeyboard(__settings__.getSetting( "latestSearch" ), ('Search ' +\
                   __settings__.getSetting("newznab_name_%s" % index)) )
    if searchString == "":
        xbmcgui.Dialog().ok('Newznab','Missing text')
    elif searchString:
        latestSearch = __settings__.setSetting( "latestSearch", searchString )
        #The XBMC onscreen keyboard outputs utf-8 and this need to be encoded to unicode
    encodedSearchString = urllib.quote_plus(searchString.decode("utf_8").encode("raw_unicode_escape"))
    return encodedSearchString

#From old undertexter.se plugin    
def unikeyboard(default, message):
    keyboard = xbmc.Keyboard(default, message)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        return keyboard.getText()
    else:
        return ""

def favorites(index):
    # http://wiki.python.org/moin/UsingPickle
    favorite_filename = "favorite_" + index + ".p"
    favorite = os.path.join(USERDATA_PATH, favorite_filename)
    try:
        favorite_dict = pickle.load( open( favorite, "rb" ) )
    except:
        return
    for key, value in favorite_dict.iteritems():
        info_labels = dict()
        info_labels['title'] = key
        url = "&url=" + value
        add_posts(info_labels, index, url=url, mode=MODE_FAVORITES)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=True)


def favorite_add(index, params):
    get = params.get
    search_term = get('search_term')
    search_url = get('search_url')
    nzbname = get('nzbname')
    if search_term is None and nzbname is not None:
        search_term = nzbname
    else:
        search_term = ''
    key = ''
    while len(key) < 1:
        key = unikeyboard(search_term, 'Favorite name')
    favorite_filename = "favorite_" + index + ".p"
    favorite = os.path.join(USERDATA_PATH, favorite_filename)
    try:
        favorite_dict = pickle.load( open( favorite, "rb" ) )
    except:
        favorite_dict = dict()
    favorite_dict[key] = search_url
    pickle.dump( favorite_dict, open( favorite, "wb" ) )
    return

def favorite_del(index):
    key = xbmc.getInfoLabel( "ListItem.Title" )
    favorite_filename = "favorite_" + index + ".p"
    favorite = os.path.join(USERDATA_PATH, favorite_filename)
    favorite_dict = pickle.load( open( favorite, "rb" ) )
    del favorite_dict[key]
    pickle.dump( favorite_dict, open( favorite, "wb" ) )
    xbmc.executebuiltin("Container.Refresh")
    return

def get_index_list():
    index_list = []
    for i in range(1, 6):
        if __settings__.getSetting("newznab_id_%s" % i):
            index_list.append(i)
    return index_list

def show_site_list(index_list):
    for index in index_list:
        add_posts({'title': __settings__.getSetting("newznab_name_%s" % index)}, index, mode=MODE_INDEX)
    add_posts({'title' : 'Browse local NZB\'s'}, 0, mode=MODE_PNEUMATIC_LOCAL)
    add_posts({'title' : 'Incomplete',}, 0, mode=MODE_PNEUMATIC_INCOMPLETE)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=True)
    return

if (__name__ == "__main__" ):
    if not (__settings__.getSetting("firstrun") and __settings__.getSetting("newznab_id_1")
        and __settings__.getSetting("newznab_key_1")):
        __settings__.openSettings()
        __settings__.setSetting("firstrun", '1')
    if (not sys.argv[2]):
        index_list = get_index_list()
        if len(index_list) == 1:
            newznab('1')
        elif len(index_list) >= 1:
            show_site_list(index_list)
        else:
            __settings__.openSettings()
    else:
        params = get_parameters(sys.argv[2])
        get = params.get
        if get("mode")== MODE_INDEX:
            newznab(get("index"))
        if get("mode")== MODE_NEWZNAB:
            newznab(get("index"), params)
        if get("mode")== MODE_HIDE:
            hide_cat(get("index"), params)
        if get("mode")== MODE_CART_DEL:
            cart_del(get("index"), params)
        if get("mode")== MODE_CART_ADD:
            cart_add(get("index"), params)
        if get("mode")== MODE_FAVORITES_TOP:
            favorites(get("index"))
        if get("mode")== MODE_FAVORITE_ADD:
            favorite_add(get("index"), params)
        if get("mode")== MODE_FAVORITE_DEL:
            favorite_del(get("index"))
