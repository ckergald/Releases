﻿namespace NZBTV_Tool
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tb_nn_api = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_maxage = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lb_channels = new System.Windows.Forms.ListBox();
            this.Shows = new System.Windows.Forms.GroupBox();
            this.lb_shows = new System.Windows.Forms.ListBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_offset = new System.Windows.Forms.TextBox();
            this.label_api = new System.Windows.Forms.Label();
            this.label_offset = new System.Windows.Forms.Label();
            this.label_info = new System.Windows.Forms.Label();
            this.tb_nn_url = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_info = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button5 = new System.Windows.Forms.Button();
            this.label_rage_score = new System.Windows.Forms.Label();
            this.label_match_score = new System.Windows.Forms.Label();
            this.label_count = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lb_rage = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lb_failed = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lb_master = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.Shows.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Newznab API Key";
            // 
            // tb_nn_api
            // 
            this.tb_nn_api.Location = new System.Drawing.Point(105, 9);
            this.tb_nn_api.Name = "tb_nn_api";
            this.tb_nn_api.Size = new System.Drawing.Size(166, 20);
            this.tb_nn_api.TabIndex = 1;
            this.tb_nn_api.TextChanged += new System.EventHandler(this.tb_nn_api_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Max age";
            // 
            // tb_maxage
            // 
            this.tb_maxage.Location = new System.Drawing.Point(60, 32);
            this.tb_maxage.Name = "tb_maxage";
            this.tb_maxage.Size = new System.Drawing.Size(64, 20);
            this.tb_maxage.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lb_channels);
            this.groupBox1.Location = new System.Drawing.Point(358, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(370, 160);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Channels";
            // 
            // lb_channels
            // 
            this.lb_channels.FormattingEnabled = true;
            this.lb_channels.Location = new System.Drawing.Point(6, 19);
            this.lb_channels.Name = "lb_channels";
            this.lb_channels.ScrollAlwaysVisible = true;
            this.lb_channels.Size = new System.Drawing.Size(358, 134);
            this.lb_channels.Sorted = true;
            this.lb_channels.TabIndex = 0;
            // 
            // Shows
            // 
            this.Shows.Controls.Add(this.lb_shows);
            this.Shows.Location = new System.Drawing.Point(358, 162);
            this.Shows.Name = "Shows";
            this.Shows.Size = new System.Drawing.Size(370, 152);
            this.Shows.TabIndex = 5;
            this.Shows.TabStop = false;
            this.Shows.Text = "Shows";
            // 
            // lb_shows
            // 
            this.lb_shows.FormattingEnabled = true;
            this.lb_shows.Location = new System.Drawing.Point(6, 19);
            this.lb_shows.Name = "lb_shows";
            this.lb_shows.ScrollAlwaysVisible = true;
            this.lb_shows.Size = new System.Drawing.Size(358, 121);
            this.lb_shows.Sorted = true;
            this.lb_shows.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(3, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(742, 368);
            this.tabControl1.TabIndex = 6;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.tb_offset);
            this.tabPage1.Controls.Add(this.label_api);
            this.tabPage1.Controls.Add(this.label_offset);
            this.tabPage1.Controls.Add(this.label_info);
            this.tabPage1.Controls.Add(this.tb_nn_url);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.tb_info);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.Shows);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.tb_nn_api);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.tb_maxage);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(734, 342);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Main";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(130, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Starting offset";
            // 
            // tb_offset
            // 
            this.tb_offset.Location = new System.Drawing.Point(206, 32);
            this.tb_offset.Name = "tb_offset";
            this.tb_offset.Size = new System.Drawing.Size(64, 20);
            this.tb_offset.TabIndex = 14;
            // 
            // label_api
            // 
            this.label_api.AutoSize = true;
            this.label_api.Location = new System.Drawing.Point(6, 317);
            this.label_api.Name = "label_api";
            this.label_api.Size = new System.Drawing.Size(35, 13);
            this.label_api.TabIndex = 12;
            this.label_api.Text = "label4";
            // 
            // label_offset
            // 
            this.label_offset.AutoSize = true;
            this.label_offset.Location = new System.Drawing.Point(236, 84);
            this.label_offset.Name = "label_offset";
            this.label_offset.Size = new System.Drawing.Size(35, 13);
            this.label_offset.TabIndex = 11;
            this.label_offset.Text = "label4";
            // 
            // label_info
            // 
            this.label_info.AutoSize = true;
            this.label_info.Location = new System.Drawing.Point(6, 84);
            this.label_info.Name = "label_info";
            this.label_info.Size = new System.Drawing.Size(35, 13);
            this.label_info.TabIndex = 10;
            this.label_info.Text = "label4";
            // 
            // tb_nn_url
            // 
            this.tb_nn_url.Location = new System.Drawing.Point(89, 58);
            this.tb_nn_url.Name = "tb_nn_url";
            this.tb_nn_url.Size = new System.Drawing.Size(182, 20);
            this.tb_nn_url.TabIndex = 9;
            this.tb_nn_url.TextChanged += new System.EventHandler(this.tb_nn_url_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Newznab URL";
            // 
            // tb_info
            // 
            this.tb_info.Location = new System.Drawing.Point(9, 109);
            this.tb_info.Multiline = true;
            this.tb_info.Name = "tb_info";
            this.tb_info.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tb_info.Size = new System.Drawing.Size(317, 205);
            this.tb_info.TabIndex = 7;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(277, 7);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Start Scan";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button5);
            this.tabPage2.Controls.Add(this.label_rage_score);
            this.tabPage2.Controls.Add(this.label_match_score);
            this.tabPage2.Controls.Add(this.label_count);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(734, 342);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Advanced";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(321, 289);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 9;
            this.button5.Text = "Force Save";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label_rage_score
            // 
            this.label_rage_score.AutoSize = true;
            this.label_rage_score.Location = new System.Drawing.Point(9, 326);
            this.label_rage_score.Name = "label_rage_score";
            this.label_rage_score.Size = new System.Drawing.Size(35, 13);
            this.label_rage_score.TabIndex = 8;
            this.label_rage_score.Text = "label4";
            // 
            // label_match_score
            // 
            this.label_match_score.AutoSize = true;
            this.label_match_score.Location = new System.Drawing.Point(415, 322);
            this.label_match_score.Name = "label_match_score";
            this.label_match_score.Size = new System.Drawing.Size(35, 13);
            this.label_match_score.TabIndex = 7;
            this.label_match_score.Text = "label4";
            // 
            // label_count
            // 
            this.label_count.AutoSize = true;
            this.label_count.Location = new System.Drawing.Point(308, 51);
            this.label_count.Name = "label_count";
            this.label_count.Size = new System.Drawing.Size(0, 13);
            this.label_count.TabIndex = 6;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(308, 191);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 5;
            this.button4.Text = "Add it";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(308, 136);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 4;
            this.button3.Text = "Look it up";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lb_rage);
            this.groupBox4.Location = new System.Drawing.Point(6, 172);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(296, 147);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "TV Rage lookup";
            // 
            // lb_rage
            // 
            this.lb_rage.FormattingEnabled = true;
            this.lb_rage.Location = new System.Drawing.Point(6, 19);
            this.lb_rage.Name = "lb_rage";
            this.lb_rage.Size = new System.Drawing.Size(284, 121);
            this.lb_rage.TabIndex = 0;
            this.lb_rage.SelectedIndexChanged += new System.EventHandler(this.lb_rage_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(308, 25);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Clear items";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lb_failed);
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(296, 160);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Failed to scan";
            // 
            // lb_failed
            // 
            this.lb_failed.FormattingEnabled = true;
            this.lb_failed.Location = new System.Drawing.Point(6, 19);
            this.lb_failed.Name = "lb_failed";
            this.lb_failed.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lb_failed.Size = new System.Drawing.Size(284, 134);
            this.lb_failed.Sorted = true;
            this.lb_failed.TabIndex = 0;
            this.lb_failed.SelectedIndexChanged += new System.EventHandler(this.lb_failed_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lb_master);
            this.groupBox2.Location = new System.Drawing.Point(412, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(319, 313);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Master List";
            // 
            // lb_master
            // 
            this.lb_master.FormattingEnabled = true;
            this.lb_master.Location = new System.Drawing.Point(6, 19);
            this.lb_master.Name = "lb_master";
            this.lb_master.ScrollAlwaysVisible = true;
            this.lb_master.Size = new System.Drawing.Size(307, 290);
            this.lb_master.Sorted = true;
            this.lb_master.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(751, 32);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(186, 337);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(949, 384);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "NZBTV";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.Shows.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_nn_api;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_maxage;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox lb_channels;
        private System.Windows.Forms.GroupBox Shows;
        private System.Windows.Forms.ListBox lb_shows;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox lb_master;
        private System.Windows.Forms.TextBox tb_info;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tb_nn_url;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label_info;
        private System.Windows.Forms.Label label_offset;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListBox lb_failed;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ListBox lb_rage;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label_count;
        private System.Windows.Forms.Label label_api;
        private System.Windows.Forms.Label label_match_score;
        private System.Windows.Forms.Label label_rage_score;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_offset;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

