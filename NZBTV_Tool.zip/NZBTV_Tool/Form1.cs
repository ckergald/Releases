﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Net;
using System.Xml;
using System.IO;
using System.Threading;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace NZBTV_Tool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            initialize();
        }
        private void initialize()
        {
            label_info.Text = "";
            label_offset.Text = "";
            label_api.Text = "API Hits ";
            label_match_score.Text = "";
            label_rage_score.Text = "";
            tb_nn_api.Text = Properties.Settings.Default.nn_api;
            tb_nn_url.Text = Properties.Settings.Default.nn_url;
            MessageBox.Show("This tool will scrub a newznab site for all TV releases\nAnd can use up thousands of API hits\nIf your newznab site restircts api useage use with care.");
            startup();
        }
        private void save_settings()
        {
            Properties.Settings.Default.nn_api = tb_nn_api.Text;
            Properties.Settings.Default.nn_url = tb_nn_url.Text;
            Properties.Settings.Default.Save();
        }

        private void tb_nn_api_TextChanged(object sender, EventArgs e)
        {
            save_settings();
        }
        private string clean_text(string text)
        {
            text = text.Replace('!', ' ');
            text = text.Replace("@", " at ");
            text = text.Replace("'s", "s");
            text = text.Replace('#', ' ');
            text = text.Replace('$', ' ');
            text = text.Replace('%', ' ');
            text = text.Replace('^', ' ');
            text = text.Replace("&", " and ");
            text = text.Replace('*', ' ');
            text = text.Replace('(', ' ');
            text = text.Replace(')', ' ');
            text = text.Replace(';', ' ');
            text = text.Replace(':', ' ');
            text = text.Replace('"', ' ');
            text = text.Replace("'", " ");
            text = text.Replace('/', ' ');
            text = text.Replace('|', ' ');
            text = text.Replace('[', ' ');
            text = text.Replace(']', ' ');
            text = text.Replace('{', ' ');
            text = text.Replace('}', ' ');
            text = text.Replace(@"\"," ");
            text = text.Replace(',', ' ');
            text = text.Replace('?', ' ');
            text = text.Replace('.', ' ');
            text = text.Replace('<', ' ');
            text = text.Replace('>', ' ');
            text = text.Replace('_', ' ');
            text = text.Replace('-', ' ');
            text = text.Replace('+', ' ');
            text = text.Replace('=', ' ');
            text = text.Replace('€', 'E');
            text = text.Replace('`', ' ');
            text = text.Replace('~', ' ');
            text = text.Replace('ƒ', 'f');
            text = text.Replace('„', ' ');
            text = text.Replace('‚', ' ');
            text = text.Replace('…', ' ');
            text = text.Replace('†', ' ');
            text = text.Replace('‡', ' ');
            text = text.Replace('ˆ', ' ');
            text = text.Replace('‰', ' ');
            text = text.Replace('Š', 'S');
            text = text.Replace('‹', ' ');
            text = text.Replace('Œ', ' ');
            text = text.Replace('Ž', 'Z');
            text = text.Replace('‘', ' ');
            text = text.Replace('’', ' ');
            text = text.Replace('“', ' ');
            text = text.Replace('”', ' ');
            text = text.Replace('•', ' ');
            text = text.Replace('–', ' ');
            text = text.Replace('—', ' ');
            text = text.Replace('˜', ' ');
            text = text.Replace('™', ' ');
            text = text.Replace('š', 's');
            text = text.Replace('›', ' ');
            text = text.Replace('œ', ' ');
            text = text.Replace('ž', 'z');
            text = text.Replace('Ÿ', 'Y');
            text = text.Replace('¡', 'i');
            text = text.Replace('¢', 'c');
            text = text.Replace('£', ' ');
            text = text.Replace('¤', ' ');
            text = text.Replace('¥', 'Y');
            text = text.Replace('¦', ' ');
            text = text.Replace('§', ' ');
            text = text.Replace('¨', ' ');
            text = text.Replace('©', 'c');
            text = text.Replace('ª', 'a');
            text = text.Replace('«', ' ');
            text = text.Replace('¬', ' ');
            text = text.Replace('®', ' ');
            text = text.Replace('¯', ' ');
            text = text.Replace('°', ' ');
            text = text.Replace('±', ' ');
            text = text.Replace('²', ' ');
            text = text.Replace('³', ' ');
            text = text.Replace('´', ' ');
            text = text.Replace('µ', 'u');
            text = text.Replace('¶', ' ');
            text = text.Replace('·', ' ');
            text = text.Replace('¸', ' ');
            text = text.Replace('¹', ' ');
            text = text.Replace('º', ' ');
            text = text.Replace('»', ' ');
            text = text.Replace('¼', ' ');
            text = text.Replace('½', ' ');
            text = text.Replace('¾', ' ');
            text = text.Replace('˜', ' ');
            text = text.Replace('¿', ' ');
            text = text.Replace('À', 'A');
            text = text.Replace('Á', 'A');
            text = text.Replace('Â', 'A');
            text = text.Replace('Ã', 'A');
            text = text.Replace('Ä', 'A');
            text = text.Replace('Å', 'A');
            text = text.Replace('Æ', 'A');
            text = text.Replace('Ç', 'C');
            text = text.Replace('È', 'E');
            text = text.Replace('É', 'E');
            text = text.Replace('Ê', 'E');
            text = text.Replace('Ë', 'E');
            text = text.Replace('Ì', 'I');
            text = text.Replace('Í', 'I');
            text = text.Replace('Î', 'I');
            text = text.Replace('Î', 'I');
            text = text.Replace('Ð', 'D');
            text = text.Replace('Ñ', 'N');
            text = text.Replace('Ò', 'O');
            text = text.Replace('Ó', 'O');
            text = text.Replace('Ô', 'O');
            text = text.Replace('Õ', 'O');
            text = text.Replace('Ö', 'O');
            text = text.Replace('×', 'x');
            text = text.Replace('Ø', 'O');
            text = text.Replace('Ù', 'U');
            text = text.Replace('Ú', 'U');
            text = text.Replace('Û', 'U');
            text = text.Replace('Ü', 'U');
            text = text.Replace('Ý', 'Y');
            text = text.Replace('Þ', 'b');
            text = text.Replace('ß', 'B');
            text = text.Replace('à', 'a');
            text = text.Replace('á', 'a');
            text = text.Replace('â', 'a');
            text = text.Replace('ã', 'a');
            text = text.Replace('ä', 'a');
            text = text.Replace('å', 'a');
            text = text.Replace('æ', 'a');
            text = text.Replace('ç', 'c');
            text = text.Replace('è', 'e');
            text = text.Replace('é', 'e');
            text = text.Replace('ê', 'e');
            text = text.Replace('ë', 'e');
            text = text.Replace('ì', 'i');
            text = text.Replace('í', 'i');
            text = text.Replace('î', 'i');
            text = text.Replace('ï', 'i');
            text = text.Replace('ð', ' ');
            text = text.Replace('ñ', 'n');
            text = text.Replace('ò', 'o');
            text = text.Replace('ó', 'o');
            text = text.Replace('ô', 'o');
            text = text.Replace('õ', 'o');
            text = text.Replace('ö', 'o');
            text = text.Replace('÷', ' ');
            text = text.Replace('ø', '0');
            text = text.Replace('ù', 'u');
            text = text.Replace('ú', 'u');
            text = text.Replace('û', 'u');
            text = text.Replace('ü', 'u');
            text = text.Replace('ý', 'y');
            text = text.Replace('þ', 'b');
            text = text.Replace('ÿ', 'y');
            text = text.Replace("        ", " ");
            text = text.Replace("       ", " ");
            text = text.Replace("      ", " ");
            text = text.Replace("     ", " ");
            text = text.Replace("    ", " ");
            text = text.Replace("   ", " ");
            text = text.Replace("  ", " ");
            text = text.Trim();
            return text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            int offset = 0;
            if (tb_offset.Text != "")
            {
                try
                {
                    offset = int.Parse(tb_offset.Text);
                }
                catch
                {
                    MessageBox.Show("Could not read starting offset value, ensure it's only numbers");
                    button1.Enabled = true;
                    return;
                }
            }
            int apihits = 1;
            string maxage = tb_maxage.Text.Trim();
            string api = tb_nn_api.Text.Trim();
            string url = tb_nn_url.Text.Trim();
            bool not_finished = true;
            while (not_finished)
            {
                label_api.Text = "API Hits " + apihits.ToString();
                apihits = apihits + 1;
                update_info("Scanning at offset " + offset.ToString(), true);
                label_offset.Text = "Offset : " + offset.ToString();
                XmlDocument xdoc = scan_nn(offset.ToString(), maxage, api, url);
                bool temp = count_results(xdoc);
                if (temp) { offset = offset + 100; }
                XmlNodeList nl = xdoc.SelectNodes("/rss/channel/item");
                foreach (XmlNode node in nl)
                {
                    update_info("Working on " + node["title"].InnerText.ToString(), false);
                    if (check_if_show_already_exists(releaseregex(node["title"].InnerText)))
                    {
                        update_info(releaseregex(node["title"].InnerText.ToString()) + "Already exists in our list, Skipping", false);
                    }
                    else if (check_if_ignored(releaseregex(node["title"].InnerText.ToString())))
                    {
                        
                    }
                    else
                    {
                        string[] showinfo = check_tv_rage(releaseregex(node["title"].InnerText));
                        if ((showinfo[0] != "") && (showinfo[1] != "") && (showinfo[2] != ""))
                        {
                            bool addit = true;
                            for (int i = 0; i < lb_shows.Items.Count; i++)
                            {
                                if (showinfo[0].ToUpper() == lb_shows.Items[i].ToString().ToUpper()) { addit = false; }
                            }
                            if (addit) { lb_shows.Items.Add(showinfo[0]); }
                            addit = true;
                            for (int i = 0; i < lb_channels.Items.Count; i++)
                            {
                                if (showinfo[2].ToUpper() == lb_channels.Items[i].ToString().ToUpper()) { addit = false; }
                            }
                            if (addit) { lb_channels.Items.Add(showinfo[2]); }
                            string tempval = showinfo[0] + "#" + showinfo[1] + "#" + showinfo[2];
                            if (showinfo[3] != "") { tempval = tempval + "#" + showinfo[3]; }
                            addit = true;
                            for (int i = 0; i < lb_master.Items.Count; i++)
                            {
                                if (tempval.ToUpper() == lb_master.Items[i].ToString().ToUpper()) { addit = false; }
                            }
                            if (addit) { lb_master.Items.Add(tempval); }
                            lb_master.Refresh();
                            lb_shows.Refresh();
                            lb_channels.Refresh();
                            Application.DoEvents();
                        }
                    }
                }
                not_finished = temp;
                save_progress();
            }
            button1.Enabled = true;
            MessageBox.Show("Finished");
        }

        private XmlDocument scan_nn(string offset, string max_age,string api, string url)
        {
            string nnurl = url + "/api?t=search&apikey=" + api + "&extended=1&maxage=" + max_age + "&offset=" + offset + "&cat=5030,5040";
            bool retry = true;
            string temp = "";
            int counter = 0;
            while (retry)
            {
                try
                {
                    WebClient wc = new WebClient();
                    temp = wc.DownloadString(nnurl);
                    retry = false;
                }
                catch
                {
                    if (counter > 5) { retry = false; }
                    else
                    {
                        counter = counter + 1;
                        Thread.Sleep(5000);
                    }
                }
            }
            XmlDocument xdoc = new XmlDocument();
            xdoc.LoadXml(temp);
            return xdoc;
        }
        private void update_info(string info,Boolean overwrite)
        {
            if (overwrite)
            {
                tb_info.Text = info;
            }
            else
            {
                tb_info.Text = tb_info.Text + "\r\n" + info;
            }
            tb_info.Refresh();
            label_info.Text = lb_channels.Items.Count.ToString() + " channels | " + lb_shows.Items.Count.ToString() + " Shows";
            Application.DoEvents();
           
        }

        private void tb_nn_url_TextChanged(object sender, EventArgs e)
        {
            save_settings();
        }
        private bool count_results(XmlDocument xdoc)
        {
            XmlNodeList nl = xdoc.SelectNodes("/rss/channel/item");
            string temp = nl.Count.ToString() + " items found";
            if (nl.Count < 100) { return false; }
            return true;
        }
        private string[] check_tv_rage(string showname)
        {
            string originalshowname = showname;
            showname = showname.Trim();
            if (showname != "")
            {
                update_info("working on " + showname , false);
            }
            string rageid = "";
            string channel = "";
            WebClient wc = new WebClient();
            bool retry = true;
            int counter = 0;
            string results = "";
            while (retry)
            {
                try
                {
                    results = wc.DownloadString("http://services.tvrage.com/feeds/full_search.php?show=" +Uri.EscapeUriString(showname));
                    retry = false;
                }
                catch
                {
                    if (counter < 5)
                    {
                        counter = counter + 1;
                    }
                    else
                    {
                        retry = false;
                        string[] temp = new string[4];
                        temp[0] = "";
                        temp[1] = "";
                        temp[2] = "";
                        temp[3] = "";
                        add_failed(clean_text(showname));
                        return temp;
                    }
                }
            }
            XmlDocument xdoc = new XmlDocument();
            xdoc.LoadXml(results);
            XmlNodeList nl = xdoc.SelectNodes("/Results/show");
            if (nl.Count > 0)
            {
                //update_info("Found " + nl.Count.ToString() + " items at tvrage",false);
                foreach (XmlNode node in nl)
                {
                    string title = clean_text(node["name"].InnerText.ToString());
                    string compare = clean_text(showname);
                    int d = score_differences(compare.ToUpper(), title.ToUpper());
                    decimal score = 0;
                    if (d != 0)
                    {
                        score = (decimal)compare.Length / (decimal)d;
                        score = decimal.Round(score, 2, MidpointRounding.AwayFromZero);
                    }
                    else
                    {
                        score = 100;
                        update_info("Found a match for " + showname + " " + score.ToString() + "% match", false);
                        rageid = clean_text(node["showid"].InnerText);
                        originalshowname = node["name"].InnerText.ToString();
                        try
                        {
                            channel = clean_text(node["network"].InnerText);
                        }
                        catch { channel = "syndicated"; }
                        showname = clean_text(showname);
                        break;
                    }
                    score = score * 10;
                    //MessageBox.Show("source " + compare + "\ntarget " + title + "\ndistance " + d.ToString() + "\nScore " + score.ToString() + "\nsource length " + compare.Length.ToString());
                    if (score > 85)
                    {
                        update_info("Found a match for " + showname + " " + score.ToString() + "% match", false);
                        rageid = clean_text(node["showid"].InnerText);
                        originalshowname = node["name"].InnerText.ToString();
                        try
                        {
                            channel = clean_text(node["network"].InnerText);
                        }
                        catch { channel = "syndicated"; }
                        showname = clean_text(showname);
                    }
                    else
                    {
                        update_info("No Match " + showname + " : " + title + " " + score.ToString() + "% match", false);
                    }
                }
            }
            string[] returnval = new string[4];
            returnval[0] = showname;
            returnval[1] = rageid;
            returnval[2] = channel;
            returnval[3] = "";
            if (rageid == "")
            {
                bool failed = true;
                for (int i = 0; i < lb_failed.Items.Count; i++)
                {
                    int d = score_differences(clean_text(showname.ToUpper()),clean_text(lb_failed.Items[i].ToString().ToUpper()));
                    if (d < 1)
                    {
                        failed = false;
                    }
                }
                for (int i = 0; i < lb_shows.Items.Count; i++)
                {
                    int d = score_differences(clean_text(showname.ToUpper()), clean_text(lb_shows.Items[i].ToString().ToUpper()));
                    if (d < 2)
                    {
                        failed = false;
                    }
                }
                if (showname.Trim() == "") { failed = false; }
                if (failed) { lb_failed.Items.Add(showname); }
            }
            string tvdb = "";
            tvdb = tvdb_lookup(originalshowname);
            if (tvdb != "") { returnval[3] = tvdb; }
            return returnval;
            
        }
        private string releaseregex(string title)
        {
            string Standard = @"^((?<series_name>.+?)[. _-]+)?s(?<season_num>\d+)[. _-]*e(?<ep_num>\d+)(([. _-]*e|-)(?<extra_ep_num>(?!(1080|720)[pi])\d+))*[. _-]*((?<extra_info>.+?)((?<![. _-])-(?<release_group>[^-]+))?)?$";
            var regexStandard = new Regex(Standard, RegexOptions.IgnoreCase);
            Match episode = regexStandard.Match(title);
            var Showname = episode.Groups["series_name"].Value;
            var Season = episode.Groups["season_num"].Value;
            var Episode = episode.Groups["ep_num"].Value;
            Showname = Showname.Replace('.', ' ');
            Showname = Showname.Trim();
            if (Showname.ToString() != "")
                {
                    Showname = clean_text(Showname);
                }
            return Showname;
        }
        private bool check_if_show_already_exists(string showname)
        {
            bool returnval = false;
            for (int i = 0; i < lb_shows.Items.Count; i++)
            {
                if (clean_text(showname.ToUpper()) == lb_shows.Items[i].ToString().ToUpper())
                {
                    returnval = true;
                    break;
                }
            }
            for (int i = 0; i < lb_failed.Items.Count; i++)
            {
                if (clean_text(showname.ToUpper()) == lb_failed.Items[i].ToString().ToUpper())
                {
                    returnval = true;
                    break;
                }
            }
            return returnval;
        }
        private void save_progress()
        {
            TextWriter tw = new StreamWriter("networks.txt");
            for (int i = 0; i < lb_channels.Items.Count; i++)
            {
                tw.WriteLine(@"        add_posts({'title' : '" + lb_channels.Items[i].ToString() + "',}, index, mode='newznab&newznab=" + lb_channels.Items[i].ToString() + "')");
            }
            tw.Close();
            TextWriter tw2 = new StreamWriter("shows.txt");
            TextWriter tw3 = new StreamWriter("rage.txt");
            string[,] shows = new string[lb_master.Items.Count, 4];
            for (int i = 0; i < lb_master.Items.Count; i++)
            {
                string[] showinfo = lb_master.Items[i].ToString().Split('#');
                shows[i, 0] = showinfo[0];
                shows[i, 1] = showinfo[1];
                if (showinfo[2].Length < 1) { showinfo[2] = "Unknown"; }
                shows[i, 2] = showinfo[2];
                try
                {
                    shows[i, 3] = showinfo[3];
                }
                catch
                {
                    shows[i, 3] = "";
                }
            }
            for (int i = 0; i < lb_channels.Items.Count; i++)
            {
                string current_network = lb_channels.Items[i].ToString();
                tw2.WriteLine(@"            if newznab_id == '" + lb_channels.Items[i].ToString() + "':");
                for (int x = 0; x < lb_master.Items.Count; x++)
                {
                    if (shows[x, 2] == current_network)
                    {
                        if (shows[x, 3] == "")
                        {
                            tw2.WriteLine(@"                add_posts({'title' : '" + shows[x, 0] + "',}, index, mode='newznab&newznab=" + shows[x, 1] + "')");
                        }
                        else
                        {
                            tw2.WriteLine(@"                add_posts({'title' : '" + shows[x, 0] + "',}, index, mode='newznab&newznab=" + shows[x, 1] + "',thumb='" + shows[x,3] + "')");
                        }
                        tw3.WriteLine(@"            if newznab_id == '" + shows[x, 1] + "':");
                        tw3.WriteLine(@"                url_out = (newznab_url_search + '&t=tvsearch&rid=" + shows[x, 1] + "&extended=1')");

                    }
                }
            }
            tw2.Close();
            tw3.Close();
            TextReader tr = new StreamReader("template.txt");
            TextWriter py = new StreamWriter("default.py");
            string line = "";
            string line2 = "";
            while ((line = tr.ReadLine()) != null)
            {
                if (line.Contains("*INSERT SHOWS*"))
                {
                    TextReader showsfile = new StreamReader("shows.txt");
                    while ((line2 = showsfile.ReadLine()) != null)
                    {
                        py.WriteLine(line2);
                    }
                    showsfile.Close();
                }
                else if (line.Contains("*INSERT RAGE*"))
                {
                    TextReader ragefile = new StreamReader("rage.txt");
                    while ((line2 = ragefile.ReadLine()) != null)
                    {
                        py.WriteLine(line2);
                    }
                    ragefile.Close();
                }
                else if (line.Contains("*INSERT NETWORKS*"))
                {
                    TextReader networksfile = new StreamReader("networks.txt");
                    while ((line2 = networksfile.ReadLine()) != null)
                    {
                        py.WriteLine(line2);
                    }
                    networksfile.Close();
                }
                else { py.WriteLine(line); }
            }
            py.Close();
            tr.Close();
            TextWriter master = new StreamWriter("masterlist.txt");
            for (int i = 0; i < lb_master.Items.Count; i++)
            {
                master.WriteLine(lb_master.Items[i].ToString());
            }
            master.Close();
            TextWriter offset = new StreamWriter("offset.txt");
            offset.WriteLine(label_offset.Text);
            offset.Close();
            TextWriter failed_items = new StreamWriter("failed.txt");
            for (int i = 0; i < lb_failed.Items.Count; i++)
            {
                failed_items.WriteLine(lb_failed.Items[i].ToString());
            }
            failed_items.Close();
        }
        private void startup()
        {
            if (File.Exists("masterlist.txt"))
            {
                TextReader tr = new StreamReader("masterlist.txt");
                string line = "";
                while ((line = tr.ReadLine()) != null)
                {
                    string[] temp = line.Split('#');
                    add_master(line);
                    add_channel(temp[2]);
                    add_show(temp[0]);
                }
                tr.Close();
                label_info.Text = lb_channels.Items.Count.ToString() + " channels | " + lb_shows.Items.Count.ToString() + " Shows";
            }
            if (File.Exists("failed.txt"))
            {
                TextReader fail = new StreamReader("failed.txt");
                string line = "";
                while ((line = fail.ReadLine()) != null)
                {
                    add_failed(line);
                }
                fail.Close();
                label_info.Text = lb_channels.Items.Count.ToString() + " channels | " + lb_shows.Items.Count.ToString() + " Shows";
            }
        }
        private void add_master(string entry)
        {
            bool addit = true;
            for (int i = 0; i < lb_master.Items.Count; i++)
            {
                if (lb_master.Items[i].ToString().ToUpper() == entry.ToUpper()) { addit = false; }
            }
            if (addit) { lb_master.Items.Add(entry); }
        }
        private void add_channel(string entry)
        {
            bool addit = true;
            for (int i = 0; i < lb_channels.Items.Count; i++)
            {
                if (lb_channels.Items[i].ToString().ToUpper() == entry.ToUpper()) { addit = false; }
            }
            if (addit) { lb_channels.Items.Add(entry); }
        }
        private void add_show(string entry)
        {
            bool addit = true;
            for (int i = 0; i < lb_shows.Items.Count; i++)
            {
                if (lb_shows.Items[i].ToString().ToUpper() == entry.ToUpper()) { addit = false; }
            }
            if (addit) { lb_shows.Items.Add(entry); }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = lb_failed.SelectedIndices.Count - 1; i >= 0; i--)
            {
                lb_failed.Items.RemoveAt(lb_failed.SelectedIndices[i]);
            }
            lb_rage.Items.Clear();
            label_rage_score.Text = "";
            label_match_score.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            lb_rage.Items.Clear();
            label_count.Text = lb_failed.Items.Count.ToString() + " failed items";
            if (lb_failed.SelectedIndices.Count > 1) { MessageBox.Show("Can only lookup 1 show at a time. Select only 1"); }
            WebClient wc = new WebClient();
            bool retry = true;
            int counter = 0;
            string temp = "";
            while (retry)
            {
                try
                {
                    temp = wc.DownloadString("http://services.tvrage.com/feeds/full_search.php?show=" + Uri.EscapeUriString(lb_failed.SelectedItem.ToString()));
                    retry = false;
                }
                catch
                {
                    if (counter < 5)
                    {
                        //update_info("Failed to lookup on tvrage retrying up to 5 times", false);
                        counter = counter + 1;
                    }
                    else
                    {
                        retry = false;
                    }
                }
            }
            XmlDocument xdoc = new XmlDocument();
            xdoc.LoadXml(temp);
            XmlNodeList nl = xdoc.SelectNodes("/Results/show");
            foreach (XmlNode node in nl)
            {
                string show = clean_text(node["name"].InnerText.ToString());
                string rage = clean_text(node["showid"].InnerText.ToString());
                string channel = clean_text(node["network"].InnerText.ToString());
                string entry = show + "#" + rage + "#" + channel;
                lb_rage.Items.Add(entry);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (lb_rage.SelectedIndex < 0) { return; }
            string[] temp = lb_rage.Items[lb_rage.SelectedIndex].ToString().Split('#');
            add_master(lb_rage.Items[lb_rage.SelectedIndex].ToString());
            add_show(temp[0]);
            add_channel(temp[2]);
            save_progress();
            lb_rage.Items.Clear();
            lb_failed.Items.RemoveAt(lb_failed.SelectedIndex);
            label_count.Text = lb_failed.Items.Count.ToString() + " failed items";
            label_rage_score.Text = "";
            label_match_score.Text = "";
        }

        private void lb_rage_SelectedIndexChanged(object sender, EventArgs e)
        {
            label_rage_score.Text = "";
            string[] temp = lb_rage.Items[lb_rage.SelectedIndex].ToString().Split('#');
            int score = score_differences(temp[0].ToUpper(), lb_failed.Items[lb_failed.SelectedIndex].ToString().ToUpper());
            decimal score1 = (decimal)lb_failed.Items[lb_failed.SelectedIndex].ToString().Length / (decimal)score;
            score1 = decimal.Round(score1, 2, MidpointRounding.AwayFromZero);
            if (score1 > 85)
            {
                add_master(lb_rage.Items[lb_rage.SelectedIndex].ToString());
                add_show(temp[0]);
                add_channel(temp[2]);
                save_progress();
                lb_rage.Items.Clear();
                lb_failed.Items.RemoveAt(lb_failed.SelectedIndex);
                label_rage_score.Text = "";
            }
            else
            {
                label_rage_score.Text = score1.ToString() + "% match";
            }
            for (int i = 0; i < lb_master.Items.Count; i++)
            {
                int score2 = score_differences(lb_rage.Items[lb_rage.SelectedIndex].ToString().ToUpper(), lb_master.Items[i].ToString().ToUpper());
                if (score2 == 0)
                {
                    label_match_score.Text = "100% match";
                    label_rage_score.Text = "100% match";
                    Thread.Sleep(1000);
                    lb_failed.Items.RemoveAt(lb_failed.SelectedIndex);
                    lb_rage.Items.Clear();
                    return;
                }
            }
        }

        private void lb_failed_SelectedIndexChanged(object sender, EventArgs e)
        {
            lb_rage.Items.Clear();
            label_count.Text = lb_failed.Items.Count.ToString() + " failed items";
            if (lb_failed.SelectedIndices.Count == 1)
            {
                int[] compares = new int[lb_master.Items.Count];
                for (int i = 0; i < lb_master.Items.Count; i++)
                {
                    string[] temp = lb_master.Items[i].ToString().Split('#');
                    compares[i] = score_differences(lb_failed.Items[lb_failed.SelectedIndex].ToString().ToUpper(), temp[0].ToUpper());
                }
                int tempval = 99;
                int index = 0;
                for (int i = 0; i < lb_master.Items.Count; i++)
                {
                    if (compares[i] < tempval) { tempval = compares[i]; index = i; }
                }
                lb_master.SelectedIndex = index;
                decimal score1 = (decimal)lb_failed.Items[lb_failed.SelectedIndex].ToString().Length / (decimal)tempval;
                score1 = decimal.Round(score1, 2, MidpointRounding.AwayFromZero);
                label_match_score.Text = score1.ToString() + "% match";
                if (score1 < 75)
                {
                    lb_rage.Items.Clear();
                    label_count.Text = lb_failed.Items.Count.ToString() + " failed items";
                    WebClient wc = new WebClient();
                    bool retry = true;
                    int counter = 0;
                    string temp = "";
                    while (retry)
                    {
                        try
                        {
                            temp = wc.DownloadString("http://services.tvrage.com/feeds/full_search.php?show=" + Uri.EscapeUriString(lb_failed.SelectedItem.ToString()));
                            retry = false;
                        }
                        catch
                        {
                            if (counter < 5)
                            {
                                counter = counter + 1;
                            }
                            else
                            {
                                retry = false;
                            }
                        }
                    }
                    XmlDocument xdoc = new XmlDocument();
                    xdoc.LoadXml(temp);
                    XmlNodeList nl = xdoc.SelectNodes("/Results/show");
                    foreach (XmlNode node in nl)
                    {
                        string show = clean_text(node["name"].InnerText.ToString());
                        string rage = clean_text(node["showid"].InnerText.ToString());
                        string channel = clean_text(node["network"].InnerText.ToString());
                        string entry = show + "#" + rage + "#" + channel;
                        lb_rage.Items.Add(entry);
                    }
                }
            }

        }

        private int score_differences(string s, string t)
        {
            int n = s.Length;
            int m = t.Length;
            int[,] d = new int[n + 1, m + 1];
            int cost;
            if (n == 0) { return m; }
            if (m == 0) { return n; }
            for (int i = 0; i <= n; d[i, 0] = i++) ;
            for (int j = 0; j <= m; d[0, j] = j++) ;
            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= m; j++)
                {
                    cost = (t.Substring(j - 1, 1) == s.Substring(i - 1, 1) ? 0 : 1);
                    d[i, j] = System.Math.Min(System.Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1),
                              d[i - 1, j - 1] + cost);
                }
            }
            return d[n, m];
        }
        private bool check_if_ignored(string showname)
        {
            bool returnval = false;
            showname = clean_text(showname);
            showname = showname.ToUpper();
            string[] ignored = { "AUTORARPAR" };
            foreach (string compare in ignored)
            {
                if (showname.Contains(compare)) { returnval = true; }
            }
            return returnval;
        }
        private void add_failed(string showname)
        {
            bool addit = true;
            for (int i = 0; i < lb_failed.Items.Count; i++)
            {
                int score = score_differences(showname.ToUpper(), lb_failed.Items[i].ToString().ToUpper());
                if (score < 1) { addit = false; }
            }
            if (addit) { lb_failed.Items.Add(showname); }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            save_progress();
            save_settings();
            MessageBox.Show("Saved");
        }
        private string tvdb_lookup(string showname)
        {
            string returnvalue = "";
            string id = "";
            XmlDocument xdoc = new XmlDocument();
            WebClient wc = new WebClient();
            string page = "";
            try
            {
                page = wc.DownloadString("http://www.thetvdb.com/api/GetSeries.php?seriesname=" + Uri.EscapeUriString(showname));
            }
            catch
            {
                return returnvalue;
            }
            try
            {
                xdoc.LoadXml(page);
                XmlNodeList nl = xdoc.SelectNodes("/Data/Series");
                foreach (XmlNode node in nl)
                {
                    int score = score_differences(clean_text(showname.ToUpper()),clean_text(node["SeriesName"].InnerText.ToString().ToUpper()));
                    if (score < 2)
                    {
                        id = node["seriesid"].InnerText.ToString();
                    }
                }
            }
            catch
            {
                return returnvalue;
            }
            if (id != "")
            {
                try
                {
                    WebClient wc1 = new WebClient();
                    string url = "http://thetvdb.com/banners/posters/" + id + "-1.jpg";
                    pictureBox1.ImageLocation = url;
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    pictureBox1.Visible = true;
                    pictureBox1.Refresh();
                    Application.DoEvents();
                    Thread.Sleep(1000);
                    returnvalue = url;
                }
                catch
                {
                    return returnvalue;
                }
            }
            return returnvalue;
        }
    }
}
